import sys; sys.path.insert(0,'test')
from harness import app
with app(width=360,height=740) as (page,base):
    page.goto(base); page.wait_for_timeout(700)
    print('chapterRead fn',page.evaluate("typeof Lectio.chapterRead"))
    page.evaluate("Lectio.go('plans')"); page.wait_for_timeout(300)
    # custom: Gospels only, 3 chapters a day
    page.click('[data-new=custom]'); page.wait_for_timeout(300)
    page.click('[data-q="3"]'); page.click('[data-mode=per]'); page.fill('#plNum','3'); page.wait_for_timeout(200)
    print('summary:',page.inner_text('#plSum'))
    page.fill('#plN','Gospels my pace'); page.click('.umodal button.main'); page.wait_for_timeout(400)
    print(page.inner_text('#v-plans .plch').replace('\n',' '), '| rows', page.eval_on_selector_all('#v-plans .plch','e=>e.length'))
    # mark Matthew 1 in app -> auto tick
    page.evaluate("Lectio.openReader(39,1)"); page.wait_for_timeout(600)
    page.click('#rMark'); page.wait_for_timeout(300)
    page.evaluate("Lectio.go('plans')"); page.wait_for_timeout(300); page.click('[data-open]'); page.wait_for_timeout(300)
    print('after marking Matt 1 in app, ticked:',page.eval_on_selector_all('#v-plans .plch .p-circ','e=>e.map(x=>x.getAttribute("aria-pressed"))'))
    # new preset with skip read & past start
    page.click('[data-back]'); page.wait_for_timeout(200)
    page.click('[data-new="2"]'); page.wait_for_timeout(300)
    print('gospels preset summary (skip read):',page.inner_text('#plSum'))
    page.evaluate("Lectio.ui.handleBack()"); page.wait_for_timeout(200)
    page.click('[data-open]'); page.wait_for_timeout(200)
    page.click('[data-stop]'); page.wait_for_timeout(200); page.click('.umodal button.main'); page.wait_for_timeout(300)
    print(page.inner_text('#v-plans .meta').replace('\n',' '))
    page.screenshot(path='/tmp/plans.png'); print(page.errors)
