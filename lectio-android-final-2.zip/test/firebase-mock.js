/* In-memory stand-in for the Firebase compat SDK, for browser tests only (never shipped in the app).
   Load it with test/harness.py, which serves www/ and swaps the real vendor files for this.
   Supports: auth (anonymous, email/password, link), firestore (doc/collection get, set, add, update, delete, where, orderBy, limit,
   onSnapshot, batch, runTransaction), FieldValue (serverTimestamp, increment, arrayUnion, arrayRemove, delete).
   It does NOT enforce security rules. Test helpers: window.__mock.db (Map path->data), window.__mock.seed(path,data), window.__mock.dump(prefix). */
(function(){
  var docs=new Map();            // "posts/abc" -> data object
  var subs=[];                   // {col, fn}
  function clone(o){return o==null?o:JSON.parse(JSON.stringify(o,function(k,v){return v&&v.__ts?{__ts:v.ms}:v}),function(k,v){return v&&typeof v==='object'&&'__ts' in v?new Ts(v.__ts):v})}
  function Ts(ms){this.ms=ms;this.__ts=1;this.seconds=Math.floor(ms/1000);this.nanoseconds=(ms%1000)*1e6}
  Ts.prototype.toMillis=function(){return this.ms};Ts.prototype.toDate=function(){return new Date(this.ms)};
  Ts.now=function(){return new Ts(Date.now())};Ts.fromMillis=function(m){return new Ts(m)};
  var FV={serverTimestamp:function(){return{__op:'ts'}},increment:function(n){return{__op:'inc',n:n}},arrayUnion:function(){return{__op:'au',a:[].slice.call(arguments)}},arrayRemove:function(){return{__op:'ar',a:[].slice.call(arguments)}},delete:function(){return{__op:'del'}}};
  function eq(a,b){return JSON.stringify(a)===JSON.stringify(b)}
  function applyOps(cur,upd,merge){
    var out=merge?clone(cur)||{}:{};
    Object.keys(upd).forEach(function(k){
      var v=upd[k];
      if(v&&v.__op){
        if(v.__op==='ts')out[k]=Ts.now();
        else if(v.__op==='inc')out[k]=(+out[k]||0)+v.n;
        else if(v.__op==='au'){var a=Array.isArray(out[k])?out[k].slice():[];v.a.forEach(function(x){if(!a.some(function(y){return eq(x,y)}))a.push(x)});out[k]=a}
        else if(v.__op==='ar'){out[k]=(Array.isArray(out[k])?out[k]:[]).filter(function(y){return!v.a.some(function(x){return eq(x,y)})})}
        else if(v.__op==='del')delete out[k];
      }else if(k.indexOf('.')>0&&merge){ // dotted field path update
        var parts=k.split('.'),o=out;for(var i=0;i<parts.length-1;i++){o[parts[i]]=o[parts[i]]&&typeof o[parts[i]]==='object'?o[parts[i]]:{};o=o[parts[i]]}
        o[parts[parts.length-1]]=(v&&v.__op==='del')?undefined:clone(v);
      }else out[k]=(v&&typeof v==='object'&&!(v instanceof Ts))?clone(v):v;
    });
    return out;
  }
  function check(data){
    (function walk(o,path){
      if(o===undefined)throw new Error('Unsupported field value: undefined at '+path);
      if(Array.isArray(o)){o.forEach(function(x,i){if(Array.isArray(x))throw new Error('Nested arrays are not supported at '+path+'['+i+']');walk(x,path+'['+i+']')})}
      else if(o&&typeof o==='object'&&!(o instanceof Ts)&&!o.__op){Object.keys(o).forEach(function(k){walk(o[k],path+'.'+k)})}
    })(data,'doc');
  }
  var bytes=function(o){return JSON.stringify(o).length};
  function notify(path){var col=path.split('/').slice(0,-1).join('/');subs.slice().forEach(function(s){if(s.col===col)setTimeout(s.fn,0)})}
  function snapOf(path){var d=docs.get(path);return{id:path.split('/').pop(),exists:docs.has(path),ref:docRef(path),data:function(){return d?clone(d):undefined},get:function(f){return d?d[f]:undefined}}}
  function docRef(path){
    var r={id:path.split('/').pop(),path:path,
      get:function(){return Promise.resolve(snapOf(path))},
      set:function(data,opt){return Promise.resolve().then(function(){check(data);var merge=opt&&opt.merge;var nd=applyOps(docs.get(path),data,merge);if(bytes(nd)>1000000)throw new Error('Document too large (exceeds 1 MiB)');docs.set(path,nd);notify(path)})},
      update:function(data){return Promise.resolve().then(function(){if(!docs.has(path)){var e=new Error('No document to update: '+path);e.code='not-found';throw e}check(data);docs.set(path,applyOps(docs.get(path),data,true));notify(path)})},
      delete:function(){return Promise.resolve().then(function(){docs.delete(path);notify(path)})},
      collection:function(n){return colRef(path+'/'+n)},
      onSnapshot:function(fn){var col=path.split('/').slice(0,-1).join('/');var s={col:col,fn:function(){fn(snapOf(path))}};subs.push(s);setTimeout(s.fn,0);return function(){var i=subs.indexOf(s);if(i>-1)subs.splice(i,1)}}
    };
    return r;
  }
  function getField(d,f){return f.split('.').reduce(function(o,k){return o==null?undefined:o[k]},d)}
  function val(x){return x instanceof Ts?x.ms:x}
  function colRef(cpath,q){
    q=q||{w:[],o:[],l:0};
    function run(){
      var out=[];
      docs.forEach(function(d,p){
        var pp=p.split('/');if(pp.slice(0,-1).join('/')!==cpath)return;
        for(var i=0;i<q.w.length;i++){
          var w=q.w[i],fv=val(getField(d,w.f)),v=val(w.v);
          var ok=w.op==='=='?eq(fv,v):w.op==='!='?!eq(fv,v):w.op==='<'?fv<v:w.op==='<='?fv<=v:w.op==='>'?fv>v:w.op==='>='?fv>=v:w.op==='in'?(w.v||[]).some(function(x){return eq(x,fv)}):w.op==='array-contains'?(Array.isArray(fv)&&fv.some(function(x){return eq(x,v)})):true;
          if(!ok)return;
        }
        out.push(p);
      });
      q.o.forEach(function(){});
      out.sort(function(a,b){
        for(var i=0;i<q.o.length;i++){var o=q.o[i],x=val(getField(docs.get(a),o.f)),y=val(getField(docs.get(b),o.f));if(x===y)continue;if(x===undefined)return 1;if(y===undefined)return-1;var r=x<y?-1:1;return o.d==='desc'?-r:r}
        return 0;
      });
      if(q.l)out=out.slice(0,q.l);
      return out;
    }
    function qsnap(){var ps=run(),ds=ps.map(function(p){return snapOf(p)});return{docs:ds,size:ds.length,empty:!ds.length,forEach:function(f){ds.forEach(f)},docChanges:function(){return ds.map(function(d){return{type:'added',doc:d}})}}}
    function ext(patch){return colRef(cpath,{w:q.w.concat(patch.w||[]),o:q.o.concat(patch.o||[]),l:patch.l!=null?patch.l:q.l})}
    return{id:cpath.split('/').pop(),path:cpath,
      doc:function(id){return docRef(cpath+'/'+(id||('m'+Date.now().toString(36)+Math.random().toString(36).slice(2,8))))},
      add:function(data){var id='m'+Date.now().toString(36)+Math.random().toString(36).slice(2,8);var r=docRef(cpath+'/'+id);return r.set(data).then(function(){return r})},
      where:function(f,op,v){return ext({w:[{f:f,op:op,v:v}]})},
      orderBy:function(f,d){return ext({o:[{f:f,d:d||'asc'}]})},
      limit:function(n){return ext({l:n})},
      get:function(){return Promise.resolve(qsnap())},
      onSnapshot:function(fn){var s={col:cpath,fn:function(){fn(qsnap())}};subs.push(s);setTimeout(s.fn,0);return function(){var i=subs.indexOf(s);if(i>-1)subs.splice(i,1)}}
    };
  }
  var db={settings:function(){},collection:colRef,doc:function(p){return docRef(p)},
    batch:function(){var ops=[];var b={set:function(r,d,o){ops.push(function(){return r.set(d,o)});return b},update:function(r,d){ops.push(function(){return r.update(d)});return b},delete:function(r){ops.push(function(){return r.delete()});return b},commit:function(){return ops.reduce(function(p,f){return p.then(f)},Promise.resolve())}};return b},
    runTransaction:function(fn){var tx={get:function(r){return r.get()},set:function(r,d,o){return r.set(d,o),tx},update:function(r,d){return r.update(d),tx},delete:function(r){return r.delete(),tx}};return Promise.resolve(fn(tx))}};
  function firestore(){return db}
  firestore.FieldValue=FV;firestore.Timestamp=Ts;

  /* ---- auth ---- */
  var authSubs=[],cur=null,uidN=0;
  function mkUser(o){var u=Object.assign({uid:'u'+(++uidN),isAnonymous:false,displayName:'',email:''},o);
    u.updateProfile=function(p){Object.assign(u,p);return Promise.resolve()};
    u.linkWithCredential=function(c){u.isAnonymous=false;u.email=c.email;return Promise.resolve({user:u}).then(function(r){fire();return r})};
    return u}
  function fire(){authSubs.slice().forEach(function(f){setTimeout(function(){f(cur)},0)})}
  var users={};
  var auth={get currentUser(){return cur},
    onAuthStateChanged:function(f){authSubs.push(f);setTimeout(function(){f(cur)},0);return function(){}},
    signInAnonymously:function(){cur=mkUser({isAnonymous:true});fire();return Promise.resolve({user:cur})},
    createUserWithEmailAndPassword:function(e,p){users[e]={p:p};cur=mkUser({email:e});fire();return Promise.resolve({user:cur})},
    signInWithEmailAndPassword:function(e,p){if(!users[e]||users[e].p!==p){var er=new Error('bad');er.code='auth/invalid-credential';return Promise.reject(er)}cur=mkUser({email:e,uid:users[e].uid||undefined});users[e].uid=cur.uid;fire();return Promise.resolve({user:cur})},
    signOut:function(){cur=null;fire();return Promise.resolve()},
    sendPasswordResetEmail:function(){return Promise.resolve()}};
  function authFn(){return auth}
  authFn.EmailAuthProvider={credential:function(e,p){return{email:e,password:p}}};

  window.firebase={initializeApp:function(){},auth:authFn,firestore:firestore,apps:[1]};
  window.__mock={db:docs,seed:function(path,data){docs.set(path,clone(data));notify(path)},dump:function(prefix){var o={};docs.forEach(function(v,k){if(!prefix||k.indexOf(prefix)===0)o[k]=clone(v)});return o},
    signInAs:function(name,email){cur=mkUser({displayName:name||'Tester',email:email||'t@example.com'});fire();return cur.uid},
    auth:auth};
})();
