/* Bible reader: chapter view (one version, or 2-4 versions stacked), text size and pinch zoom, auto-scroll,
   audio (text to speech), verse menu (copy / save / share / note / highlight) and the "go to" picker.
   Versions, book loading and references all come from Lectio.bible (bible.js).

   File map:  preferences > rendering > verse selection and menu > auto-scroll > audio > dock and sheets > view lifecycle. */
(function(){
'use strict';
var L=window.Lectio,$=L.$,esc=L.esc,UI=L.ui,B=L.bible;
var Cap=window.Capacitor||{};
var native=!!(Cap.isNativePlatform&&Cap.isNativePlatform());
function plug(n){try{return(Cap.Plugins&&Cap.Plugins[n])||(native&&Cap.registerPlugin?Cap.registerPlugin(n):null)}catch(e){return null}}

var MAX_VERS=4;                                   /* most versions that can be stacked */
var INDIC=['te','hi','ta','kn','ml','bn','mr','gu','pa','or','ne'];   /* scripts that need taller lines */

/* ================= preferences ================= */
/* vers     = ordered ids of the chosen versions (first = primary). Only the first is shown unless parallel is on.
   read     = what audio reads: a version id, or 'all'.        voices = chosen TTS voice per language ('en','te',...) */
var P={vers:null,parallel:false,vlabels:false,size:20,nums:true,ms:30,autoNext:true,autoMark:false,nextOnMark:false,read:'',rate:1,pitch:1,voices:{},last:{b:0,c:1}};
(function loadPrefs(){
  var sv={};
  try{sv=JSON.parse(L.lsGet('lectio-reader-v1')||'{}')||{}}catch(e){}
  Object.keys(sv).forEach(function(k){P[k]=sv[k]});
  /* older versions of the app stored two keys: a (first version) and b (second, used when parallel) */
  if(!Array.isArray(P.vers)||!P.vers.length){
    P.vers=[sv.a||'kjv'];
    if(sv.parallel&&sv.b&&sv.b!==P.vers[0])P.vers.push(sv.b);
  }
  if(sv.read==='both')P.read='all';
  else if(sv.read==='a')P.read=P.vers[0];
  else if(sv.read==='b')P.read=P.vers[1]||P.vers[0];
  if(!P.read)P.read=P.vers[0];
  ['a','b','side'].forEach(function(k){delete P[k]});
  P.vers=P.vers.filter(function(id,i,a){return typeof id==='string'&&a.indexOf(id)===i}).slice(0,MAX_VERS);
  if(!P.vers.length)P.vers=['kjv'];
  if(!P.voices||typeof P.voices!=='object')P.voices={};
  if(!P.last||typeof P.last!=='object')P.last={b:0,c:1};
  if(typeof P.awake!=='boolean')P.awake=false;
  if(['never','always','scroll'].indexOf(P.hideBar)<0)P.hideBar='never';
})();
function saveP(){L.lsSet('lectio-reader-v1',JSON.stringify(P))}
function clamp(v,a,b){return Math.max(a,Math.min(b,v))}

/* Drop chosen versions that no longer exist (e.g. an imported one was removed). Only after bibles/manifest.json
   was read, because before that the list is just the built-in fallback. */
var verReady=false;
function pruneVers(){
  if(!verReady)return;
  P.vers=P.vers.filter(B.hasVersion);
  if(!P.vers.length)P.vers=[B.versions()[0].id];
  if(P.read!=='all'&&!B.hasVersion(P.read))P.read=P.vers[0];
  saveP();
}
/* ids of the versions on screen right now, in reading order */
function shownIds(){
  var ids=P.vers.filter(B.hasVersion);
  if(!ids.length)ids=[B.versions()[0].id];
  return P.parallel?ids.slice(0,MAX_VERS):ids.slice(0,1);
}
function setVers(ids){
  P.vers=ids.slice(0,MAX_VERS);saveP();
  renderSheetSoft();render();restartIfPlaying();
}
/* make `id` the primary version. In parallel mode the other chosen versions stay behind it. */
function choosePrimary(id){
  var rest=P.vers.filter(function(x){return x!==id});
  if(P.parallel)setVers([id].concat(rest));
  else setVers([id].concat(rest.slice(P.vers.length>1?P.vers.indexOf(id)===0?0:1:0)).filter(function(x,i){return i===0||P.vers.indexOf(x)>0}));
}

var pos={b:clamp(+P.last.b||0,0,65),c:1};
pos.c=clamp(+P.last.c||1,1,BOOKS[pos.b].c);
function savePos(v){P.last={b:pos.b,c:pos.c,v:v||0};saveP();refreshHome()}
function curV(){var m=P.mark;if(m&&m.b===pos.b&&m.c===pos.c)return m.v;return window.scrollY<40?0:firstVisible()}
var svT=0;
window.addEventListener('scroll',function(){
  if(L.view!=='read')return;
  clearTimeout(svT);svT=setTimeout(function(){
    if(L.view!=='read'||!rt.querySelector('.vs'))return;
    var v=curV();
    if(P.last.b===pos.b&&P.last.c===pos.c&&P.last.v!==v){P.last.v=v;saveP()}
  },250);
},{passive:true});
/* Save the exact spot the moment the app leaves the foreground — not after a debounce — so a
   swipe-to-close (which can kill the WebView process outright on Android) never races a pending
   scroll-save. Several independent triggers, because no single one is reliable on every OEM. */
function saveLastNow(){
  if(L.view!=='read'||!rt.querySelector('.vs'))return;
  var v=curV();
  P.last={b:pos.b,c:pos.c,v:v};saveP();
}
document.addEventListener('visibilitychange',function(){if(document.hidden)saveLastNow()});
window.addEventListener('pagehide',saveLastNow);
window.addEventListener('blur',saveLastNow);
(function(){var A=plug('App');if(A&&A.addListener){A.addListener('pause',saveLastNow);A.addListener('appStateChange',function(st){if(st&&!st.isActive)saveLastNow()})}})();
function step(d){
  var b=pos.b,c=pos.c+d;
  if(c<1){if(b===0)return false;b--;c=BOOKS[b].c}
  else if(c>BOOKS[b].c){if(b===BOOKS.length-1)return false;b++;c=1}
  pos={b:b,c:c};savePos();L.curBook=b;clearSel();return true;
}

/* ================= rendering ================= */
var tok=0,data=[],V=$('vRead'),rt=$('rText');
/* data = [{id, t:version, verses:string[]|null}] for the versions on screen; verses is null when that version has no such chapter */

function langKey(lang){return String(lang||'en').slice(0,2).toLowerCase()}
function vkey(v){return'hl-'+pos.b+'.'+pos.c+'.'+v}

/* inline style attribute for one paragraph: the per-translation font/colour from Settings */
function pStyle(d){
  var s=L.theme.tstyle(d.id,B.isTel(d.t)),o='';
  if(s.font)o+='font-family:'+s.font+';';
  if(s.color)o+='color:'+s.color+';';
  return o?' style="'+esc(o)+'"':'';
}
function vbgStyle(ids,b,c,v){
  try{
    var vb=window.Lectio.vbg;
    var r=vb&&vb.forVerse&&vb.forVerse(ids,b,c,v);
    if(r&&r.bg)return' style="'+esc('--vbg:'+r.bg+';--vfg:'+(r.fg||'inherit'))+'"';
  }catch(e){}
  return'';
}
var noteMap={};
function NOTE_BTN(v){return' <button type="button" class="vnote" data-vn="'+v+'" aria-label="Notes for verse '+v+'">'+UI.icon('note',15)+'</button>'}
function verseHtml(v,par,ids,b,c){
  var h='<div class="vs" data-v="'+v+'"'+vbgStyle(ids,b,c,v)+'>';
  if(P.nums)h+='<span class="vn">'+v+'</span>';
  h+='<div class="vcols">';
  data.forEach(function(d,i){
    var tx=d.verses?(d.verses[v-1]||''):'',lk=langKey(d.t.lang);
    var cls='vt'+(i?' vt2':'')+(B.isTel(d.t)?' tel':'')+(INDIC.indexOf(lk)>=0?' ind':'');
    h+='<p class="'+cls+'" lang="'+esc(lk)+'" data-tid="'+esc(d.id)+'"'+pStyle(d)+'>';
    if(i===0&&P.nums)h+='<span class="vni">'+v+'</span>';
    if(par&&P.vlabels)h+='<span class="vl">'+esc(d.t.short)+'</span>';
    h+=(tx?esc(tx):'<span class="dash">—</span>');
    if(i===data.length-1&&noteMap[v])h+=NOTE_BTN(v);
    h+='</p>';
  });
  return h+'</div></div>';
}
var lastKey='',lastLog='';
function render(){
  var my=++tok;
  return B.ready.then(function(){
    if(my!==tok)return;
    var b=pos.b,c=pos.c,ids=shownIds();
    $('rBook').textContent=BOOKS[b].n;
    $('rCh').textContent=c;
    if(L.vlog&&lastLog!==b+'.'+c){lastLog=b+'.'+c;L.vlog.add({k:'open',b:b,c:c})}
    $('rVer').textContent=((B.version(ids[0])||{}).short||String(ids[0]).toUpperCase()).toString().slice(0,6);
    if(L.bars)L.bars.refresh();
    document.title='Lectio · '+BOOKS[b].n+' '+c;
    return Promise.all(ids.map(function(id){return B.loadBook(id,b).catch(function(){return null})})).then(function(books){
      if(my!==tok)return;
      data=ids.map(function(id,i){return{id:id,t:B.version(id),verses:books[i]?(books[i][c-1]||[]):null}});
      var n=0;data.forEach(function(d){if(d.verses)n=Math.max(n,d.verses.length)});
      var par=data.length>1,h='';
      noteMap=(window.Lectio.notes&&window.Lectio.notes.verseMap)?window.Lectio.notes.verseMap(b,c):{};
      if(!n)h+='<p class="rempty">'+(par?'These versions have':'This version has')+' no text for '+esc(BOOKS[b].n)+' '+c+'.</p>';
      for(var v=1;v<=n;v++)h+=verseHtml(v,par,ids,b,c);
      rt.className='rtext'+(par?' par':'')+(P.nums?'':' nonum');
      var keepY=(lastKey===b+'.'+c)?window.scrollY:-1;lastKey=b+'.'+c;
      rt.innerHTML=h;
      if(keepY>0)window.scrollTo(0,keepY);
      paintHl();paintSel();paintMark();markNow(S.on||S.paused?S.v:0);
      refreshMark();
      $('rPrev').disabled=$('rPrevH').disabled=(b===0&&c===1);
      $('rNext').disabled=$('rNextH').disabled=(b===BOOKS.length-1&&c===BOOKS[b].c);
      if(sel.size)updateBar();
    });
  });
}
function refreshMark(){
  var on=L.vprog.read(shownIds()[0],pos.b,pos.c),m=$('rMark');
  m.textContent=on?'Read ✓':'Mark as read';
  m.classList.toggle('on',on);
}
function setSize(px,persist){
  P.size=Math.round(clamp(px,12,48)*2)/2;
  V.style.setProperty('--rsize',P.size+'px');
  var e=$('szV');if(e)e.textContent=P.size+' px';
  var r=$('szR');if(r&&+r.value!==P.size)r.value=P.size;
  if(persist)saveP();
}
setSize(P.size,false);

/* ---- header: title opens the version/book/chapter picker; swap lives inside that popup ---- */
$('rTitle').setAttribute('aria-label','Go to another book or chapter');

/* ---- opening the reader ---- */
var pendingV=0;
/* used by app.js when restoring the page after the app was closed */
L.resumeVerse=function(){pendingV=+(P.last&&P.last.v)||0};
function openReader(b,c,v,tid){
  if(tid&&B.hasVersion(tid)){P.vers=[tid].concat(P.vers.filter(function(x){return x!==tid}));P.parallel=false;saveP()}
  if(b==null&&!v&&P.last&&P.last.b===pos.b&&P.last.c===pos.c)v=P.last.v;
  if(b!=null){
    b=clamp(+b||0,0,65);
    pos={b:b,c:clamp(+c||1,1,BOOKS[b].c)};
  }
  pendingV=+v||0;
  L.curBook=pos.b;savePos(pendingV);
  L.go('read');
}
L.openReader=openReader;
L.reader={pos:function(){return{b:pos.b,c:pos.c}},version:function(){return shownIds()[0]},act:function(a){readerAct(a)},playerOpen:function(){return typeof miniOpen!=='undefined'&&miniOpen}};
function scrollToVerse(v){
  var el=rt.querySelector('.vs[data-v="'+v+'"]');
  if(!el)return;
  try{el.scrollIntoView({block:'center'})}catch(e){}
  el.classList.remove('flash');void el.offsetWidth;el.classList.add('flash');
  setTimeout(function(){el.classList.remove('flash')},1900);
}
function goChapter(d,keepAudio){
  if(!step(d))return;
  var wasAudio=S.on,wasScroll=A.on;
  render().then(function(){
    window.scrollTo(0,0);
    if(wasAudio&&keepAudio!==false)play(1);
    if(wasScroll){A.last=0;A.acc=0}
  });
  updateFg();
}
$('rPrev').onclick=function(){goChapter(-1)};
$('rNext').onclick=function(){goChapter(1)};
$('rMark').onclick=function(){
  var tid=shownIds()[0],on=!L.vprog.read(tid,pos.b,pos.c);
  var still=L.vprog.mark(tid,pos.b,pos.c,on);
  L.setChapterRead(pos.b,pos.c,on||!!still);refreshMark();
  var sh=(B.version(tid)||{}).short||'';
  L.toast(on?BOOKS[pos.b].n+' '+pos.c+' marked as read ('+sh+')':'Marked unread ('+sh+')');
  if(on&&P.nextOnMark)goChapter(1);
};
$('rPrevH').onclick=function(){goChapter(-1)};
$('rNextH').onclick=function(){goChapter(1)};

/* ---- tap the title: pick version, book and chapter ---- */
function pickWithSwap(extra){
  var prim=shownIds();
  return B.pick(Object.assign({verses:false,tid:prim[0],b:pos.b,c:pos.c,title:'Go to',parallel:true,vers:prim,multi:P.parallel,onSwap:function(vers){
    P.vers=vers.concat(P.vers.filter(function(x){return vers.indexOf(x)<0})).slice(0,MAX_VERS);saveP();render();restartIfPlaying();
  },onOptions:function(){openOptions()}},extra||{}));
}
$('rTitle').onclick=function(){
  var prim=shownIds()[0];
  pickWithSwap().then(function(r){
    if(!r)return;
    var wasAudio=S.on;
    if(r.vers&&r.vers.length){
      P.parallel=r.vers.length>1;
      P.vers=r.vers.concat(P.vers.filter(function(x){return r.vers.indexOf(x)<0})).slice(0,MAX_VERS);
    }else if(r.tid!==prim){
      P.vers=[r.tid].concat(P.vers.slice(1).filter(function(x){return x!==r.tid})).slice(0,MAX_VERS);
    }
    pos={b:r.b,c:clamp(r.c,1,BOOKS[r.b].c)};
    L.curBook=pos.b;savePos();clearSel();
    render().then(function(){
      window.scrollTo(0,0);
      if(wasAudio)play(1);
      updateFg();
    });
  });
};

/* version button: choose the version shown for this chapter */
$('rVer').onclick=function(){
  var cur=shownIds()[0];
  UI.actionSheet({title:'Version · '+BOOKS[pos.b].n+' '+pos.c,items:B.versions().map(function(v){
    return{label:(v.id===cur?'\u2713 ':'')+v.name+' ('+v.short+')',on:function(){
      P.vers=[v.id].concat(P.vers.filter(function(x){return x!==v.id})).slice(0,MAX_VERS);saveP();render();restartIfPlaying();
    }};
  })});
};
/* chevron: pill menu */
$('rMore').onclick=function(){
  var rows=L.bars?L.bars.rows('more'):[];
  UI.actionSheet({title:'Reader',items:rows.map(function(r){return{label:r.label,icon:UI.icons&&UI.icons[r.icon]?r.icon:'',on:function(){L.bars.run(r.link)}}})});
};
/* actions the bars can call */
function readerAct(a){
  if(a==='library')L.pop.library();
  else if(a==='options')openOptions();
  else if(a==='fullscreen')document.body.classList.toggle('rbar-hide');
}

/* ---- pinch to zoom the text ---- */
(function(){
  var d0=0,s0=0,raf=0,next=0;
  function dist(t){return Math.hypot(t[0].clientX-t[1].clientX,t[0].clientY-t[1].clientY)}
  V.addEventListener('touchstart',function(e){if(e.touches.length===2){d0=dist(e.touches);s0=P.size;cancelPress()}},{passive:true});
  V.addEventListener('touchmove',function(e){
    if(e.touches.length!==2||!d0)return;
    e.preventDefault();
    next=s0*dist(e.touches)/d0;
    if(!raf)raf=requestAnimationFrame(function(){raf=0;setSize(next,false)});
  },{passive:false});
  function end(e){if(d0&&e.touches.length<2){d0=0;saveP()}}
  V.addEventListener('touchend',end);V.addEventListener('touchcancel',end);
})();

/* ================= highlights ================= */
var hlC=L.coll('hl'),savedC=L.coll('saved');
var COLS=[['y','Yellow'],['g','Green'],['b','Blue'],['p','Pink'],['o','Orange'],['v','Violet'],['r','Red'],['t','Teal'],['l','Lime'],['c','Sky'],['m','Magenta'],['k','Grey']];
/* put data-hl="y" etc. on the verse blocks of this chapter */
function paintHl(){
  var m={};
  hlC.list().forEach(function(i){if(i.b===pos.b&&i.c===pos.c)m[i.v]=i.col});
  rt.querySelectorAll('.vs').forEach(function(el){
    var c=m[el.dataset.v];
    if(c)el.setAttribute('data-hl',c);else el.removeAttribute('data-hl');
  });
  if(sel.size)updateBar();
}
hlC.on(paintHl);
function paintNotes(){
  if(L.view!=='read'||!window.Lectio.notes||!window.Lectio.notes.verseMap)return;
  noteMap=window.Lectio.notes.verseMap(pos.b,pos.c);
  rt.querySelectorAll('.vnote').forEach(function(x){x.remove()});
  Object.keys(noteMap).forEach(function(v){var vs=rt.querySelector('.vs[data-v="'+v+'"]');if(!vs)return;var ps=vs.querySelectorAll('.vt'),last=ps[ps.length-1];if(last)last.insertAdjacentHTML('beforeend',NOTE_BTN(+v))});
}
L.on('ready',function(){if(window.Lectio.notes&&window.Lectio.notes.on)window.Lectio.notes.on(paintNotes)});
savedC.on(function(){if(sel.size)updateBar()});

/* ================= verse selection and the bottom bar ================= */
var sel=new Set();            /* selected verse numbers of the current chapter */
var bar=document.createElement('div');
bar.className='vbar';bar.id='vbar';bar.hidden=true;
bar.innerHTML='<div class="vb-dots">'+
  COLS.map(function(c){return'<button type="button" class="dot hl-'+c[0]+'" data-col="'+c[0]+'" aria-label="Highlight '+c[1]+'" aria-pressed="false"></button>'}).join('')+
  '<button type="button" class="vb-x" data-vb="clear" aria-label="Close">'+UI.icon('x',18)+'</button></div><div class="vb-acts">'+
  [['copy','copy','Copy'],['note','note','Note'],['save','bookmark','Save'],['share','share','Share'],['more','more','More']].map(function(a){
    return'<button type="button" data-vb="'+a[0]+'" aria-label="'+a[2]+'">'+UI.icon(a[1],22)+'</button>';
  }).join('')+'</div>';
document.body.appendChild(bar);

function selList(){return Array.from(sel).sort(function(a,b){return a-b})}
/* runs of neighbouring verses: [16,17,20] -> [[16,17],[20,20]] */
function runs(){
  var out=[];
  selList().forEach(function(v){
    var last=out[out.length-1];
    if(last&&last[1]===v-1)last[1]=v;else out.push([v,v]);
  });
  return out;
}
function runId(r){return'sv-b-'+pos.b+'.'+pos.c+'.'+r[0]+'-'+r[1]}
function verseText(i,v){var d=data[i];return d&&d.verses?(d.verses[v-1]||''):''}
function paintSel(){
  rt.querySelectorAll('.vs').forEach(function(el){el.classList.toggle('sel',sel.has(+el.dataset.v))});
}
function updateBar(){
  var on=sel.size>0;
  bar.hidden=!on||L.view!=='read';
  document.body.classList.toggle('selecting',on);
  if(!on)return;
  var rs=runs(),saved=rs.every(function(r){return savedC.get(runId(r))});
  var sb=bar.querySelector('[data-vb="save"]');
  sb.setAttribute('aria-pressed',String(saved));
  sb.classList.toggle('on',saved);
  bar.querySelector('[data-vb="note"]').hidden=!(window.Lectio.notes&&window.Lectio.notes.addVerse);
  /* highlight dot that all selected verses share is shown as pressed */
  var cols={};
  sel.forEach(function(v){var h=hlC.get(vkey(v));cols[h?h.col:'']=1});
  var keys=Object.keys(cols),one=keys.length===1?keys[0]:null;
  bar.querySelectorAll('.dot').forEach(function(d){d.setAttribute('aria-pressed',String(one!==null&&one!==''&&d.dataset.col===one))});
}
function clearSel(){
  if(!sel.size&&bar.hidden)return;
  sel.clear();paintSel();updateBar();
}
function toggleVerse(v){
  if(sel.has(v))sel.delete(v);else sel.add(v);
  if(sel.size&&sheetName)closeSheet();       /* the sheet and the bar share the same spot */
  paintSel();updateBar();
}

/* long press (about 450 ms) on a verse starts selecting; moving the finger (scrolling) cancels it */
var LP={t:0,x:0,y:0,fired:false};
function cancelPress(){clearTimeout(LP.t)}
rt.addEventListener('pointerdown',function(e){
  if(e.pointerType==='mouse'&&e.button!==0)return;
  var vs=e.target.closest('.vs');if(!vs)return;
  LP.fired=false;LP.x=e.clientX;LP.y=e.clientY;
  cancelPress();
  LP.t=setTimeout(function(){
    LP.fired=true;
    try{if(navigator.vibrate)navigator.vibrate(12)}catch(x){}
    toggleVerse(+vs.dataset.v);
  },450);
});
rt.addEventListener('pointermove',function(e){if(Math.hypot(e.clientX-LP.x,e.clientY-LP.y)>10)cancelPress()});
['pointerup','pointercancel','pointerleave'].forEach(function(n){rt.addEventListener(n,cancelPress)});
rt.addEventListener('contextmenu',function(e){e.preventDefault()});
/* a tap: toggles while selecting, otherwise jumps the audio to that verse */
rt.addEventListener('click',function(e){
  var nb=e.target.closest('.vnote');
  if(nb){e.stopPropagation();LP.fired=false;var vv=+nb.dataset.vn,tx0=data.map(function(d,i){return{s:d.t.short,t:verseText(i,vv)}}).filter(function(x){return x.t});window.Lectio.notes.verseNotes({b:pos.b,c:pos.c,v1:vv,v2:vv,verses:[vv],ref:B.refName(pos.b,pos.c,vv),short:tx0.length===1?tx0[0].s:'',text:tx0.map(function(x){return(tx0.length>1?x.s+': ':'')+x.t}).join('\n')});return}
  if(LP.fired){LP.fired=false;return}       /* this click is just the end of the long press */
  var vs=e.target.closest('.vs');if(!vs)return;
  var v=+vs.dataset.v;
  if(sel.size)toggleVerse(v);
  else{
    if(S.on)play(v);
    setMark(v);
  }
});
/* tapping a verse remembers where you stopped; reopening the app scrolls back to it */
function setMark(v){
  var m=P.mark;
  if(m&&m.b===pos.b&&m.c===pos.c&&m.v===v){P.mark=null;P.last.v=0}
  else{P.mark={b:pos.b,c:pos.c,v:v};P.last={b:pos.b,c:pos.c,v:v}}
  saveP();paintMark();
}
function paintMark(){
  var m=P.mark,ok=m&&m.b===pos.b&&m.c===pos.c;
  rt.querySelectorAll('.vs').forEach(function(el){el.classList.toggle('rmark',!!ok&&+el.dataset.v===m.v)});
}
/* swipe left/right on the text turns the chapter */
(function(){
  var x0=0,y0=0,t0=0,multi=false;
  V.addEventListener('touchstart',function(e){
    if(e.touches.length>1){multi=true;return}
    multi=false;x0=e.touches[0].clientX;y0=e.touches[0].clientY;t0=Date.now();
  },{passive:true});
  V.addEventListener('touchend',function(e){
    if(multi||e.touches.length||sel.size||!e.changedTouches.length)return;
    var dx=e.changedTouches[0].clientX-x0,dy=e.changedTouches[0].clientY-y0;
    if(Date.now()-t0>700||Math.abs(dx)<70||Math.abs(dy)>Math.abs(dx)*0.6)return;
    var g=window.getSelection&&window.getSelection();if(g&&String(g).length)return;
    cancelPress();goChapter(dx<0?1:-1);
  },{passive:true});
})();

/* text of the selected verses, one block per shown version */
function selText(){
  var list=selList(),single=list.length===1,ref=B.refList(pos.b,pos.c,list);
  return data.map(function(d,i){
    var lines=[];
    list.forEach(function(v){var t=verseText(i,v);if(t)lines.push(single?t:v+' '+t)});
    return ref+' ('+d.t.short+')\n'+lines.join('\n');
  }).join('\n\n');
}
function saveSelection(){
  var rs=runs(),all=rs.every(function(r){return savedC.get(runId(r))});
  if(all){rs.forEach(function(r){savedC.remove(runId(r))});L.toast('Removed from saved verses');return}
  rs.forEach(function(r){
    var tx=[],multi=r[1]>r[0];
    data.forEach(function(d,i){
      var parts=[];for(var v=r[0];v<=r[1];v++){var t=verseText(i,v);if(t)parts.push(multi?v+' '+t:t)}
      if(parts.length)tx.push({s:d.t.short,t:parts.join(' ')});
    });
    savedC.put({id:runId(r),src:'bible',ref:B.refName(pos.b,pos.c,r[0],r[1]),b:pos.b,c:pos.c,v1:r[0],v2:r[1],tx:tx,ts:Date.now()});
  });
  L.toast('Saved. See Saved verses in the menu.');
}
function highlightSelection(col){
  selList().forEach(function(v){
    var id=vkey(v);
    if(!col){hlC.remove(id);return}
    var tx=[];
    data.forEach(function(d,i){var t=verseText(i,v);if(t)tx.push({s:d.t.short,t:t})});
    hlC.put({id:id,b:pos.b,c:pos.c,v:v,col:col,tx:tx,ts:Date.now()});
  });
  paintHl();
}
function lookUp(){
  var txt=verseText(0,selList()[0])||'',seen={},ws=txt.replace(/[^\p{L}\s'-]/gu,' ').split(/\s+/).filter(function(w){w=w.toLowerCase();if(w.length<4||seen[w])return false;seen[w]=1;return true}).slice(0,14);
  var m=UI.modal({title:'Look Up',body:'<p class="muted">Tap a word to find every verse that uses it.</p><div class="chips">'+ws.map(function(w){return'<button type="button" class="chip" data-w="'+esc(w)+'">'+esc(w)+'</button>'}).join('')+'</div>'});
  m.body.addEventListener('click',function(ev){var c=ev.target.closest('[data-w]');if(!c)return;m.close();clearSel();L.searchFor(c.dataset.w)});
}
bar.addEventListener('click',function(e){
  var t=e.target.closest('button');if(!t||!sel.size)return;
  if(t.dataset.col!==undefined&&t.classList.contains('dot')){highlightSelection(t.getAttribute('aria-pressed')==='true'?'':t.dataset.col);return}
  var a=t.dataset.vb;
  if(a==='copy'){UI.copy(selText()).then(function(ok){L.toast(ok?'Copied with reference':'Could not copy')});clearSel()}
  else if(a==='share'){UI.share({title:B.refList(pos.b,pos.c,selList()),text:selText()+'\n\nShared from Lectio'});clearSel()}
  else if(a==='save')saveSelection();
  else if(a==='note'){
    var list=selList(),multi=list.length>1;
    var tx=data.map(function(d,i){return{s:d.t.short,t:list.map(function(v){var t=verseText(i,v);return t?(multi?v+' '+t:t):''}).filter(Boolean).join(' ')}});
    window.Lectio.notes.verseNotes({b:pos.b,c:pos.c,v1:list[0],v2:list[list.length-1],verses:list,ref:B.refList(pos.b,pos.c,list),short:tx.length===1?tx[0].s:'',text:tx.map(function(x){return(tx.length>1?x.s+': ':'')+x.t}).join('\n')});
    clearSel();
  }
  else if(a==='more'){
    UI.actionSheet({title:B.refList(pos.b,pos.c,selList()),items:[
      {label:'Look Up',icon:'search',on:function(){lookUp()}},
      {label:'Remove highlight',icon:'highlight',on:function(){highlightSelection('')}},
      {label:'Clear selection',icon:'x',on:function(){clearSel()}}]});
  }
  else if(a==='clear')clearSel();
});

/* ================= auto-scroll ================= */
var A={on:false,raf:0,last:0,acc:0,hold:false,touch:false,endAt:0,paused:false};
var wl=null;
function keepAwake(on){
  try{
    if(on&&navigator.wakeLock&&!wl){navigator.wakeLock.request('screen').then(function(l){wl=l;l.addEventListener('release',function(){wl=null})}).catch(function(){})}
    else if(!on&&wl){wl.release().catch(function(){});wl=null}
  }catch(e){}
}
function startScroll(){
  if(S.on)stopAudio();
  A.on=true;A.paused=false;A.last=0;A.acc=0;A.endAt=0;A.hold=false;
  keepAwake(true);refreshDock();
  A.raf=requestAnimationFrame(scrollFrame);
}
function stopScroll(){
  if(!A.on)return;
  A.on=false;cancelAnimationFrame(A.raf);keepAwake(false);refreshDock();renderSheetSoft();
}
function scrollFrame(t){
  if(!A.on)return;
  var held=A.hold||A.touch||A.paused||sel.size>0;      /* touching the screen or selecting verses pauses it */
  if(A.last&&!held){
    A.acc+=Math.min(t-A.last,100)/P.ms;
    var px=Math.floor(A.acc);
    if(px>0){A.acc-=px;window.scrollBy(0,px)}
  }
  A.last=t;
  var atEnd=window.innerHeight+window.scrollY>=document.documentElement.scrollHeight-2;
  if(atEnd&&!held){
    if(!A.endAt)A.endAt=t;
    else if(t-A.endAt>1200){A.endAt=0;scrollEnded()}
  }else A.endAt=0;
  A.raf=requestAnimationFrame(scrollFrame);
}
function scrollEnded(){
  if(P.autoMark){L.setChapterRead(pos.b,pos.c,true);refreshMark()}
  A.hold=true;
  if(P.autoNext&&step(1)){
    render().then(function(){window.scrollTo(0,0);A.last=0;A.acc=0;A.hold=false});
  }else{A.hold=false;stopScroll();L.toast(P.autoNext?'End of the Bible':'End of chapter')}
}
document.addEventListener('touchstart',function(){A.touch=true},{passive:true});
document.addEventListener('touchend',function(){setTimeout(function(){A.touch=false},700)},{passive:true});
document.addEventListener('touchcancel',function(){setTimeout(function(){A.touch=false},700)},{passive:true});

/* ================= audio (text to speech) ================= */
var TTSP=native?plug('TextToSpeech'):null,FGS=native?plug('ForegroundService'):null;
var voices=null,webVoices=[];
var engine=null;
if(TTSP){
  engine={
    kind:'native',
    voices:function(){return TTSP.getSupportedVoices().then(function(r){return r.voices||[]})},
    speak:function(o){
      var op={text:o.text,lang:o.lang,rate:o.rate,pitch:o.pitch,volume:1,queueStrategy:o.add?1:0};
      if(o.voice&&voices){for(var i=0;i<voices.length;i++)if(voices[i].voiceURI===o.voice){op.voice=i;break}}
      return TTSP.speak(op);
    },
    stop:function(){return TTSP.stop()}
  };
}else if(window.speechSynthesis){
  engine={
    kind:'web',
    voices:function(){
      return new Promise(function(res){
        var get=function(){webVoices=speechSynthesis.getVoices()||[];return webVoices.map(function(v){return{voiceURI:v.voiceURI,name:v.name,lang:v.lang}})};
        var l=get();if(l.length)return res(l);
        speechSynthesis.onvoiceschanged=function(){res(get())};
        setTimeout(function(){res(get())},800);
      });
    },
    speak:function(o){
      return new Promise(function(res,rej){
        if(!o.add)speechSynthesis.cancel();
        var u=new SpeechSynthesisUtterance(o.text);u.lang=o.lang;u.rate=o.rate;u.pitch=o.pitch;
        for(var i=0;i<webVoices.length;i++)if(webVoices[i].voiceURI===o.voice){u.voice=webVoices[i];break}
        u.onend=function(){res()};u.onerror=function(e){rej(e)};
        speechSynthesis.speak(u);
      });
    },
    stop:function(){speechSynthesis.cancel();return Promise.resolve()}
  };
}
function loadVoices(){
  if(voices)return Promise.resolve(voices);
  if(!engine)return Promise.resolve([]);
  return engine.voices().then(function(v){voices=v;return v}).catch(function(){voices=[];return voices});
}
function voiceFor(lang){return P.voices[langKey(lang)]||null}
L.tts={engine:function(){return engine},load:loadVoices,voice:voiceFor,rate:function(){return P.rate},pitch:function(){return P.pitch}};

/* foreground service keeps playback going when the app is minimised */
var FG={on:false,id:4217};
function fgBody(){return 'Reading '+BOOKS[pos.b].n+' '+pos.c}
function fgOpts(){return{id:FG.id,title:'Lectio',body:fgBody(),smallIcon:'ic_stat_lectio',serviceType:2,silent:true}}
function startFg(){
  if(!FGS||FG.on)return Promise.resolve();
  return FGS.checkPermissions().then(function(p){
    if(p&&p.display!=='granted')return FGS.requestPermissions();
  }).catch(function(){}).then(function(){
    return FGS.startForegroundService(fgOpts()).then(function(){FG.on=true}).catch(function(){});
  });
}
function updateFg(){if(FGS&&FG.on)FGS.updateForegroundService(fgOpts()).catch(function(){})}
function stopFg(){if(FGS&&FG.on){FG.on=false;FGS.stopForegroundService().catch(function(){})}}

var S={on:false,paused:false,sess:0,v:1,list:[],needVoice:''};
/* which shown versions are read aloud: all of them, or the chosen one (falls back to the first) */
function readIds(){
  if(data.length<2||P.read==='all')return data.map(function(d){return d.id});
  return data.some(function(d){return d.id===P.read})?[P.read]:[data[0].id];
}
function buildList(){
  var out=[],n=0,want=readIds();
  data.forEach(function(d){if(d.verses)n=Math.max(n,d.verses.length)});
  for(var v=1;v<=n;v++){
    data.forEach(function(d){
      if(!d.verses||!d.verses[v-1]||want.indexOf(d.id)<0)return;
      out.push({v:v,text:d.verses[v-1],lang:d.t.lang});
    });
  }
  return out;
}
function markNow(v,scroll){
  var old=rt.querySelector('.vs.now');if(old)old.classList.remove('now');
  if(!v)return;
  var el=rt.querySelector('.vs[data-v="'+v+'"]');
  if(el){el.classList.add('now');if(scroll){try{el.scrollIntoView({block:'center',behavior:'smooth'})}catch(e){}}}
}
function highlight(v){
  S.v=v;markNow(v,true);updateSeek();
}
function statusText(){
  if(S.needVoice)return'No voice installed for '+S.needVoice+'.';
  var n=rt.querySelectorAll('.vs').length;
  if(S.on)return'Reading verse '+S.v+' of '+n;
  if(S.paused)return'Paused at verse '+S.v;
  return'Ready';
}
function fatal(err){
  var m=String(err&&(err.message||err)||'');
  return/not supported|unavailable|not available|not yet initialized/i.test(m);
}
function play(fromV){
  if(!engine){L.toast('This phone has no speech engine available');return}
  stopScroll();
  S.needVoice='';
  var sess=++S.sess;S.on=true;S.paused=false;
  Promise.resolve(engine.stop()).catch(function(){});
  refreshDock();renderSheetSoft();
  loadVoices().then(function(){
    if(sess!==S.sess)return;
    return startFg();
  }).then(function(){
    if(sess!==S.sess)return;
    var list=buildList(),start=-1;
    for(var i=0;i<list.length;i++)if(list[i].v>=fromV){start=i;break}
    if(start<0){chapterEnded(sess);return}
    S.list=list;
    highlight(list[start].v);
    list.forEach(function(u,i){
      if(i<start)return;
      engine.speak({text:u.text,lang:u.lang,rate:P.rate,pitch:P.pitch,voice:voiceFor(u.lang),add:i>start})
        .then(function(){advance(sess,list,i)})
        .catch(function(err){
          if(sess!==S.sess)return;
          if(fatal(err)){
            S.needVoice=B.langName(u.lang)||'this language';
            stopAudio();renderSheetSoft();
            L.toast('No '+S.needVoice+' voice found. See the Audio panel.');
            return;
          }
          advance(sess,list,i);
        });
    });
  });
}
function advance(sess,list,i){
  if(sess!==S.sess)return;
  if(i+1<list.length)highlight(list[i+1].v);else chapterEnded(sess);
}
function chapterEnded(sess){
  if(sess!==S.sess)return;
  if(P.autoMark){L.setChapterRead(pos.b,pos.c,true);refreshMark()}
  if(P.autoNext&&step(1)){
    updateFg();
    render().then(function(){if(sess===S.sess){window.scrollTo(0,0);play(1)}});
  }else{stopAudio();L.toast('Finished')}
}
function stopAudio(){
  S.sess++;S.on=false;S.paused=false;
  if(engine)Promise.resolve(engine.stop()).catch(function(){});
  stopFg();
  markNow(0);
  refreshDock();renderSheetSoft();
}
function pauseAudio(){
  var v=S.v;stopAudio();S.paused=true;S.v=v;
  markNow(v);
  refreshDock();renderSheetSoft();
}

function paintFab(){if(L.bars)L.bars.refresh()}
/* ================= floating player =================
   One small round handle (bottom right). Tap it to open the player: timeline, speed, previous / play-pause / next verse,
   start / pause scrolling, and an options button. It dims while you read so it does not distract. */
function pic(d,fill,size){return'<svg viewBox="0 0 24 24" width="'+(size||22)+'" height="'+(size||22)+'" '+(fill?'fill="currentColor"':'fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"')+' aria-hidden="true"><path d="'+d+'"/></svg>'}
var IP={play:'M8 5v14l11-7z',pause:'M7 5h3.5v14H7z M13.5 5H17v14h-3.5z',prev:'M6 5v14 M19 5L9 12l10 7z',next:'M18 5v14 M5 5l10 7-10 7z',
  gauge:'M4.5 17a8.5 8.5 0 1 1 15 0 M12 13l4-4 M7 17h.01 M12 8.5h.01 M17 17h.01',scroll:'M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z M8 7.5l4 4 4-4 M8 12.5l4 4 4-4',
  gear:'M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z M19 12a7 7 0 0 0-.1-1.2l2-1.6-2-3.4-2.4 1a7 7 0 0 0-2-1.2L14 3h-4l-.5 2.6a7 7 0 0 0-2 1.2l-2.4-1-2 3.4 2 1.6a7 7 0 0 0 0 2.4l-2 1.6 2 3.4 2.4-1a7 7 0 0 0 2 1.2L10 21h4l.5-2.6a7 7 0 0 0 2-1.2l2.4 1 2-3.4-2-1.6c.1-.4.1-.8.1-1.2z',
  note:'M9 18V5l10-2v13 M9 18a3 3 0 1 1-3-3 3 3 0 0 1 3 3z M19 16a3 3 0 1 1-3-3 3 3 0 0 1 3 3z'};
var mini=document.createElement('div');mini.id='rplayer';mini.hidden=true;
mini.innerHTML='<div class="ppop" hidden></div>'
 +'<div class="pb" hidden>'
 +'<div class="pr">'
 +'<button type="button" data-p="speed" aria-label="Speed">'+pic(IP.gauge)+'</button>'
 +'<button type="button" data-p="vprev" aria-label="Previous verse">'+pic(IP.prev,false,22)+'</button>'
 +'<button type="button" data-p="aplay" class="big" aria-label="Play">'+pic(IP.play,true,24)+'</button>'
 +'<button type="button" data-p="vnext" aria-label="Next verse">'+pic(IP.next,false,22)+'</button>'
 +'<button type="button" data-p="sgo" aria-label="Start scrolling">'+pic(IP.scroll)+'</button>'
 +'</div>'
 +'<div class="pt"><span class="pcur"></span><input class="pseek" type="range" min="0" max="1000" value="0" aria-label="Position"><button type="button" class="pclose" data-p="close" aria-label="Minimise controls">'+pic('M6 9l6 6 6-6',false,20)+'</button></div>'
 +'</div>'
 +'<button type="button" class="mh" data-p="handle" aria-label="Reading controls">\uD83C\uDFB5</button>';
document.body.appendChild(mini);
var miniOpen=false,miniT=0,popOpen='',seeking=false,pb=mini.querySelector('.pb'),pp=mini.querySelector('.ppop'),pseek=mini.querySelector('.pseek');
function miniFade(){clearTimeout(miniT);mini.classList.remove('dim');miniT=setTimeout(function(){if(A.on||S.on)mini.classList.add('dim')},3500)}
function nVerses(){return rt.querySelectorAll('.vs').length}
function updateSeek(){
  if(!mini||seeking)return;
  var cur=mini.querySelector('.pcur'),n=nVerses();
  if(S.on||S.paused){pseek.value=n>1?Math.round((S.v-1)/(n-1)*1000):0;cur.textContent='Verse '+S.v+' / '+n}
  else{
    var h=document.documentElement.scrollHeight-window.innerHeight,f=h>0?window.scrollY/h:0;
    pseek.value=Math.round(f*1000);cur.textContent=Math.round(f*100)+'%';
  }
}
function paintPop(){
  if(!popOpen){pp.hidden=true;return}
  pp.hidden=false;
  pp.innerHTML='<div class="pp-row"><span>Voice speed</span><input id="ppRate" type="range" min="0.5" max="2" step="0.05" value="'+P.rate+'"><b id="ppRateV">'+P.rate.toFixed(2)+'×</b></div>'
   +'<div class="pp-row"><span>Scroll speed</span><input id="ppScroll" type="range" min="1" max="200" step="1" value="'+(201-P.ms)+'"><small>Slow ‹ › Fast</small></div>';
}
function paintMini(){
  var audio=S.on||S.paused;
  pb.hidden=!miniOpen;
  mini.classList.toggle('open',miniOpen);
  mini.classList.toggle('live',A.on||S.on);
  var ap=mini.querySelector('[data-p="aplay"]');
  ap.innerHTML=pic(S.on?IP.pause:IP.play,true,26);ap.setAttribute('aria-label',S.on?'Pause':'Play');
  var sg=mini.querySelector('[data-p="sgo"]');
  sg.innerHTML=pic(A.on&&!A.paused?IP.pause:IP.scroll,A.on&&!A.paused);sg.classList.toggle('on',A.on);
  sg.setAttribute('aria-label',A.on?(A.paused?'Resume scrolling':'Pause scrolling'):'Start scrolling');
  mini.querySelector('[data-p="vprev"]').disabled=mini.querySelector('[data-p="vnext"]').disabled=!audio&&false;
  paintPop();updateSeek();
}
function refreshMini(){
  if(!mini)return;
  var on=L.view==='read';
  mini.hidden=!on;if(typeof paintFab==='function')paintFab();
  if(!on){miniOpen=false;popOpen='';spk.setAttribute('aria-pressed','false');return}
  paintMini();miniFade();
}
function stepVerse(d){
  var n=nVerses(),active=S.on||S.paused,v=clamp((active?S.v:firstVisible())+d,1,Math.max(1,n));
  if(S.on)play(v);
  else if(S.paused){S.v=v;markNow(v,true);updateSeek()}
  else scrollToVerse(v);
}
function firstVisible(){
  var els=rt.querySelectorAll('.vs'),i;
  for(i=0;i<els.length;i++){if(els[i].getBoundingClientRect().bottom>120)return+els[i].dataset.v}
  return 1;
}
mini.addEventListener('click',function(e){
  var b=e.target.closest('button');if(!b||!b.dataset.p)return;
  var m=b.dataset.p;
  if(m==='close'){miniOpen=false;popOpen='';paintMini();miniFade();return}
  if(m==='handle'){miniOpen=!miniOpen;if(!miniOpen)popOpen='';paintMini();miniFade();return}
  if(m==='speed'){popOpen=popOpen?'':'speed';paintPop();miniFade();return}
  if(m==='vprev')stepVerse(-1);
  else if(m==='vnext')stepVerse(1);
  else if(m==='aplay'){if(S.on)pauseAudio();else play(S.paused?S.v:firstVisible())}
  else if(m==='sgo'){
    if(!A.on)startScroll();else{A.paused=!A.paused;A.last=0}
    paintMini();
  }
  miniFade();
});
pseek.addEventListener('input',function(){
  seeking=true;var f=pseek.value/1000,cur=mini.querySelector('.pcur');
  if(S.on||S.paused){var n=nVerses(),v=Math.round(f*(n-1))+1;cur.textContent='Verse '+v+' / '+n}
  else{window.scrollTo(0,f*(document.documentElement.scrollHeight-window.innerHeight));cur.textContent=Math.round(f*100)+'%'}
  miniFade();
});
pseek.addEventListener('change',function(){
  var f=pseek.value/1000;seeking=false;
  if(S.on||S.paused){var n=nVerses(),v=Math.round(f*(n-1))+1;if(S.on)play(v);else{S.v=v;markNow(v,true)}}
  updateSeek();
});
pp.addEventListener('input',function(e){
  if(e.target.id==='ppRate'){P.rate=+e.target.value;$('ppRateV').textContent=P.rate.toFixed(2)+'×';saveP()}
  else if(e.target.id==='ppScroll'){P.ms=clamp(201-(+e.target.value),1,200);saveP()}
  miniFade();
});
pp.addEventListener('change',function(e){if(e.target.id==='ppRate')restartIfPlaying()});
var scT=0;
window.addEventListener('scroll',function(){if(scT||!miniOpen||S.on||S.paused)return;scT=requestAnimationFrame(function(){scT=0;updateSeek()})},{passive:true});

/* the speaker in the top pill is the handle: it presses the original round handle (hidden) */
var spk=$('rSpk');spk.innerHTML=pic(IP.play,false,18).replace('M8 5v14l11-7z','M11 5L6 9H3v6h3l5 4z M15.5 8.5a5 5 0 0 1 0 7 M18.5 5.5a9 9 0 0 1 0 13');
$('rMore').innerHTML=UI.icon('chevron',16).replace('<svg ','<svg style="transform:rotate(90deg)" ');
spk.onclick=function(){mini.querySelector('.mh').click();spk.setAttribute('aria-pressed',String(miniOpen));if(L.bars)L.bars.refresh()};
/* a little see-through while the page scrolls (never blocks taps) */
var sdT=0;
window.addEventListener('scroll',function(){if(!miniOpen)return;mini.classList.add('sdim');clearTimeout(sdT);sdT=setTimeout(function(){mini.classList.remove('sdim')},700)},{passive:true});

var restartT=0;
function restartIfPlaying(){
  if(!S.on)return;
  clearTimeout(restartT);
  restartT=setTimeout(function(){if(S.on)play(S.v)},450);
}

/* ================= reading options (gear button) ================= */
var sheetName='',optsM=null;
function refreshDock(){refreshMini()}
function closeSheet(){if(optsM){optsM.close();optsM=null}}
function renderSheetSoft(){paintMini();if(optsM)drawOpts()}
function seg(items,attr,cur){return'<div class="seg">'+items.map(function(i){return'<button type="button" '+attr+'="'+esc(i[0])+'" aria-pressed="'+(i[0]===cur)+'">'+esc(i[1])+'</button>'}).join('')+'</div>'}
function tgl(act,label,on){return'<button type="button" class="tgl" data-act="'+act+'" aria-pressed="'+!!on+'"><span>'+label+'</span><i></i></button>'}
function rng(id,label,min,max,step,val,txt){return'<label class="rng">'+label+' <b id="'+id+'V">'+txt+'</b><input id="'+id+'" type="range" min="'+min+'" max="'+max+'" step="'+step+'" value="'+val+'"></label>'}
function voiceSelect(lang){
  var k=langKey(lang),label=B.langName(lang),list=(voices||[]).filter(function(v){return langKey(v.lang)===k});
  var cur=P.voices[k]||'';
  var h='<label class="field">'+esc(label)+' voice<select id="vo_'+k+'" data-voice="'+k+'"><option value="">Automatic</option>';
  list.forEach(function(v){
    var id=String(v.voiceURI||''),m=id.match(/x-([a-z0-9]+)-?(.*)$/i),short=m?(m[1]+(m[2]?' '+m[2]:'')):id;
    h+='<option value="'+esc(id)+'"'+(id===cur?' selected':'')+'>'+esc((v.name||v.lang)+' · '+short)+'</option>';
  });
  h+='</select></label>';
  if(!list.length)h+='<p class="note">No '+esc(label)+' voice found on this phone.'+(native?' <button type="button" class="linkbtn" data-act="installvoice">Open voice settings</button>':'')+'</p>';
  return h;
}
function drawOpts(){
  if(!optsM)return;
  var h='',seen={};
  h+='<div class="sec-t">While scrolling</div>';
  h+=tgl('next','Continue to the next chapter',P.autoNext)+tgl('mark','Mark chapters read when finished',P.autoMark);
  h+=tgl('nom','Go to the next chapter after marking as read',P.nextOnMark);
  h+=tgl('nums','Verse numbers',P.nums);
  if(data.length>1)h+=tgl('vlab','Show version names on each verse',P.vlabels);
  h+='<div class="sec-t">Audio</div>';
  if(data.length>1){var rid=readIds().length>1?'all':readIds()[0];h+='<div class="lbl">Read aloud</div>'+seg(data.map(function(d){return[d.id,d.t.short]}).concat([['all','All']]),'data-read',rid)}
  h+=rng('pitchR','Pitch',0.5,2,0.05,P.pitch,P.pitch.toFixed(2));
  data.forEach(function(d){var k=langKey(d.t.lang);if(seen[k])return;seen[k]=1;h+=voiceSelect(d.t.lang)});
  h+='<button type="button" class="linkbtn" data-act="layout">Fonts, colours and layout in Settings ›</button>';
  optsM.body.innerHTML=h;
}
function openOptions(){
  if(optsM)return;
  optsM=UI.modal({title:'Reading options',sheet:true,body:'<div class="ropts"></div>',onClose:function(){optsM=null}});
  var box=optsM.body.querySelector('.ropts');
  optsM.body=Object.assign(optsM.body,{});
  drawOpts();
  loadVoices().then(function(){if(optsM)drawOpts()});
  optsM.body.addEventListener('click',function(e){
    var t=e.target.closest('button');if(!t)return;var d=t.dataset;
    if(d.read){P.read=d.read;saveP();drawOpts();restartIfPlaying()}
    else if(d.act==='next'){P.autoNext=!P.autoNext;saveP();drawOpts()}
    else if(d.act==='mark'){P.autoMark=!P.autoMark;saveP();drawOpts()}
    else if(d.act==='nom'){P.nextOnMark=!P.nextOnMark;saveP();drawOpts()}
    else if(d.act==='nums'){P.nums=!P.nums;saveP();drawOpts();render()}
    else if(d.act==='vlab'){P.vlabels=!P.vlabels;saveP();drawOpts();render()}
    else if(d.act==='layout'){closeSheet();L.openSettings('sc-readerlayout')}
    else if(d.act==='installvoice'&&TTSP){TTSP.openInstall().catch(function(){})}
  });
  optsM.body.addEventListener('input',function(e){
    var id=e.target.id;
    if(id==='szR')setSize(+e.target.value,true);
    else if(id==='pitchR'){P.pitch=+e.target.value;$('pitchRV').textContent=P.pitch.toFixed(2);saveP()}
  });
  optsM.body.addEventListener('change',function(e){
    var id=e.target.id;
    if(id==='pitchR')restartIfPlaying();
    else if(e.target.dataset&&e.target.dataset.voice){P.voices[e.target.dataset.voice]=e.target.value;saveP();restartIfPlaying()}
  });
}

/* ================= view lifecycle ================= */
L.back.push(function(){
  if(L.view!=='read')return false;
  if(sel.size){clearSel();return true}        /* Back cancels a selection first, then closes the sheet */
  return false;
});
L.onShow.push(function(name){
  var inRead=name==='read';
  if(inRead){
    var pv=pendingV;pendingV=0;
    render().then(function(){if(pv)scrollToVerse(pv);else window.scrollTo(0,0)});
    refreshDock();
  }else{
    mini.hidden=true;closeSheet();stopScroll();if(S.on||S.paused)stopAudio();
    clearSel();bar.hidden=true;document.body.classList.remove('selecting');
    if(name==='home')refreshHome();
  }
});
/* Settings (fonts, colours per translation, layout, verse backgrounds) and the version list can change while the reader is open */
L.on('settings',function(){if(L.view==='read')render()});
L.on('versions',function(){
  pruneVers();
  if(L.view==='read'){render();renderSheetSoft()}
});
function refreshHome(){
  var e=$('readNow');
  if(e)e.textContent='Continue reading · '+BOOKS[pos.b].n+' '+pos.c;
}

B.ready.then(function(){verReady=true;pruneVers();refreshHome()});
refreshHome();
/* ================= settings hooks: keep screen on, hide menu bar, size, version ================= */
(function(){
  var lastY=0,hidden=false;
  function barHide(h){hidden=h;document.body.classList.toggle('rbar-hide',h&&L.view==='read')}
  function applyBar(){
    if(L.view!=='read'){barHide(false);return}
    if(P.hideBar==='always')barHide(true);else barHide(false);
  }
  window.addEventListener('scroll',function(){
    if(L.view!=='read'||P.hideBar!=='scroll')return;
    var y=window.scrollY,d=y-lastY;
    if(Math.abs(d)>14){barHide(d>0&&y>80);lastY=y}
  },{passive:true});
  function awake(){keepAwake(L.view==='read'&&P.awake)}
  document.addEventListener('visibilitychange',function(){if(!document.hidden)awake()});
  L.onShow.push(function(){applyBar();awake()});
  /* in "always" mode a tap on the page edge-top brings the bars back for a moment */
  L.readerPrefs={
    get:function(){return P},
    set:function(k,v){
      if(k==='size')setSize(v,true);
      else if(k==='version'){choosePrimary(v);if(L.view==='read')render()}
      else{P[k]=v;saveP()}
      applyBar();awake();
    }
  };
})();
})();

/* parallel view: tap a version label to copy or share just that version's verse */
(function(){
  var L=window.Lectio,UI=L.ui,B=L.bible,rt=document.getElementById('rText');if(!rt)return;
  rt.addEventListener('click',function(e){
    var lab=e.target.closest('.vl');if(!lab)return;
    e.stopPropagation();e.preventDefault();
    var p=lab.closest('.vt'),vs=lab.closest('.vs');if(!p||!vs)return;
    var v=+vs.dataset.v,v0=B.version(p.dataset.tid),txt=p.textContent.replace(lab.textContent,'').trim();
    var bk=L.curBook,ch=(document.getElementById('rCh')||{}).textContent;
    var ref=B.refName(bk,+ch,v)+' ('+(v0?v0.short:'')+')',full=ref+'\n'+txt;
    UI.actionSheet({title:ref,items:[
      {label:'Copy with reference',icon:'copy',on:function(){UI.copy(full).then(function(ok){L.toast(ok?'Copied':'Could not copy')})}},
      {label:'Share',icon:'share',on:function(){UI.share({title:ref,text:full+'\n\nShared from Lectio'})}}
    ]});
  },true);



})();
