package com.leo.lectio;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
