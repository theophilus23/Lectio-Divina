import sys; sys.path.insert(0,'test')
from harness import app
with app(width=360,height=740) as (page,base):
    page.goto(base); page.wait_for_timeout(700)
    page.screenshot(path='/tmp/m0.png')
    page.evaluate('Lectio.go("settings")'); page.wait_for_timeout(400); page.screenshot(path='/tmp/m1.png')
    page.evaluate("Lectio.openReader(42,3)"); page.wait_for_timeout(500)
    page.evaluate("Lectio.openReader(0,1)"); page.wait_for_timeout(500)
    page.evaluate('Lectio.pop.history()'); page.wait_for_timeout(400); page.screenshot(path='/tmp/m2.png')
    page.click('.umodal [data-x]'); page.wait_for_timeout(200)
    page.click('#topbar [data-link="act:more"]'); page.wait_for_timeout(300); page.click('text=Library >> visible=true'); page.wait_for_timeout(300); page.screenshot(path='/tmp/m3.png')
    print(page.errors)
