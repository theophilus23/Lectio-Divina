#!/usr/bin/env node
/* Converts raw Bible JSON files into the app's format and updates www/bibles/manifest.json.
 *
 *   npm run bibles                      builds every folder in bible-sources/  (each needs an info.json)
 *   node tools/add-bible.js <folder> --id niv --name "New International Version" --short NIV --lang en-US
 *                                       builds one folder (and writes info.json for you)
 *
 * Output: www/bibles/<id>/0.json ... 65.json (one file per book, Genesis = 0), a list of chapters, each a list of verse strings.
 */
var fs = require('fs'), path = require('path');
var P = require('../www/bibleparse.js');
var ROOT = path.join(__dirname, '..'), SRC = path.join(ROOT, 'bible-sources'), OUT = path.join(ROOT, 'www', 'bibles');

function walk(d) {
  var r = [];
  fs.readdirSync(d, { withFileTypes: true }).forEach(function (e) {
    var p = path.join(d, e.name);
    if (e.isDirectory()) r = r.concat(walk(p));
    else if (/\.json$/i.test(e.name) && e.name.toLowerCase() !== 'info.json') r.push(p);
  });
  return r;
}
function build(dir, info) {
  if (!/^[a-z0-9_-]+$/.test(info.id || '')) throw new Error('info.id must be lowercase letters, digits, - or _ (got "' + info.id + '")');
  var books = new Array(66), files = walk(dir).sort();
  if (!files.length) throw new Error('No .json files in ' + dir);
  files.forEach(function (f) {
    var j;
    try { j = JSON.parse(fs.readFileSync(f, 'utf8').replace(/^﻿/, '')); } catch (e) { console.warn('  skip (not valid JSON): ' + path.relative(dir, f)); return; }
    var hint = P.bookFromFileName(path.basename(f));
    var before = books.filter(Boolean).length;
    P.parseBible(j, books, hint);
    if (books.filter(Boolean).length === before) console.warn('  nothing recognised in ' + path.relative(dir, f) + ' (rename it to the book name, e.g. Genesis.json or 1.json)');
  });
  var missing = [];
  for (var i = 0; i < 66; i++) if (!books[i]) missing.push(i);
  var od = path.join(OUT, info.id);
  fs.mkdirSync(od, { recursive: true });
  for (i = 0; i < 66; i++) if (books[i]) fs.writeFileSync(path.join(od, i + '.json'), JSON.stringify(books[i]));
  var names = P.NAMES || [];
  console.log('  ' + info.id + ': ' + (66 - missing.length) + '/66 books' + (missing.length ? ' (missing: ' + missing.map(function (m) { return names[m] || m; }).join(', ') + ')' : ''));
  return { id: info.id, name: info.name || info.id.toUpperCase(), short: info.short || info.id.toUpperCase(), lang: info.lang || 'en-US', dir: info.id };
}
function writeManifest(entries) {
  var mf = path.join(OUT, 'manifest.json'), cur = { versions: [] };
  try { cur = JSON.parse(fs.readFileSync(mf, 'utf8')); } catch (e) {}
  entries.forEach(function (e) {
    var k = cur.versions.findIndex(function (v) { return v.id === e.id; });
    if (k > -1) cur.versions[k] = e; else cur.versions.push(e);
  });
  fs.writeFileSync(mf, JSON.stringify(cur, null, 2) + '\n');
  console.log('manifest.json now lists: ' + cur.versions.map(function (v) { return v.id; }).join(', '));
}
function arg(n) { var i = process.argv.indexOf('--' + n); return i > -1 ? process.argv[i + 1] : undefined; }

var first = process.argv[2], out = [];
if (first && first[0] !== '-') {
  var dir = path.resolve(first), id = arg('id');
  if (!id) { console.error('Missing --id (for example --id niv)'); process.exit(1); }
  var info = { id: id, name: arg('name'), short: arg('short'), lang: arg('lang') };
  out.push(build(dir, info));
} else {
  if (!fs.existsSync(SRC)) { console.log('No bible-sources folder.'); process.exit(0); }
  fs.readdirSync(SRC, { withFileTypes: true }).forEach(function (e) {
    if (!e.isDirectory() || e.name[0] === '_') return;
    var d = path.join(SRC, e.name), ip = path.join(d, 'info.json');
    if (!fs.existsSync(ip)) { console.warn('skip ' + e.name + ': no info.json'); return; }
    console.log('Building ' + e.name);
    var info = JSON.parse(fs.readFileSync(ip, 'utf8')); info.id = info.id || e.name;
    out.push(build(d, info));
  });
}
if (out.length) writeManifest(out);
