/* Navigation dock (gesture dock): a small translucent button you can drag anywhere.
   Touch = Back.  Touch, hold and release in the middle = nothing.  Touch, hold and slide:
   left = previous page, right = forward page, up / down / the four diagonals = pages you choose in Settings. */
(function(){
var L=window.Lectio,UI=L.ui,KEY='lectio-fdock',MAPKEY='lectio-dock-map';
var PAGES=[['home','Today'],['lib','Bible'],['read','Reader'],['search','Search'],['songs','Songs'],['notes','Journal'],['mypray','Prayer points'],['prayerwall','Prayer wall'],['quiz','Quiz'],['plans','Plans'],['saved','Saved verses'],['settings','Settings'],['none','Nothing']];
var SLOTS=[['up','Slide up'],['down','Slide down'],['ul','Slide up-left'],['ur','Slide up-right'],['dl','Slide down-left'],['dr','Slide down-right']];
var DEF={up:'lib',down:'notes',ul:'search',ur:'mypray',dl:'quiz',dr:'settings'};
var map=Object.assign({},DEF);
try{Object.assign(map,JSON.parse(localStorage.getItem(MAPKEY)||'{}'))}catch(e){}
function saveMap(){try{localStorage.setItem(MAPKEY,JSON.stringify(map))}catch(e){}}
function pname(id){var p=PAGES.filter(function(x){return x[0]===id})[0];return p?p[1]:''}
var el=document.createElement('div');el.id='fdock';
el.innerHTML='<div class="fd-tip" hidden></div><button type="button" class="fd-btn" aria-label="Navigation dock"><i></i></button>';
document.body.appendChild(el);
var btn=el.querySelector('.fd-btn'),tip=el.querySelector('.fd-tip'),pos={x:null,y:null};
try{pos=JSON.parse(localStorage.getItem(KEY)||'{}')}catch(e){}
function W(){return window.innerWidth}function H(){return window.innerHeight}
function place(){
  var s=46,x=pos.x==null?W()-s-10:pos.x,y=pos.y==null?H()*0.62:pos.y;
  x=Math.max(4,Math.min(W()-s-4,x));y=Math.max(4,Math.min(H()-s-4,y));
  pos.x=x;pos.y=y;el.style.left=x+'px';el.style.top=y+'px';
}
function save(){try{localStorage.setItem(KEY,JSON.stringify(pos))}catch(e){}}
var idleT=0;
function idle(){clearTimeout(idleT);el.classList.remove('idle');idleT=setTimeout(function(){el.classList.add('idle')},2200)}
function openPage(id){
  if(!id||id==='none')return;
  if(id==='read'){L.openReader();return}
  if(L.view!==id)L.go(id);
}
function doBack(){
  if(L.view==='home'&&!document.body.classList.contains('modalopen')){return}
  L.goBack();
}
/* 8 sectors from the touch point: angle 0 = right */
function action(dx,dy){
  if(Math.hypot(dx,dy)<34)return{label:'Stay here',run:function(){}};
  var a=Math.atan2(dy,dx)*180/Math.PI;   /* -180..180, y down */
  var k=Math.round(a/45);                /* -4..4 */
  var key={0:'r',1:'dr',2:'down','3':'dl',4:'l','-4':'l','-3':'ul','-2':'up','-1':'ur'}[k];
  if(key==='r')return{label:L.canForward&&L.canForward()?'Forward':'Forward (none)',run:function(){if(!L.goForward())L.toast('No page to go forward to')}};
  if(key==='l')return{label:'Back',run:doBack};
  var id=map[key];
  return{label:pname(id)||'Nothing',run:function(){openPage(id)}};
}
var down=null,holdT=0,moved=false;
btn.addEventListener('pointerdown',function(e){
  e.preventDefault();try{btn.setPointerCapture(e.pointerId)}catch(x){}
  down={x:e.clientX,y:e.clientY,px:pos.x,py:pos.y,held:false};moved=false;
  el.classList.remove('idle');clearTimeout(idleT);
  holdT=setTimeout(function(){
    if(moved||!down)return;
    down.held=true;el.classList.add('held');
    if(navigator.vibrate)try{navigator.vibrate(12)}catch(x){}
    tip.textContent='Stay here';tip.hidden=false;
  },380);
});
btn.addEventListener('pointermove',function(e){
  if(!down)return;
  var dx=e.clientX-down.x,dy=e.clientY-down.y;
  if(down.held){tip.textContent=action(dx,dy).label;return}
  if(!moved&&Math.abs(dx)+Math.abs(dy)>8){moved=true;clearTimeout(holdT)}
  if(moved){pos.x=down.px+dx;pos.y=down.py+dy;place()}
});
function end(e){
  if(!down)return;clearTimeout(holdT);
  var d=down;down=null;el.classList.remove('held');tip.hidden=true;
  if(d.held){action(e.clientX-d.x,e.clientY-d.y).run();idle();return}
  if(moved){save();idle();return}
  doBack();idle();
}
btn.addEventListener('pointerup',end);
btn.addEventListener('pointercancel',function(){down=null;clearTimeout(holdT);el.classList.remove('held');tip.hidden=true;idle()});
window.addEventListener('resize',place);
var ON=true;try{ON=localStorage.getItem('lectio-dock-on')!=='0'}catch(e){}
function applyOn(){el.hidden=!ON}
applyOn();place();idle();
L.addSettingsCard({id:'dock',order:55,render:function(c){
  c.innerHTML='<h3>Navigation dock</h3><p class="note">A small round button over every page. Drag it to move it. <b>Touch</b>: back. <b>Touch, hold, release in the middle</b>: nothing (stay on this page). <b>Hold and slide left</b>: previous page. <b>Hold and slide right</b>: forward page. Hold and slide up, down or diagonally to open the pages you choose below.</p>'
    +'<button type="button" class="tgl" id="dkOn" aria-pressed="'+ON+'"><span>Show the navigation dock</span><i></i></button>'
    +'<div class="dk-grid">'+SLOTS.map(function(s){
      return'<label class="field">'+s[1]+'<select data-slot="'+s[0]+'">'+PAGES.map(function(p){return'<option value="'+p[0]+'"'+(map[s[0]]===p[0]?' selected':'')+'>'+p[1]+'</option>'}).join('')+'</select></label>';
    }).join('')+'</div>'
    +'<div class="row"><button type="button" class="btn" id="dkReset">Move back to the corner</button></div>';
  c.querySelector('#dkOn').onclick=function(){ON=!ON;try{localStorage.setItem('lectio-dock-on',ON?'1':'0')}catch(e){}this.setAttribute('aria-pressed',String(ON));applyOn()};
  c.querySelector('#dkReset').onclick=function(){pos={x:null,y:null};place();save();L.toast('Dock moved to the corner')};
  c.addEventListener('change',function(e){var t=e.target;if(t.dataset&&t.dataset.slot){map[t.dataset.slot]=t.value;saveMap()}});
}});
})();
