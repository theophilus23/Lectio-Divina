import sys; sys.path.insert(0,'test')
from harness import app
with app(width=360,height=740) as (page,base):
    page.goto(base); page.wait_for_timeout(700)
    page.evaluate("""(()=>{const L=Lectio;
      L.coll('notes').put({title:'Sunday sermon',cat:'Sermon',ts:Date.now(),blocks:[{t:'text',h:'Main',x:'Grace upon grace'}]});
      L.coll('saved').put({src:'bible',ref:'John 3:16',b:42,c:3,v1:16,v2:16,tx:[{s:'KJV',t:'For God so loved the world'}],ts:Date.now()-86400000});
      L.coll('hl').put({b:42,c:3,v:3,col:'y',tx:[{s:'KJV',t:'Jesus answered'}],ts:Date.now()-5000});})()""")
    page.evaluate("Lectio.go('notes')"); page.wait_for_timeout(500); page.screenshot(path='/tmp/j0.png')
    page.click('#jpill [data-link="act:jmenu"], #jpill .bbtn:last-child'); page.wait_for_timeout(300); page.click('text=Recent'); page.wait_for_timeout(300); page.screenshot(path='/tmp/j1.png')
    page.click('[data-src=saved]'); page.wait_for_timeout(200)
    print('saved cards',page.eval_on_selector_all('.j-verse','e=>e.length'))
    page.click('[data-src=all]'); page.click('[data-open]'); page.wait_for_timeout(300)
    page.click('[data-act=more]'); page.wait_for_timeout(300); page.screenshot(path='/tmp/j2.png')
    print(page.errors)
