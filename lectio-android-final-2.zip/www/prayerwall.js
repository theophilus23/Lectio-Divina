/* Prayer wall: requests from everyone (members and guests), two lists (praying / answered), reactions, thank-you notes. */
(function(){
'use strict';
var L=window.Lectio,$=L.$,esc=L.esc,UI=L.ui;
var CATS=[['family','Family'],['health','Health'],['church','Church'],['nation','Nation'],['work','Work & Study'],['finances','Finances'],['thanks','Thanksgiving'],['others','Others']];
var EMOJI=['🙏','❤️','🙌','😇','💯','🕊️','✝️','🔥','😢','🙂','🤗','😷'];
var S={tab:'open',cat:'all',rows:null,busy:false,err:''};
function catName(id){var c=CATS.filter(function(x){return x[0]===id})[0];return c?c[1]:'Others'}
function uid(){return L.user?L.user.uid:null}

var el=L.registerView({id:'prayerwall',title:'Prayer wall',menu:{label:'Prayer wall',icon:'people',group:'pray',order:10},show:function(){draw();load()}});

async function load(){
  if(!L.fb.on){S.err='The prayer wall needs the online setup (Firebase) to be switched on.';draw();return}
  S.busy=true;S.err='';draw();
  try{
    var s=await L.fb.db.collection('prayerwall').orderBy('t','desc').limit(100).get(),rows=[];
    s.forEach(function(d){var x=d.data();x.id=d.id;rows.push(x)});S.rows=rows;
  }catch(e){S.err='Could not load requests. Check your connection.'}
  S.busy=false;if(L.view==='prayerwall')draw();
}
/* the free, hosted page anyone can scan or open without the app — see portal/index.html */
function portalUrl(){
  var id=(window.LECTIO_FIREBASE||{}).projectId;
  return id?'https://'+id+'.web.app/':'';
}
function openQr(){
  var url=portalUrl();
  if(!url){UI.modal({title:'Prayer request QR code',body:'<p class="mtext">This needs the online setup (Firebase) switched on first — see FIREBASE_SETUP.md.</p>',actions:[{label:'OK'}]});return}
  var m=UI.modal({title:'Scan to post a prayer',sheet:true,body:
    '<p class="muted" style="margin-top:0">Print this, display it at church, or share it anywhere. Anyone who scans it — no app required — lands on a page where they can post a prayer request, and edit or delete it later.</p>'+
    '<div id="pwQrBox" style="text-align:center;background:var(--surface2,#fff);border-radius:14px;padding:18px;margin:14px 0"></div>'+
    '<p class="note" style="word-break:break-all;text-align:center">'+esc(url)+'</p>',
    actions:[{label:'Copy link',on:function(){UI.copy(url).then(function(ok){L.toast(ok?'Link copied':'Could not copy')});return false}},
      {label:'Share',kind:'main',on:function(){UI.share({title:'Post a prayer request',text:'Share a prayer request with us — no app needed:\n'+url});return false}}]});
  try{
    var qr=qrcode(0,'M');qr.addData(url);qr.make();
    m.body.querySelector('#pwQrBox').innerHTML=qr.createSvgTag({cellSize:5,margin:2});
  }catch(e){m.body.querySelector('#pwQrBox').textContent='Could not draw the QR code.'}
}
function draw(){
  var h='<div class="head"><div class="eyebrow">Pray together</div><h1>Prayer wall</h1><p>Share a need. Pray for one another.</p></div>';
  h+='<div class="row" style="justify-content:flex-end;margin:-6px 0 6px"><button type="button" class="linkbtn" id="pwQrBtn">'+UI.icon('qr',16)+' Share QR code</button></div>';
  h+='<div class="seg">'+[['open','Needs prayer'],['ans','Answered']].map(function(t){return'<button type="button" data-tab="'+t[0]+'" aria-pressed="'+(S.tab===t[0])+'">'+t[1]+'</button>'}).join('')+'</div>';
  h+='<div class="chips hscroll" style="margin-top:10px"><button type="button" class="chip" data-cat="all" aria-pressed="'+(S.cat==='all')+'">All</button>'+CATS.map(function(c){return'<button type="button" class="chip" data-cat="'+c[0]+'" aria-pressed="'+(S.cat===c[0])+'">'+esc(c[1])+'</button>'}).join('')+'</div>';
  if(S.err)h+='<p class="empty">'+esc(S.err)+'</p>';
  else if(S.rows===null)h+='<p class="empty">Loading…</p>';
  else{
    var list=S.rows.filter(function(r){return(S.tab==='ans'?r.ans:!r.ans)&&(S.cat==='all'||r.cat===S.cat)});
    if(!list.length)h+='<p class="empty">'+(S.tab==='ans'?'No answered prayers yet.':'No requests here yet. Post the first one.')+'</p>';
    h+='<div class="list">'+list.map(card).join('')+'</div>';
  }
  if(S.tab!=='ans')h+='<button class="fab" id="pwNew" type="button" aria-label="Post a request">'+UI.icon('plus',22)+'</button>';
  el.innerHTML=h;
}
function card(r){
  var me=uid(),mine=me&&r.uid===me,rc=r.r||{},cnt={};
  Object.keys(rc).forEach(function(u){cnt[rc[u]]=(cnt[rc[u]]||0)+1});
  var h='<div class="li pwc" data-id="'+esc(r.id)+'"><div class="row2"><b class="t">'+esc(r.title||'Prayer request')+'</b><span class="tag">'+esc(catName(r.cat))+'</span></div>';
  h+='<div class="meta muted">'+esc(r.name||'Anonymous')+' · '+UI.fmt.ago(r.t)+'</div>';
  if(r.text)h+='<div class="body">'+esc(r.text).replace(/\n/g,'<br>')+'</div>';
  if(r.ans)h+='<div class="pw-thanks"><b>Answered'+(r.at?' · '+UI.fmt.date(r.at):'')+'</b>'+(r.thanks?'<p>'+esc(r.thanks).replace(/\n/g,'<br>')+'</p>':'')+'</div>';
  h+='<div class="pw-react">'+Object.keys(cnt).sort(function(x,y){return cnt[y]-cnt[x]}).map(function(k){return'<button type="button" class="chip" data-r="'+esc(k)+'" aria-pressed="'+(me&&rc[me]===k)+'">'+esc(k)+' '+cnt[k]+'</button>'}).join('')+'<button type="button" class="chip" data-a="react" aria-label="Add reaction">'+UI.icon('plus',14)+'</button></div>';
  h+='<div class="acts">';
  if(mine){
    if(!r.ans)h+='<button class="btn" data-a="ans">Mark answered</button>';else h+='<button class="btn" data-a="thank">Edit thank-you</button>';
    h+='<button class="btn" data-a="edit">Edit</button><button class="btn danger" data-a="del">Delete</button>';
  }else h+='<button class="btn" data-a="report">Report</button>';
  h+='<button class="btn" data-a="share">Share</button></div></div>';
  return h;
}
function find(id){return(S.rows||[]).filter(function(r){return r.id===id})[0]}

async function compose(pre,editing){
  var id=await L.ensureIdentity({reason:'to post on the prayer wall'});if(!id)return;
  var d={title:editing?editing.title:(pre&&pre.title)||'',text:editing?editing.text:(pre&&pre.text)||'',cat:editing?editing.cat:CATS.some(function(c){return c[1]===(pre&&pre.cat)})?CATS.filter(function(c){return c[1]===pre.cat})[0][0]:'family',anon:editing?editing.name==='Anonymous':false};
  var m=UI.modal({title:editing?'Edit request':'Post a prayer request',body:
    '<label class="field">Title<input id="pwT" maxlength="80" value="'+esc(d.title)+'"></label>'+
    '<label class="field">Details<textarea id="pwX" class="ta" rows="5" maxlength="1500">'+esc(d.text)+'</textarea></label>'+
    '<label class="field">Category<select id="pwC">'+CATS.map(function(c){return'<option value="'+c[0]+'"'+(c[0]===d.cat?' selected':'')+'>'+esc(c[1])+'</option>'}).join('')+'</select></label>'+
    '<label class="row"><span>Post without my name</span><input type="checkbox" id="pwA"'+(d.anon?' checked':'')+'></label>',
    actions:[{label:'Cancel'},{label:editing?'Save':'Post',kind:'main',keep:true,on:async function(close,mod){
      var t=mod.body.querySelector('#pwT').value.trim(),x=mod.body.querySelector('#pwX').value.trim();
      if(!t){L.toast('Add a title');return}
      var f={title:t.slice(0,80),text:x.slice(0,1500),cat:mod.body.querySelector('#pwC').value,name:mod.body.querySelector('#pwA').checked?'Anonymous':String(id.name||'Reader').slice(0,40)};
      try{
        if(editing)await L.fb.db.collection('prayerwall').doc(editing.id).update(f);
        else await L.fb.db.collection('prayerwall').add(Object.assign({uid:id.uid,t:Date.now(),ans:0,at:0,thanks:'',r:{}},f));
        close();L.toast(editing?'Saved':'Posted');S.tab='open';if(L.view!=='prayerwall')L.go('prayerwall');else load();
      }catch(e){L.toast('Could not post. Try again.')}
    }}]});
}
async function react(r,type){
  var id=await L.ensureIdentity({reason:'to react'});if(!id)return;
  var ref=L.fb.db.collection('prayerwall').doc(r.id),FV=firebase.firestore.FieldValue,cur=(r.r||{})[id.uid];
  r.r=r.r||{};
  try{
    if(cur===type){await ref.update({['r.'+id.uid]:FV.delete()});delete r.r[id.uid]}
    else{await ref.update({['r.'+id.uid]:type});r.r[id.uid]=type}
    draw();
  }catch(e){L.toast('Could not save')}
}
async function answer(r){
  var v=await UI.prompt({title:'Thank you for your prayers',label:'Say thanks (optional): how did God answer?',value:r.thanks||'',multiline:true,ok:'Save'});
  if(v===null)return;
  try{await L.fb.db.collection('prayerwall').doc(r.id).update({ans:1,at:r.at||Date.now(),thanks:v.trim().slice(0,800)});L.toast('Marked answered. Praise God!');S.tab='ans';load()}catch(e){L.toast('Could not save')}
}
async function report(r){
  var id=await L.ensureIdentity({reason:'to report'});if(!id)return;
  var ok=await UI.confirm('Report this request as inappropriate?',{ok:'Report'});if(!ok)return;
  try{await L.fb.db.collection('prayer_reports').doc(r.id+'_'+id.uid).set({pid:r.id,uid:id.uid,t:Date.now()});L.toast('Thanks. We will take a look.')}catch(e){L.toast('Could not send')}
}
el.addEventListener('click',function(e){
  var t=e.target.closest('button');if(!t)return;
  if(t.id==='pwNew'){compose();return}
  if(t.id==='pwQrBtn'){openQr();return}
  if(t.dataset.tab){S.tab=t.dataset.tab;draw();return}
  if(t.dataset.cat){S.cat=t.dataset.cat;draw();return}
  var c=t.closest('.pwc'),r=c&&find(c.dataset.id);if(!r)return;
  if(t.dataset.r)react(r,t.dataset.r);
  else if(t.dataset.a==='react'){var m=UI.modal({title:'React',sheet:true,body:'<div class="pw-emoji">'+EMOJI.map(function(e){return'<button type="button" data-e="'+e+'">'+e+'</button>'}).join('')+'</div>'});m.body.addEventListener('click',function(ev){var b=ev.target.closest('[data-e]');if(!b)return;m.close();react(r,b.dataset.e)})}
  else if(t.dataset.a==='ans'||t.dataset.a==='thank')answer(r);
  else if(t.dataset.a==='edit')compose(null,r);
  else if(t.dataset.a==='report')report(r);
  else if(t.dataset.a==='share')UI.share({title:r.title,text:r.title+'\n'+(r.text||'')+'\n\nPray with me on Lectio'});
  else if(t.dataset.a==='del')UI.confirm('Delete this request?',{ok:'Delete',danger:true}).then(function(ok){if(ok)L.fb.db.collection('prayerwall').doc(r.id).delete().then(function(){S.rows=S.rows.filter(function(x){return x!==r});draw();L.toast('Deleted')}).catch(function(){L.toast('Could not delete')})});
});
L.prayerwall={compose:function(pre){return compose(pre)},open:function(){L.go('prayerwall')}};
})();
