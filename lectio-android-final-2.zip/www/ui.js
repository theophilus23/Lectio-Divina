/* Shared UI helpers: dialogs, action sheets, toast, icons, date formatting, share and copy.
   Loaded before app.js. app.js exposes this as Lectio.ui. */
(function(){
'use strict';
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}

/* ---------- toast ---------- */
var toastT;
function toast(msg){
  var t=document.getElementById('toast');if(!t)return;
  t.textContent=msg;t.classList.add('on');clearTimeout(toastT);toastT=setTimeout(function(){t.classList.remove('on')},2400);
}

/* ---------- icons (24x24, stroked with currentColor) ---------- */
var IC={
  home:'M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z',
  book:'M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2z M4 19a2 2 0 0 1 2-2h13',
  clock:'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18z M12 7v5l3 2',
  bookmark:'M6 3h12v18l-6-4-6 4z',
  note:'M6 3h9l4 4v14H6z M14 3v5h5 M9 13h7 M9 17h5',
  pray:'M12 4c-3 3-5 6-5 10a5 5 0 0 0 5 5 M12 4c3 3 5 6 5 10a5 5 0 0 1-5 5 M12 4v15',
  globe:'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18z M3 12h18 M12 3c3 3 3 15 0 18 M12 3c-3 3-3 15 0 18',
  trophy:'M8 4h8v6a4 4 0 0 1-8 0z M8 6H5v2a3 3 0 0 0 3 3 M16 6h3v2a3 3 0 0 1-3 3 M12 14v4 M8 21h8 M10 18h4',
  people:'M9 5a3 3 0 1 0 0 6 3 3 0 0 0 0-6z M3 20a6 6 0 0 1 12 0 M17 7a2.5 2.5 0 1 1 0 5 M16 14a5 5 0 0 1 6 5',
  search:'M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14z M20 20l-4-4',
  bell:'M6 16v-5a6 6 0 0 1 12 0v5l2 2H4z M10 20a2 2 0 0 0 4 0',
  gear:'M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.9.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z',
  menu:'M4 7h16 M4 12h16 M4 17h16',
  plus:'M12 5v14 M5 12h14',
  trash:'M4 7h16 M9 7V4h6v3 M6 7l1 13h10l1-13',
  edit:'M4 20h4L19 9l-4-4L4 16z',
  share:'M12 3v12 M7 8l5-5 5 5 M5 14v6h14v-6',
  copy:'M11 9h7a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2h-7a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2z M5 15V6a2 2 0 0 1 2-2h9',
  check:'M5 12.5l4.5 4.5L19 7.5',
  x:'M6 6l12 12 M18 6L6 18',
  swap:'M7 4v14 M3 14l4 4 4-4 M17 20V6 M13 10l4-4 4 4',
  calendar:'M4 6h16v14H4z M4 10h16 M8 3v4 M16 3v4',
  more:'M5 12h.01 M12 12h.01 M19 12h.01',
  heart:'M12 20s-7-4.5-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 10c0 5.5-7 10-7 10z',
  star:'M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z',
  clip:'M20 12l-8 8a5 5 0 0 1-7-7l9-9a3.5 3.5 0 0 1 5 5l-9 9a2 2 0 0 1-3-3l8-8',
  chevron:'M9 6l6 6-6 6',
  image:'M4 5h16v14H4z M8.5 10a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z M4 17l5-5 4 4 3-3 4 4',
  quiz:'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18z M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.7.4-1 1-1 1.7 M12 17h.01',
  send:'M4 12l16-8-6 16-3-7z',
  chat:'M4 5h16v11H9l-5 4z',
  file:'M6 3h9l4 4v14H6z M14 3v5h5',
  down:'M6 9l6 6 6-6',
  up:'M6 15l6-6 6 6',
  flag:'M5 21V4 M5 4h12l-2 4 2 4H5',
  highlight:'M4 20h6 M14 4l6 6-9 9H5v-6z',
  qr:'M4 4h6v6H4z M14 4h6v6h-6z M4 14h6v6H4z M17 14v1 M14 14h1 M14 17h3 M14 20h1 M17 17h3 M20 20h-1 M6.5 6.5h1v1h-1z M16.5 6.5h1v1h-1z M6.5 16.5h1v1h-1z'
};
function icon(name,size){
  var d=IC[name]||IC.star,s=size||20;
  return'<svg class="ic" viewBox="0 0 24 24" width="'+s+'" height="'+s+'" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="'+d+'"/></svg>';
}

/* ---------- dates ---------- */
function dt(ts){
  if(!ts)return'';
  try{return new Date(ts).toLocaleString([],{day:'numeric',month:'short',year:'numeric',hour:'numeric',minute:'2-digit'})}catch(e){return new Date(ts).toString()}
}
function date(ts){
  if(!ts)return'';
  try{return new Date(ts).toLocaleDateString([],{day:'numeric',month:'short',year:'numeric'})}catch(e){return new Date(ts).toDateString()}
}
function ago(ts){
  var s=Math.max(0,Math.round((Date.now()-ts)/1000));
  if(s<60)return'just now';
  var m=Math.round(s/60);if(m<60)return m+' min ago';
  var h=Math.round(m/60);if(h<24)return h+' h ago';
  var d=Math.round(h/24);if(d<7)return d+' d ago';
  return date(ts);
}
function days(a,b){return Math.max(0,Math.round((b-a)/86400000))}
/* local calendar day key, e.g. 2026-10-07 */
function dayKey(ts){var d=new Date(ts||Date.now());return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')}
/* value for <input type="datetime-local"> */
function dtLocalValue(ts){var d=new Date(ts||Date.now());return dayKey(ts)+'T'+String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0')}

/* ---------- clipboard + share ---------- */
function copy(text){
  return new Promise(function(res){
    function legacy(){
      try{
        var ta=document.createElement('textarea');ta.value=text;ta.style.cssText='position:fixed;left:-999px;top:0';
        document.body.appendChild(ta);ta.select();var ok=document.execCommand('copy');ta.remove();res(!!ok);
      }catch(e){res(false)}
    }
    if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(text).then(function(){res(true)},legacy)}
    else legacy();
  });
}
function share(o){
  var Cap=window.Capacitor||{},P=Cap.Plugins&&Cap.Plugins.Share;
  var text=o.text||'',title=o.title||'Lectio';
  function fallback(){return copy((title&&text.indexOf(title)!==0?title+'\n\n':'')+text).then(function(ok){toast(ok?'Copied. Paste it anywhere to share.':'Could not share')})}
  if(P&&P.share)return P.share({title:title,text:text,dialogTitle:'Share'}).catch(function(e){if(!/cancel/i.test(String(e&&e.message||e)))return fallback()});
  if(navigator.share)return navigator.share({title:title,text:text}).catch(function(e){if(e&&e.name!=='AbortError')return fallback()});
  return fallback();
}

/* ---------- dialogs ---------- */
var stack=[];
function lockScroll(){document.body.classList.toggle('modalopen',stack.length>0)}
/* modal({title, body:string|Element, actions:[{label,kind:'main'|'danger'|'',keep:bool,on:function(close,modal)}], sheet:bool, wide:bool, onClose})
   Returns {el, body, close(value)}. Tapping outside, the X, or the phone's back button closes it. */
function modal(o){
  o=o||{};
  var root=document.createElement('div');root.className='umodal'+(o.cls?' '+o.cls:'');
  root.setAttribute('role','dialog');root.setAttribute('aria-modal','true');
  var card=document.createElement('div');card.className='ucard'+(o.wide?' wide':'');
  var h='';
  if(o.title!==false)h+='<header class="uhead"><h3>'+esc(o.title||'')+'</h3><button type="button" class="iconbtn" data-x aria-label="Close">'+icon('x',18)+'</button></header>';
  h+='<div class="ubody"></div>';
  if(o.actions&&o.actions.length)h+='<footer class="uacts"></footer>';
  card.innerHTML=h;root.appendChild(card);
  var body=card.querySelector('.ubody');
  if(typeof o.body==='string')body.innerHTML=o.body;else if(o.body)body.appendChild(o.body);
  var closed=false,m={el:root,card:card,body:body};
  m.close=function(v){
    if(closed)return;closed=true;
    var i=stack.indexOf(m);if(i>-1)stack.splice(i,1);
    root.remove();lockScroll();
    if(o.onClose)try{o.onClose(v)}catch(e){}
  };
  if(o.actions&&o.actions.length){
    var f=card.querySelector('.uacts');
    o.actions.forEach(function(a){
      var b=document.createElement('button');b.type='button';
      b.className='btn'+(a.kind==='main'?' main':a.kind==='danger'?' danger':'');
      b.textContent=a.label;
      b.onclick=function(){
        var r=a.on?a.on(m.close,m):undefined;
        if(!a.keep&&r!==false)m.close(a.value);
      };
      f.appendChild(b);
    });
  }
  root.addEventListener('mousedown',function(e){if(e.target===root&&!o.modalOnly)root._down=true});
  root.addEventListener('click',function(e){
    if(e.target===root&&root._down&&!o.modalOnly){root._down=false;m.close()}
    var x=e.target.closest&&e.target.closest('[data-x]');if(x&&card.contains(x))m.close();
  });
  document.body.appendChild(root);stack.push(m);lockScroll();
  return m;
}
function handleBack(){
  if(!stack.length)return false;
  stack[stack.length-1].close();return true;
}
function confirmBox(text,o){
  o=o||{};
  return new Promise(function(res){
    var ans=false;
    modal({title:o.title||'Are you sure?',body:'<p class="mtext">'+esc(text)+'</p>',onClose:function(){res(ans)},actions:[
      {label:o.cancel||'Cancel',value:false},
      {label:o.ok||'OK',kind:o.danger?'danger':'main',on:function(){ans=true}}
    ]});
  });
}
/* prompt({title,label,value,multiline,placeholder,ok,max}) -> Promise<string|null> */
function promptBox(o){
  o=o||{};
  return new Promise(function(res){
    var ans=null;
    var tag=o.multiline?'<textarea class="ta" rows="5"':'<input type="text"';
    var m=modal({title:o.title||'',body:'<label class="field">'+esc(o.label||'')+tag+' id="uprompt" maxlength="'+(o.max||2000)+'" placeholder="'+esc(o.placeholder||'')+'">'+(o.multiline?esc(o.value||'')+'</textarea>':'')+'</label>',
      onClose:function(){res(ans)},
      actions:[{label:'Cancel'},{label:o.ok||'Save',kind:'main',on:function(){
        var v=m.body.querySelector('#uprompt').value.trim();
        if(!v&&!o.allowEmpty){toast('Type something first');return false}
        ans=v;
      }}]});
    var inp=m.body.querySelector('#uprompt');if(!o.multiline)inp.value=o.value||'';
    setTimeout(function(){try{inp.focus()}catch(e){}},60);
  });
}
/* actionSheet({title, items:[{label,icon,danger,on}]}) */
function actionSheet(o){
  var h='<div class="alist">'+o.items.map(function(it,i){
    return'<button type="button" class="aitem'+(it.danger?' danger':'')+'" data-i="'+i+'">'+(it.icon?icon(it.icon,20):'')+'<span>'+esc(it.label)+'</span></button>';
  }).join('')+'</div>';
  var m=modal({title:o.title||'Options',body:h,sheet:true});
  m.body.addEventListener('click',function(e){
    var b=e.target.closest('[data-i]');if(!b)return;
    var it=o.items[+b.dataset.i];m.close();if(it.on)it.on();
  });
  return m;
}


/* ---------- sliders become small arrow buttons ---------- */
(function(){
  var VERT={py:1,vy:1,gap:1,lh:1},HORI={gx:1,px:1,vx:1,radius:1,op:1};
  function glyphs(inp){
    var k=(inp.dataset&&inp.dataset.k)||inp.id||'';
    if(VERT[k])return['\u2B07','\u2B06'];            /* down / up */
    if(HORI[k])return['\u2B05','\u27A1'];            /* left / right */
    if(/Sz$|szR|size/i.test(k))return['A\u2193','A\u2191'];  /* smaller / bigger text */
    return['\u2212','+'];
  }
  function step(inp,dir){
    var st=+inp.step||1,mn=+inp.min,mx=+inp.max,v=+inp.value+dir*st;
    v=Math.max(mn,Math.min(mx,Math.round(v/st)*st));
    if(+inp.value===v)return;
    inp.value=v;inp.dispatchEvent(new Event('input',{bubbles:true}));inp.dispatchEvent(new Event('change',{bubbles:true}));
  }
  function convert(inp){
    if(inp.dataset.stp||inp.classList.contains('pseek')||inp.closest('#rplayer'))return;
    inp.dataset.stp='1';
    var g=glyphs(inp),w=document.createElement('span');w.className='stepper';
    w.innerHTML='<button type="button" class="stpb" aria-label="Decrease">'+g[0]+'</button><button type="button" class="stpb" aria-label="Increase">'+g[1]+'</button>';
    inp.style.display='none';inp.parentNode.insertBefore(w,inp.nextSibling);
    var bs=w.querySelectorAll('button'),t=0,iv=0;
    function hold(b,dir){
      function go(){step(inp,dir)}
      b.addEventListener('pointerdown',function(e){e.preventDefault();go();clearTimeout(t);clearInterval(iv);t=setTimeout(function(){iv=setInterval(go,90)},420)});
      ['pointerup','pointerleave','pointercancel'].forEach(function(n){b.addEventListener(n,function(){clearTimeout(t);clearInterval(iv)})});
    }
    hold(bs[0],-1);hold(bs[1],1);
  }
  function scan(root){(root.querySelectorAll?root:document).querySelectorAll('input[type=range]').forEach(convert)}
  new MutationObserver(function(ms){
    ms.forEach(function(m){m.addedNodes.forEach(function(n){if(n.nodeType===1){if(n.matches&&n.matches('input[type=range]'))convert(n);else scan(n)}})});
  }).observe(document.documentElement,{childList:true,subtree:true});
  document.addEventListener('DOMContentLoaded',function(){scan(document)});
})();

window.LUI={esc:esc,toast:toast,icon:icon,icons:IC,fmt:{dt:dt,date:date,ago:ago,days:days,dayKey:dayKey,dtLocal:dtLocalValue},copy:copy,share:share,
  modal:modal,confirm:confirmBox,prompt:promptBox,actionSheet:actionSheet,handleBack:handleBack};
})();
