import sys, os; sys.path.insert(0, 'test')
from harness import app
OUT='/tmp/claude-0/-home-claude/9ac21290-e598-5b5b-8a6d-943898313428/scratchpad/shots'
os.makedirs(OUT,exist_ok=True)
with app(width=390,height=800) as (page, base):
    page.goto(base); page.wait_for_timeout(800)
    page.evaluate("Lectio.go('songs')"); page.wait_for_timeout(1200)
    page.screenshot(path=OUT+'/1_list.png')
    page.click('.sg-row >> nth=2'); page.wait_for_timeout(1000)
    page.screenshot(path=OUT+'/2_reader.png')
    page.click('[data-a="panel"]'); page.wait_for_timeout(500)
    page.screenshot(path=OUT+'/3_panel.png')
    page.click('[data-tab="col"]'); page.click('[data-th="night"]'); page.wait_for_timeout(300)
    page.screenshot(path=OUT+'/4_night.png')
    page.click('[data-a="close"]')  # close reader
    page.wait_for_timeout(300)
    page.click('.sg-tabs [data-s="chords"]'); page.wait_for_timeout(1200)
    page.click('.sg-row >> nth=1'); page.wait_for_timeout(1000)
    page.screenshot(path=OUT+'/5_chords.png')
    print('ERR',page.errors)
