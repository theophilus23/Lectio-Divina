/* Paste your Firebase web app config here (Firebase console > Project settings > Your apps).
   Until the keys are filled in, the app works fully offline without sign-in. See FIREBASE_SETUP.md. */
window.LECTIO_FIREBASE = {
  apiKey: "PASTE_API_KEY",
  authDomain: "PASTE_PROJECT_ID.firebaseapp.com",
  projectId: "PASTE_PROJECT_ID",
  storageBucket: "PASTE_PROJECT_ID.appspot.com",
  messagingSenderId: "PASTE_SENDER_ID",
  appId: "PASTE_APP_ID"
};
