/* Search page: find words in the verses of every Bible version (KJV, Telugu, anything added later). */
(function(){
'use strict';
var L=window.Lectio,$=L.$,esc=L.esc,UI=L.ui,B=L.bible;
var savedC=L.coll('saved');

var S={q:'',sel:null,scope:'all',mode:'any',res:{},busy:false,cancel:false,prog:0,shown:{},err:''};
var PAGE=100;
function recent(){try{return JSON.parse(L.lsGet('lectio-search-recent')||'[]')}catch(e){return[]}}
function addRecent(q){if(L.vlog)L.vlog.add({k:'search',q:q});var r=recent().filter(function(x){return x!==q});r.unshift(q);L.lsSet('lectio-search-recent',JSON.stringify(r.slice(0,8)))}

/* lower-case and drop Latin accents; other scripts (Telugu...) are left as they are */
function norm(s){return String(s).normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase()}
function terms(q){return norm(q).split(/\s+/).filter(Boolean)}
function matcher(q,mode){
  var t=terms(q);if(!t.length)return null;
  var phrase=norm(q).trim().replace(/\s+/g,' ');
  if(mode==='phrase')return function(x){return norm(x).replace(/\s+/g,' ').indexOf(phrase)>-1};
  if(mode==='all')return function(x){var n=norm(x);return t.every(function(w){return n.indexOf(w)>-1})};
  return function(x){var n=norm(x);return t.some(function(w){return n.indexOf(w)>-1})};
}
function markText(text,q,mode){
  var t=mode==='phrase'?[q.trim().replace(/\s+/g,' ')]:q.trim().split(/\s+/);
  t=t.filter(Boolean).map(function(w){return w.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')});
  var out=esc(text);if(!t.length)return out;
  try{
    var re=new RegExp('('+t.join('|')+')','giu');
    /* mark on the escaped text but never inside an entity */
    return out.replace(re,function(m,a,off,str){return/&[#a-z0-9]*$/i.test(str.slice(0,off))&&/^[a-z0-9]*;/i.test(str.slice(off))?m:'<mark>'+m+'</mark>'});
  }catch(e){return out}
}

function ddText(vs){var n=S.sel.map(function(id){var v=B.version(id);return v?v.short:id});return n.length?(n.length>3?n.slice(0,3).join(', ')+' +'+(n.length-3):n.join(', ')):'Choose versions'}
var el=L.registerView({id:'search',title:'Search',menu:{label:'Search',icon:'search',group:'read',order:3},show:function(){if(!S.sel){var rv=(L.reader&&L.reader.version&&L.reader.version())||B.versions()[0].id;S.sel=[B.hasVersion(rv)?rv:B.versions()[0].id]}draw()}});

function scopeBooks(){
  if(S.scope==='ot')return range(0,OT_N-1);
  if(S.scope==='nt')return range(OT_N,BOOKS.length-1);
  if(/^b\d+$/.test(S.scope))return[+S.scope.slice(1)];
  return range(0,BOOKS.length-1);
}
function range(a,b){var r=[];for(var i=a;i<=b;i++)r.push(i);return r}

function draw(){
  var vs=B.versions(),h='<div class="head"><div class="eyebrow">Search</div><h1>Find a word</h1><p>Looks in every Bible version you choose.</p></div>';
  h+='<div class="card"><div class="srow"><input id="sq" type="search" class="sinp" placeholder="Word, phrase, or a verse like John 3:16" value="'+esc(S.q)+'" autocomplete="off"><button class="btn main" id="sgo" type="button"'+(S.busy?' disabled':'')+'>Search</button></div>';
  var rc=recent();
  if(rc.length)h+='<div class="chips">'+rc.map(function(r){return'<button type="button" class="chip" data-rec="'+esc(r)+'">'+esc(r)+'</button>'}).join('')+'</div>';
  h+='<div class="sec-t">Versions</div><div class="vdd"><button type="button" class="vddb" id="svDD" aria-expanded="'+!!S.dd+'"><span id="svDDt">'+ddText(vs)+'</span><span aria-hidden="true">'+(S.dd?'▴':'▾')+'</span></button>'+(S.dd?'<div class="vddp">'+vs.map(function(v){return'<button type="button" class="vddr" data-v="'+esc(v.id)+'" aria-pressed="'+(S.sel.indexOf(v.id)>-1)+'"><span>'+esc(v.name)+' <small>'+esc(v.short)+'</small></span><i aria-hidden="true">✓</i></button>'}).join('')+'</div>':'')+'</div>';
  h+='<div class="grid2"><label class="field">Where<select id="sscope"><option value="all">Whole Bible</option><option value="ot">Old Testament</option><option value="nt">New Testament</option>'+BOOKS.map(function(b,i){return'<option value="b'+i+'">'+esc(b.n)+'</option>'}).join('')+'</select></label>';
  h+='<label class="field">Match<select id="smode"><option value="any">Any word</option><option value="all">All words</option><option value="phrase">Exact phrase</option></select></label></div></div>';
  h+='<div id="sout"></div>';
  el.innerHTML=h;
  $('sscope').value=S.scope;$('smode').value=S.mode;
  results();
}

function results(){
  var out=$('sout');if(!out)return;
  var h='';
  var ref=S.q&&B.parseRef(S.q);
  if(ref)h+='<button type="button" class="btn wide" data-open="'+ref.b+'.'+ref.c+'.'+(ref.v1||0)+'" style="margin-top:12px">Open '+esc(B.refName(ref.b,ref.c,ref.v1,ref.v2))+'</button>';
  if(S.busy){
    h+='<div class="card" style="margin-top:12px"><div class="meter"><i style="width:'+Math.round(S.prog*100)+'%"></i></div><div class="row"><span class="muted">Searching… '+Math.round(S.prog*100)+'%</span><button class="btn" id="scancel" type="button">Cancel</button></div></div>';
  }
  if(S.err)h+='<p class="empty">'+esc(S.err)+'</p>';
  var any=false;
  Object.keys(S.res).forEach(function(tid){
    var list=S.res[tid],v=B.version(tid);any=any||list.length>0;
    var n=S.shown[tid]||PAGE;
    h+='<div class="sgroup"><div class="pagehead"><h3>'+esc(v.name)+'</h3><span class="tag">'+list.length+' verse'+(list.length===1?'':'s')+'</span></div>';
    if(!list.length)h+='<p class="sub2">No matches.</p>';
    h+='<div class="list">'+list.slice(0,n).map(function(r,i){
      var sid='sv-b-'+r.b+'.'+r.c+'.'+r.v+'-'+r.v,on=!!savedC.get(sid);
      return'<div class="li sr-card" data-t="'+esc(tid)+'" data-i="'+i+'"><div class="row2"><b class="t">'+esc(B.refName(r.b,r.c,r.v))+'</b><span class="tag">'+esc(v.short)+'</span><button type="button" class="iconbtn sr-heart'+(on?' on':'')+'" data-a="save" aria-pressed="'+on+'" aria-label="Save verse">'+UI.icon('heart',20)+'</button></div><div class="body'+(B.isTel(v)?' ind':'')+'" lang="'+esc(String(v.lang).slice(0,2))+'">'+markText(r.t,S.q,S.mode)+'</div></div>';
    }).join('')+'</div>';
    if(list.length>n)h+='<button class="btn wide" data-more="'+esc(tid)+'" style="margin-top:10px">Show more ('+(list.length-n)+' left)</button>';
    h+='</div>';
  });
  if(!S.busy&&S.ran&&!any&&!S.err)h+='<p class="empty">No verses found. Try fewer words, or “Any word”.</p>';
  out.innerHTML=h;
}

function tick(){return new Promise(function(r){setTimeout(r,0)})}
async function run(){
  var q=$('sq').value.trim();S.q=q;
  if(!q){L.toast('Type a word first');return}
  if(!S.sel.length){L.toast('Choose at least one version');return}
  var m=matcher(q,S.mode);if(!m)return;
  addRecent(q);S.busy=true;S.cancel=false;S.res={};S.shown={};S.err='';S.ran=true;S.prog=0;
  S.sel.forEach(function(t){S.res[t]=[]});
  results();
  var books=scopeBooks(),total=books.length*S.sel.length,done=0;
  for(var vi=0;vi<S.sel.length;vi++){
    var tid=S.sel[vi];
    for(var bi=0;bi<books.length;bi++){
      if(S.cancel)break;
      var b=books[bi];
      try{
        var bk=await B.loadBook(tid,b,{keep:false});
        for(var c=0;c<bk.length;c++){var ch=bk[c]||[];for(var v=0;v<ch.length;v++)if(ch[v]&&m(ch[v]))S.res[tid].push({b:b,c:c+1,v:v+1,t:ch[v]})}
      }catch(e){}
      done++;
      if(bi%4===0){S.prog=done/total;if($('sout'))results();await tick()}
    }
    if(S.cancel)break;
  }
  S.busy=false;S.prog=1;if(L.view==='search'){draw();var o=$('sout');if(o)o.scrollIntoView({behavior:'smooth',block:'start'})}
}

el.addEventListener('click',function(e){
  var t=e.target.closest('button');
  if(!t){var cd=e.target.closest('.sr-card');if(cd){var tid0=cd.dataset.t,r0=S.res[tid0][+cd.dataset.i];if(r0)L.openReader(r0.b,r0.c,r0.v,tid0)}return}
  if(t.id==='svDD'){S.dd=!S.dd;draw();return}
  if(t.id==='sgo'){run();return}
  if(t.id==='scancel'){S.cancel=true;return}
  if(t.dataset.rec!=null){S.q=t.dataset.rec;draw();run();return}
  if(t.dataset.v){
    var i=S.sel.indexOf(t.dataset.v);if(i>-1)S.sel.splice(i,1);else S.sel.push(t.dataset.v);
    t.setAttribute('aria-pressed',String(i===-1));var tt=$('svDDt');if(tt)tt.textContent=ddText();return;
  }
  if(t.dataset.open){var p=t.dataset.open.split('.').map(Number);L.openReader(p[0],p[1],p[2]||undefined,S.sel&&S.sel.length===1?S.sel[0]:undefined);return}
  if(t.dataset.more){S.shown[t.dataset.more]=(S.shown[t.dataset.more]||PAGE)+PAGE;results();return}
  if(t.dataset.a){
    var li=t.closest('.li'),tid=li.dataset.t,r=S.res[tid][+li.dataset.i],v=B.version(tid);
    var ref=B.refName(r.b,r.c,r.v),txt=ref+' ('+v.short+')\n'+r.t;
    if(t.dataset.a==='open')L.openReader(r.b,r.c,r.v,tid);
    else if(t.dataset.a==='copy')UI.copy(txt).then(function(ok){L.toast(ok?'Copied with reference':'Could not copy')});
    else if(t.dataset.a==='share')UI.share({title:ref,text:txt+'\n\nShared from Lectio'});
    else if(t.dataset.a==='save'){
      var sid2='sv-b-'+r.b+'.'+r.c+'.'+r.v+'-'+r.v;
      if(savedC.get(sid2)){savedC.remove(sid2);t.classList.remove('on');t.setAttribute('aria-pressed','false');L.toast('Removed from saved verses');return}
      t.classList.add('on');t.setAttribute('aria-pressed','true');
      savedC.put({id:'sv-b-'+r.b+'.'+r.c+'.'+r.v+'-'+r.v,src:'bible',ref:ref,b:r.b,c:r.c,v1:r.v,v2:r.v,tx:[{s:v.short,t:r.t}],ts:Date.now()});
      L.toast('Saved. See Saved verses in the menu.');
    }
  }
});
el.addEventListener('change',function(e){
  if(e.target.id==='sscope')S.scope=e.target.value;
  else if(e.target.id==='smode')S.mode=e.target.value;
});
el.addEventListener('keydown',function(e){if(e.key==='Enter'&&e.target.id==='sq'){e.preventDefault();run()}});
L.on('versions',function(){S.sel=null});
L.searchFor=function(q){S.q=q;L.go('search');setTimeout(function(){var i=$('sq');if(i){i.value=q;run()}},80)};
})();
