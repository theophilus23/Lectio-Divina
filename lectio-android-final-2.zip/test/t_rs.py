import sys; sys.path.insert(0,'test')
from harness import app
with app(width=360,height=740) as (page,base):
    page.goto(base); page.wait_for_timeout(800)
    page.add_style_tag(content="#fdock{display:none!important}")
    page.evaluate("()=>Lectio.openSettings('sc-readerlayout')"); page.wait_for_timeout(700)
    def st(): return page.evaluate("()=>{const c=getComputedStyle(document.documentElement);const r=Lectio.settings.reader;return [JSON.stringify(r),document.documentElement.getAttribute('style')&&document.documentElement.getAttribute('style').length]}")
    print(st())
    for sel in ['[data-align=center]','[data-align=right]','[data-align=justify]','[data-align=left]','[data-nums=inline]','[data-nums=col]','#rlBorder','[data-rv=w+]','[data-rv=w-]','[data-rv=s+]','[data-rv=s-]','[data-rv=o-]','[data-rv=o+]','[data-rv=r+]','[data-rv=r-]','#rqAwake','[data-hide=always]','[data-rfont]:nth-child(2)','#rqAuto']:
        try:
            page.click(sel,timeout=2000); page.wait_for_timeout(250)
            print(sel, st())
        except Exception as e: print(sel,'FAIL',str(e)[:80])
    print(page.errors)
