"""Browser test harness for Lectio.
   from harness import app   # then:  with app() as (page, base): page.goto(base) ...
Serves www/ on a free port, replaces the Firebase SDK with test/firebase-mock.js (unless mock=False) and fills in a fake firebase-config.js.
Run a test file with:  python3 -I test/yourtest.py   (Playwright for Python and Chromium are already installed). """
import contextlib, http.server, socketserver, threading, os, functools
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WWW = os.path.join(ROOT, 'www')
MOCK = open(os.path.join(ROOT, 'test', 'firebase-mock.js'), encoding='utf-8').read()
FAKECFG = "window.LECTIO_FIREBASE={apiKey:'test',authDomain:'t.firebaseapp.com',projectId:'test',storageBucket:'t.appspot.com',messagingSenderId:'1',appId:'1:1:web:1'};"

class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
    def end_headers(self):
        self.send_header('Cache-Control', 'no-store'); super().end_headers()

@contextlib.contextmanager
def app(mock=True, width=390, height=800, init_script=None, **ctx):
    handler = functools.partial(Quiet, directory=WWW)
    srv = socketserver.TCPServer(('127.0.0.1', 0), handler)
    port = srv.server_address[1]
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path='/opt/pw-browsers/chromium-1194/chrome-linux/chrome' if os.path.exists('/opt/pw-browsers/chromium-1194/chrome-linux/chrome') else None, args=['--no-sandbox'])
        c = b.new_context(viewport={'width': width, 'height': height}, **ctx)
        page = c.new_page()
        errors = []
        page.on('pageerror', lambda e: errors.append(str(e)))
        page.on('console', lambda m: errors.append('console.error: ' + m.text) if m.type == 'error' and 'Failed to load resource' not in m.text else None)
        page.errors = errors
        if mock:
            page.route('**/vendor/firebase-app-compat.js', lambda r: r.fulfill(body=MOCK, content_type='application/javascript'))
            page.route('**/vendor/firebase-auth-compat.js', lambda r: r.fulfill(body='', content_type='application/javascript'))
            page.route('**/vendor/firebase-firestore-compat.js', lambda r: r.fulfill(body='', content_type='application/javascript'))
            page.route('**/firebase-config.js', lambda r: r.fulfill(body=FAKECFG, content_type='application/javascript'))
        if init_script: page.add_init_script(init_script)
        try:
            yield page, 'http://127.0.0.1:%d/index.html' % port
        finally:
            b.close(); srv.shutdown()
