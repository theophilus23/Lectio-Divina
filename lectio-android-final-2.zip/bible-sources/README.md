# Bible sources
One folder per Bible version: `bible-sources/<id>/` holding your JSON files (one per book, or one big file) and an `info.json`.
Copy `_example/info.json` into your folder and edit it. Folders starting with `_` are ignored.
Then run `npm run bibles`. See "Adding Bible versions" in the main README.
