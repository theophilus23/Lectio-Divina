# Songs of Zion – track maker (free setup, Cloudflare R2)



Runs on **your computer**. It takes the melodies people shared from the app, joins them into one tune per song,
works out key / tempo / chords, makes two MP3s per song (**guide track** = accompaniment + soft melody, **instrumental**),
and uploads them to Cloudflare R2. The app then shows a *Listen* row on those songs.

Zion songs have no chord data, so chords are **derived from the melody** (simple diatonic triads). Fine for a hymn-style pad, not a transcription.

## One-time setup
1. Install Python 3.10+, ffmpeg, then `pip install -r requirements.txt`.
2. Firebase console → Project settings → Service accounts → *Generate new private key* → save as `serviceAccountKey.json` (keep it private, never put it in the app).
3. Cloudflare → R2 → create a bucket (e.g. `lectio-tracks`). Make it public (R2.dev subdomain or your own domain).
   Bucket → Settings → CORS policy:
   `[{"AllowedOrigins":["*"],"AllowedMethods":["GET","HEAD"],"AllowedHeaders":["*"]}]`
4. R2 → Manage API tokens → create token with *Object Read & Write* for that bucket. Note account id, key id, secret.
5. In the app, edit `www/songs/config.js`: `tracksBase: 'https://pub-xxxx.r2.dev/'` (trailing slash), then `npx cap sync android`.

## Each time you want to refresh tracks
```
python3 make_tracks.py --source firestore --key serviceAccountKey.json --dump melodies.json --out out --min-contributors 3
export R2_ACCOUNT_ID=... R2_ACCESS_KEY_ID=... R2_SECRET_ACCESS_KEY=... R2_BUCKET=lectio-tracks
python3 upload_r2.py --out out
```
* `--min-contributors` – skip songs with fewer usable melodies (3+ recommended; with 1 the track just follows one person's singing).
* `--songs 3,23` – only these songs. Later runs re-use `out/manifest.json`, so you can add songs gradually.
* Offline test: `python3 make_tracks.py --source json --file melodies.json --out out`.
* Wrong tempo/key for a song? Copy `overrides.example.json` to `overrides.json` and set `bpm`, `meter` ("3/4"), `key` ("G", "Em", "Bb"), `pickup` (beats before the first bar line), then re-run with `--songs`.

## Notes
* Only melodies (pitch numbers) are uploaded by users, never their voice. The app asks consent before sharing.
* Storage: ≈ 4 MB per MP3 (≈ 8 MB per song). R2 free tier is 10 GB-month with free downloads, so ≈ 1,000 songs fit free.
* Generated music is synthesised by this script, so you own it. Listen to a few before publishing; delete bad files from `out/` and `manifest.json`.

## Running it automatically (GitHub Actions)
`.github/workflows/zion-tracks.yml` runs the same two scripts in GitHub's cloud every Sunday (or on demand from the Actions tab), so your computer can stay off.
Put the project in a **private** GitHub repo, add the secrets listed at the top of that file (Settings → Secrets and variables → Actions), done.
Private repos get 2,000 free Actions minutes a month; a run takes minutes for a few songs, longer as the song count grows.
Every run re-makes all songs that have enough melodies (about 10 s per song); the upload step skips files that did not change.
