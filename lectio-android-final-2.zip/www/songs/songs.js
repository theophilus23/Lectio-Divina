/* Songs page: sections (Songs of Zion, Telugu, Malayalam, Tamil, Hindi, Bengali, Kannada, Others, Chords, Mine), search, list.
   The song reader, settings panel, slide mode and chord diagrams are in reader.js. Data files are in songs/data (loaded when a section opens). */
(function(){
'use strict';
var L=window.Lectio,UI=L.ui,esc=L.esc,$=L.$;
var BASE=(function(){var s=document.currentScript;return s&&s.src?s.src.replace(/[^\/]*$/,''):'songs/'})();
var S=window.LSongs={base:BASE};
function clone(o){return JSON.parse(JSON.stringify(o))}

/* ================= sections ================= */
var SECS=S.secs=[
  {id:'zion',name:'Songs of Zion',short:'Zion',sc:'te',zion:true,n:818,hint:'సీయోను గీతములు'},
  {id:'telugu',name:'Telugu songs',short:'Telugu',sc:'te',n:410},
  {id:'malayalam',name:'Malayalam songs',short:'Malayalam',sc:'ml',n:4840},
  {id:'tamil',name:'Tamil songs',short:'Tamil',sc:'ta',n:2392},
  {id:'hindi',name:'Hindi songs',short:'Hindi',sc:'hi',n:1683},
  {id:'bengali',name:'Bengali songs',short:'Bengali',sc:'bn',n:343},
  {id:'kannada',name:'Kannada songs',short:'Kannada',sc:'kn',n:201},
  {id:'nyishi',name:'Other songs (Nyishi)',short:'Others',sc:'en',n:226},
  {id:'chords',name:'Chords (Malayalam)',short:'Chords',sc:'en',chords:true,n:571},
  {id:'mine',name:'My songs',short:'Mine',sc:'en',mine:true}
];
function secById(id){for(var i=0;i<SECS.length;i++)if(SECS[i].id===id)return SECS[i];return SECS[0]}
S.secById=secById;

/* ================= settings ================= */
var KEY='lectio-songs-v1';
var DEF={theme:'app',cbg:'#F7F2E7',cfg:'#2B2218',size:24,lh:1.75,ls:0,bold:false,align:'left',gap:20,
  fonts:{te:'te-notoserifte',ml:'Noto Sans Malayalam',ta:'Noto Sans Tamil',hi:'Noto Sans Devanagari',bn:'Noto Sans Bengali',kn:'Noto Sans Kannada',en:'hanken'},
  col:{text:'',title:'',num:'',chorus:'',rom:'',chord:''},
  chorusStyle:'bar',nums:true,zionChorus:'every',view:'auto',romScale:80,eng:true,
  chords:true,chordScale:78,inst:'guitar',bgimg:false,dim:55,blur:0,delay:40,wake:true,page:'zion'};
var set=S.settings=(function(){
  var s=clone(DEF),o={};
  try{o=JSON.parse(L.lsGet(KEY)||'{}')||{}}catch(e){}
  Object.keys(o).forEach(function(k){
    if(k==='fonts'||k==='col')Object.assign(s[k],o[k]);else s[k]=o[k];
  });
  return s;
})();
S.save=function(){L.lsSet(KEY,JSON.stringify(set))};
S.DEF=DEF;

/* ================= fonts ================= */
var SANS="system-ui,-apple-system,'Segoe UI',Roboto,sans-serif",SERIF="Georgia,'Times New Roman',serif";
function mk(n,fb){return{id:n,name:n,css:"'"+n+"',"+fb}}
var F=S.fontSets={
  ml:[mk('Noto Sans Malayalam',SANS),mk('Noto Serif Malayalam',SERIF),mk('Manjari',SANS),mk('Baloo Chettan 2',SANS),mk('Chilanka',SANS)],
  ta:[mk('Noto Sans Tamil',SANS),mk('Noto Serif Tamil',SERIF),mk('Baloo Thambi 2',SANS),mk('Catamaran',SANS),mk('Hind Madurai',SANS)],
  hi:[mk('Noto Sans Devanagari',SANS),mk('Noto Serif Devanagari',SERIF),mk('Hind',SANS),mk('Baloo 2',SANS),mk('Kalam',SANS)],
  bn:[mk('Noto Sans Bengali',SANS),mk('Noto Serif Bengali',SERIF),mk('Hind Siliguri',SANS),mk('Baloo Da 2',SANS)],
  kn:[mk('Noto Sans Kannada',SANS),mk('Noto Serif Kannada',SERIF),mk('Baloo Tamma 2',SANS)]
};
var LF=window.FONTS||[];
F.te=LF.filter(function(f){return f.tel});
F.en=LF.filter(function(f){return !f.tel});
if(!F.te.length)F.te=[mk('Noto Serif Telugu',SERIF)];
if(!F.en.length)F.en=[mk('Hanken Grotesk',SANS)];
S.scriptNames={te:'Telugu',ml:'Malayalam',ta:'Tamil',hi:'Hindi',bn:'Bengali',kn:'Kannada',en:'Romanized / English'};
function fontOf(sc,id){var a=F[sc]||F.en;for(var i=0;i<a.length;i++)if(a[i].id===id)return a[i];return a[0]}
S.fontOf=fontOf;
S.applyFonts=function(){
  var r=document.documentElement.style,lat=fontOf('en',set.fonts.en).css;
  ['te','ml','ta','hi','bn','kn'].forEach(function(sc){r.setProperty('--sg-f-'+sc,fontOf(sc,set.fonts[sc]).css+','+lat)});
  r.setProperty('--sg-f-en',lat);
};

/* ================= data ================= */
var loading={};
function loadData(name){
  if(window.LSD&&window.LSD[name])return Promise.resolve(window.LSD[name]);
  if(loading[name])return loading[name];
  loading[name]=new Promise(function(res,rej){
    var s=document.createElement('script');s.async=true;s.src=BASE+'data/'+name+'.js';
    s.onload=function(){res(window.LSD[name])};
    s.onerror=function(){delete loading[name];rej(new Error('Could not load '+name))};
    document.head.appendChild(s);
  });
  return loading[name];
}
S.loadData=loadData;
var idxCache={};
function getIdx(sec){
  if(idxCache[sec.id])return Promise.resolve(idxCache[sec.id]);
  return loadData(sec.id+'.i').then(function(d){
    var r=sec.zion?{items:d.songs,cats:d.cats}:{items:d,cats:null};
    r.map={};r.items.forEach(function(it,i){r.map[sid(sec,it)]=i});
    idxCache[sec.id]=r;return r;
  });
}
S.getIdx=getIdx;S._idx=function(id){return idxCache[id]};
S.getBody=function(sec){return loadData(sec.id+'.b')};
function sid(sec,it){return sec.zion?String(it.n):sec.chords?it.t:String(it.i)}
S.sid=sid;
function titleOf(sec,it){return it.t||''}

/* ================= favourites + recent ================= */
var fav=S.fav=L.coll('songfav');
function favKey(sec,it){return sec.id+':'+sid(sec,it)}
S.isFav=function(sec,it){return !!fav.get(favKey(sec,it))};
S.toggleFav=function(sec,it){
  var k=favKey(sec,it);
  if(fav.get(k)){fav.remove(k);return false}
  fav.put({id:k,s:sec.id,k:sid(sec,it),t:titleOf(sec,it)});return true;
};
var RK='lectio-songs-recent';
function recents(){try{return JSON.parse(L.lsGet(RK)||'[]')||[]}catch(e){return[]}}
S.pushRecent=function(sec,it){
  var k=favKey(sec,it),a=recents().filter(function(x){return x.id!==k});
  a.unshift({id:k,s:sec.id,k:sid(sec,it),t:titleOf(sec,it)});
  L.lsSet(RK,JSON.stringify(a.slice(0,40)));
  L.lsSet('lectio-songs-last',JSON.stringify({s:sec.id,k:sid(sec,it),t:titleOf(sec,it)}));
};

/* ================= text helpers ================= */
function fold(s){return(s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f\u200c\u200d]/g,'')}
S.fold=fold;
function catName(idx,c){var cs=idx.cats||[];for(var i=0;i<cs.length;i++)if(cs[i].c===c)return cs[i];return null}

/* ================= page state ================= */
var st={sec:set.page&&secById(set.page).mine?'zion':(set.page||'zion'),q:'',lyr:false,cat:'',mine:'fav',rows:[],idx:null,bodies:null,seq:0};
var ROW=66,page=null,box=null,fR=-1,lR=-1,onScroll=null,tmr=0;

function build(el){
  el.innerHTML='<div class="head"><div class="eyebrow">Songs</div><h1>Songbook <span class="sg-total" id="sgTotal"></span></h1></div>'
    +'<div class="chips hscroll sg-tabs" id="sgTabs" role="tablist"></div>'
    +'<div class="sg-tools"><label class="sg-search">'+UI.icon('search',18)+'<input id="sgQ" type="search" enterkeyhint="search" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="Search"><button type="button" class="sg-clr" id="sgClr" aria-label="Clear" hidden>'+UI.icon('x',16)+'</button></label>'
    +'<button type="button" class="roundicon" id="sgGear" aria-label="Song display settings">'+UI.icon('gear',20)+'</button></div>'
    +'<div id="sgResume"></div><div class="sg-sub" id="sgSub"></div><div class="chips hscroll sg-cats" id="sgCats" hidden></div><div class="sg-az" id="sgAz" hidden></div>'
    +'<div class="sg-box" id="sgBox"></div>';
  box=$('sgBox');
  var q=$('sgQ');
  q.oninput=function(){
    st.q=q.value;$('sgClr').hidden=!q.value;
    clearTimeout(tmr);tmr=setTimeout(refresh,st.lyr?260:120);
  };
  $('sgClr').onclick=function(){q.value='';st.q='';$('sgClr').hidden=true;refresh();q.focus()};
  $('sgGear').onclick=function(){S.openPreview&&S.openPreview(secById(st.sec))};
  $('sgTabs').onclick=function(e){var b=e.target.closest('[data-s]');if(b)pick(b.dataset.s)};
  $('sgCats').onclick=function(e){var b=e.target.closest('[data-c]');if(!b)return;st.cat=b.dataset.c;paintCats();refresh()};
  $('sgAz').onclick=function(e){var b=e.target.closest('[data-p]');if(!b)return;var y=box.getBoundingClientRect().top+window.scrollY+(+b.dataset.p)*ROW-128;window.scrollTo({top:Math.max(0,y),behavior:'auto'})};
  $('sgSub').onclick=function(e){
    var b=e.target.closest('[data-a]');if(!b)return;
    if(b.dataset.a==='lyr'){st.lyr=!st.lyr;refresh()}
    else if(b.dataset.a==='mine'){st.mine=b.dataset.v;refresh()}
  };
  box.onclick=function(e){
    var f=e.target.closest('[data-fv]');
    if(f){
      e.stopPropagation();
      var r=st.rows[+f.dataset.fv],sec=secById(r.s),idx=idxCache[sec.id];
      var on=S.toggleFav(sec,idx.items[r.i]);
      f.setAttribute('aria-pressed',String(on));
      if(st.sec==='mine'&&st.mine==='fav'&&!on)setTimeout(refresh,160);
      return;
    }
    var b=e.target.closest('[data-p]');if(!b)return;
    S.open&&S.open({rows:st.rows,pos:+b.dataset.p});
  };
  var tabs='';
  SECS.forEach(function(s){tabs+='<button type="button" class="chip" role="tab" data-s="'+s.id+'">'+(s.mine?UI.icon('star',14)+' ':'')+esc(s.short)+(s.n?' <small>'+s.n+'</small>':'')+'</button>'});
  $('sgTabs').innerHTML=tabs;
  onScroll=function(){requestAnimationFrame(paintRows)};
}
function pick(id){
  if(id===st.sec)return;
  st.sec=id;st.q='';st.cat='';st.lyr=false;
  var q=$('sgQ');q.value='';$('sgClr').hidden=true;
  if(!secById(id).mine){set.page=id;S.save()}
  window.scrollTo(0,0);
  refresh();
}
function paintTabs(){
  Array.prototype.forEach.call($('sgTabs').children,function(b){
    var on=b.dataset.s===st.sec;b.setAttribute('aria-pressed',String(on));b.setAttribute('aria-selected',String(on));
    if(on&&b.scrollIntoView){var p=b.parentNode;p.scrollLeft=b.offsetLeft-(p.clientWidth-b.offsetWidth)/2}
  });
}
function paintCats(){
  var box=$('sgCats'),sec=secById(st.sec),idx=idxCache[sec.id];
  if(!sec.zion||!idx){box.hidden=true;return}
  box.hidden=false;
  var h='<button type="button" class="chip" data-c="" aria-pressed="'+(st.cat==='')+'">All</button>';
  idx.cats.forEach(function(c){h+='<button type="button" class="chip" data-c="'+c.c+'" aria-pressed="'+(st.cat===c.c)+'">'+esc(c.en)+' <small style="opacity:.6">'+c.a+'–'+c.b+'</small></button>'});
  box.innerHTML=h;
}
function resume(){
  var r=$('sgResume'),last=null;
  try{last=JSON.parse(L.lsGet('lectio-songs-last')||'null')}catch(e){}
  if(!last||st.q||st.sec==='mine'){r.innerHTML='';return}
  r.innerHTML='<button type="button" class="sg-resume"><span><span class="e">Continue</span><b>'+esc(last.t)+'</b></span>'+UI.icon('chevron',18)+'</button>';
  r.firstChild.onclick=function(){S.openByKey(last.s,last.k)};
}

/* ---------- build the visible rows for the current section ---------- */
function matches(it,qs,sec,idx){
  if(!it._h){
    it._h=fold((sec.zion?it.n+' '+it.t+' '+it.r+' '+it.b+' '+((catName(idx,it.c)||{}).en||''):(it.t+' '+it.r+' '+(it.k||'')+' '+(it.n||'')+' '+(it.by||''))));
  }
  for(var i=0;i<qs.length;i++)if(it._h.indexOf(qs[i])<0)return false;
  return true;
}
function refresh(){
  var my=++st.seq,sec=secById(st.sec);
  paintTabs();resume();
  $('sgTotal').textContent='';
  if(sec.mine)return refreshMine(my);
  box.style.height='';box.innerHTML='<div class="sg-load">Loading '+esc(sec.short)+'…</div>';
  getIdx(sec).then(function(idx){
    if(my!==st.seq)return;
    st.idx=idx;
    var items=idx.items,out=[],i;
    var q=fold(st.q).trim(),qs=q?q.split(/\s+/):[];
    var needBody=st.lyr&&q.length>=2;
    var go=function(bodies){
      if(my!==st.seq)return;
      for(i=0;i<items.length;i++){
        var it=items[i];
        if(sec.zion&&st.cat&&it.c!==st.cat)continue;
        if(qs.length){
          var ok=matches(it,qs,sec,idx);
          if(!ok&&bodies){
            var b=bodies[i];
            if(b._h===undefined)b._h=fold(sec.zion?JSON.stringify([b.g,b.ro,b.en]).replace(/[\[\]{}"]|\b(s|sn|c|a|x)\b:/g,' '):(b.l||'')+' '+(b.r||'')+' '+(b.c||''));
            ok=true;for(var k=0;k<qs.length;k++)if(b._h.indexOf(qs[k])<0){ok=false;break}
          }
          if(!ok)continue;
        }
        out.push({s:sec.id,i:i});
      }
      if(sec.zion&&/^\d+$/.test(q)){ /* a typed number goes to the top */
        var num=+q;out.sort(function(a,b){var x=items[a.i].n===num?0:1,y=items[b.i].n===num?0:1;return x-y||items[a.i].n-items[b.i].n});
      }
      st.rows=out;fR=lR=-1;
      paintCats();paintSub(sec,idx,items.length,out.length);paintAz(sec,idx,out);
      box.style.height=Math.max(out.length,1)*ROW+'px';
      if(!out.length){box.style.height='';box.innerHTML='<div class="sg-msg">'+(qs.length?'No songs match “'+esc(st.q)+'”.'+(st.lyr?'':' Try “Search lyrics” too.'):'Nothing here yet.')+'</div>'}
      else paintRows();
    };
    if(needBody){box.innerHTML='<div class="sg-load">Searching lyrics…</div>';S.getBody(sec).then(go)}else go(null);
  }).catch(function(e){
    if(my===st.seq)box.innerHTML='<div class="sg-msg">Could not load this section. '+esc(e.message||'')+'</div>';
  });
}
function refreshMine(my){
  var list=st.mine==='fav'?fav.list().sort(function(a,b){return(b.u||0)-(a.u||0)}):recents();
  var q=fold(st.q).trim();
  var secs={};list.forEach(function(x){secs[x.s]=1});
  Promise.all(Object.keys(secs).map(function(id){return getIdx(secById(id))})).then(function(){
    if(my!==st.seq)return;
    var out=[];
    list.forEach(function(x){
      var idx=idxCache[x.s],i=idx&&idx.map[x.k];
      if(i==null)return;
      if(q&&fold(idx.items[i].t+' '+idx.items[i].r).indexOf(q)<0)return;
      out.push({s:x.s,i:i});
    });
    st.rows=out;fR=lR=-1;
    $('sgCats').hidden=true;$('sgAz').hidden=true;
    $('sgSub').innerHTML='<span class="chips"><button type="button" class="chip" data-a="mine" data-v="fav" aria-pressed="'+(st.mine==='fav')+'">Favourites</button><button type="button" class="chip" data-a="mine" data-v="rec" aria-pressed="'+(st.mine==='rec')+'">Recent</button></span><span>'+out.length+' song'+(out.length===1?'':'s')+'</span>';
    box.style.height=Math.max(out.length,1)*ROW+'px';
    if(!out.length){box.style.height='';box.innerHTML='<div class="sg-msg">'+(st.mine==='fav'?'No favourites yet. Tap the star beside any song to keep it here.':'Songs you open will show up here.')+'</div>'}
    else paintRows();
  });
}
function paintSub(sec,idx,total,shown){
  var h='<span>'+(shown===total?total+' songs':shown+' of '+total)+(sec.zion?' · '+esc(sec.hint):'')+'</span>';
  h+='<button type="button" class="chip" data-a="lyr" aria-pressed="'+st.lyr+'">Search lyrics</button>';
  $('sgSub').innerHTML=h;
}
function paintAz(sec,idx,rows){
  var az=$('sgAz');
  if(sec.zion||st.q||rows.length<60){az.hidden=true;return}
  var seen={},h='',latin=(sec.id!=='telugu');
  rows.forEach(function(r,p){
    var it=idx.items[r.i],t=(latin?(it.r||it.t):it.t)||'',c=(t.trim().charAt(0)||'#');
    c=latin?c.toUpperCase():c;if(latin&&!/[A-Z]/.test(c))c='#';
    if(seen[c])return;seen[c]=1;h+='<button type="button" data-p="'+p+'">'+esc(c)+'</button>';
  });
  az.innerHTML=h;az.hidden=false;
}
function paintRows(){
  if(!page||page.hidden||!box||!st.rows.length)return;
  var top=box.getBoundingClientRect().top,vh=window.innerHeight;
  var f=Math.max(0,Math.floor((-top-300)/ROW)),l=Math.min(st.rows.length,Math.ceil((vh-top+300)/ROW));
  if(f===fR&&l===lR)return;
  fR=f;lR=l;
  var h='';
  for(var p=f;p<l;p++){
    var r=st.rows[p],sec=secById(r.s),idx=idxCache[r.s],it=idx.items[r.i],isF=S.isFav(sec,it);
    var tc=sec.id==='nyishi'||sec.chords?'en':sec.sc;
    var sub='';
    if(sec.zion){sub=it.r||''}
    else sub=it.r&&it.r!==it.t?it.r:'';
    h+='<button type="button" class="sg-row'+(it.x?' nolyr':'')+'" style="top:'+p*ROW+'px" data-p="'+p+'">'
      +(sec.zion?'<span class="sg-no">'+it.n+'</span>':'')
      +'<span class="sg-rt"><span class="sg-t sg-f-'+tc+'">'+esc(it.t)+'</span>'+(sub?'<span class="sg-s">'+esc(sub)+'</span>':'')+'</span>'
      +(st.sec==='mine'?'<span class="sg-badge">'+esc(sec.short)+'</span>':'')
      +(it.k?'<span class="sg-key">'+esc(it.k)+'</span>':'')
      +'<span class="sg-fv" role="button" aria-label="Favourite" aria-pressed="'+isF+'" data-fv="'+p+'">'+UI.icon('star',19)+'</span></button>';
  }
  box.innerHTML=h;
}

/* open by section id + song id (used by Continue and favourites) */
S.openByKey=function(secId,k){
  var sec=secById(secId);
  getIdx(sec).then(function(idx){
    var i=idx.map[k];if(i==null){L.toast('Song not found');return}
    var rows=idx.items.map(function(_,j){return{s:sec.id,i:j}});
    S.open({rows:rows,pos:i});
  });
};

/* ================= register the page ================= */
UI.icons.music='M9 18V5l11-2v13 M9 18a3 3 0 1 1-6 0 3 3 0 0 1 6 0z M20 16a3 3 0 1 1-6 0 3 3 0 0 1 6 0z';
S.applyFonts();
var built=false;
page=L.registerView({id:'songs',title:'Songs',menu:{label:'Songs',icon:'music',group:'read',order:6},
  show:function(el){
    page=el;
    if(!built){build(el);built=true}
    window.addEventListener('scroll',onScroll,{passive:true});window.addEventListener('resize',onScroll);
    refresh();
  },
  leave:function(){
    window.removeEventListener('scroll',onScroll);window.removeEventListener('resize',onScroll);
    if(S.closeReader)S.closeReader(true);
  }});
S.refreshList=function(){fR=lR=-1;if(page&&!page.hidden&&built)paintRows()};
S.show=function(sec){if(sec)st.sec=sec;L.go('songs')};

/* ================= Today card + Settings card + dock ================= */
L.onShow.push(function(name){
  if(name!=='home')return;
  var box=$('homeExtra');if(!box||$('sgHome'))return;
  var b=document.createElement('button');b.type='button';b.className='sg-home';b.id='sgHome';
  b.innerHTML='<span class="ic">'+UI.icon('music',22)+'</span><span><b>Songs</b><span class="s">Songs of Zion, Telugu, Malayalam, Tamil, Hindi and chords</span></span>'+UI.icon('chevron',18);
  b.onclick=function(){L.go('songs')};
  box.appendChild(b);
});
if(L.addSettingsCard)L.addSettingsCard({id:'songs',order:36,render:function(el){
  el.innerHTML='<h3>Songs</h3><p class="muted">Fonts, colours, text size, background photo, chords and auto-scroll for the song reader. Changes show live on a sample song.</p><div class="row"><button type="button" class="btn main" id="sgOpenSet">Song display settings</button></div>';
  el.querySelector('#sgOpenSet').onclick=function(){L.go('songs');setTimeout(function(){var c=secById(st.sec);S.openPreview&&S.openPreview(c.mine?secById('zion'):c)},60)};
}});
})();
