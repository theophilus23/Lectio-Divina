/* Bars: the header pill, the Journal pill, the main menu and the Reader menu are lists of items (the layout from the Layout Studio).
   Each item has a link, and is shown or hidden per page. */
(function(){
'use strict';
var L=window.Lectio,UI=L.ui,esc=L.esc,$=L.$;


function defaults(){
  return{
    header:[
      {id:'h-brand',kind:'brand',label:'Lectio',onlyOn:null,hideOn:['read']},
      {id:'h-hist',kind:'icon',icon:'clock',link:'pop:history',onlyOn:['read','history']},
      {id:'h-spk',kind:'tab',icon:'volume',link:'act:listen',label:'',onlyOn:['read']},
      {id:'h-ch',kind:'tab',label:'{chapter}',link:'act:chapter',cls:'strong',onlyOn:['read']},
      {id:'h-ver',kind:'tab',label:'{version}',link:'act:version',cls:'gold',onlyOn:['read']},
      {id:'h-more',kind:'tab',icon:'chevdown',link:'act:more',label:'',onlyOn:['read']},
      {id:'h-today',kind:'tab',label:'Today',link:'page:home',onlyOn:['home','prayerwall']},
      {id:'h-bible',kind:'tab',label:'Bible',link:'page:lib',onlyOn:['home','prayerwall','lib','book']},
      {id:'h-menu',kind:'icon',icon:'menu',link:'pop:menu'}],
    jpill:[
      {id:'j-add',kind:'icon',icon:'plus',link:'act:newnote',onlyOn:['notes']},
      {id:'j-t',kind:'tab',label:'{journal}',link:'page:notes',onlyOn:['notes']},
      {id:'j-m',kind:'icon',icon:'chevdown',link:'act:jmenu',onlyOn:['notes']}],
    menu:[
      {id:'m-home',kind:'row',label:'Today',icon:'home',link:'page:home'},{id:'m-lib',kind:'row',label:'Bible',icon:'book',link:'page:lib'},
      {id:'m-read',kind:'row',label:'Reader',icon:'note',link:'page:read'},{id:'m-notes',kind:'row',label:'Journal',icon:'edit',link:'page:notes'},
      {id:'m-comm',kind:'row',label:'Community',icon:'people',link:'page:community'},{id:'m-quiz',kind:'row',label:'Quiz',icon:'quiz',link:'page:quiz'},
      {id:'m-pray',kind:'row',label:'Prayer points',icon:'pray',link:'page:mypray'},{id:'m-set',kind:'row',label:'Settings',icon:'gear',link:'page:settings'}],
    more:[
      {id:'r-lib',kind:'row',label:'Library',icon:'book',link:'act:library'},{id:'r-split',kind:'row',label:'Add view',icon:'plus',link:'page:split'},
      {id:'r-full',kind:'row',label:'Full screen',icon:'more',link:'act:fullscreen'},{id:'r-opt',kind:'row',label:'Reading options',icon:'gear',link:'act:options'},
      {id:'r-close',kind:'row',label:'Close reader',icon:'x',link:'page:home'}]
  };
}
function ui(){var s=L.settings;if(!s.ui||typeof s.ui!=='object')s.ui={};return s.ui}
function get(bar){return defaults()[bar]}
function setBar(bar,items){var u=ui();u.bars=u.bars||{};if(items)u.bars[bar]=items;else delete u.bars[bar];L.commitSettings()}
function uid(){return'b'+Date.now().toString(36)+Math.random().toString(36).slice(2,5)}
function clone(o){return JSON.parse(JSON.stringify(o))}

/* ---------- icons ---------- */
var CUSTOM={volume:'M11 5L6 9H3v6h3l5 4z M15.5 8.5a5 5 0 0 1 0 7 M18.5 5.5a9 9 0 0 1 0 13',chevdown:'M6 9l6 6 6-6'};
function icon(n,s){
  s=s||18;if(!n||n==='none')return'';
  if(CUSTOM[n])return'<svg viewBox="0 0 24 24" width="'+s+'" height="'+s+'" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="'+CUSTOM[n]+'"/></svg>';
  return UI.icon(n,s);
}

/* ---------- running a link ---------- */
function clickLegacy(id){var e=document.getElementById(id);if(e)e.click()}
function run(link){
  if(!link)return;
  var k=link.split(':')[0],v=link.slice(k.length+1);
  if(k==='page'){if(v==='read')L.openReader();else if(L.hasView&&!L.hasView(v))L.toast('That page is not available');else L.go(v)}
  else if(k==='pop'){if(L.pop&&L.pop[v])L.pop[v]()}
  else if(k==='ext'){window.open(v,'_blank','noopener')}
  else if(k==='act'){
    if(v==='listen')clickLegacy('rSpk');else if(v==='chapter')clickLegacy('rTitle');else if(v==='version')clickLegacy('rVer');else if(v==='more')clickLegacy('rMore');
    else if(v==='back')L.goBack();
    else if(v==='newnote'||v==='jmenu'){if(L.notes&&L.notes.act)L.notes.act(v==='newnote'?'new':'jmenu')}
    else if(L.reader&&L.reader.act)L.reader.act(v);
  }
}

/* ---------- drawing a bar ---------- */
function shown(it,view){
  if(it.hidden)return false;
  if(it.onlyOn&&it.onlyOn.length)return it.onlyOn.indexOf(view)>-1;
  return(it.hideOn||[]).indexOf(view)<0;
}
function tokens(s){
  return String(s||'').replace(/\{(chapter|version|journal)\}/g,function(_,k){
    if(k==='chapter'){var b=document.getElementById('rBook'),c=document.getElementById('rCh');return(b?b.textContent:'')+' '+(c?c.textContent:'')}
    if(k==='version'){var v=document.getElementById('rVer');return v?v.textContent:''}
    return L.notes&&L.notes.title?L.notes.title():'Journal';
  });
}
function itemHtml(it,view,tab){
  var link=it.link?' data-link="'+esc(it.link)+'"':'',lab=tokens(it.label),ic=icon(it.icon,it.kind==='icon'?18:16);
  var st=(it.sBg?'background:'+esc(it.sBg)+';':'')+(it.sFg?'color:'+esc(it.sFg)+';':'');st=st?' style="'+st+'"':'';
  var cur=it.link==='page:'+view,pressed=it.link==='act:listen'&&L.reader&&L.reader.playerOpen&&L.reader.playerOpen();
  var a=(cur?' aria-current="page"':'')+(pressed?' aria-pressed="true"':'');
  var cls=it.cls?' '+esc(it.cls):'';
  if(it.kind==='brand')return'<div class="brand">'+(it.label==='Lectio'?'Lect<b>i</b>o':esc(lab))+'</div>';
  if(it.kind==='gap')return'<i class="bgap"></i>';
  if(it.kind==='icon')return'<button type="button" class="roundicon'+cls+'"'+link+a+st+' aria-label="'+esc(lab||it.icon)+'">'+ic+'</button>';
  if(tab)return'<button type="button" class="btab'+cls+'"'+link+a+st+(lab?'':' aria-label="'+esc(it.icon)+'"')+'>'+ic+(lab?'<span>'+esc(lab)+'</span>':'')+'</button>';
  return'<button type="button" class="bbtn'+cls+'"'+link+a+st+'>'+ic+(lab?'<span>'+esc(lab)+'</span>':'')+'</button>';
}
function barHtml(items,view){
  var vis=items.filter(function(i){return shown(i,view)}),out='',i=0;
  while(i<vis.length){
    if(vis[i].kind==='tab'){
      var g=[];while(i<vis.length&&vis[i].kind==='tab'){g.push(itemHtml(vis[i],view,true));i++}
      out+='<div class="tabs bgrp">'+g.join('')+'</div>';continue;
    }
    out+=itemHtml(vis[i],view,false);i++;
  }
  return out;
}
var hosts={};
function host(id,make){
  if(hosts[id])return hosts[id];
  var e=make();hosts[id]=e;
  e.addEventListener('click',function(ev){var b=ev.target.closest('[data-link]');if(b)run(b.dataset.link)});
  return e;
}
function paint(){
  var v=L.view;
  var top=host('header',function(){return document.getElementById('topbar')});
  if(top)top.innerHTML=barHtml(get('header'),v);
  var old=document.getElementById('rfab');if(old)old.remove();
  var jp=host('jpill',function(){var e=document.createElement('div');e.id='jpill';document.body.appendChild(e);return e});
  jp.innerHTML=barHtml(get('jpill'),v);jp.hidden=!jp.innerHTML;
  applyPlayer();
}
function rows(bar){return get(bar).filter(function(i){return!i.hidden})}

/* ---------- player placement ---------- */
function applyPlayer(){
  var el=document.getElementById('rplayer');if(!el)return;
  var p={place:'bottom-center',offX:0,offY:-70,widthPct:0,fade:true},a=p.place.split('-'),y=a[0],x=a[1],tr=[];
  var s=el.style;s.top=s.bottom=s.left=s.right='auto';s.transform='';
  if(y==='top')s.top='calc('+(64-p.offY)+'px + env(safe-area-inset-top,0px))';
  else if(y==='middle'){s.top='calc(50% - '+p.offY+'px)';tr.push('translateY(-50%)')}
  else s.bottom='calc('+(78+(+p.offY))+'px + env(safe-area-inset-bottom,0px))';
  if(x==='left'){s.left=(10+(+p.offX))+'px';s.alignItems='flex-start'}
  else if(x==='center'){s.left='50%';tr.push('translateX(-50%)');if(p.offX)tr.push('translateX('+p.offX+'px)');s.alignItems='center'}
  else{s.right=(10-(+p.offX))+'px';s.alignItems='flex-end'}
  if(tr.length)s.transform=tr.join(' ');
  el.style.setProperty('--pw',p.widthPct>0?p.widthPct+'vw':'');
  el.dataset.fade=p.fade?'1':'0';
}

/* ---------- wiring ---------- */
L.bars={get:get,rows:rows,run:run,paint:paint,refresh:paint,icon:icon,applyPlayer:applyPlayer,defaults:defaults};
L.onShow.push(function(){paint()});
L.on('settings',function(){paint()});
})();
