/* Small IndexedDB helper: photos for page backgrounds and imported Bible versions. */
(function(){
  var dbp=null;
  function open(){
    if(dbp)return dbp;
    dbp=new Promise(function(res,rej){
      try{
        var r=indexedDB.open('lectio',1);
        r.onupgradeneeded=function(){var d=r.result;['imgs','bibles'].forEach(function(n){if(!d.objectStoreNames.contains(n))d.createObjectStore(n)})};
        r.onsuccess=function(){res(r.result)};
        r.onerror=function(){rej(r.error)};
      }catch(e){rej(e)}
    });
    dbp.catch(function(){dbp=null});
    return dbp;
  }
  function tx(store,mode,fn){
    return open().then(function(d){
      return new Promise(function(res,rej){
        var t=d.transaction(store,mode),rq=fn(t.objectStore(store));
        t.oncomplete=function(){res(rq&&rq.result)};
        t.onerror=t.onabort=function(){rej(t.error)};
      });
    });
  }
  window.LStore={
    get:function(s,k){return tx(s,'readonly',function(o){return o.get(k)})},
    set:function(s,k,v){return tx(s,'readwrite',function(o){return o.put(v,k)})},
    del:function(s,k){return tx(s,'readwrite',function(o){return o.delete(k)})},
    keys:function(s){return tx(s,'readonly',function(o){return o.getAllKeys()})}
  };
})();
