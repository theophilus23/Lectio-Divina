# Lectio developer guide

Lectio is a plain HTML/CSS/JS app in `www/` (no build step, no framework), wrapped for Android with Capacitor.
Every page is a small script that registers itself with the core. Read this before changing or adding a page.

## Script order (index.html)
`data.js` (books, verses, fonts) → `store.js` (IndexedDB) → `ui.js` (dialogs, icons, dates, share) → `collections.js` (synced lists) →
`app.js` (core) → `bg.js` → `bibleparse.js` → `bible.js` (versions, books, references, picker) → `reader.js` → page scripts
(`appearance.js, history.js, saved.js, notes.js, prayers.js, prayerwall.js, community.js, quizdata.js, quiz.js, plans.js, search.js, reminders.js`) → `Lectio.start()`.
Each script is an IIFE and starts with `var L=window.Lectio, UI=L.ui;`. Style: `var`, plain functions, ES2017 `async/await` is fine (Android WebView is modern).

## Adding a page
```js
var el = L.registerView({
  id: 'notes',                       // section id is "v-notes"
  title: 'Notes',
  menu: {label:'Notes', icon:'note', group:'study', order:10},   // group: read | study | pray | together | app ; icon: see UI.icons
  show: function(el){ render(el) },  // called every time the page opens
  leave: function(el){ }             // optional
});
L.go('notes');                       // open it (Back button returns)
```
The page element is empty; build your HTML inside it. Use `<div class="head"><div class="eyebrow">…</div><h1>…</h1></div>` for the title block.

## Core API (`window.Lectio`)
| Thing | What it does |
|---|---|
| `L.$(id)`, `L.esc(s)` | getElementById, HTML-escape (always escape user text) |
| `L.toast(msg)` | small message at the bottom |
| `L.go(name)`, `L.show(name)`, `L.goBack()` | navigation; Back button support is automatic |
| `L.back.push(fn)` | back-button handler, return `true` if you handled it (e.g. closed a panel) |
| `L.onShow.push(fn(name))` | called whenever any page opens |
| `L.on(evt, fn)`, `L.emit(evt, data)` | events: `progress`, `settings`, `track`, `identity`, `versions`, `ready` |
| `L.coll(name)` | synced list, see below |
| `L.settings` | live settings object (fonts, colours, `tfonts`, `tcolors`, `reader`, `vbg`, `autoTrack`). After changing it call `L.commitSettings()` |
| `L.displayName()`, `L.readerName()` | account name, or guest name, or ''/"Reader" |
| `L.user` | Firebase user or null (`isAnonymous` for guests) |
| `L.fb` | `{on, auth, db}`; `fb.on` is false when Firebase is not configured |
| `L.ensureIdentity()` | `await` it before any online write. Signs in a guest if needed and asks for a name. Returns `{uid,name,guest}` or `null` (user cancelled / offline / not set up) |
| `L.history` | collection of finished Bible rounds |
| `L.addSettingsCard({id,order,render(el)})` | adds a card on the Settings page |
| `L.bible` | see below |
| `L.openReader(b, c, v)` | open the reader at book index `b` (0-65), chapter `c`, optionally scroll to verse `v` |
| `#homeExtra` | empty container at the bottom of the Today page for small cards |

## UI helpers (`L.ui`)
`UI.modal({title, body, actions:[{label, kind:'main'|'danger', on(close,modal), keep}], sheet, wide, onClose})`, `UI.confirm(text,{ok,danger})` → Promise<bool>,
`UI.prompt({title,label,value,multiline,ok})` → Promise<string|null>, `UI.actionSheet({title,items:[{label,icon,danger,on}]})`,
`UI.icon(name,size)` (SVG string), `UI.share({title,text})`, `UI.copy(text)`,
`UI.fmt.dt(ts)` "7 Oct 2026, 4:00 PM", `UI.fmt.date`, `UI.fmt.ago`, `UI.fmt.dayKey(ts)` "2026-10-07", `UI.fmt.dtLocal(ts)` for `<input type=datetime-local>`.

## Synced lists (`L.coll(name)`)
Items are plain objects. `c.put(obj)` (adds or replaces, makes `id` and `u` = last change time), `c.get(id)`, `c.list()`, `c.remove(id)`, `c.on(fn)` (fires on any change, including sync).
Stored in localStorage and merged with the cloud copy `users/{uid}/stores/{name}` when the user is signed in. Newest `u` wins per item; deletes sync too.
Rules: values must be JSON (no `undefined`, no arrays directly inside arrays — Firestore refuses those), keep each list under a few hundred KB (one cloud document per list).
Existing lists: `history`, `saved` (saved verses), `hl` (highlights), `notes`, `prayers`, `prayercats`.

## Bible data (`L.bible`)
`versions()` → `[{id,name,short,lang,builtin}]`, `version(id)`, `isTel(v)`, `ready` (Promise), `loadBook(tid,b)` → `book[chapter-1][verse-1]`, `chapter(tid,b,c)` → `string[]|null`,
`verses(tid,b,c,v1,v2)` → `string[]`, `refName(b,c,v1,v2)` → "John 3:16-18", `refList(b,c,[16,17,20])`, `parseRef("jn 3:16")` → `{b,c,v1,v2}`,
`pick({verses:true, tid, b, c})` → Promise of `{tid,short,b,c,v1,v2,ref,text}` (a dialog to choose version/book/chapter/verses), `pick({verses:false})` → `{tid,b,c}`.
Book indexes follow `BOOKS` in `data.js` (0 = Genesis … 65 = Revelation). Verse text is plain text. `BOOKS[i] = {n:name, c:chapterCount, t:testament}`.

## Cloud (Firebase) rules of thumb
- Free (Spark) plan only: no Cloud Functions, no Storage. Files are kept inside Firestore documents (max 1 MiB per document).
- Never read/write a Firestore doc with `undefined` fields or nested arrays. Check `L.fb.on` first, and `await L.ensureIdentity()` before writing.
- Avoid queries that need a composite index (equality on one field + `orderBy` on another). Query on one field, sort in JS.
- Every collection you use needs rules in `firestore.rules`. Ownership is by `request.auth.uid`; guests have an anonymous uid.
- Everything must still render (with an explanation) when `L.fb.on` is false or the phone is offline.

## Styling
Use the existing CSS variables (`--bg --fg --surface --surface2 --line --muted --gold --green --f-title --f-ui --f-num`) so themes and fonts apply.
Ready-made classes: `.head .eyebrow .card .row .btn(.main/.danger) .iconbtn .chips .chip[aria-pressed] .seg>button[aria-pressed] .field .ta .tgl .rng .list .li(.t .meta .body .acts) .tag .empty .fab .vq .dots .dot .muted .note`.
Page-specific CSS goes in that page's own file (`notes.css`, `prayers.css`, `community.css`, `quiz.css`, `search.css`). Design for a 360 px wide phone first; nothing may scroll sideways.
The fixed bottom area is 120 px of padding on `<body>`; a `.fab` sits at the bottom-right.

## Testing in a browser
`test/harness.py` serves `www/` and replaces Firebase with `test/firebase-mock.js` (in-memory; does not enforce security rules).
```python
import sys, os; sys.path.insert(0, 'test')
from harness import app
with app() as (page, base):
    page.goto(base); page.wait_for_timeout(500)
    page.evaluate("Lectio.go('notes')")
    print(page.errors)           # uncaught errors + console.error lines collected for you
    page.screenshot(path='/tmp/x.png')
```
Run with `python3 -I yourtest.py` (from the project root). `window.__mock.seed(path, data)` / `window.__mock.dump(prefix)` read and write the fake database; `window.__mock.signInAs(name)` signs in a real (non-guest) fake user.
Use `app(width=360,height=740)` to check small phones.
