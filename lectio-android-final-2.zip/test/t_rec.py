import sys, os; sys.path.insert(0, 'test')
from harness import app
OUT='/tmp/claude-0/-home-claude/9ac21290-e598-5b5b-8a6d-943898313428/scratchpad/shots'
INIT="""
(function(){
 const md=navigator.mediaDevices||{}; 
 navigator.mediaDevices.getUserMedia=async function(){const ac=new AudioContext();const o=ac.createOscillator();const d=ac.createMediaStreamDestination();o.connect(d);o.start();return d.stream};
})();
"""
with app(width=390,height=800,init_script=INIT,permissions=['microphone']) as (page, base):
    page.goto(base); page.wait_for_timeout(800)
    page.evaluate("Lectio.go('songs')"); page.wait_for_timeout(900)
    page.click('.sg-row >> nth=2'); page.wait_for_timeout(900)
    page.click('[data-a="rec"]'); page.wait_for_timeout(400)
    page.click('[data-r="toggle"]'); page.wait_for_timeout(2300)
    page.screenshot(path=OUT+'/r1.png')
    page.click('[data-r="toggle"]'); page.wait_for_timeout(700)
    page.click('[data-r="toggle"]'); page.wait_for_timeout(1600); page.click('[data-r="toggle"]'); page.wait_for_timeout(700)
    page.click('[data-r="saveall"]'); page.wait_for_timeout(600)
    page.click('.sg-take >> nth=0 >> [data-r="pick"]'); page.wait_for_timeout(300)
    page.screenshot(path=OUT+'/r2.png')
    print(page.evaluate("localStorage.getItem('lectio-songs-rec')")[:300])
    print(page.evaluate("[...document.querySelectorAll('.sg-take')].map(e=>[e.innerText.replace(/\\n/g,' '),JSON.stringify(e.getBoundingClientRect())])"))
    print('ERR',page.errors)
