/* Notes page: sermon / study / prayer notes made of text sections and Bible verses.
   Stored in the synced list L.coll('notes').  One note looks like:
     { id, title, cat, ts (created), u (last edited, set by coll.put),
       blocks: [ {t:'text', h:'heading or empty', x:'text'},
                 {t:'verse', tid, short, b, c, v1, v2, ref, text} ] }
   The page has three screens that share one <section>: the list, one note (view), and the editor.
   The editor keeps its working copy in S.d and autosaves it to localStorage as a draft, so nothing is lost
   if the app is closed.  "Save" writes it to the synced list and removes the draft.
   Other scripts can call  Lectio.notes.addVerse({tid,short,b,c,v1,v2,ref,text})  to drop a verse into a note. */
(function(){
'use strict';
var L=window.Lectio,UI=L.ui,esc=L.esc;
var coll=L.coll('notes');
var DRAFT_KEY='lectio-note-draft-v1';
var BULLET='• ';

/* ================= templates (add a new one by adding an object here) =================
   sections: a name, or [name,'points'] when the section should start as a bullet list. */
var TEMPLATES=[
  {id:'sunday',name:'Sunday worship service',hint:'Preacher, theme, key points, songs',cat:'Sunday service',
    title:function(d){return'Sunday Worship Service, '+d},
    sections:['Preacher','Theme','Scripture',['Key points','points'],['Songs','points'],['Prayer requests','points'],['Action steps','points']]},
  {id:'table',name:'Table / communion service',hint:'Scripture, reflection, confession, thanksgiving',cat:'Communion',
    title:function(d){return'Communion Service, '+d},
    sections:['Scripture','Reflection','Confession','Thanksgiving']},
  {id:'fasting',name:'Fasting prayer',hint:'Purpose, duration, prayer points, testimony',cat:'Fasting',
    title:function(d){return'Fasting Prayer, '+d},
    sections:['Purpose','Duration','Scriptures',['Prayer points','points'],'Testimony']},
  {id:'study',name:'Bible study',hint:'Observation, interpretation, application',cat:'Bible study',
    title:function(d){return'Bible Study, '+d},
    sections:['Passage','Observation','Interpretation','Application','Prayer']},
  {id:'special',name:'Special meeting',hint:'Speaker, event, theme, takeaways',cat:'Special meeting',
    title:function(d){return'Special Meeting, '+d},
    sections:['Speaker','Event','Theme','Notes',['Takeaways','points']]},
  {id:'custom',name:'Custom',hint:'Start with a blank page',cat:'General',
    title:function(d){return'Note, '+d},
    sections:[]}
];
/* categories offered in the editor: one per template (General is the Custom one) */
var CATS=TEMPLATES.map(function(t){return t.cat});

/* ================= state ================= */
var S={mode:'list',   /* 'list' | 'view' | 'edit' */
  id:null,            /* note being viewed */
  d:null,             /* working copy while editing */
  dirty:false,        /* working copy changed since opening the editor */
  from:'list',        /* where Back from the editor goes */
  q:'',cat:'all',src:'all',recent:false};
var el=null,draftT=0;

/* ================= small helpers ================= */
function today(){return UI.fmt.date(Date.now())}
function copyJson(o){return JSON.parse(JSON.stringify(o))}
function sorted(){return coll.list().sort(function(a,b){return(b.u||0)-(a.u||0)})}
function verseCount(n){return(n.blocks||[]).filter(function(b){return b.t==='verse'}).length}
function mkText(h,x){return{t:'text',h:h||'',x:x||''}}
/* makes a clean verse block (no undefined values, numbers are numbers) */
function mkVerse(r){
  return{t:'verse',tid:String(r.tid||''),short:String(r.short||''),b:+r.b||0,c:+r.c||1,v1:+r.v1||0,v2:+r.v2||+r.v1||0,ref:String(r.ref||''),text:String(r.text||'')};
}
function verseLine(b){return b.ref+(b.short?' ('+b.short+')':'')+' '+b.text}
function getTemplate(id){return TEMPLATES.filter(function(t){return t.id===id})[0]}
function newDraftFrom(tpl){
  return{id:null,title:tpl.title(today()),cat:tpl.cat,ts:Date.now(),
    blocks:tpl.sections.map(function(s){return Array.isArray(s)?mkText(s[0],BULLET):mkText(s,'')})};
}
/* first lines of a note, for the list card */
function snippet(n){
  var out=[];
  (n.blocks||[]).forEach(function(b){
    if(b.t!=='text')return;
    String(b.x||'').split('\n').forEach(function(line){
      line=line.replace(/^•\s*/,'').trim();
      if(line&&out.length<4)out.push(line);
    });
  });
  return out.join(' • ');
}

/* ================= plain-text version, for sharing and copying ================= */
function noteText(n){
  var t=[n.title||'Untitled note',n.cat+' · '+UI.fmt.date(n.ts||n.u),''];
  (n.blocks||[]).forEach(function(b){
    if(b.t==='verse'){t.push(verseLine(b),'');return}
    var x=String(b.x||'').trim();
    if(!x&&!b.h)return;
    if(b.h)t.push(b.h.toUpperCase());
    if(x)t.push(x);
    t.push('');
  });
  t.push('Shared from Lectio');
  return t.join('\n');
}

/* ================= draft (autosave) ================= */
function saveDraftNow(){
  clearTimeout(draftT);draftT=0;
  if(!S.d||!S.dirty)return;
  try{L.lsSet(DRAFT_KEY,JSON.stringify(S.d))}catch(e){}
}
function saveDraftSoon(){S.dirty=true;clearTimeout(draftT);draftT=setTimeout(saveDraftNow,400)}
function loadDraft(){
  try{var d=JSON.parse(L.lsGet(DRAFT_KEY)||'null');return d&&d.blocks?d:null}catch(e){return null}
}
function clearDraft(){clearTimeout(draftT);draftT=0;try{window.localStorage.removeItem(DRAFT_KEY)}catch(e){}}
window.addEventListener('pagehide',saveDraftNow);
document.addEventListener('visibilitychange',function(){if(document.hidden)saveDraftNow()});

/* ================= screen: list ================= */
function dayLabel(t){
  var d=new Date(t),n=new Date(),k=function(x){return x.getFullYear()*400+x.getMonth()*32+x.getDate()};
  var y=new Date();y.setDate(n.getDate()-1);
  return k(d)===k(n)?'Today':k(d)===k(y)?'Yesterday':UI.fmt.date(t);
}
function jItems(){
  var q=S.q.trim().toLowerCase(),out=[];
  if(S.src==='all'||S.src==='notes')sorted().forEach(function(n){
    if(S.cat!=='all'&&n.cat!==S.cat)return;
    var hay=(n.title+' '+n.cat+' '+(n.blocks||[]).map(function(b){return b.t==='verse'?b.ref+' '+b.text:b.h+' '+b.x}).join(' ')).toLowerCase();
    if(!q||hay.indexOf(q)>-1)out.push({k:'n',ts:n.u||n.ts||0,n:n});
  });
  function vtxt(i){return(i.tx||[]).map(function(x){return x.t}).join(' ')}
  if(S.src==='all'||S.src==='saved')L.coll('saved').list().forEach(function(i){
    var ref=i.ref||(i.b!=null?L.bible.refName(i.b,i.c,i.v1||i.v,i.v2||i.v1||i.v):'');
    if(!q||(ref+' '+vtxt(i)).toLowerCase().indexOf(q)>-1)out.push({k:'s',ts:i.ts||0,i:i,ref:ref});
  });
  if(S.src==='all'||S.src==='hl')L.coll('hl').list().forEach(function(i){
    var ref=L.bible.refName(i.b,i.c,i.v,i.v);
    if(!q||(ref+' '+vtxt(i)).toLowerCase().indexOf(q)>-1)out.push({k:'h',ts:i.ts||0,i:i,ref:ref});
  });
  return out.sort(function(a,b){return b.ts-a.ts});
}
function jCard(x){
  if(x.k==='n'){
    var n=x.n,vc=verseCount(n),sn=snippet(n);
    return'<div class="li n-card" role="button" tabindex="0" data-open="'+esc(n.id)+'">'+
      '<div class="row2"><div class="t">'+esc(n.title||'Untitled note')+'</div><span class="tag">'+esc(n.cat)+'</span><button type="button" class="iconbtn jdel" data-ndel="'+esc(n.id)+'" aria-label="Delete note">'+UI.icon('trash',18)+'</button></div>'+
      (sn?'<div class="n-snip">'+esc(sn)+'</div>':'')+
      '<div class="meta">'+(vc?vc+(vc===1?' verse':' verses')+' · ':'')+'Edited '+esc(UI.fmt.dt(n.u))+'</div></div>';
  }
  var i=x.i,tx=(i.tx||[]).map(function(t){return'<p class="sv-tx">'+esc(t.t)+'</p>'}).join('');
  var vsn=(i.tx||[]).map(function(t){return t.s}).filter(Boolean).filter(function(v,n,a){return a.indexOf(v)===n});
  return'<div class="li j-verse jk-'+x.k+'" role="button" tabindex="0" data-sid="'+esc(i.id)+'" data-sk="'+x.k+'"><div class="row2"><span class="sv-ref">'+esc(x.ref)+'</span>'+vsn.map(function(v){return'<span class="tag">'+esc(v)+'</span>'}).join('')+(x.k==='h'&&i.col?'<span class="jdot hl-'+esc(i.col)+'"></span>':'')+'<button type="button" class="iconbtn jdel" data-sdel="1" aria-label="Remove">'+UI.icon('trash',18)+'</button></div>'+tx+'</div>';
}
function renderList(){
  var all=sorted(),draft=loadDraft();
  var cats=[];all.forEach(function(n){if(cats.indexOf(n.cat)<0)cats.push(n.cat)});
  if(S.cat!=='all'&&cats.indexOf(S.cat)<0)S.cat='all';
  var items=jItems();
  var h='<div class="head"><div class="eyebrow">Study</div><h1>'+(S.recent?'Recent':'Journal')+'</h1><p>Notes, saved verses and highlights in one place.</p></div>';
  if(draft){
    h+='<div class="card n-draft"><div><b>Unsaved draft</b><div class="muted">'+esc(draft.title||'Untitled note')+'</div></div>'+
      '<div class="row"><button type="button" class="btn main" data-act="resume">Continue</button><button type="button" class="btn" data-act="discard">Discard</button></div></div>';
  }
  h+='<label class="field n-search"><span class="n-sr">Search journal</span><input type="search" id="nQ" placeholder="Search journal" value="'+esc(S.q)+'" autocomplete="off"></label>';
  h+='<div class="chips n-chips">'+[['all','All'],['notes','Notes'],['saved','Saved'],['hl','Highlights']].map(function(c){return'<button type="button" class="chip" data-src="'+c[0]+'" aria-pressed="'+(S.src===c[0])+'">'+c[1]+'</button>'}).join('')+'</div>';
  if(cats.length>1&&(S.src==='all'||S.src==='notes')){
    h+='<div class="chips n-chips"><button type="button" class="chip" data-cat="all" aria-pressed="'+(S.cat==='all')+'">Any topic</button>'+
      cats.map(function(c){return'<button type="button" class="chip" data-cat="'+esc(c)+'" aria-pressed="'+(S.cat===c)+'">'+esc(c)+'</button>'}).join('')+'</div>';
  }
  h+='<div class="list" id="nList">';
  if(!items.length)h+='<div class="empty">'+(S.q||S.src!=='all'?'Nothing matches.':'Your journal is empty.<br>Tap + to write a note, or save a verse from the reader.')+'</div>';
  else if(S.recent){
    var last='';
    items.forEach(function(x){var d=dayLabel(x.ts);if(d!==last){h+='<div class="sec-t j-day">'+esc(d)+'</div>';last=d}h+=jCard(x)});
  }else h+=items.map(jCard).join('');
  h+='</div>';
  el.innerHTML=h;
}

/* ================= screen: one note ================= */
function renderView(){
  var n=coll.get(S.id);
  if(!n){S.mode='list';render();return}
  var h='<div class="n-top"><button type="button" class="back" data-act="list">'+UI.icon('chevron',16).replace('class="ic"','class="ic n-flip"')+'Journal</button></div>';
  h+='<div class="head"><div class="eyebrow">'+esc(n.cat)+'</div><h1 class="n-title">'+esc(n.title||'Untitled note')+'</h1>'+
    '<p>Created '+esc(UI.fmt.dt(n.ts||n.u))+'<br>Edited '+esc(UI.fmt.dt(n.u))+'</p></div>';
  h+='<div class="vacts n-acts">'+
    '<button type="button" class="vact" data-act="edit">'+UI.icon('edit')+'Edit</button>'+
    '<button type="button" class="vact" data-act="share">'+UI.icon('share')+'Share</button>'+
    '<button type="button" class="vact" data-act="copy">'+UI.icon('copy')+'Copy</button>'+
    '<button type="button" class="vact" data-act="more">'+UI.icon('more')+'More</button></div>';
  h+='<div class="n-body">';
  var shown=0;
  (n.blocks||[]).forEach(function(b){
    if(b.t==='verse'){
      shown++;
      h+='<button type="button" class="vq n-vq n-vopen" data-ob="'+b.b+'" data-oc="'+b.c+'" data-ov="'+b.v1+'" data-ot="'+esc(b.tid||'')+'"><div class="r">'+esc(b.ref)+(b.short?' · '+esc(b.short):'')+' ›</div><div class="x">'+esc(b.text)+'</div></button>';
    }else if(b.h||String(b.x||'').trim()){
      shown++;
      h+='<div class="card n-sec">'+(b.h?'<div class="n-h">'+esc(b.h)+'</div>':'')+(String(b.x||'').trim()?'<div class="n-x">'+esc(b.x)+'</div>':'<div class="muted">Nothing written.</div>')+'</div>';
    }
  });
  if(!shown)h+='<div class="empty">This note is empty. Tap Edit to add something.</div>';
  h+='</div>';
  el.innerHTML=h;
}

/* ================= screen: editor ================= */
function blockHtml(b,i,n){
  var mv='<div class="n-mv"><button type="button" class="iconbtn" data-up="'+i+'" aria-label="Move up"'+(i===0?' disabled':'')+'>'+UI.icon('up',18)+'</button>'+
    '<button type="button" class="iconbtn" data-down="'+i+'" aria-label="Move down"'+(i===n-1?' disabled':'')+'>'+UI.icon('down',18)+'</button>'+
    '<button type="button" class="iconbtn" data-rm="'+i+'" aria-label="Delete section">'+UI.icon('trash',18)+'</button></div>';
  if(b.t==='verse'){
    return'<div class="n-blk" data-i="'+i+'"><div class="n-bt"><div class="n-vref">'+esc(b.ref)+(b.short?' · '+esc(b.short):'')+'</div>'+mv+'</div>'+
      '<div class="vq n-vq"><div class="x">'+esc(b.text)+'</div></div></div>';
  }
  return'<div class="n-blk" data-i="'+i+'"><div class="n-bt"><input type="text" class="n-hin" data-i="'+i+'" data-k="h" placeholder="Heading (optional)" maxlength="80" value="'+esc(b.h)+'" aria-label="Section heading">'+mv+'</div>'+
    '<textarea class="ta n-tx" data-i="'+i+'" data-k="x" rows="3" placeholder="Write here" aria-label="Section text">'+esc(b.x)+'</textarea></div>';
}
function renderEdit(){
  var d=S.d,cats=CATS.slice();
  if(cats.indexOf(d.cat)<0)cats.push(d.cat);
  var h='<div class="head"><div class="eyebrow">'+(d.id?'Edit note':'New note')+'</div></div>';
  h+='<label class="field">Title<input type="text" id="nTitle" maxlength="120" value="'+esc(d.title)+'"></label>';
  h+='<label class="field n-gap">Category<select id="nCat">'+cats.map(function(c){return'<option'+(c===d.cat?' selected':'')+'>'+esc(c)+'</option>'}).join('')+'</select></label>';
  h+='<div class="n-blocks">'+d.blocks.map(function(b,i){return blockHtml(b,i,d.blocks.length)}).join('')+'</div>';
  if(!d.blocks.length)h+='<div class="empty">Add some text or a verse below.</div>';
  h+='<div class="n-add">'+
    '<button type="button" class="btn" data-add="text">+ Add text</button>'+
    '<button type="button" class="btn" data-add="points">+ Add points</button>'+
    '<button type="button" class="btn" data-add="verse">+ Add verse</button></div>';
  h+='<p class="note n-stamps">'+(d.id?'Created '+esc(UI.fmt.dt(d.ts))+'. Last saved '+esc(UI.fmt.dt((coll.get(d.id)||{}).u))+'.':'Created '+esc(UI.fmt.dt(d.ts))+'.')+' Your writing is kept as a draft automatically.</p>';
  h+='<div class="actionbar n-bar"><div class="abin"><button type="button" class="btn" data-act="cancel">'+(d.id?'Discard changes':'Discard')+'</button><button type="button" class="btn main" data-act="save">Save</button></div></div>';
  el.innerHTML=h;
  el.querySelectorAll('.n-tx').forEach(grow);
}
function grow(ta){ta.style.height='auto';ta.style.height=Math.max(ta.scrollHeight+2,84)+'px'}

function startEdit(draft,from){
  S.d=draft;S.dirty=false;S.from=from;S.mode='edit';render();window.scrollTo(0,0);
}
function leaveEdit(){
  saveDraftNow();
  S.mode=S.from==='view'&&S.d&&S.d.id&&coll.get(S.d.id)?'view':'list';
  if(S.mode==='view')S.id=S.d.id;
  S.d=null;S.dirty=false;
  render();window.scrollTo(0,0);
}
function saveNote(){
  var d=S.d;
  /* drop text sections with nothing written (an untouched bullet counts as empty); keep verses */
  var blocks=d.blocks.filter(function(b){return b.t==='verse'||String(b.x||'').replace(BULLET,'').trim()});
  var title=String(d.title||'').trim();
  if(!blocks.length&&!title){L.toast('Nothing to save yet');return}
  var saved=coll.put({id:d.id||null,title:title||'Untitled note',cat:d.cat||'General',ts:d.ts||Date.now(),
    blocks:blocks.map(function(b){return b.t==='verse'?mkVerse(b):mkText(String(b.h||'').trim(),String(b.x||'').replace(/\s+$/,''))})});
  clearDraft();S.d=null;S.dirty=false;S.id=saved.id;S.mode='view';
  render();window.scrollTo(0,0);L.toast('Note saved');
}

/* template chooser */
function chooseTemplate(){
  var h='<div class="alist">'+TEMPLATES.map(function(t){
    return'<button type="button" class="aitem n-tpl" data-tpl="'+t.id+'"><span><b>'+esc(t.name)+'</b><small>'+esc(t.hint)+'</small></span></button>';
  }).join('')+'</div>';
  var m=UI.modal({title:'Start a note',sheet:true,body:h});
  m.body.addEventListener('click',function(e){
    var b=e.target.closest('[data-tpl]');if(!b)return;
    var tpl=getTemplate(b.dataset.tpl);m.close();
    var old=loadDraft();
    if(old&&old.blocks.length){clearDraft()}   /* a new note replaces an unfinished draft; the list already offered Continue */
    startEdit(newDraftFrom(tpl),'list');
  });
}

/* ================= actions ================= */
function addBlock(kind){
  if(kind==='verse'){
    L.bible.pick({verses:true,place:'notes'}).then(function(r){
      if(!r||!S.d)return;
      S.d.blocks.push(mkVerse(r));saveDraftSoon();renderEdit();scrollToLast();
    });
    return;
  }
  S.d.blocks.push(mkText('',kind==='points'?BULLET:''));
  saveDraftSoon();renderEdit();scrollToLast();
  var tas=el.querySelectorAll('.n-tx');var last=tas[tas.length-1];
  if(last){last.focus();last.setSelectionRange(last.value.length,last.value.length)}
}
function scrollToLast(){
  var bs=el.querySelectorAll('.n-blk');var b=bs[bs.length-1];
  if(b&&b.scrollIntoView)b.scrollIntoView({block:'center',behavior:'smooth'});
}
function moveBlock(i,dir){
  var a=S.d.blocks,j=i+dir;if(j<0||j>=a.length)return;
  var t=a[i];a[i]=a[j];a[j]=t;saveDraftSoon();renderEdit();
}

function onAction(act){
  var n=S.id?coll.get(S.id):null;
  if(act==='new')chooseTemplate();
  else if(act==='list'){S.mode='list';render();window.scrollTo(0,0)}
  else if(act==='resume'){var d=loadDraft();if(d){S.dirty=true;startEdit(d,d.id&&coll.get(d.id)?'view':'list')}}
  else if(act==='discard')UI.confirm('Throw away this unsaved draft?',{ok:'Discard',danger:true}).then(function(ok){if(ok){clearDraft();render()}});
  else if(act==='edit'&&n)startEdit(copyJson(n),'view');
  else if(act==='share'&&n)UI.share({title:n.title,text:noteText(n)});
  else if(act==='copy'&&n)UI.copy(noteText(n)).then(function(ok){L.toast(ok?'Copied':'Could not copy')});
  else if(act==='del'&&n)UI.confirm('Delete “'+(n.title||'Untitled note')+'”? This cannot be undone.',{ok:'Delete',danger:true}).then(function(ok){
    if(!ok)return;coll.remove(n.id);S.mode='list';S.id=null;render();window.scrollTo(0,0);L.toast('Note deleted');
  });
  else if(act==='jmenu')UI.actionSheet({title:'Journal',items:[
    {label:'Journal',icon:'note',on:function(){S.recent=false;renderList();if(L.bars)L.bars.refresh()}},
    {label:'Recent',icon:'clock',on:function(){S.recent=true;renderList();if(L.bars)L.bars.refresh()}}]});
  else if(act==='more'&&n)UI.actionSheet({title:n.title||'Note',items:[
    {label:'Add as view',icon:'swap',on:function(){try{var k='lectio-split-v1',o=JSON.parse(L.lsGet(k)||'null');if(o){o.b.k='notes';L.lsSet(k,JSON.stringify(o))}}catch(e){}L.go('split')}},
    {label:'All verse notes',icon:'note',on:function(){S.mode='list';S.src='notes';S.q='';render()}},
    {label:'Show in Journal',icon:'book',on:function(){S.mode='list';S.src='all';S.q=n.title||'';render()}},
    {label:'Share',icon:'share',on:function(){onAction('share')}},
    {label:'Email',icon:'send',on:function(){window.location.href='mailto:?subject='+encodeURIComponent(n.title||'Note')+'&body='+encodeURIComponent(noteText(n))}},
    {label:'Print',icon:'file',on:function(){window.print()}},
    {label:'Delete',icon:'trash',danger:true,on:function(){onAction('del')}}]});
  else if(act==='save')saveNote();
  else if(act==='cancel'){
    if(!S.dirty){clearDraft();leaveEdit();return}
    UI.confirm(S.d.id?'Throw away your changes to this note?':'Throw away this new note?',{ok:'Discard',danger:true}).then(function(ok){
      if(ok){S.dirty=false;clearDraft();leaveEdit()}
    });
  }
}

/* ================= events (one set of listeners; the page's HTML is rebuilt freely) ================= */
/* tap a saved verse or highlight: open it in the reader, in the version it was saved in */
function openSaved(li){
  var c=L.coll(li.dataset.sk==='h'?'hl':'saved'),it=c.get(li.dataset.sid);if(!it)return;
  var loc=li.dataset.sk==='h'?{b:it.b,c:it.c,v:it.v}:(it.b!=null?{b:it.b,c:it.c,v:it.v1}:(function(){var p=L.bible.parseRef(it.ref||'');return p&&{b:p.b,c:p.c,v:p.v1}})());
  var sh=it.tx&&it.tx[0]&&it.tx[0].s,ver=sh&&L.bible.versions().filter(function(v){return v.short===sh})[0];
  if(loc)L.openReader(loc.b,loc.c,loc.v,ver?ver.id:undefined);
}
function wire(){
  el.addEventListener('click',function(e){
    var t=e.target.closest('button,[data-open]');
    if(t&&t.dataset.ndel){e.stopPropagation();var nid=t.dataset.ndel;UI.confirm('Delete this note?',{ok:'Delete',danger:true}).then(function(y){if(y){coll.remove(nid);renderList()}});return}
    if(!t||!el.contains(t)){
      var jv=e.target.closest&&e.target.closest('.j-verse');
      if(jv&&el.contains(jv))openSaved(jv);
      return;
    }
    if(t.dataset.act){onAction(t.dataset.act);return}
    if(t.dataset.open){S.id=t.dataset.open;S.mode='view';render();window.scrollTo(0,0);return}
    if(t.dataset.ob!=null){L.openReader(+t.dataset.ob,+t.dataset.oc,+t.dataset.ov||undefined,t.dataset.ot||undefined);return}
    if(t.dataset.cat){S.cat=t.dataset.cat;renderList();return}
    if(t.dataset.src){S.src=t.dataset.src;renderList();return}
    if(t.dataset.sopen||t.dataset.sdel){
      var li=t.closest('[data-sid]'),c=L.coll(li.dataset.sk==='h'?'hl':'saved'),it=c.get(li.dataset.sid);if(!it)return;
      if(t.dataset.sdel){UI.confirm('Remove this from your journal?',{ok:'Remove',danger:true}).then(function(y){if(y){c.remove(it.id);renderList()}});return}
      openSaved(li);return}
    if(t.dataset.add){addBlock(t.dataset.add);return}
    if(t.dataset.up!=null)moveBlock(+t.dataset.up,-1);
    else if(t.dataset.down!=null)moveBlock(+t.dataset.down,1);
    else if(t.dataset.rm!=null){
      var i=+t.dataset.rm,b=S.d.blocks[i];
      var empty=b.t==='text'&&!String(b.x||'').trim()&&!String(b.h||'').trim();
      if(empty){S.d.blocks.splice(i,1);saveDraftSoon();renderEdit();return}
      UI.confirm('Delete this section?',{ok:'Delete',danger:true}).then(function(ok){if(ok){S.d.blocks.splice(i,1);saveDraftSoon();renderEdit()}});
    }
  });
  el.addEventListener('keydown',function(e){
    var c=e.target.closest&&e.target.closest('[data-open]');
    if(c&&e.target===c&&(e.key==='Enter'||e.key===' ')){e.preventDefault();c.click()}
  });
  el.addEventListener('input',function(e){
    var t=e.target;
    if(t.id==='nQ'){
      S.q=t.value;
      /* only redraw the cards so the search box keeps focus */
      var keep=t.selectionStart;renderList();var q=L.$('nQ');if(q){q.focus();try{q.setSelectionRange(keep,keep)}catch(x){}}
      return;
    }
    if(S.mode!=='edit'||!S.d)return;
    if(t.id==='nTitle'){S.d.title=t.value;saveDraftSoon()}
    else if(t.dataset.k){
      S.d.blocks[+t.dataset.i][t.dataset.k]=t.value;saveDraftSoon();
      if(t.tagName==='TEXTAREA')grow(t);
    }
  });
  el.addEventListener('change',function(e){
    if(e.target.id==='nCat'&&S.d){S.d.cat=e.target.value;saveDraftSoon()}
  });
  /* Pressing Enter inside a bullet line starts a new bullet; Enter on an empty bullet ends the list. */
  el.addEventListener('beforeinput',function(e){
    var ta=e.target;
    if(!ta||!ta.classList||!ta.classList.contains('n-tx'))return;
    if(e.inputType!=='insertLineBreak'&&e.inputType!=='insertParagraph')return;
    if(ta.selectionStart!==ta.selectionEnd)return;
    var v=ta.value,pos=ta.selectionStart,ls=v.lastIndexOf('\n',pos-1)+1,line=v.slice(ls,pos);
    if(line.indexOf(BULLET)!==0)return;
    e.preventDefault();
    var before,after=v.slice(pos);
    if(line===BULLET){before=v.slice(0,ls);ta.value=before+after;ta.setSelectionRange(before.length,before.length)}
    else{before=v.slice(0,pos)+'\n'+BULLET;ta.value=before+after;ta.setSelectionRange(before.length,before.length)}
    ta.dispatchEvent(new Event('input',{bubbles:true}));
  });
}

function render(){
  if(!el)return;
  if(S.mode==='edit'&&S.d)renderEdit();
  else if(S.mode==='view')renderView();
  else{S.mode='list';renderList()}
}

/* ================= register the page ================= */
el=L.registerView({
  id:'notes',title:'Journal',
  menu:{label:'Journal',icon:'note',group:'study',order:10},
  show:function(){render()},
  leave:function(){saveDraftNow()}
});
wire();
/* synced changes from another phone: refresh unless the user is typing */
coll.on(function(){if(L.view==='notes'&&S.mode!=='edit')render()});
/* Back button: close the editor / note before leaving the page */
L.back.push(function(){
  if(L.view!=='notes')return false;
  if(S.mode==='edit'){
    if(S.dirty)saveDraftNow();
    leaveEdit();return true;
  }
  if(S.mode==='view'){S.mode='list';render();return true}
  return false;
});

/* ================= public API: notes for verses (used by the reader) ================= */
function appendBlocks(id,blocks){
  var title;
  if(S.d&&S.d.id===id){
    /* that note is open in the editor: add to the working copy so nothing gets overwritten */
    S.d.blocks=S.d.blocks.concat(blocks);saveDraftSoon();saveDraftNow();title=S.d.title;
    if(L.view==='notes'&&S.mode==='edit')renderEdit();
  }else{
    var n=coll.get(id);if(!n)return;
    var c=copyJson(n);c.blocks=(c.blocks||[]).concat(blocks);
    coll.put(c);title=n.title;
  }
  L.toast('Added to “'+(title||'note')+'”');
}
/* notes that contain verse v of chapter c of book b */
function forVerse(b,c,v){
  return sorted().filter(function(n){return(n.blocks||[]).some(function(k){return k.t==='verse'&&k.b===b&&k.c===c&&k.v1<=v&&v<=(k.v2||k.v1)})});
}
/* {verseNumber:count} for one chapter (reader draws a small note icon for these) */
function verseMap(b,c){
  var m={};
  coll.list().forEach(function(n){(n.blocks||[]).forEach(function(k){
    if(k.t!=='verse'||k.b!==b||k.c!==c)return;
    for(var v=k.v1;v<=(k.v2||k.v1);v++)m[v]=(m[v]||0)+1;
  })});
  return m;
}
function textOf(n){
  return(n.blocks||[]).filter(function(k){return k.t==='text'&&String(k.x||'').trim()}).map(function(k){return String(k.x).replace(/^•\s*/gm,'').trim()}).join(' · ');
}
/* the popup: notes about these verses, plus a form to write a note, add more verses and save it */
function verseNotes(r){
  if(!r||!r.ref)return;
  var pend=[mkVerse(r)],typed='';
  var linked=[];
  if(r.b!=null&&r.v1){
    var seen={};
    for(var v=r.v1;v<=(r.v2||r.v1);v++)forVerse(r.b,r.c,v).forEach(function(n){if(!seen[n.id]){seen[n.id]=1;linked.push(n)}});
  }
  var m=UI.modal({title:'Notes for '+r.ref,sheet:true,body:'<div class="n-pop"></div>'});
  var box=m.body.querySelector('.n-pop');
  function draw(){
    var t=box.querySelector('#npT');if(t)typed=t.value;
    var list=sorted(),h='';
    if(linked.length){
      h+='<div class="sec-t">Your notes on this verse</div><div class="n-pick">'+linked.map(function(n){
        return'<button type="button" class="n-pickrow" data-open="'+esc(n.id)+'"><b>'+esc(n.title||'Untitled note')+'</b><small>'+esc(n.cat)+' · '+esc(UI.fmt.dt(n.u))+'</small>'+(textOf(n)?'<span class="n-snip">'+esc(textOf(n).slice(0,160))+'</span>':'')+'</button>';
      }).join('')+'</div>';
    }
    h+='<div class="sec-t">'+(linked.length?'Add another note':'Add a note')+'</div>';
    h+='<div class="n-pv">'+pend.map(function(v,i){return'<div class="n-pvrow"><span><b>'+esc(v.ref)+'</b>'+(v.short?' <small>'+esc(v.short)+'</small>':'')+'</span>'+(pend.length>1?'<button type="button" class="iconbtn" data-rmv="'+i+'" aria-label="Remove verse">'+UI.icon('x',16)+'</button>':'')+'</div>'}).join('')+'</div>';
    h+='<button type="button" class="btn n-addv" data-addv="1">'+UI.icon('plus',16)+' Add another verse</button>';
    h+='<label class="field">Your note<textarea class="ta" id="npT" rows="4" placeholder="Write what this verse says to you…">'+esc(typed)+'</textarea></label>';
    h+='<button type="button" class="btn main n-newnote" data-new="1">'+UI.icon('plus',18)+' Save as new note</button>';
    if(list.length)h+='<div class="sec-t">Or add to an existing note</div><div class="n-pick">'+list.map(function(n){
      return'<button type="button" class="n-pickrow" data-id="'+esc(n.id)+'"><b>'+esc(n.title||'Untitled note')+'</b><small>'+esc(n.cat)+' · edited '+esc(UI.fmt.ago(n.u))+'</small></button>';
    }).join('')+'</div>';
    box.innerHTML=h;
  }
  function blocks(){
    var t=box.querySelector('#npT'),x=t?t.value.trim():typed.trim(),b=pend.slice();
    if(x)b.push(mkText('',x));
    return b;
  }
  box.addEventListener('click',function(e){
    var t=e.target.closest('button');if(!t)return;
    if(t.dataset.open){m.close();L.notes.open(t.dataset.open);return}
    if(t.dataset.rmv!=null){draw();pend.splice(+t.dataset.rmv,1);draw();return}
    if(t.dataset.addv){
      draw();
      B().pick({verses:true,place:'notes'}).then(function(x){if(x){pend.push(mkVerse(x));draw()}});
      return;
    }
    if(t.dataset.id){var bl=blocks();m.close();appendBlocks(t.dataset.id,bl);return}
    if(t.dataset.new){
      var bl2=blocks();
      UI.prompt({title:'New note',label:'Title',value:'Notes on '+pend[0].ref,ok:'Create'}).then(function(title){
        if(title==null)return;
        var n=coll.put({title:title,cat:'General',ts:Date.now(),blocks:bl2});
        m.close();L.toast('Saved to “'+n.title+'”');
      });
    }
  });
  draw();
}
function B(){return L.bible}
function addVerse(r){verseNotes(r)}
L.notes={act:function(a){onAction(a)},title:function(){return S.recent?'Recent':'Journal'},addVerse:addVerse,verseNotes:verseNotes,forVerse:forVerse,verseMap:verseMap,on:function(f){return coll.on(f)},
  /* open a note by id (handy for search or other pages) */
  open:function(id){if(!coll.get(id))return;S.id=id;S.mode='view';if(L.view==='notes')render();else L.go('notes')}};
})();
