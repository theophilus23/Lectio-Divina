/* Quiz: daily challenge (10 questions, one try a day), endless practice, and a leaderboard. */
(function(){
'use strict';
var L=window.Lectio,$=L.$,esc=L.esc,UI=L.ui,B=L.bible;
var DAILY_N=10;
var S={tab:'home',q:null,idx:0,list:[],ans:[],start:0,mode:'',pf:{cat:'all',d:0},streak:0,sess:{n:0,ok:0},picked:-1,lb:'today',lbData:null,lbErr:'',lbBusy:false};

function key(){return UI.fmt.dayKey(Date.now())}
function ls(k,def){try{var v=L.lsGet(k);return v?JSON.parse(v):def}catch(e){return def}}
function lset(k,v){L.lsSet(k,JSON.stringify(v))}
function stats(){return ls('lectio-quiz-stats',{best:0,ok:0,n:0,days:0,pts:0})}

/* seeded random so everybody gets the same daily set */
function hash(s){var h=2166136261;for(var i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0}
function rng(seed){var a=hash(String(seed));return function(){a|=0;a=a+0x6D2B79F5|0;var t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
function shuffle(arr,r){var a=arr.slice();for(var i=a.length-1;i>0;i--){var j=Math.floor(r()*(i+1)),t=a[i];a[i]=a[j];a[j]=t}return a}
function dailySet(k){
  var r=rng('lectio-'+k),pool=window.QUIZ,hand=pool.filter(function(q){return q.cat!=='Verses'}),vs=pool.filter(function(q){return q.cat==='Verses'});
  var pick=shuffle(hand,r).slice(0,8).concat(shuffle(vs,r).slice(0,2));
  return shuffle(pick,r);
}
function dayEnd(){var d=new Date();d.setHours(24,0,0,0);return d-Date.now()}
function hm(ms){var m=Math.max(0,Math.round(ms/60000));return Math.floor(m/60)+'h '+(m%60)+'m'}
function mmss(ms){var s=Math.round(ms/1000);return Math.floor(s/60)+':'+String(s%60).padStart(2,'0')}
function myDaily(k){return ls('lectio-quiz-d-'+k,null)}

var el=L.registerView({id:'quiz',title:'Quiz',menu:{label:'Quiz',icon:'star',group:'study',order:20},show:function(){S.q=null;S.tab=S.tab==='play'?'home':S.tab;draw()},leave:function(){}});

function head(){return'<div class="head"><div class="eyebrow">Quiz</div><h1>Know your Bible</h1></div>'}
function tabs(){return'<div class="seg qtabs">'+[['home','Play'],['board','Leaderboard']].map(function(t){return'<button type="button" data-tab="'+t[0]+'" aria-pressed="'+(S.tab===t[0])+'">'+t[1]+'</button>'}).join('')+'</div>'}

function draw(){
  if(S.tab==='play'){drawQ();return}
  if(S.tab==='board'){drawBoard();return}
  var k=key(),dn=myDaily(k),st=stats(),h=head()+tabs();
  h+='<div class="card qcard"><div class="row"><b>Daily challenge</b><span class="tag">'+k+'</span></div>';
  if(dn)h+='<p class="big">'+dn.score+' / '+DAILY_N+'</p><p class="muted">Done in '+mmss(dn.ms)+'. New questions in '+hm(dayEnd())+'.</p><button class="btn wide" data-act="review">Review answers</button>';
  else h+='<p class="muted">'+DAILY_N+' questions, the same for everyone today. One try, so take your time.</p><button class="btn main wide" data-act="daily">Start today’s challenge</button>';
  h+='</div>';
  h+='<div class="card qcard"><b>Practice</b><p class="muted">Endless questions, no limit. Build your memory of the Word.</p>';
  h+='<div class="grid2"><label class="field">Topic<select id="pcat"><option value="all">All topics</option>'+window.QUIZ_CATS.map(function(c){return'<option>'+esc(c)+'</option>'}).join('')+'</select></label><label class="field">Level<select id="pd"><option value="0">Any</option><option value="1">Easy</option><option value="2">Medium</option><option value="3">Hard</option></select></label></div>';
  h+='<button class="btn main wide" data-act="practice">Start practice</button></div>';
  h+='<div class="card qcard"><b>Your numbers</b><div class="qstats"><div><i>'+st.days+'</i><span>Daily done</span></div><div><i>'+st.best+'</i><span>Best streak</span></div><div><i>'+(st.n?Math.round(st.ok*100/st.n):0)+'%</i><span>Correct</span></div></div></div>';
  el.innerHTML=h;
  $('pcat').value=S.pf.cat;$('pd').value=String(S.pf.d);
}

function startDaily(){
  S.mode='daily';S.list=dailySet(key());S.idx=0;S.ans=[];S.start=Date.now();S.picked=-1;S.tab='play';draw();
}
function nextPractice(){
  var pool=window.QUIZ.filter(function(q){return(S.pf.cat==='all'||q.cat===S.pf.cat)&&(!S.pf.d||q.d===S.pf.d)});
  if(!pool.length)pool=window.QUIZ;
  var last=S.list[0]&&S.list[0].id,q;
  for(var i=0;i<6;i++){q=pool[Math.floor(Math.random()*pool.length)];if(q.id!==last)break}
  S.list=[q];S.idx=0;S.picked=-1;
}
function startPractice(){S.mode='practice';S.streak=0;S.sess={n:0,ok:0};S.tab='play';nextPractice();draw()}

function qHtml(q){
  var h='<div class="qq">'+esc(q.q).replace(/\n/g,'<br>')+'</div><div class="qopts">';
  q.o.forEach(function(o,i){
    var cls='qo';if(S.picked>-1){if(i===q.a)cls+=' ok';else if(i===S.picked)cls+=' bad'}
    h+='<button type="button" class="'+cls+'" data-o="'+i+'"'+(S.picked>-1?' disabled':'')+'>'+esc(o)+'</button>';
  });
  return h+'</div>';
}
function drawQ(){
  var q=S.list[S.idx],h='<div class="head"><div class="eyebrow">'+(S.mode==='daily'?'Daily challenge':'Practice')+'</div></div>';
  h+='<div class="card qcard"><div class="row"><span class="muted">'+(S.mode==='daily'?'Question '+(S.idx+1)+' of '+S.list.length:'Streak '+S.streak+' · '+S.sess.ok+'/'+S.sess.n)+'</span><span class="tag">'+esc(q.cat)+'</span></div>';
  if(S.mode==='daily')h+='<div class="meter"><i style="width:'+(S.idx/S.list.length*100)+'%"></i></div>';
  h+=qHtml(q);
  if(S.picked>-1&&S.mode==='practice'){
    var ok=S.picked===q.a;
    h+='<div class="qexp '+(ok?'ok':'bad')+'"><b>'+(ok?'Correct':'Not quite')+'</b>'+(q.e?'<p>'+esc(q.e)+'</p>':'')+'<p class="muted">'+esc(q.ref)+'</p></div><div class="row"><button class="btn" data-act="open">Open passage</button><button class="btn main" data-act="next">Next</button></div>';
  }
  h+='<button class="btn qquit" data-act="quit">'+(S.mode==='daily'?'Quit (counts as not played)':'Finish')+'</button></div>';
  el.innerHTML=h;
}
function answer(i){
  var q=S.list[S.idx];if(S.picked>-1)return;
  S.picked=i;
  if(S.mode==='daily'){
    S.ans.push(i);drawQ();
    setTimeout(function(){if(S.tab!=='play')return;S.idx++;S.picked=-1;if(S.idx>=S.list.length)finishDaily();else drawQ()},650);
  }else{
    var ok=i===q.a,st=stats();S.sess.n++;st.n++;
    if(ok){S.sess.ok++;S.streak++;st.ok++;if(S.streak>st.best)st.best=S.streak}else S.streak=0;
    lset('lectio-quiz-stats',st);drawQ();
  }
}
async function finishDaily(){
  var score=0;S.list.forEach(function(q,i){if(S.ans[i]===q.a)score++});
  var ms=Date.now()-S.start,k=key();
  lset('lectio-quiz-d-'+k,{score:score,ms:ms,ans:S.ans,ids:S.list.map(function(q){return q.id})});
  var st=stats();st.days++;st.pts+=score;st.n+=DAILY_N;st.ok+=score;lset('lectio-quiz-stats',st);
  S.tab='home';
  var h=head()+'<div class="card qcard qdone"><p class="big">'+score+' / '+DAILY_N+'</p><p>'+(score>=9?'Excellent!':score>=7?'Well done!':score>=5?'Good effort.':'Keep reading, keep growing.')+'</p><p class="muted">Time '+mmss(ms)+'</p><div id="qsub" class="muted">Posting to the leaderboard…</div><button class="btn main wide" data-act="review">Review answers</button><button class="btn wide" data-act="board">See leaderboard</button></div>';
  el.innerHTML=h;
  var r=await submit(k);
  var n=$('qsub');if(n)n.textContent=r==='ok'?'Posted to the leaderboard.':r==='queued'?'Saved. It will post when you are online and signed in.':'';
}

/* ---- leaderboard ---- */
function queue(){return ls('lectio-quiz-queue',[])}
async function submit(k){
  var d=myDaily(k);if(!d)return'';
  if(!L.fb.on)return'';
  var q=queue();if(q.indexOf(k)<0){q.push(k);lset('lectio-quiz-queue',q)}
  return await flush();
}
async function flush(){
  var q=queue();if(!q.length||!L.fb.on)return'';
  var id=null;try{id=await L.ensureIdentity({reason:'to join the leaderboard'})}catch(e){}
  if(!id)return'queued';
  var db=L.fb.db,left=[];
  for(var i=0;i<q.length;i++){
    var k=q[i],d=myDaily(k);if(!d)continue;
    try{
      var ref=db.collection('quiz_daily').doc(k+'_'+id.uid),ex=await ref.get();
      if(!ex.exists){
        await ref.set({date:k,uid:id.uid,name:String(id.name||'Reader').slice(0,40),score:d.score,total:DAILY_N,ms:d.ms,t:Date.now()});
        var sr=db.collection('quiz_scores').doc(id.uid),sd=await sr.get(),o=sd.exists?sd.data():{pts:0,days:0};
        await sr.set({uid:id.uid,name:String(id.name||'Reader').slice(0,40),pts:(o.pts||0)+d.score,days:(o.days||0)+1,t:Date.now()});
      }
    }catch(e){left.push(k)}
  }
  lset('lectio-quiz-queue',left);
  return left.length?'queued':'ok';
}
function weekStart(){var d=new Date();d.setDate(d.getDate()-6);return UI.fmt.dayKey(d.getTime())}
async function loadBoard(){
  S.lbBusy=true;S.lbErr='';S.lbData=null;drawBoard();
  if(!L.fb.on){S.lbBusy=false;S.lbErr='The leaderboard needs the online setup (Firebase) to be switched on.';drawBoard();return}
  try{
    try{await flush()}catch(e){}
    var db=L.fb.db,rows=[];
    if(S.lb==='today'){
      var s=await db.collection('quiz_daily').where('date','==',key()).get();s.forEach(function(d){rows.push(d.data())});
      rows.sort(function(a,b){return b.score-a.score||a.ms-b.ms});
    }else if(S.lb==='week'){
      var s2=await db.collection('quiz_daily').where('date','>=',weekStart()).get(),m={};
      s2.forEach(function(d){var x=d.data(),r=m[x.uid]||(m[x.uid]={uid:x.uid,name:x.name,score:0,days:0,ms:0});r.score+=x.score;r.days++;r.ms+=x.ms;r.name=x.name});
      rows=Object.keys(m).map(function(u){return m[u]}).sort(function(a,b){return b.score-a.score||a.ms-b.ms});
    }else{
      var s3=await db.collection('quiz_scores').orderBy('pts','desc').limit(50).get();s3.forEach(function(d){var x=d.data();rows.push({uid:x.uid,name:x.name,score:x.pts,days:x.days})});
    }
    S.lbData=rows.slice(0,50);
  }catch(e){S.lbErr='Could not load the leaderboard. Check your connection.'}
  S.lbBusy=false;if(S.tab==='board')drawBoard();
}
function drawBoard(){
  var h=head()+tabs()+'<div class="seg qtabs">'+[['today','Today'],['week','This week'],['all','All time']].map(function(t){return'<button type="button" data-lb="'+t[0]+'" aria-pressed="'+(S.lb===t[0])+'">'+t[1]+'</button>'}).join('')+'</div>';
  if(S.lbBusy)h+='<p class="empty">Loading…</p>';
  else if(S.lbErr)h+='<p class="empty">'+esc(S.lbErr)+'</p>';
  else if(S.lbData){
    if(!S.lbData.length)h+='<p class="empty">No scores yet. Be the first!</p>';
    else{
      var me=L.user&&L.user.uid;
      h+='<div class="list">'+S.lbData.map(function(r,i){
        return'<div class="li qrow'+(r.uid===me?' me':'')+'"><span class="qrank">'+(i<3?['🥇','🥈','🥉'][i]:i+1)+'</span><div class="qname"><b>'+esc(r.name||'Reader')+'</b><span class="muted">'+(S.lb==='today'?mmss(r.ms):r.days+' day'+(r.days===1?'':'s'))+'</span></div><span class="qscore">'+r.score+(S.lb==='today'?'/'+(r.total||DAILY_N):' pts')+'</span></div>';
      }).join('')+'</div>';
    }
  }
  el.innerHTML=h;
}
function review(){
  var k=key(),d=myDaily(k);if(!d)return;
  var qs=d.ids.map(function(id){return window.QUIZ.filter(function(q){return q.id===id})[0]}).filter(Boolean);
  var h=head()+'<div class="row"><button class="btn" data-act="home">Back</button><span class="tag">'+d.score+' / '+DAILY_N+'</span></div><div class="list">';
  qs.forEach(function(q,i){var a=d.ans[i],ok=a===q.a;
    h+='<div class="li"><div class="t">'+(i+1)+'. '+esc(q.q).replace(/\n/g,'<br>')+'</div><div class="body">Your answer: <b class="'+(ok?'qok':'qbad')+'">'+esc(q.o[a]!=null?q.o[a]:'—')+'</b>'+(ok?'':'<br>Right answer: <b>'+esc(q.o[q.a])+'</b>')+'</div><div class="muted">'+esc(q.ref)+(q.e?' · '+esc(q.e):'')+'</div></div>'});
  el.innerHTML=h+'</div>';
}

el.addEventListener('click',function(e){
  var t=e.target.closest('button');if(!t)return;
  if(t.dataset.tab){S.tab=t.dataset.tab;if(S.tab==='board')loadBoard();else draw();return}
  if(t.dataset.lb){S.lb=t.dataset.lb;loadBoard();return}
  if(t.dataset.o!=null){answer(+t.dataset.o);return}
  var a=t.dataset.act;if(!a)return;
  if(a==='daily')startDaily();
  else if(a==='practice'){S.pf.cat=$('pcat').value;S.pf.d=+$('pd').value;startPractice()}
  else if(a==='next'){nextPractice();drawQ()}
  else if(a==='open'){var q=S.list[S.idx],r=B.parseRef(q.ref);if(r)L.openReader(r.b,r.c,r.v1||undefined)}
  else if(a==='quit'){S.tab='home';draw()}
  else if(a==='review')review();
  else if(a==='home'){S.tab='home';draw()}
  else if(a==='board'){S.tab='board';loadBoard()}
});

/* small card on the Today page */
function home(){
  var box=$('homeExtra');if(!box)return;
  var c=$('qHome');if(!c){c=document.createElement('div');c.id='qHome';box.appendChild(c)}
  var dn=myDaily(key());
  c.innerHTML='<div class="card qhome"><div class="row"><div><b>Daily quiz</b><div class="muted">'+(dn?'Today: '+dn.score+'/'+DAILY_N:'10 questions waiting')+'</div></div><button class="btn '+(dn?'':'main')+'" id="qGo" type="button">'+(dn?'Practice':'Play')+'</button></div></div>';
  $('qGo').onclick=function(){S.tab='home';L.go('quiz')};
}
L.onShow.push(function(n){if(n==='home')home()});
L.on('ready',home);
window.addEventListener('online',function(){if(queue().length)flush()});
})();
