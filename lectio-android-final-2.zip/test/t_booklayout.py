import sys; sys.path.insert(0,'test')
from harness import app
with app(width=390,height=800) as (page,base):
    page.set_default_timeout(4000); page.goto(base); page.wait_for_timeout(800)
    # 1. notes verse picker: pills by default, chooses Psalms
    page.evaluate("window.__r=null;void Lectio.bible.pick({verses:true,place:'notes'}).then(function(r){window.__r=r})"); page.wait_for_timeout(500)
    print('notes picker pills:',page.eval_on_selector_all('.umodal .blb','e=>e.length'),'first',page.inner_text('.umodal .blb .nm'),'| chapters visible while choosing book:',page.eval_on_selector_all('.umodal .pickgrid','e=>e.length'))
    page.screenshot(path='/tmp/bl_notes1.png')
    page.click('.umodal .blb[data-b="18"]'); page.wait_for_timeout(250)
    print('after pick book:',page.inner_text('.umodal .pkbook').replace('\n',' '),'| chapter buttons',page.eval_on_selector_all('.umodal .pickgrid button','e=>e.length'))
    page.click('.umodal [data-c="23"]'); page.wait_for_timeout(500)
    page.click('.umodal [data-v="1"]'); page.click('.umodal button.main'); page.wait_for_timeout(300)
    print('result:',page.evaluate("__r&&__r.ref"))
    # 2. settings card
    page.evaluate("Lectio.openSettings('sc-booklayout')"); page.wait_for_timeout(500)
    print('title:',page.inner_text('#sTitle'),'| places',page.eval_on_selector_all('#sc-booklayout .blplace','e=>e.length'))
    page.screenshot(path='/tmp/bl_set1.png',full_page=True)
    # change notes -> names, prayers -> tiles, plans -> dropdown not allowed
    page.click('[data-set="notes:names"]'); page.click('[data-set="prayers:tiles"]'); page.wait_for_timeout(200)
    print('layouts:',page.evaluate("['lib','reader','notes','prayers','plans'].map(function(p){return p+'='+Lectio.bookLayout.get(p)}).join(' ')"))
    print('stored:',page.evaluate("JSON.stringify(Lectio.settings.bookLayouts)"))
    print('plans has dropdown button:',page.eval_on_selector_all('[data-set="plans:dropdown"]','e=>e.length'))
    # apply to all -> names
    page.click('[data-all="names"]'); page.wait_for_timeout(200)
    print('all names:',page.evaluate("['lib','reader','notes','prayers','plans'].map(function(p){return Lectio.bookLayout.get(p)}).join(',')"))
    # reset one
    page.click('[data-reset="notes"]'); print('notes reset ->',page.evaluate("Lectio.bookLayout.get('notes')"))
    page.screenshot(path='/tmp/bl_set2.png',full_page=True)
    # dropdown for the reader
    page.click('[data-set="reader:dropdown"]'); page.wait_for_timeout(100)
    page.evaluate("void Lectio.bible.pick({verses:true,place:'reader'})"); page.wait_for_timeout(400)
    print('reader dropdown select present:',page.eval_on_selector_all('.umodal #pkB','e=>e.length'),'pills',page.eval_on_selector_all('.umodal .blb','e=>e.length'))
    page.evaluate("Lectio.ui.handleBack()"); page.wait_for_timeout(200)
    # 3. Bible page as pills
    page.click('[data-set="lib:pills"]'); page.evaluate("Lectio.go('lib')"); page.wait_for_timeout(500)
    print('bible page pills:',page.eval_on_selector_all('#otGrid .book.blpill','e=>e.length'),page.eval_on_selector_all('#ntGrid .book.blpill','e=>e.length'))
    page.screenshot(path='/tmp/bl_lib.png')
    page.click('#otGrid .book:nth-child(2)'); page.wait_for_timeout(400); print('tapped book -> view',page.evaluate("Lectio.view"))
    # 4. plans setup uses layout
    page.evaluate("Lectio.bookLayout.resetAll();Lectio.go('plans')"); page.wait_for_timeout(300)
    page.click('[data-new=custom]'); page.wait_for_timeout(300)
    page.click('.plsetup .blb[data-b="39"]'); page.click('.plsetup .blb[data-b="40"]'); page.wait_for_timeout(200)
    print('plan summary:',page.inner_text('#plSum'))
    page.screenshot(path='/tmp/bl_plans.png')
    print('ERRORS',page.errors)
