/* Reading plans: preset or custom plans, a few chapters a day on a calendar, ticked off by hand or automatically
   when the chapter is marked read in the app. Synced list L.coll('plans'):
   { id, name, start (ms, local midnight of day 1), days, l:[b*1000+c ...] (chapters in reading order),
     ch:{ "b.c":1 } (ticked in the plan), stop (ms or 0), made }                                             */
(function(){
'use strict';
var L=window.Lectio,$=L.$,esc=L.esc,UI=L.ui;
var coll=L.coll('plans');
var DAY=86400000;

function idx(name){for(var i=0;i<BOOKS.length;i++)if(BOOKS[i].n===name)return i;return 0}
function range(a,b){var r=[];for(var i=a;i<=b;i++)r.push(i);return r}
var PRESETS=[
  {name:'Whole Bible in a year',days:365,books:range(0,BOOKS.length-1),desc:'Genesis to Revelation, about 3 chapters a day.'},
  {name:'New Testament in 90 days',days:90,books:range(OT_N,BOOKS.length-1),desc:'Matthew to Revelation, about 3 chapters a day.'},
  {name:'The four Gospels in 30 days',days:30,books:range(idx('Matthew'),idx('John')),desc:'Matthew, Mark, Luke and John.'},
  {name:'Psalms and Proverbs in a month',days:31,books:[idx('Psalms'),idx('Proverbs')],desc:'Five Psalms and a Proverb a day.'},
  {name:'Old Testament in 270 days',days:270,books:range(0,OT_N-1),desc:'Genesis to Malachi, about 4 chapters a day.'}
];
function day0(ts){var d=new Date(ts);d.setHours(0,0,0,0);return d.getTime()}
function ymd(ts){var d=new Date(ts);return d.getFullYear()+'-'+('0'+(d.getMonth()+1)).slice(-2)+'-'+('0'+d.getDate()).slice(-2)}
function fromYmd(s){var p=String(s).split('-').map(Number);return p.length===3&&p[0]?new Date(p[0],p[1]-1,p[2]).getTime():day0(Date.now())}
function chapsOf(books,skipRead){
  var r=[];books.slice().sort(function(a,b){return a-b}).forEach(function(b){for(var c=1;c<=BOOKS[b].c;c++)if(!(skipRead&&L.chapterRead(b,c)))r.push(b*1000+c)});
  return r;
}
function dayIndex(it,ts){return Math.round((day0(ts)-it.start)/DAY)}
function readingFor(it,i){var l=it.l,n=l.length;return l.slice(Math.floor(i*n/it.days),Math.floor((i+1)*n/it.days))}
function ckey(x){return Math.floor(x/1000)+'.'+(x%1000)}
function chDone(it,x){return !!(it.ch&&it.ch[ckey(x)])||L.chapterRead(Math.floor(x/1000),x%1000)}
function dayDone(it,i){var r=readingFor(it,i);return r.length>0&&r.every(function(x){return chDone(it,x)})}
function cname(x){return BOOKS[Math.floor(x/1000)].n+' '+(x%1000)}
function stats(it){
  var done=0,streak=0,today=dayIndex(it,Date.now()),behind=0,i;
  for(i=0;i<it.days;i++)if(dayDone(it,i))done++;
  for(i=Math.min(today,it.days-1);i>=0;i--){if(dayDone(it,i))streak++;else if(i===today)continue;else break}
  for(i=0;i<Math.min(today,it.days);i++)if(!dayDone(it,i))behind++;
  var left=it.l.filter(function(x){return!chDone(it,x)}).length;
  return{done:done,streak:streak,behind:behind,today:today,left:left,finished:left===0&&it.l.length>0};
}

/* Time-based plans: fixed presets only (no custom minutes). One chapter takes about 3.6 minutes at a calm pace
   (the KJV is roughly 660 words a chapter), so N minutes a day is about N/3.6 chapters, spread evenly over the unread Bible. */
var MINS=[15,30,45,60],CH_MIN=3.6;
function timeInfo(m,skip){var l=chapsOf(range(0,BOOKS.length-1),skip!==false),per=Math.max(1,Math.round(m/CH_MIN)),days=Math.min(1000,Math.min(l.length,Math.max(1,Math.ceil(l.length*CH_MIN/m))));
  return{l:l,per:per,days:days}}
function startTime(m){var t=timeInfo(m);if(!t.l.length){L.toast('You have already marked every chapter read');return}
  var id='pl-'+Date.now();coll.put({id:id,name:'Read '+m+' minutes a day',start:day0(Date.now()),days:t.days,l:t.l,ch:{},stop:0,made:Date.now(),mins:m});
  S.id=id;S.sel=null;S.month=null;draw();L.toast('Plan started: '+m+' minutes a day')}
function timeCard(){var m=S.mins||30,t=timeInfo(m),end=day0(Date.now())+(t.days-1)*DAY;
  return'<div class="card tplans"><div class="sec-t" style="margin-top:0">Read every day for…</div><div class="tpt" role="radiogroup" aria-label="Minutes a day">'+MINS.map(function(x){
    return'<button type="button" class="tpb" role="radio" data-mins="'+x+'" aria-checked="'+(x===m)+'"><b>'+x+'</b><span>min</span></button>'}).join('')+'</div>'+
    '<p class="note tpest">'+(t.l.length?'About '+t.per+' chapter'+(t.per>1?'s':'')+' a day. '+t.l.length+' chapters left, finished in about '+t.days+' days (around '+UI.fmt.date(end)+').':'You have marked every chapter read.')+'</p>'+
    '<button type="button" class="btn main tpgo" data-startmins="'+m+'">Start '+m+' min a day</button><p class="note">Pick a length. Lectio sets a daily amount and ticks chapters off as you mark them read. Times are estimates.</p></div>'}
var S={id:null,month:null,sel:null,mins:30};
var el=L.registerView({id:'plans',title:'Reading plans',menu:{label:'Reading plans',icon:'calendar',group:'read',order:4},show:function(){S.id=null;draw()}});

function card(it,past){
  var st=stats(it),pct=Math.round(100*(it.l.length-st.left)/Math.max(1,it.l.length));
  var info=it.stop?'Stopped '+UI.fmt.date(it.stop):st.finished?'Finished':st.today<0?'Starts '+UI.fmt.date(it.start):'Day '+Math.min(st.today+1,it.days)+' of '+it.days+(st.behind?' · '+st.behind+' day'+(st.behind>1?'s':'')+' behind':' · on track');
  return'<button type="button" class="li plcard" data-open="'+esc(it.id)+'"><div class="row2"><b class="t">'+esc(it.name)+'</b><span class="tag">'+pct+'%</span></div><div class="meter"><i style="width:'+pct+'%"></i></div><div class="meta">'+esc(info)+'</div></button>';
}
function draw(){
  var h='<div class="head"><div class="eyebrow">Read</div><h1>Reading plans</h1><p>A few chapters a day. Chapters you mark read in the app tick off automatically.</p></div>';
  if(S.id){h+=detail()}
  else{
    var all=coll.list().sort(function(a,b){return(b.made||0)-(a.made||0)});
    var act=all.filter(function(i){return!i.stop&&!stats(i).finished}),old=all.filter(function(i){return i.stop||stats(i).finished});
    h+=timeCard();
    h+='<button type="button" class="plnew" data-new="custom"><span class="pi">'+UI.icon('plus',18)+'</span><span>Make my own plan</span>'+UI.icon('chevron',16)+'</button>';
    if(act.length)h+='<div class="sec-t">My plans</div><div class="list">'+act.map(function(i){return card(i)}).join('')+'</div>';
    h+='<div class="sec-t">Ready-made plans</div><div class="list">'+PRESETS.map(function(p,i){
      return'<div class="li plpre"><div class="row2"><b class="t">'+esc(p.name)+'</b><span class="tag">'+p.days+' days</span></div><div class="plrow2"><div class="body">'+esc(p.desc)+'</div><button type="button" class="iconbtn plgo" data-new="'+i+'" aria-label="Set up and start" title="Set up and start">'+UI.icon('plus',20)+'</button></div></div>'}).join('')+'</div>';
    if(old.length)h+='<div class="sec-t">Finished or stopped</div><div class="list">'+old.map(function(i){return card(i)}).join('')+'</div>';
  }
  el.innerHTML=h;
}

function detail(){
  var it=coll.get(S.id);if(!it){S.id=null;return''}
  var st=stats(it),total=it.l.length,pct=Math.round(100*(total-st.left)/Math.max(1,total));
  if(!S.month)S.month=new Date(new Date().getFullYear(),new Date().getMonth(),1).getTime();
  if(S.sel==null)S.sel=Math.max(0,Math.min(st.today,it.days-1));
  var h='<button type="button" class="btn" data-back="1">‹ All plans</button><div class="card" style="margin-top:12px"><div class="row2"><b class="t">'+esc(it.name)+'</b><span class="tag">'+pct+'%</span></div><div class="meter"><i style="width:'+pct+'%"></i></div>'+
    '<div class="meta">'+(total-st.left)+' of '+total+' chapters · '+st.done+' of '+it.days+' days done · streak '+st.streak+(st.behind?' · '+st.behind+' behind':'')+'<br>Started '+UI.fmt.date(it.start)+(it.stop?' · Stopped '+UI.fmt.date(it.stop):'')+(st.finished?' · Finished':'')+'</div></div>';
  var m=new Date(S.month),first=m.getDay(),dim=new Date(m.getFullYear(),m.getMonth()+1,0).getDate();
  h+='<div class="card"><div class="row"><button type="button" class="iconbtn" data-mn="-1" aria-label="Previous month">‹</button><b>'+m.toLocaleString(undefined,{month:'long',year:'numeric'})+'</b><button type="button" class="iconbtn" data-mn="1" aria-label="Next month">›</button></div><div class="cal">';
  'SMTWTFS'.split('').forEach(function(d){h+='<span class="dw">'+d+'</span>'});
  for(var b=0;b<first;b++)h+='<span></span>';
  for(var d=1;d<=dim;d++){
    var ts=new Date(m.getFullYear(),m.getMonth(),d).getTime(),i=dayIndex(it,ts),inP=i>=0&&i<it.days;
    h+='<button type="button" class="cd'+(inP?'':' off')+(i===S.sel?' sel':'')+(day0(Date.now())===ts?' today':'')+'" '+(inP?'data-day="'+i+'"':'disabled')+'>'+d+(inP?'<i>'+(dayDone(it,i)?'✓':'•')+'</i>':'')+'</button>';
  }
  h+='</div></div>';
  var r=readingFor(it,S.sel);
  h+='<div class="card"><div class="row2"><b class="t">Day '+(S.sel+1)+(it.mins?' · about '+it.mins+' min':'')+'</b><span class="muted">'+UI.fmt.date(it.start+S.sel*DAY)+'</span></div><div>'+r.map(function(x){
    var on=chDone(it,x);
    return'<div class="plch"><button type="button" class="p-circ" data-tick="'+ckey(x)+'" aria-pressed="'+on+'" aria-label="Mark read">'+(on?UI.icon('check',16):'')+'</button><span class="plname">'+esc(cname(x))+'</span><button type="button" class="btn" data-read="'+ckey(x)+'">Read</button></div>'}).join('')+'</div>'+
    '<div class="acts"><button type="button" class="btn main" data-all="1">'+(dayDone(it,S.sel)?'Day done ✓ (tap to undo)':'Mark day done')+'</button></div></div>';
  h+='<div class="row plfoot">'+(it.stop?'<button type="button" class="btn" data-resume="1">Resume plan</button>':'<button type="button" class="btn" data-stop="1">Stop plan</button>')+'<button type="button" class="btn" data-home="1">'+(it.home===false?'Show on Today':'Shown on Today ✓')+'</button><button type="button" class="linkbtn" data-del="1">Delete</button></div>';
  return h;
}

/* ---- set up a plan (preset or custom) ---- */
function openSetup(preset){
  var f={name:preset?preset.name:'My reading plan',books:preset?preset.books.slice():[],mode:'days',n:preset?preset.days:30,start:ymd(Date.now()),skip:true};
  var QUICK=[['All',range(0,BOOKS.length-1)],['Old Testament',range(0,OT_N-1)],['New Testament',range(OT_N,BOOKS.length-1)],['Gospels',range(idx('Matthew'),idx('John'))],['Psalms',[idx('Psalms')]],['Proverbs',[idx('Proverbs')]],['Clear',[]]];
  var m=UI.modal({title:preset?'Set up this plan':'Make my own plan',wide:true,body:'<div class="plsetup"></div>',actions:[{label:'Cancel'},{label:'Start plan',kind:'main',on:function(){
    sync();var l=chapsOf(f.books,f.skip);
    if(!l.length){L.toast('Choose books with chapters you have not read yet');return false}
    var days=f.mode==='days'?Math.max(1,Math.min(1000,Math.floor(+f.n)||1)):Math.max(1,Math.ceil(l.length/Math.max(1,Math.floor(+f.n)||1)));
    if(days>l.length)days=l.length;
    var id='pl-'+Date.now();
    coll.put({id:id,name:f.name.trim()||'My reading plan',start:fromYmd(f.start),days:days,l:l,ch:{},stop:0,made:Date.now()});
    S.id=id;S.sel=null;S.month=null;draw();L.toast('Plan started');
  }}]});
  var box=m.body.querySelector('.plsetup');
  function sync(){var g=function(i){var e=box.querySelector(i);return e};
    f.name=g('#plN').value;f.n=g('#plNum').value;f.start=g('#plS').value||ymd(Date.now())}
  function summary(){
    sync();var l=chapsOf(f.books,f.skip),n=Math.floor(+f.n)||0,days,per;
    if(!l.length){box.querySelector('#plSum').textContent='Choose at least one book.';return}
    days=f.mode==='days'?Math.max(1,n):Math.max(1,Math.ceil(l.length/Math.max(1,n)));if(days>l.length)days=l.length;per=l.length/days;
    box.querySelector('#plSum').textContent=l.length+' chapters over '+days+' day'+(days>1?'s':'')+', about '+(Math.round(per*10)/10)+' chapter'+(per>1.05?'s':'')+' a day. Ends '+UI.fmt.date(fromYmd(f.start)+(days-1)*DAY)+'.';
  }
  function draw1(){
    box.innerHTML='<label class="field">Plan name<input id="plN" maxlength="60" value="'+esc(f.name)+'"></label>'+
    '<div class="sec-t">Books</div><div class="chips">'+QUICK.map(function(q,i){return'<button type="button" class="chip" data-q="'+i+'">'+q[0]+'</button>'}).join('')+'</div>'+
    '<div class="plbooks plbl">'+L.bookLayout.html('plans',{selected:f.books})+'</div>'+
    '<div class="sec-t">How fast</div><div class="seg"><button type="button" data-mode="days" aria-pressed="'+(f.mode==='days')+'">I choose the days</button><button type="button" data-mode="per" aria-pressed="'+(f.mode==='per')+'">I choose chapters a day</button></div>'+
    '<label class="field">'+(f.mode==='days'?'Number of days':'Chapters per day')+'<input id="plNum" type="number" inputmode="numeric" min="1" max="1000" value="'+esc(f.n)+'"></label>'+
    '<label class="field">Start date<input id="plS" type="date" value="'+esc(f.start)+'"></label>'+
    '<button type="button" class="tgl" data-skip="1" aria-pressed="'+f.skip+'"><span>Skip chapters I have already marked read</span><i></i></button>'+
    '<p class="note">Pick a past start date to continue where you already are. Chapters you mark read in the app always tick off in the plan by themselves.</p><p class="note" id="plSum"></p>';
    summary();
  }
  box.addEventListener('click',function(e){
    var b=e.target.closest('button');if(!b)return;sync();
    if(b.dataset.b!=null){var i=+b.dataset.b,k=f.books.indexOf(i);if(k>-1)f.books.splice(k,1);else f.books.push(i);b.setAttribute('aria-pressed',String(k===-1));summary()}
    else if(b.dataset.q!=null){f.books=QUICK[+b.dataset.q][1].slice();draw1()}
    else if(b.dataset.mode){if(f.mode!==b.dataset.mode){f.mode=b.dataset.mode;f.n=f.mode==='days'?30:3;draw1()}}
    else if(b.dataset.skip){f.skip=!f.skip;b.setAttribute('aria-pressed',String(f.skip));summary()}
  });
  box.addEventListener('input',summary);
  draw1();
}

el.addEventListener('click',function(e){
  var t=e.target.closest('button');if(!t)return;
  var d=t.dataset,it=S.id&&coll.get(S.id);
  if(d.mins){S.mins=+d.mins;draw()}
  else if(d.startmins){startTime(+d.startmins)}
  else if(d.new!=null){openSetup(d.new==='custom'?null:PRESETS[+d.new])}
  else if(d.open){S.id=d.open;S.sel=null;S.month=null;draw()}
  else if(d.back){S.id=null;draw()}
  else if(d.mn){var m=new Date(S.month);S.month=new Date(m.getFullYear(),m.getMonth()+(+d.mn),1).getTime();draw()}
  else if(d.day!=null){S.sel=+d.day;draw()}
  else if(d.tick&&it){
    var q=d.tick.split('.').map(Number);
    if(L.chapterRead(q[0],q[1])){L.toast('Already marked read in your Bible progress');return}
    var ch=Object.assign({},it.ch);if(ch[d.tick])delete ch[d.tick];else ch[d.tick]=1;coll.put(Object.assign({},it,{ch:ch}));draw()}
  else if(d.read){var p=d.read.split('.').map(Number);L.openReader(p[0],p[1])}
  else if(d.all&&it){var was=dayDone(it,S.sel),ch2=Object.assign({},it.ch);
    readingFor(it,S.sel).forEach(function(x){if(was){if(!L.chapterRead(Math.floor(x/1000),x%1000))delete ch2[ckey(x)]}else ch2[ckey(x)]=1});
    coll.put(Object.assign({},it,{ch:ch2}));draw();if(!was)L.toast('Day '+(S.sel+1)+' done. Well done!')}
  else if(d.stop&&it){UI.confirm('Stop this plan? You can resume it later.',{ok:'Stop'}).then(function(ok){if(ok){coll.put(Object.assign({},it,{stop:Date.now()}));draw()}})}
  else if(d.home&&it){coll.put(Object.assign({},it,{home:it.home===false}));draw();homeCard()}
  else if(d.resume&&it){coll.put(Object.assign({},it,{stop:0}));draw()}
  else if(d.del&&it){UI.confirm('Delete this plan and its ticks? Your Bible reading progress is not affected.',{ok:'Delete',danger:true}).then(function(ok){if(ok){coll.remove(it.id);S.id=null;draw()}})}
});
coll.on(function(src){if(src==='sync'&&L.view==='plans')draw()});
L.on('progress',function(){if(L.view==='plans')draw();homeCard()});

/* Today page card: every plan the reader ticked "Show on Today" (default on), each with a progress bar */
function homeCard(){
  var box=$('homeExtra');if(!box)return;var old=$('plHome');if(old)old.remove();
  var its=coll.list().filter(function(it){return!it.stop&&it.home!==false&&it.l&&it.l.length}).sort(function(a,b){return(b.made||0)-(a.made||0)});
  if(!its.length)return;
  var c=document.createElement('div');c.id='plHome';c.className='card plhome';
  c.innerHTML=its.map(function(it){
    var st=stats(it),pct=Math.round(100*(it.l.length-st.left)/Math.max(1,it.l.length)),line='';
    if(st.finished)line='Finished';
    else if(st.today>=0&&st.today<it.days){var r=readingFor(it,st.today);line=dayDone(it,st.today)?'Done for today ✓':r.map(cname).join(', ')}
    else line='Starts soon';
    return'<button type="button" class="plrow" data-pl="'+esc(it.id)+'"><div class="row2"><b>'+esc(it.name)+'</b><span class="tag">'+pct+'%</span></div><div class="meter"><i style="width:'+pct+'%"></i></div><div class="meta">'+esc(line)+'</div></button>';
  }).join('');
  c.onclick=function(e){var b=e.target.closest('[data-pl]');if(!b)return;S.id=b.dataset.pl;S.sel=null;S.month=null;L.go('plans')};
  box.appendChild(c);
}
L.onShow.push(function(n){if(n==='home')homeCard()});
L.on('ready',homeCard);coll.on(homeCard);
})();
