import sys, os; sys.path.insert(0, 'test')
from harness import app
OUT='/tmp/claude-0/-home-claude/9ac21290-e598-5b5b-8a6d-943898313428/scratchpad/shots'
with app(width=390,height=800) as (page, base):
    page.goto(base); page.wait_for_timeout(800)
    page.evaluate("Lectio.go('songs')"); page.wait_for_timeout(800)
    for sec in ['malayalam','tamil','hindi']:
        page.click('.sg-tabs [data-s="%s"]'%sec); page.wait_for_timeout(1500)
        page.screenshot(path=OUT+'/s_%s_list.png'%sec)
        page.click('.sg-row >> nth=3'); page.wait_for_timeout(1500)
        page.screenshot(path=OUT+'/s_%s_read.png'%sec)
        if sec=='tamil':
            page.click('[data-a="slides"]'); page.wait_for_timeout(500)
            page.screenshot(path=OUT+'/s_slides.png')
            page.click('[data-s="close"]')
        page.click('[data-a="close"]'); page.wait_for_timeout(300)
    # search lyrics in zion
    page.click('.sg-tabs [data-s="zion"]'); page.wait_for_timeout(1000)
    page.fill('#sgQ','yesu'); page.wait_for_timeout(600)
    print('rows yesu',page.evaluate("document.querySelectorAll('.sg-row').length"), page.inner_text('#sgSub')[:60])
    page.fill('#sgQ','23'); page.wait_for_timeout(600)
    print('first row for 23:',page.inner_text('.sg-row >> nth=0')[:40].replace('\n',' | '))
    # favourite + mine
    page.click('.sg-row >> nth=0 >> [data-fv]'); page.click('.sg-tabs [data-s="mine"]'); page.wait_for_timeout(800)
    print('mine rows',page.evaluate("document.querySelectorAll('.sg-row').length"))
    print('ERR',page.errors)
