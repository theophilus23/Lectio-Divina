# Turn on sign-in and cloud sync (Firebase)

The app works without this. Do these steps once to enable accounts and sync.

1. Go to https://console.firebase.google.com and create a project (Analytics is not needed).
2. Project settings > General > Your apps > add a **Web** app (the `</>` icon). Copy the `firebaseConfig` values.
3. Open `www/firebase-config.js` and replace each `PASTE_...` value with yours.
4. Build > Authentication > Get started > Sign-in method > enable **Email/Password** and also **Anonymous** (guests use it to post on the prayer wall and join the quiz leaderboard).
5. Build > Firestore Database > Create database (production mode, pick a region near you).
6. Firestore > Rules: paste the contents of `firestore.rules` and Publish.
7. Rebuild the app: `npx cap sync android`, then run it again from Android Studio.

What gets stored:
- `users/{uid}`: name, email, reading progress and appearance settings.
- `users/{uid}/stores/{list}`: your reading history, saved verses, highlights, notes and prayer points (one document per list, only you can read it).
- `quiz_daily` and `quiz_scores`: daily quiz results and totals for the leaderboard (everyone can read, one result per person per day).
- `prayerwall` and `prayer_reports`: community prayer requests, reactions and reports.
- `portal_tokens`: short backup codes for the prayer-request QR portal (see below). Each one just maps a code to a post id — not listable or browsable.
Everything stays on the free Spark plan (no Cloud Functions, no Storage). Re-paste `firestore.rules` whenever you update the app.
Progress merges per book by newest change, so reading offline on two devices never loses a book you marked.

Google sign-in is not included. It needs a native plugin and an SHA-1 key; email and password works inside the app as is.

## Turn on the prayer-request QR portal

A free, public web page anyone can scan or open without installing the app, to post a prayer request straight to the prayer wall. Needs the Firebase steps above done first (it reuses the same project, same Anonymous sign-in, same `prayerwall` collection).

1. Copy `portal/firebase-config.example.js` to `portal/firebase-config.js` and paste in the **same** keys you used for `www/firebase-config.js`.
2. Install the Firebase CLI once, if you don't have it: `npm install -g firebase-tools`, then `firebase login`.
3. From the project folder, run `firebase init hosting` — when it asks, pick your existing project, and when it asks for a public directory just leave `firebase.json` as committed (it already points `hosting` at the `portal` folder) or answer "No" to overwriting it.
4. Deploy: `firebase deploy --only hosting,firestore:rules`.
5. Firebase gives you a URL like `https://<your-project-id>.web.app` — that's the portal, live immediately. In the app, open **Prayer wall → Share QR code** and it builds the QR code from that same address automatically (no extra setup there).
6. Whenever you change `portal/index.html` or `firestore.rules`, redeploy with the same command.

How someone's post stays theirs to edit or delete:
- The portal signs them in anonymously (same mechanism as a guest posting from inside the app), and that sign-in is remembered on their device — so reopening the portal later on the *same* phone/browser shows "Manage your requests" automatically, even if they posted more than once.
- They're also shown a one-time backup code after posting. Entering that code on a *different* device links that request to the new device too — it never expires and isn't guessable (Firestore rules refuse to let it even be listed, only looked up by its exact value).

## Communities (church / group profiles)
Needs nothing new beyond the steps above: publish the updated `firestore.rules` and redeploy the portal.
- **Menu → Community → Create a community** (signed-in accounts only, so the creator keeps control). Each community gets a 6-letter code and its own QR code (**QR code** button: copy link, save a printable PNG, or share). The QR opens `https://<project>.web.app/?c=CODE`, a page for that community where anyone, with no app, can send a prayer request or a testimony (choosing Man/Woman) and see the links the leaders share.
- Each community has its **own** Prayers and Testimonies, separate from the open prayer wall. They are readable only by the community's leaders (and by the person who wrote a post) until a leader turns on **Show to everyone** on that tab.
- Leaders (owner + invited leaders) can add YouTube videos, a channel, social posts and other links, set an announcement, edit the profile, and remove posts. Owner: **Manage → Invite another leader** makes a one-time-style code; the other person opens the community, taps **Become a leader** and enters it.
- Members join with the code (or by scanning the QR and installing the app later). Guests and anonymous visitors can post from the portal or the app.
- Firestore paths: `communities/{code}` and its `prayers`, `testimonies`, `links`, `invites` subcollections.
