import sys, os; sys.path.insert(0, 'test')
from harness import app
OUT='/tmp/claude-0/-home-claude/9ac21290-e598-5b5b-8a6d-943898313428/scratchpad/shots'
with app(width=390,height=1500) as (page, base):
    page.goto(base); page.wait_for_timeout(800)
    page.evaluate("Lectio.go('songs')"); page.wait_for_timeout(1000)
    page.click('.sg-row >> nth=2'); page.wait_for_timeout(800)
    page.click('[data-a="panel"]'); page.wait_for_timeout(400)
    page.evaluate("document.querySelector('.sg-panel').style.height='100%'")
    page.screenshot(path=OUT+'/6_panel_full.png')
    print(page.evaluate("[...document.querySelectorAll('.sg-pbody input[type=range]')].map(i=>[i.offsetWidth,i.offsetHeight,getComputedStyle(i).display])"))
