/* Lectio core: progress, reading history, settings model, accounts + cloud sync, navigation, menu, today page. */
(function(){
'use strict';
var $=function(id){return document.getElementById(id)};
var UI=window.LUI,esc=UI.esc,toast=UI.toast;
var CHECK='<svg viewBox="0 0 24 24"><path pathLength="1" d="M5 12.5l4.5 4.5L19 7.5"/></svg>';
function lsGet(k){try{return window.localStorage.getItem(k)}catch(e){return null}}
function lsSet(k,v){try{window.localStorage.setItem(k,v)}catch(e){}}
function clone(o){return JSON.parse(JSON.stringify(o))}

/* tiny event bus: progress, settings, track, identity, versions */
var bus={};
function on(n,f){(bus[n]=bus[n]||[]).push(f)}
function emit(n,d){(bus[n]||[]).slice().forEach(function(f){try{f(d)}catch(e){if(window.console)console.error(n,e)}})}

/* ================= settings model ================= */
var DEF_FONTS={verse:'cormorant',title:'cormorant',ui:'hanken',num:'cormorant',read:'lora'};
var DEF_COLORS={bg:null,book:null,chapter:null,done:null,accent:null,text:null};
var DEF_READER={gx:16,px:14,py:12,vx:6,vy:5,gap:6,align:'left',lh:1.7,op:92,border:true,radius:22,numStyle:'col'};
var DEF_VBG={on:false,mode:'all',sel:[],palette:'soft',seed:1};
function defaultSettings(){return{mode:'auto',fonts:clone(DEF_FONTS),colors:clone(DEF_COLORS),tfonts:{},tcolors:{},reader:clone(DEF_READER),vbg:clone(DEF_VBG),autoTrack:true,bookLayouts:{},bookOrder:'bible',ui:{}}}
var SWATCHES=['#0B1020','#101820','#14110F','#0E1A14','#1B1B1B','#000000','#1E2A4A','#2B1D3A','#3B2A20','#123B33','#4A1F2A','#2F3640','#FFFFFF','#F4F1EA','#EDEFF3','#E8F1EC','#F6E9EE','#FFF6DD','#E5EEFB','#EADFF5','#1F8A5B','#35C089','#2E7D32','#00A86B','#D6B268','#8A6819','#E4572E','#C2185B','#3B82F6','#7C4DFF','#F59E0B','#14B8A6','#9AA3B8','#5A6479'];
var ALLVARS=['--bg','--fg','--surface','--surface2','--line','--muted','--book','--book-fg','--chap','--chap-fg','--green','--green-fg','--gold','--gold-soft','--f-verse','--f-title','--f-ui','--f-num','--f-read','--verse-style'];

function fontById(id){for(var i=0;i<FONTS.length;i++)if(FONTS[i].id===id)return FONTS[i];return FONTS[0]}
function hex2rgb(h){h=h.replace('#','');return[parseInt(h.slice(0,2),16),parseInt(h.slice(2,4),16),parseInt(h.slice(4,6),16)]}
function rgb2hex(r){return'#'+r.map(function(v){return Math.max(0,Math.min(255,Math.round(v))).toString(16).padStart(2,'0')}).join('')}
function mix(a,b,t){var x=hex2rgb(a),y=hex2rgb(b);return rgb2hex([x[0]+(y[0]-x[0])*t,x[1]+(y[1]-x[1])*t,x[2]+(y[2]-x[2])*t])}
function hexA(h,a){var c=hex2rgb(h);return'rgba('+c[0]+','+c[1]+','+c[2]+','+a+')'}
function lum(h){var c=hex2rgb(h).map(function(v){v/=255;return v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4)});return .2126*c[0]+.7152*c[1]+.0722*c[2]}
function readable(h){return lum(h)>0.36?'#10151F':'#FFFFFF'}

function fontVars(f){
  var v={};
  v['--f-verse']=fontById(f.verse).css;v['--f-title']=fontById(f.title).css;v['--f-ui']=fontById(f.ui).css;
  v['--f-num']=fontById(f.num).css;v['--f-read']=fontById(f.read).css;
  v['--verse-style']=fontById(f.verse).it?'italic':'normal';
  return v;
}
function colorVars(c){
  var v={}, fg=null;
  if(c.bg){
    fg=c.text||(lum(c.bg)>0.36?'#121A2E':'#ECEFF7');
    v['--bg']=c.bg;v['--fg']=fg;
    v['--surface']=mix(c.bg,fg,.07);v['--surface2']=mix(c.bg,fg,.14);
    v['--line']=hexA(fg,.14);v['--muted']=mix(fg,c.bg,.42);
    v['--book']=v['--surface'];v['--chap']=v['--surface'];
    v['--book-fg']=fg;v['--chap-fg']=fg;
  }else if(c.text){v['--fg']=c.text}
  if(c.book){v['--book']=c.book;v['--book-fg']=readable(c.book)}
  if(c.chapter){v['--chap']=c.chapter;v['--chap-fg']=readable(c.chapter)}
  if(c.done){v['--green']=c.done;v['--green-fg']=readable(c.done)}
  if(c.accent){v['--gold']=c.accent;v['--gold-soft']=hexA(c.accent,.15)}
  return v;
}
function applyVars(el,s){
  ALLVARS.forEach(function(n){el.style.removeProperty(n)});
  var v=Object.assign({},fontVars(s.fonts),colorVars(s.colors));
  Object.keys(v).forEach(function(n){el.style.setProperty(n,v[n])});
}
/* reader layout: written as CSS variables on <html>, so the reader and the Settings preview both follow it */
function applyReaderLayout(r){
  var el=document.documentElement.style;
  el.setProperty('--r-gx',r.gx+'px');el.setProperty('--r-px',r.px+'px');el.setProperty('--r-py',r.py+'px');
  el.setProperty('--r-vx',r.vx+'px');el.setProperty('--r-vy',r.vy+'px');el.setProperty('--r-gap',(r.gap==null?6:r.gap)+'px');
  el.setProperty('--r-align',r.align);el.setProperty('--r-lh',String(r.lh));
  el.setProperty('--r-op',r.op+'%');el.setProperty('--r-bw',r.border?'1px':'0px');el.setProperty('--r-radius',r.radius+'px');
  document.documentElement.setAttribute('data-rnums',r.numStyle==='inline'?'inline':'col');
}
function applyTheme(s){
  var r=document.documentElement;
  applyVars(r,s);applyReaderLayout(s.reader);
  if(s.mode==='light'||s.mode==='dark')r.setAttribute('data-theme',s.mode);else r.removeAttribute('data-theme');
}
/* per-translation reading style: {font:css|null, color:hex|null} */
function tstyle(tid,isTel){
  var f=settings.tfonts[tid],c=settings.tcolors[tid];
  return{font:f&&FONTS.some(function(x){return x.id===f})?fontById(f).css:(isTel?fontById(TEL_DEFAULT).css:null),color:c||null};
}

var settings=defaultSettings(), settingsT=0;
function setSettings(d){
  if(!d)return;
  var s=defaultSettings();
  s.mode=(d.mode==='light'||d.mode==='dark')?d.mode:'auto';
  s.fonts=Object.assign(s.fonts,d.fonts||{});
  s.colors=Object.assign(s.colors,d.colors||{});
  s.tfonts=Object.assign({},d.tfonts||{});s.tcolors=Object.assign({},d.tcolors||{});
  s.reader=Object.assign(s.reader,d.reader||{});
  s.vbg=Object.assign(s.vbg,d.vbg||{});if(!Array.isArray(s.vbg.sel))s.vbg.sel=[];
  s.autoTrack=d.autoTrack!==false;
  s.bookLayouts=(d.bookLayouts&&typeof d.bookLayouts==='object')?Object.assign({},d.bookLayouts):{};s.bookOrder=d.bookOrder==='az'?'az':'bible';
  s.ui=(d.ui&&typeof d.ui==='object')?JSON.parse(JSON.stringify(d.ui)):{};
  Object.keys(DEF_FONTS).forEach(function(k){if(!FONTS.some(function(f){return f.id===s.fonts[k]}))s.fonts[k]=DEF_FONTS[k]});
  Object.keys(s.tfonts).forEach(function(k){if(!FONTS.some(function(f){return f.id===s.tfonts[k]}))delete s.tfonts[k]});
  settings=s;
}
function loadSettings(){
  try{var raw=lsGet('lectio-settings-v1');if(!raw)return;var o=JSON.parse(raw);setSettings(o.d);settingsT=+o.t||0}catch(e){}
}
function saveSettings(){settingsT=Date.now();lsSet('lectio-settings-v1',JSON.stringify({d:settings,t:settingsT}))}
/* call after changing L.settings: saves, applies the theme, syncs, and tells listeners */
function commitSettings(){saveSettings();applyTheme(settings);schedulePush();emit('settings',settings)}

/* ================= progress (local) ================= */
var done=BOOKS.map(function(){return new Set()}), stamp=BOOKS.map(function(){return 0});
var rounds=0,roundsT=0;
var rs={s:0,t:0,est:0};               /* current round: start time (0 = not started), time of last change, est = start was estimated */
var historyC=LColl.make('history');   /* one item per completed round: {id:'round-N', n, s:start, e:end, name} */
function progressObj(){
  var p={};
  done.forEach(function(s,i){if(stamp[i]>0||s.size)p[i]={c:Array.from(s).sort(function(a,b){return a-b}),t:stamp[i]||1}});
  return p;
}
function setProgress(p){
  done.forEach(function(s){s.clear()});stamp.fill(0);
  Object.keys(p||{}).forEach(function(k){
    var i=+k, r=p[k];if(!BOOKS[i]||!r)return;
    (r.c||[]).forEach(function(c){if(c>=1&&c<=BOOKS[i].c)done[i].add(c)});
    stamp[i]=+r.t||1;
  });
}
function saveProgress(){lsSet('lectio-v2',JSON.stringify({p:progressObj(),r:{n:rounds,t:roundsT},rs:rs}))}
function mergeRounds(r){if(r&&(+r.n||0)>rounds){rounds=+r.n;roundsT=+r.t||0;return true}return false}
function mergeRS(r){if(r&&(+r.t||0)>(rs.t||0)){rs={s:+r.s||0,t:+r.t||0,est:r.est?1:0};return true}return false}
function loadProgress(){
  try{
    var raw=lsGet('lectio-v2');
    if(raw){var o2=JSON.parse(raw);setProgress(o2.p);if(o2.r){rounds=+o2.r.n||0;roundsT=+o2.r.t||0}if(o2.rs)mergeRS(o2.rs);return}
    var old=lsGet('lectio-progress-v1');
    if(old){var o=JSON.parse(old),p={};Object.keys(o).forEach(function(k){p[k]={c:o[k],t:1}});setProgress(p)}
  }catch(e){}
}
function isDone(i){return done[i].size===BOOKS[i].c}
function totals(){var ch=0,bk=0;done.forEach(function(s,i){ch+=s.size;if(isDone(i))bk++});return{ch:ch,bk:bk}}
function mergeProgress(rp){
  var changed=false;
  Object.keys(rp||{}).forEach(function(k){
    var i=+k, r=rp[k];if(!BOOKS[i]||!r)return;
    if((+r.t||0)>(stamp[i]||0)){
      done[i].clear();(r.c||[]).forEach(function(c){if(c>=1&&c<=BOOKS[i].c)done[i].add(c)});
      stamp[i]=+r.t;changed=true;
    }
  });
  return changed;
}

/* ---- reading rounds: start and end times ---- */
/* With auto-tracking ON the start time is set by the app (when a round begins, or at the first chapter marked).
   With it OFF the reader sets the start by hand (Today or History page). The end time is stored when the last chapter is marked. */
function ensureStart(){
  if(settings.autoTrack&&!rs.s&&totals().ch>0){
    var min=0;stamp.forEach(function(t){if(t>1&&(!min||t<min))min=t});
    rs={s:min||Date.now(),t:Date.now(),est:min?1:0};saveProgress();
  }
}
function setStart(ts){rs={s:ts||Date.now(),t:Date.now(),est:0};saveProgress();schedulePush();emit('track');refreshViews()}
function clearStart(){rs={s:0,t:Date.now(),est:0};saveProgress();schedulePush();emit('track');refreshViews()}
function afterMark(){
  ensureStart();
  var id='round-'+(rounds+1),cur=historyC.get(id);
  if(totals().ch===TOTAL_CH){
    if(!cur)historyC.put({id:id,n:rounds+1,s:rs.s||0,e:Date.now(),name:displayName()});
    emit('progress');return true;
  }
  if(cur)historyC.remove(id);      /* a chapter was unmarked, so the round is not finished after all */
  emit('progress');return false;
}
function displayName(){
  if(user&&!user.isAnonymous)return user.displayName||(user.email||'').split('@')[0]||'';
  return(lsGet('lectio-guest-name')||'').trim();
}
function readerName(){return displayName()||'Reader'}

/* ================= Firebase: account + sync ================= */
var CFG=window.LECTIO_FIREBASE||(typeof firebaseConfig!=='undefined'?firebaseConfig:{});
var fb={on:false,err:'',reason:'',auth:null,db:null}, user=null, sync={state:'idle',at:null}, pushT=null, lastResume=0;
(function initFirebase(){
  if(!window.firebase){fb.reason='sdk';return}
  if(!CFG.apiKey){fb.reason='nocfg';return}
  if(/PASTE/.test(CFG.apiKey+(CFG.projectId||'')+(CFG.appId||''))){fb.reason='placeholder';return}
  try{
    firebase.initializeApp(CFG);
    fb.auth=firebase.auth();fb.db=firebase.firestore();
    try{fb.db.settings({experimentalAutoDetectLongPolling:true,merge:true})}catch(e){}
    fb.on=true;
  }catch(e){fb.err='Firebase setup problem: '+(e&&e.message||e)}
})();
function userName(){return displayName()}
function firstName(){return userName().trim().split(/\s+/)[0]||''}
function canSync(){return fb.on&&user&&!user.isAnonymous}

async function syncNow(manual){
  if(!canSync())return;
  sync.state='syncing';renderAccount();
  try{
    var ref=fb.db.collection('users').doc(user.uid);
    var snap=await ref.get();
    var rd=snap.exists?snap.data():{};
    var chP=mergeProgress(rd.p||{});
    if(mergeRounds(rd.rounds))chP=true;
    if(mergeRS(rd.rs))chP=true;
    var chS=false;
    if(rd.settings&&(+rd.settings.t||0)>settingsT){setSettings(rd.settings.d);settingsT=+rd.settings.t;lsSet('lectio-settings-v1',JSON.stringify({d:settings,t:settingsT}));chS=true}
    ensureStart();
    if(chP){saveProgress()}
    await ref.set({name:userName(),email:user.email||'',p:progressObj(),rounds:{n:rounds,t:roundsT},rs:rs,settings:JSON.parse(JSON.stringify({d:settings,t:settingsT})),updated:firebase.firestore.FieldValue.serverTimestamp()});
    /* notes, prayer points, saved verses, highlights, history ... */
    var colls=LColl.all(),chC=false;
    for(var i=0;i<colls.length;i++){
      var c=colls[i],cref=ref.collection('stores').doc(c.name),cs=await cref.get();
      var remote=cs.exists?(cs.data().items||{}):{};
      if(c.merge(remote))chC=true;
      var mine=c.raw(),need=Object.keys(mine).some(function(k){return!remote[k]||(+remote[k].u||0)<(+mine[k].u||0)});
      if(need)await cref.set({items:JSON.parse(JSON.stringify(mine)),u:Date.now()});
    }
    sync.state='ok';sync.at=new Date();sync.msg='';
    if(chS)applyTheme(settings);
    if(chP||chS||chC){refreshViews();emit('progress');if(chS)emit('settings',settings)}
    if(manual)toast('Synced');
  }catch(e){
    sync.state=(e&&(e.code==='unavailable'||/network|offline/i.test(e.message||'')))?'offline':'error';
    sync.msg=e&&e.code==='permission-denied'?'Cloud rules block this account. Check firestore.rules.':(e&&/too large|exceeds/i.test(e.message||'')?'Some data is too large to sync.':'');
    if(manual)toast(sync.state==='offline'?'You are offline. Will sync later.':'Sync failed');
  }
  renderAccount();
}
function schedulePush(){
  if(!canSync())return;
  clearTimeout(pushT);pushT=setTimeout(function(){syncNow(false)},1500);
}
if(fb.on){
  fb.auth.onAuthStateChanged(function(u){
    user=u;
    if(u&&!u.isAnonymous){
      var owner=lsGet('lectio-owner');
      if(owner&&owner!==u.uid){setProgress({});rounds=0;roundsT=0;rs={s:0,t:0,est:0};saveProgress();LColl.clearAll()}
      lsSet('lectio-owner',u.uid);
      refreshViews();
      syncNow(false);
    }else{sync.state='idle'}
    renderAccount();renderHome();renderMenuHead();emit('identity');
  });
  window.addEventListener('online',function(){syncNow(false)});
  document.addEventListener('visibilitychange',function(){
    if(document.visibilityState==='visible'&&canSync()&&Date.now()-lastResume>30000){lastResume=Date.now();syncNow(false)}
  });
}
/* Community, prayer wall and quiz need an identity: a real account, or a guest with a name. Resolves {uid,name,guest} or null. */
async function ensureIdentity(o){
  o=o||{};
  if(!fb.on){toast('Online features need the cloud setup. See FIREBASE_SETUP.md.');return null}
  try{
    if(!user)await fb.auth.signInAnonymously();
  }catch(e){
    toast(e&&e.code==='auth/operation-not-allowed'?'Guest access is not switched on in Firebase yet (Authentication > Sign-in method > Anonymous).':'Could not connect. Check your internet.');
    return null;
  }
  user=fb.auth.currentUser;
  var guest=!!user.isAnonymous,name=displayName();
  if(!name&&o.needName!==false){
    var n=await UI.prompt({title:'Your name',label:'This name is shown next to what you post.',placeholder:'Your name',ok:'Continue',max:40});
    if(!n)return null;
    lsSet('lectio-guest-name',n);name=n;emit('identity');renderAccount();renderMenuHead();
  }
  return{uid:user.uid,name:name||'Guest',guest:guest};
}

/* ---- account card ---- */
function syncLine(){
  if(sync.state==='syncing')return'<p class="sync">Syncing…</p>';
  if(sync.state==='ok')return'<p class="sync ok">Synced '+sync.at.toLocaleTimeString([], {hour:'numeric',minute:'2-digit'})+'</p>';
  if(sync.state==='offline')return'<p class="sync bad">Offline. Changes sync when you are back online.</p>';
  if(sync.state==='error')return'<p class="sync bad">Could not sync. '+esc(sync.msg||'Tap Sync now to retry.')+'</p>';
  return'';
}
function renderAccount(){
  var el=$('acct'),h;
  if(!fb.on){
    var why={
      sdk:'The Firebase files did not load. Run <code>npx cap sync android</code>, then rebuild and reinstall.',
      nocfg:'The app cannot read <code>www/firebase-config.js</code>. It must contain only the <code>window.LECTIO_FIREBASE = {...}</code> block, with no import lines. If the file is missing, copy <code>firebase-config.example.js</code> to that name. Then sync and rebuild.',
      placeholder:'<code>www/firebase-config.js</code> still has the PASTE placeholders. Replace them with the keys from your Firebase <b>Web</b> app, then run <code>npx cap sync android</code> and rebuild.'
    }[fb.reason]||'Add your Firebase keys to <code>www/firebase-config.js</code>.';
    h='<h3>Account</h3><p class="muted">Cloud sign-in is off. '+why+' Until then your progress, notes and prayers are saved on this phone.</p>'+(fb.err?'<p class="err">'+esc(fb.err)+'</p>':'');
  }else if(!user||user.isAnonymous){
    var g=displayName();
    h='<h3>Account</h3>'+(g?'<p class="muted">Posting as guest <b>'+esc(g)+'</b>.</p>':'')+'<p class="muted">Sign in to back up your progress, notes and prayers and read on any device. What is on this phone is kept and merged into your account.</p><div class="row"><button class="btn main" data-act="signin" type="button">Sign in</button><button class="btn" data-act="signup" type="button">Create account</button></div>';
  }else{
    h='<h3>'+esc(userName())+'</h3><p class="muted">'+esc(user.email||'')+'</p>'+syncLine()+'<div class="row"><button class="btn" data-act="sync" type="button">Sync now</button><button class="btn" data-act="signout" type="button">Sign out</button></div>';
  }
  el.innerHTML=h;
}
$('acct').addEventListener('click',function(e){
  var a=e.target.closest('[data-act]');if(!a)return;
  var act=a.dataset.act;
  if(act==='signin')openAuth('signin');
  else if(act==='signup')openAuth('signup');
  else if(act==='sync')syncNow(true);
  else if(act==='signout'){fb.auth.signOut().then(function(){toast('Signed out. Progress stays on this phone.')})}
});

/* ---- sign-in screen ---- */
var authMode='signin';
function setAuthMode(m){
  authMode=m;
  $('authTitle').textContent=m==='signin'?'Sign in':'Create account';
  $('authGo').textContent=m==='signin'?'Sign in':'Create account';
  $('authSwap').textContent=m==='signin'?'Create an account':'I already have an account';
  $('nameRow').hidden=m==='signin';
  $('authPass').autocomplete=m==='signin'?'current-password':'new-password';
  $('authErr').textContent='';
}
function openAuth(m){go('auth');setAuthMode(m)}
function authMsg(e){
  var c=e&&e.code||'';
  if(c==='auth/invalid-credential'||c==='auth/wrong-password'||c==='auth/user-not-found')return'Email or password is not right.';
  if(c==='auth/email-already-in-use')return'That email already has an account. Try signing in.';
  if(c==='auth/weak-password')return'Choose a password with at least 6 characters.';
  if(c==='auth/invalid-email')return'Enter a valid email address.';
  if(c==='auth/network-request-failed')return'No internet connection.';
  if(c==='auth/too-many-requests')return'Too many tries. Wait a bit and try again.';
  if(c==='auth/operation-not-allowed')return'Email sign-in is not switched on in Firebase yet.';
  return'Something went wrong. Try again.';
}
$('authSwap').onclick=function(){setAuthMode(authMode==='signin'?'signup':'signin')};
$('authForgot').onclick=async function(){
  var em=$('authEmail').value.trim();
  if(!em){$('authErr').textContent='Enter your email first.';return}
  try{await fb.auth.sendPasswordResetEmail(em);$('authErr').textContent='';toast('Password reset email sent')}
  catch(e){$('authErr').textContent=authMsg(e)}
};
$('authForm').addEventListener('submit',async function(e){
  e.preventDefault();
  var err=$('authErr'),btn=$('authGo');err.textContent='';
  if(!fb.on){err.textContent='Cloud sync is not set up yet. See FIREBASE_SETUP.md.';return}
  var em=$('authEmail').value.trim(),pw=$('authPass').value,nm=$('authName').value.trim();
  if(!em||!pw){err.textContent='Enter your email and password.';return}
  if(authMode==='signup'&&!nm){err.textContent='Enter your name.';return}
  btn.disabled=true;
  try{
    if(authMode==='signup'){
      if(user&&user.isAnonymous){
        /* keep the guest's posts: turn the guest into this account */
        var res=await user.linkWithCredential(firebase.auth.EmailAuthProvider.credential(em,pw));
        await res.user.updateProfile({displayName:nm});
      }else{
        var cred=await fb.auth.createUserWithEmailAndPassword(em,pw);
        await cred.user.updateProfile({displayName:nm});
      }
      user=fb.auth.currentUser;
    }else{await fb.auth.signInWithEmailAndPassword(em,pw)}
    $('authPass').value='';
    toast(authMode==='signup'?'Welcome, '+(nm||'friend'):'Signed in');
    stack.length=0;show('home');
    syncNow(false);
  }catch(ex){err.textContent=authMsg(ex)}
  btn.disabled=false;
});

/* ================= verse of the moment ================= */
var SLOT_MS=15*60*1000, shownSlot=-1, curVerse=null;
function rnd(seed){var t=(seed+0x6D2B79F5)|0;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296}
function idxFor(slot){return Math.floor(rnd(slot*7919+13)*VERSES.length)}
function verseIdx(slot){var i=idxFor(slot);if(i===idxFor(slot-1))i=(i+1)%VERSES.length;return i}
var savedC=LColl.make('saved');   /* saved verses: {id, src:'today'|'bible', ref, tx:[{s,t}], ts, b,c,v1,v2} */
function todayId(ref){return'sv-today-'+ref.replace(/[^A-Za-z0-9]+/g,'-')}
function renderVerse(slot){
  var v=VERSES[verseIdx(slot)];curVerse=v;
  $('vtext').innerHTML=v[0].split(' ').map(function(w,i){return'<span style="--i:'+i+'">'+esc(w)+'</span>'}).join(' ');
  $('vref').textContent=v[1];shownSlot=slot;paintSaveBtn();fitVerse();
}
/* the verse box is a fixed size: shrink the text until the whole verse fits */
function fitVerse(){
  var t=$('vtext'),w=t&&t.parentNode;if(!w||!w.clientHeight)return;
  var s=Math.min(36,Math.round(window.innerWidth*.095)),min=15;t.style.fontSize=s+'px';
  while(s>min&&t.scrollHeight>w.clientHeight+1){s--;t.style.fontSize=s+'px'}
}
window.addEventListener('resize',fitVerse);
if(document.fonts&&document.fonts.ready)document.fonts.ready.then(function(){fitVerse()});
var PRAYERS=['Lord, help me to start this day with You.','Father, give me peace for what is ahead today.','God is closer than you may think. Talk to Him now.','Thank You, Lord, for every good gift this week.','Jesus, teach me to trust You with what I cannot control.','Holy Spirit, guide my words and my steps today.','Lord, bless my family and keep them in Your care.','Father, show me who needs my prayer today.','Give me a thankful heart, Lord, whatever the day brings.','Lord, forgive me and help me forgive others.','God, strengthen those who are tired and afraid.','Thank You, Father, that Your mercies are new every morning.'];
function paintPray(){var d=Math.floor(Date.now()/864e5),el=$('prayLine');if(el)el.textContent=PRAYERS[d%PRAYERS.length]}
function paintSaveBtn(){
  if(!curVerse)return;
  var on=!!savedC.get(todayId(curVerse[1])),b=$('vSave');
  b.setAttribute('aria-pressed',String(on));
}
function toggleSaveToday(){
  if(!curVerse)return;
  var id=todayId(curVerse[1]);
  if(savedC.get(id)){savedC.remove(id);toast('Removed from saved verses')}
  else{savedC.put({id:id,src:'today',ref:curVerse[1],tx:[{s:'KJV',t:curVerse[0]}],ts:Date.now()});toast('Saved. See Saved verses in the menu.')}
  paintSaveBtn();
}
function tick(){
  var now=Date.now(),slot=Math.floor(now/SLOT_MS);
  if(slot!==shownSlot)renderVerse(slot);
  var into=now-slot*SLOT_MS,left=Math.ceil((SLOT_MS-into)/1000);
  $('tleft').textContent=String(Math.floor(left/60)).padStart(2,'0')+':'+String(left%60).padStart(2,'0');
  $('tbar').style.width=(into/SLOT_MS*100)+'%';
}
$('vSave').onclick=toggleSaveToday;
savedC.on(paintSaveBtn);

/* ================= navigation: views, menu, back button ================= */
var view='home',curBook=0,stack=[],exitArmed=false;
var V={home:$('vHome'),lib:$('vLib'),book:$('vBook'),read:$('vRead'),settings:$('vSettings'),auth:$('vAuth')};
var MENU=[];   /* {id,label,icon,group,order} */
var GROUPS=[['read','Read'],['study','Study'],['pray','Pray'],['together','Together'],['app','App']];
/* Add a page. def = {id, title, menu:{label,icon,group,order}|null, show(el), leave(el)}. Returns the page's <section> element. */
function registerView(def){
  var el=document.createElement('section');
  el.id='v-'+def.id;el.className='view';el.hidden=true;
  $('pages').appendChild(el);
  V[def.id]=el;
  if(def.menu)MENU.push({id:def.id,label:def.menu.label||def.title,icon:def.menu.icon||'star',group:def.menu.group||'study',order:def.menu.order||50});
  extra[def.id]=def;
  return el;
}
var extra={};
function show(name){
  clearSel();
  if(extra[view]&&extra[view].leave&&view!==name){try{extra[view].leave(V[view])}catch(e){}}
  view=name;
  Object.keys(V).forEach(function(k){
    var el=V[k];el.hidden=k!==name;
    if(k===name){el.style.animation='none';void el.offsetWidth;el.style.animation=''}
  });
  closeMenu();
  document.body.classList.toggle('reading',name==='read');
  document.body.setAttribute('data-view',name);
  window.scrollTo(0,0);
  if(name==='home')renderHome();
  else if(name==='lib')renderLib();
  else if(name==='book')renderBook();
  else if(name==='settings')openSettings();
  if(name!=='auth')lsSet('lectio-lastview',JSON.stringify({view:name,book:curBook}));
  if(extra[name]&&extra[name].show){try{extra[name].show(V[name])}catch(e){if(window.console)console.error(name,e)}}
  L.onShow.forEach(function(fn){try{fn(name)}catch(e){}});
}
var fwd=[];
var TOPV={read:1,book:1,auth:1};
function snap(){return{view:view,book:curBook,y:window.scrollY}}
function restoreY(y){
  if(!y)return;
  [0,80,250,600].forEach(function(t){setTimeout(function(){if(Math.abs(window.scrollY-y)>2)window.scrollTo(0,y)},t)});
}
function go(name,bookIdx){
  if(name==='book')bookIdx=bookIndex_(bookIdx);
  if(name===view&&(name!=='book'||bookIdx===curBook)){show(name);return}
  var e=snap();
  fwd=[];
  if(!TOPV[name]){
    /* a page opened from the reader / split view (or from a page that was): Back returns there, step by step.
       Otherwise a main page (menu, dock, button): Back returns to Today. Going to Today itself clears the trail. */
    if(name!=='home'&&(view==='read'||view==='split'||stack.length))stack.push(e);
    else stack=[];
  }else if(view==='home'||view==='lib'||view==='book'||view==='read'){
    /* Today > Bible > chapters > reader: Back goes straight to Today */
    stack=[];
  }else{
    /* reader opened from Journal / saved verses / search...: Back returns there, at the same spot */
    stack.push(e);
  }
  if(stack.length>60)stack.shift();
  if(name==='book')curBook=bookIdx;
  show(name);
}
function goForward(){
  var n=fwd.pop();if(!n)return false;
  var e=snap();if(view!=='home'||stack.length)stack.push(e);
  if(n.view==='book')curBook=n.book;
  show(n.view);restoreY(n.y);return true;
}
function bookIndex_(i){return i==null?curBook:i}
function onBack(){
  if(UI.handleBack())return;
  if(!$('drawer').hidden){closeMenu();return}
  for(var i=0;i<L.back.length;i++){try{if(L.back[i]())return}catch(e){}}
  if(!$('doneModal').hidden){closeFinish();return}
  if(sel.size){clearSel();return}
  if(stack.length){fwd.push(snap());var p=stack.pop();if(p.view==='book')curBook=p.book;show(p.view);restoreY(p.y);return}
  if(view!=='home'){fwd.push(snap());show('home');return}
  if(exitArmed){var A=capApp();if(A&&A.exitApp)A.exitApp();return}
  exitArmed=true;toast('Press back again to exit');setTimeout(function(){exitArmed=false},2000);
}
function capApp(){return window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.App}
(function(){var A=capApp();if(A&&A.addListener)A.addListener('backButton',onBack)})();
function refreshViews(){
  if(view==='home')renderHome();else if(view==='lib')renderLib();else if(view==='book')renderBook();
}

/* ---- side menu ---- */
function renderMenuHead(){
  var n=displayName(),el=$('drawHead');if(!el)return;
  var guest=user&&user.isAnonymous;
  el.innerHTML='<div class="dn">'+esc(n||'Welcome')+'</div><div class="ds">'+(canSync()?esc(user.email||'Signed in'):(guest?'Guest':'Not signed in'))+'</div>';
}
function renderMenu(){
  var all=MENU.slice().sort(function(a,b){return a.order-b.order});
  var h='';
  GROUPS.forEach(function(g){
    var items=all.filter(function(m){return m.group===g[0]});if(!items.length)return;
    h+='<div class="dgroup">'+g[1]+'</div>'+items.map(function(m){
      return'<button type="button" class="ditem" data-view="'+m.id+'"'+(view===m.id?' aria-current="page"':'')+'>'+UI.icon(m.icon,20)+'<span>'+esc(m.label)+'</span></button>';
    }).join('');
  });
  $('drawList').innerHTML=h;
}
var dEl=$('drawer'),dPanel=dEl.querySelector('.dpanel'),dMain=document.querySelector('main'),dTop=document.querySelector('header.top'),dOpen=false,dT=0;
function dW(){return dPanel.offsetWidth||Math.min(320,window.innerWidth*0.86)}
/* p = 0 (closed) .. 1 (open): panel slides in, the page is pushed to the right and dims */
function dSet(p){
  var w=dW();
  dPanel.style.transform='translateX('+((p-1)*100)+'%)';
  dEl.style.background='rgba(5,8,18,'+(0.5*p).toFixed(3)+')';
  var push='translateX('+(p*w*0.42).toFixed(1)+'px) scale('+(1-0.04*p).toFixed(3)+')';
  [dMain,dTop].forEach(function(e){if(e){e.style.transform=p?push:'';e.style.transformOrigin='left center'}});
}
function openMenu(){
  clearTimeout(dT);renderMenuHead();renderMenu();dEl.hidden=false;dOpen=true;
  document.body.classList.add('menuopen');
  void dEl.offsetWidth;dEl.classList.add('anim');dSet(1);
}
function closeMenu(){
  if(dEl.hidden&&!dOpen)return;
  dOpen=false;dEl.classList.add('anim');dSet(0);document.body.classList.remove('menuopen');
  clearTimeout(dT);dT=setTimeout(function(){if(!dOpen){dEl.hidden=true;dEl.classList.remove('anim')}},280);
}
/* swipe: from the left edge to open, anywhere on the menu to close, and the menu follows the finger */
(function(){
  var st=null;
  document.addEventListener('touchstart',function(e){
    if(e.touches.length!==1||document.querySelector('.umodal'))return;
    var t=e.touches[0];
    if(false&&!dOpen&&t.clientX<=18&&view!=='auth'){st={x:t.clientX,y:t.clientY,mode:'open',lock:0}}
    else if(dOpen){st={x:t.clientX,y:t.clientY,mode:'close',lock:0}}
  },{passive:true});
  document.addEventListener('touchmove',function(e){
    if(!st)return;var t=e.touches[0],dx=t.clientX-st.x,dy=t.clientY-st.y;
    if(!st.lock){
      if(Math.abs(dx)<8&&Math.abs(dy)<8)return;
      if(Math.abs(dy)>Math.abs(dx)){st=null;return}
      st.lock=1;
      if(st.mode==='open'){clearTimeout(dT);renderMenuHead();renderMenu();dEl.hidden=false;dEl.classList.remove('anim')}
      else{dEl.classList.remove('anim');document.body.classList.remove('menuopen')}
    }
    var w=dW(),p=st.mode==='open'?dx/w:1+dx/w;
    st.p=Math.max(0,Math.min(1,p));dSet(st.p);
  },{passive:true});
  document.addEventListener('touchend',function(){
    if(!st||!st.lock){st=null;return}
    var p=st.p==null?(st.mode==='open'?0:1):st.p;st=null;
    dEl.classList.add('anim');
    if(p>0.4){dOpen=true;document.body.classList.add('menuopen');dSet(1)}
    else{dOpen=true;closeMenu()}
  });
})();
$('drawer').addEventListener('click',function(e){
  if(e.target.id==='drawer'||e.target.closest('[data-closemenu]')){closeMenu();return}
  var b=e.target.closest('[data-view]');if(!b)return;
  var id=b.dataset.view;closeMenu();
  if(view!==id)go(id);
});
MENU.push({id:'home',label:'Today',icon:'home',group:'read',order:1},{id:'lib',label:'Bible',icon:'book',group:'read',order:2},{id:'settings',label:'Settings',icon:'gear',group:'app',order:99});

/* ================= shared API for the other scripts ================= */
function logActivity(){
  try{
    var a=JSON.parse(lsGet('lectio-activity')||'{}'),d=new Date(),k=d.getFullYear()+'-'+('0'+(d.getMonth()+1)).slice(-2)+'-'+('0'+d.getDate()).slice(-2);
    a[k]=(a[k]||0)+1;lsSet('lectio-activity',JSON.stringify(a));
  }catch(e){}
}
var L=window.Lectio={openAuth:function(m){openAuth(m||'signin')},setName:function(n){lsSet('lectio-guest-name',n);emit('identity');renderAccount();renderMenuHead();renderHome()},signOut:function(){if(fb.on)return fb.auth.signOut()},$:$,esc:esc,toast:toast,lsGet:lsGet,lsSet:lsSet,onShow:[],back:[],ui:UI,on:on,emit:emit,
  openReader:function(){},
  chapterRead:function(b,c){return done[b].has(c)},
  setChapterRead:function(b,c,on){
    if(on)done[b].add(c);else done[b].delete(c);
    if(on)logActivity();
    stamp[b]=Date.now();saveProgress();schedulePush();
    if(afterMark()&&on)openFinish();
  },
  go:function(n,b){go(n,b)},show:function(n){show(n)},
  registerView:registerView,
  get curBook(){return curBook},set curBook(v){curBook=v},
  get view(){return view},
  goBack:function(){onBack()},goForward:goForward,canForward:function(){return fwd.length>0},
  /* settings */
  get settings(){return settings},commitSettings:commitSettings,defaultSettings:defaultSettings,
  theme:{applyVars:applyVars,applyReaderLayout:applyReaderLayout,applyTheme:applyTheme,clone:clone,mix:mix,hexA:hexA,lum:lum,readable:readable,fontById:fontById,
    DEF_FONTS:DEF_FONTS,DEF_COLORS:DEF_COLORS,DEF_READER:DEF_READER,DEF_VBG:DEF_VBG,SWATCHES:SWATCHES,tstyle:tstyle},
  /* identity + cloud */
  fb:fb,get user(){return user},canSync:canSync,displayName:displayName,readerName:readerName,ensureIdentity:ensureIdentity,pushSoon:schedulePush,syncNow:syncNow,
  coll:LColl.make,hasView:function(id){return!!V[id]},
  /* progress + reading rounds */
  get rounds(){return rounds},get roundStart(){return rs},history:historyC,
  startReading:setStart,clearStart:clearStart,
  progress:{totals:totals,chaptersDone:function(){return totals().ch},isDone:isDone},
  refresh:refreshViews
};

/* ================= home ================= */
function trackHtml(){
  if(settings.autoTrack)return'';
  var t=totals();
  if(t.ch===TOTAL_CH)return'';
  if(rs.s)return'';
  if(0)return'<div class="track"><div><b>Reading started</b><span>'+esc(UI.fmt.dt(rs.s))+'</span></div><button type="button" class="linkbtn" data-track="change">Change</button></div>';
  return'<div class="track"><div><b>Auto-tracking is off</b><span>Tell the app when you begin reading the Bible. The finish time is saved when you mark the last chapter.</span></div><div class="row"><button type="button" class="btn main" data-track="now">Start now</button><button type="button" class="btn" data-track="pick">Pick a date</button></div></div>';
}
function pickStart(){
  var m=UI.modal({title:'When did you start?',body:'<label class="field">Start date and time<input type="datetime-local" id="startDt" value="'+UI.fmt.dtLocal(rs.s||Date.now())+'" max="'+UI.fmt.dtLocal(Date.now())+'"></label>',actions:[
    {label:'Cancel'},
    rs.s?{label:'Clear',kind:'danger',on:function(){clearStart()}}:null,
    {label:'Save',kind:'main',on:function(){
      var v=m.body.querySelector('#startDt').value,ts=v?new Date(v).getTime():NaN;
      if(!ts||ts>Date.now()+60000){toast('Pick a date and time that has passed');return false}
      setStart(ts);toast('Start date saved');
    }}
  ].filter(Boolean)});
}
document.addEventListener('click',function(e){
  var a=e.target.closest&&e.target.closest('[data-track]');if(!a)return;
  var k=a.dataset.track;
  if(k==='now'){setStart(Date.now());toast('Started. Good reading!')}
  else pickStart();
});
function renderHome(){
  var t=totals(),pct=t.ch/TOTAL_CH,C=263.9,n=firstName();
  $('ringfg').style.strokeDashoffset=C;
  requestAnimationFrame(function(){requestAnimationFrame(function(){$('ringfg').style.strokeDashoffset=C*(1-pct)})});
  $('ringpct').textContent=Math.round(pct*100)+'%';
  $('pname').textContent=n?(n+(/s$/i.test(n)?'’':'’s')+' progress'):'Your progress';
  $('pline1').textContent=t.ch+' of '+TOTAL_CH+' chapters read';
  $('pline2').textContent=t.bk+' of '+BOOKS.length+' books complete';
  $('pline3').textContent='Bible completed '+rounds+(rounds===1?' time':' times')+(rounds>0?' · now on round '+(rounds+1):'');
  $('finishBtn').hidden=t.ch!==TOTAL_CH;
  $('signinHome').hidden=true;
  $('trackBox').innerHTML=trackHtml();
  paintPray();fitVerse();
}

/* ================= library + chapters ================= */
function libLayout(){return L.bookLayout?L.bookLayout.get('lib'):'tiles'}
function bookTile(i,delay){
  var b=BOOKS[i],n=done[i].size,full=n===b.c,lay=libLayout();
  var cls='book'+(lay!=='tiles'?' blpill':'')+(full?' done':'')+(sel.has(i)&&selMode==='lib'?' sel':'')+(popSet.has(i)?' pop':'');
  if(lay!=='tiles')return'<button type="button" class="'+cls+'" data-id="'+i+'" aria-label="'+b.n+', '+n+' of '+b.c+' chapters read"><span class="nm">'+(lay==='pills'?L.bookLayout.AB[i]:b.n)+'</span><span class="bar"><i style="width:'+(n/b.c*100)+'%"></i></span></button>';
  return'<button type="button" class="'+cls+'" data-id="'+i+'" style="--d:'+delay+'" aria-label="'+b.n+', '+n+' of '+b.c+' chapters read">'
    +'<span class="nm">'+b.n+'</span><span class="ct">'+n+'/'+b.c+'</span>'
    +'<span class="bar"><i style="width:'+(n/b.c*100)+'%"></i></span>'
    +'<span class="tick">'+CHECK+'</span><span class="pick">'+CHECK+'</span></button>';
}
function renderLib(){
  var ot='',nt='',otCh=0,ntCh=0,otB=0,ntB=0,otTot=0,ntTot=0;
  BOOKS.forEach(function(b,i){
    if(i<OT_N){ot+=bookTile(i,i);otCh+=done[i].size;otTot+=b.c;if(isDone(i))otB++}
    else{nt+=bookTile(i,i-OT_N);ntCh+=done[i].size;ntTot+=b.c;if(isDone(i))ntB++}
  });
  var gl=libLayout(),gc='tgrid'+(gl==='pills'?' blpills':gl==='names'?' blnames':'');$('otGrid').className=gc;$('ntGrid').className=gc;
  $('otGrid').innerHTML=ot;$('ntGrid').innerHTML=nt;
  $('otSub').textContent=otB+'/'+OT_N+' books · '+otCh+'/'+otTot+' ch.';
  $('ntSub').textContent=ntB+'/'+(BOOKS.length-OT_N)+' books · '+ntCh+'/'+ntTot+' ch.';
  var t=totals();
  $('libStats').textContent=t.bk+' of '+BOOKS.length+' books · '+t.ch+' of '+TOTAL_CH+' chapters read';
  popSet.clear();
}
on('settings',function(){if(typeof renderLib==='function')renderLib()});
function renderBook(){
  var b=BOOKS[curBook],n=done[curBook].size,h='';
  $('bkTest').textContent=b.t;$('bkName').textContent=b.n;
  $('bkStats').textContent=n+' of '+b.c+' chapters read';
  $('bkMeter').style.width=(n/b.c*100)+'%';
  for(var c=1;c<=b.c;c++){
    var cls='chap'+(done[curBook].has(c)?' done':'')+(sel.has(c)&&selMode==='book'?' sel':'')+(popSet.has(c)?' pop':'');
    h+='<button type="button" class="'+cls+'" data-id="'+c+'" style="--d:'+Math.min(c,40)+'" aria-label="Chapter '+c+(done[curBook].has(c)?', read':'')+'">'+c+'<span class="pick">'+CHECK+'</span></button>';
  }
  $('cGrid').innerHTML=h;popSet.clear();
}

/* ================= selection ================= */
var selMode=null,sel=new Set(),popSet=new Set();
function clearSel(){sel.clear();selMode=null;updateBar()}
function updateBar(){
  var bar=$('bar');
  if(!sel.size){bar.hidden=true;document.querySelectorAll('.sel').forEach(function(e){e.classList.remove('sel')});return}
  bar.hidden=false;$('cnt').textContent=sel.size;
  $('cntLbl').textContent=selMode==='lib'?(sel.size===1?'book':'books'):(sel.size===1?'chapter':'chapters');
  var all=Array.from(sel).every(function(id){return selMode==='lib'?isDone(id):done[curBook].has(id)});
  var btn=$('doneBtn');btn.textContent=all?'Mark unread':'Done';
  btn.classList.toggle('undo',all);btn.dataset.undo=all?'1':'';
}
function paintSel(){
  document.querySelectorAll('#vLib [data-id], #vBook [data-id]').forEach(function(e){
    e.classList.toggle('sel',sel.has(+e.dataset.id)&&(e.classList.contains('book')?selMode==='lib':selMode==='book'));
  });
  updateBar();
}
function startSel(mode,id){selMode=mode;sel.clear();sel.add(id);paintSel()}
function toggle(id){if(sel.has(id))sel.delete(id);else sel.add(id);if(!sel.size)selMode=null;paintSel()}
$('cancelBtn').onclick=clearSel;
$('allBtn').onclick=function(){
  if(selMode==='lib')BOOKS.forEach(function(b,i){sel.add(i)});
  else for(var c=1;c<=BOOKS[curBook].c;c++)sel.add(c);
  paintSel();
};
$('doneBtn').onclick=function(){
  var undo=!!$('doneBtn').dataset.undo,n=sel.size,mode=selMode;
  if(mode==='lib'){
    sel.forEach(function(i){
      if(undo)done[i].clear();else{for(var c=1;c<=BOOKS[i].c;c++)done[i].add(c);popSet.add(i)}
      stamp[i]=Date.now();
    });
  }else{
    sel.forEach(function(c){if(undo)done[curBook].delete(c);else{done[curBook].add(c);popSet.add(c)}});
    stamp[curBook]=Date.now();
  }
  saveProgress();schedulePush();
  sel.clear();selMode=null;updateBar();
  var finished=afterMark();
  if(mode==='lib')renderLib();else renderBook();
  toast(undo?'Marked unread':(n+(mode==='lib'?(n===1?' book':' books'):(n===1?' chapter':' chapters'))+' marked as read'));
  if(!undo&&finished)openFinish();
};
/* ---- whole Bible completed ---- */
function openFinish(){
  $('finNum').textContent=rounds+1;$('finNum2').textContent=rounds+1;
  $('finTimes').textContent=(rounds+1===1?'time':'times');
  var h=historyC.get('round-'+(rounds+1));
  $('finWhen').textContent=h&&h.e?('Finished '+UI.fmt.dt(h.e)+(h.s?' · started '+UI.fmt.dt(h.s):'')):'';
  $('doneModal').hidden=false;
}
function closeFinish(){$('doneModal').hidden=true}
function startNewRound(){
  var now=Date.now();
  afterMark();                                   /* makes sure the finished round is in History */
  rounds++;roundsT=now;
  done.forEach(function(s,i){s.clear();stamp[i]=now});
  rs={s:settings.autoTrack?now:0,t:now,est:0};
  saveProgress();schedulePush();closeFinish();clearSel();
  refreshViews();emit('progress');toast('Round '+(rounds+1)+' started');
}
$('newRoundBtn').onclick=startNewRound;
$('finLater').onclick=closeFinish;
$('finishBtn').onclick=openFinish;
function bindPress(grid,mode,onTap){
  var timer=null,fired=false,sx=0,sy=0,tgt=null;
  function clear(){clearTimeout(timer);timer=null;if(tgt){tgt.classList.remove('pressing');tgt=null}}
  grid.addEventListener('pointerdown',function(e){
    var t=e.target.closest('[data-id]');if(!t||e.button>0)return;
    fired=false;sx=e.clientX;sy=e.clientY;tgt=t;t.classList.add('pressing');
    var id=+t.dataset.id;
    timer=setTimeout(function(){
      fired=true;clear();
      if(navigator.vibrate)try{navigator.vibrate(14)}catch(_){}
      if(selMode===mode)toggle(id);else startSel(mode,id);
    },440);
  });
  grid.addEventListener('pointermove',function(e){if(timer&&(Math.abs(e.clientX-sx)>10||Math.abs(e.clientY-sy)>10))clear()});
  ['pointerup','pointercancel','pointerleave'].forEach(function(ev){grid.addEventListener(ev,clear)});
  grid.addEventListener('contextmenu',function(e){e.preventDefault()});
  grid.addEventListener('click',function(e){
    var t=e.target.closest('[data-id]');if(!t)return;
    if(fired){fired=false;e.preventDefault();return}
    var id=+t.dataset.id;
    if(selMode===mode)toggle(id);else onTap(id);
  });
}
bindPress($('otGrid'),'lib',function(i){go('book',i)});
bindPress($('ntGrid'),'lib',function(i){go('book',i)});
bindPress($('cGrid'),'book',function(c){L.openReader(curBook,c)});

/* ================= settings page: cards ================= */
/* Other scripts add cards with Lectio.addSettingsCard({id, order, title?, render(el)}). render runs each time Settings opens. */
var sCards=[];
function addSettingsCard(def){
  var el=document.createElement('div');el.className='card';el.id='sc-'+def.id;el.dataset.order=def.order||50;
  sCards.push({def:def,el:el});
  return el;
}
function mountSettingsCards(){
  var box=$('scards'),items=[];
  Array.prototype.forEach.call(box.children,function(c){items.push({el:c,order:+c.dataset.order||50})});
  sCards.forEach(function(c){items.push({el:c.el,order:+c.el.dataset.order||50})});
  items.sort(function(a,b){return a.order-b.order});
  items.forEach(function(i){box.appendChild(i.el)});
}
/* hidden from Settings for now (ask to bring back): Book layouts, Reader text options, Verse backgrounds, Layout & buttons */
var SECS=[
  ['acct','Profile','people','Name, picture and sign in'],
  ['sc-tracking','Reading history','clock','Auto-tracking and reading rounds'],
  ['sc-appearance','Appearance','highlight','Theme, fonts and colours'],
  ['bgCard','Page backgrounds','image','A photo for each page'],
  ['sc-reminders','Reminders','bell','Daily reading and prayer reminders'],
  ['verCard','Bible versions','globe','Add, remove and order versions'],
  ['sc-dock','Quick dock','more','The floating shortcut button'],
  ['backupCard','Backup','file','Copy or restore your data']
];
var sOpen=null,sWant=null;
function settingsSection(id){
  sOpen=id;
  var hub=$('sHub'),box=$('scards'),title=$('sTitle'),eb=$('sEyebrow');
  Array.prototype.forEach.call(box.children,function(c){c.hidden=!id||c.id!==id});
  hub.hidden=!!id;
  var sec=SECS.filter(function(x){return x[0]===id})[0];
  eb.hidden=true;
  title.textContent=sec?sec[1]:'Make it yours';
  $('sBack').hidden=!id;
  window.scrollTo(0,0);
}
function renderHub(){
  $('sHub').innerHTML=SECS.filter(function(x){return $(x[0])}).map(function(x){
    return'<button type="button" class="hrow" data-sec="'+x[0]+'"><span class="hic">'+UI.icon(x[2],20)+'</span><span class="htx"><b>'+esc(x[1])+'</b><small>'+esc(x[3])+'</small></span>'+UI.icon('chevron',18)+'</button>';
  }).join('');
}
function openSettings(){
  renderAccount();
  sCards.forEach(function(c){try{c.def.render(c.el)}catch(e){if(window.console)console.error(c.def.id,e)}});
  $('bkText').value='';
  renderHub();
  var w=sWant;sWant=null;
  settingsSection(w);
}
$('sHub').addEventListener('click',function(e){var b=e.target.closest('[data-sec]');if(!b)return;if(b.dataset.sec==='acct'&&L.hasView('profile')){go('profile');return}settingsSection(b.dataset.sec)});
$('sBack').onclick=function(){settingsSection(null)};
L.back.push(function(){if(view==='settings'&&sOpen){settingsSection(null);return true}return false});
L.addSettingsCard=addSettingsCard;
L.openSettings=function(id){sWant=id||null;if(view==='settings')settingsSection(sWant);else go('settings')};

/* ---- appearance mode switch (light/dark/auto) lives with the first card in appearance.js ---- */

/* ---- backup ---- */
function backupText(){
  var c={};LColl.all().forEach(function(k){var items={};var raw=k.raw();Object.keys(raw).forEach(function(i){if(!raw[i].x)items[i]=raw[i]});c[k.name]=items});
  return JSON.stringify({app:'lectio',v:3,p:progressObj(),settings:{d:settings,t:settingsT},r:{n:rounds,t:roundsT},rs:rs,c:c});
}
$('bkCopy').onclick=function(){
  var txt=backupText(),ta=$('bkText');ta.value=txt;ta.focus();ta.select();
  UI.copy(txt).then(function(ok){toast(ok?'Backup copied':'Select the text and copy it')});
};
var restoreArmed=false;
$('bkRestore').onclick=function(){
  var raw=$('bkText').value.trim();
  if(!raw){toast('Paste a backup first');return}
  var o;try{o=JSON.parse(raw)}catch(e){toast('That is not a Lectio backup');return}
  if(!o||o.app!=='lectio'||!o.p){toast('That is not a Lectio backup');return}
  if(!restoreArmed){
    restoreArmed=true;$('bkRestore').textContent='Tap again to replace';
    setTimeout(function(){restoreArmed=false;$('bkRestore').textContent='Restore'},4000);return;
  }
  restoreArmed=false;$('bkRestore').textContent='Restore';
  var now=Date.now(),p={};
  Object.keys(o.p).forEach(function(k){p[k]={c:o.p[k].c,t:now}});
  setProgress(p);if(o.r){rounds=+o.r.n||0;roundsT=now}
  if(o.rs){rs={s:+o.rs.s||0,t:now,est:o.rs.est?1:0}}
  saveProgress();
  if(o.settings&&o.settings.d){setSettings(o.settings.d);saveSettings();applyTheme(settings);emit('settings',settings)}
  if(o.c){LColl.all().forEach(function(k){if(o.c[k.name]){k.clear();var items={};Object.keys(o.c[k.name]).forEach(function(i){var it=o.c[k.name][i];it.u=now;items[i]=it});k.merge(items)}})}
  schedulePush();emit('progress');toast('Backup restored');
};

/* ================= wiring ================= */
$('goLib').onclick=function(){go('lib')};
$('goPray').onclick=function(){if(document.getElementById('v-mypray'))go('mypray');else toast('Prayer points are not available')};
$('goQuiz').onclick=function(){if(document.getElementById('v-quiz'))go('quiz');else toast('Quiz is not available')};
$('readNow').onclick=function(){L.openReader()};
$('backBtn').onclick=onBack;
$('signinHome').onclick=function(){if(fb.on)openAuth('signin');else L.openSettings('acct')};

loadProgress();loadSettings();applyTheme(settings);
L.start=function(){
  mountSettingsCards();renderAccount();renderMenuHead();
  ensureStart();
  show('home');   /* the app always opens on Today */
  tick();setInterval(tick,1000);
  emit('ready');
};
})();
