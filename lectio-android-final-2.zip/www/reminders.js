/* Reminders: daily notifications to read, save progress, pray, take the quiz. Settings card + scheduling.
   Uses the Capacitor Local Notifications plugin (Android app only). In a normal browser the settings are saved but nothing is scheduled. */
(function(){
'use strict';
var L=window.Lectio,$=L.$,esc=L.esc,UI=L.ui;
var Cap=window.Capacitor||{};
var native=!!(Cap.isNativePlatform&&Cap.isNativePlatform());
function plugin(){try{return(Cap.Plugins&&Cap.Plugins.LocalNotifications)||(native&&Cap.registerPlugin?Cap.registerPlugin('LocalNotifications'):null)}catch(e){return null}}

/* ---------- settings ---------- */
var KEY='lectio-reminders-v1';
var R={on:false,mode:'auto',readTime:'07:00',custom:[]};
try{Object.assign(R,JSON.parse(L.lsGet(KEY)||'{}'))}catch(e){}
if(!Array.isArray(R.custom))R.custom=[];
function save(){L.lsSet(KEY,JSON.stringify(R))}

/* ---------- messages (each type rotates through its list) ---------- */
var TYPES={read:'Read Bible',verse:'Verse of the day',quiz:'Bible quiz',save:'Save progress',pray:'Pray',custom:'Custom'};
var MSG={
  read:['Time to read your Bible today.','A few verses a day add up. Open Lectio and keep going.','Your Bible is waiting. Even one chapter counts.','Take a quiet moment with God’s Word.','Continue where you stopped yesterday.','“Thy word is a lamp unto my feet.” Psalm 119:105'],
  verse:['Today’s verse is ready for you in Lectio.','A new verse for this moment is waiting.','Open Lectio for a verse to carry through the day.','Pause and read today’s verse.','A word of encouragement is waiting for you.','Save a verse you love in Lectio today.'],
  quiz:['Today’s Bible quiz is ready. Try the daily challenge!','Test your Bible knowledge with today’s 10 questions.','Ready for the daily challenge?','Build your Bible memory: take today’s quiz.','See how you score on today’s quiz.','A quick quiz, a stronger memory.'],
  save:['Did you read today? Mark your chapters so your progress is saved.','Save your Bible progress before the day ends.','Mark today’s chapters as read in Lectio.','Keep your streak: record what you read today.','Don’t forget to save your reading progress.','Evening check: update your Bible progress.'],
  pray:['Take a moment to pray.','Time to pray. Open your prayer points.','Bring today’s needs to God in prayer.'],
  custom:['Reminder from Lectio.']
};
function pick(type,i){var a=MSG[type]||MSG.custom;return a[i%a.length]}

/* ---------- scheduling ---------- */
var CH='lectio-reminders';
function lastRead(){return L.lsGet('lectio-lastread')||''}
function inRange(id){return(id>=1000&&id<2000)||(id>=5000&&id<6000)}
function parseTime(t){var m=String(t||'07:00').match(/^(\d{1,2}):(\d{2})$/);return m?{h:Math.min(23,+m[1]),m:Math.min(59,+m[2])}:{h:7,m:0}}
async function ensurePermission(ask){
  var P=plugin();if(!P)return false;
  try{
    var s=await P.checkPermissions();
    if(s.display==='granted')return true;
    if(!ask)return false;
    s=await P.requestPermissions();return s.display==='granted';
  }catch(e){return false}
}
async function clearAll(P){
  try{
    var p=await P.getPending();
    var ids=(p.notifications||[]).filter(function(n){return inRange(+n.id)}).map(function(n){return{id:+n.id}});
    if(ids.length)await P.cancel({notifications:ids});
  }catch(e){}
}
function planAuto(){
  var out=[],t=parseTime(R.readTime),now=new Date(),today=UI.fmt.dayKey(now.getTime()),skipToday=lastRead()===today;
  var slots=[['read',t.h,t.m,0],['verse',12,30,1],['quiz',18,30,2],['save',20,30,3]];
  for(var d=0;d<14;d++){
    slots.forEach(function(s){
      var type=s[0];
      if(d===0&&skipToday&&(type==='read'||type==='save'))return;
      var at=new Date(now.getFullYear(),now.getMonth(),now.getDate()+d,s[1],s[2],0);
      if(at.getTime()<=now.getTime()+20000)return;
      out.push({id:1000+d*10+s[3],title:'Lectio',body:pick(type,d+s[3]),schedule:{at:at,allowWhileIdle:true},channelId:CH,smallIcon:'ic_stat_lectio'});
    });
  }
  return out;
}
function planCustom(){
  var out=[];
  R.custom.forEach(function(c,i){
    if(!c.on)return;
    var t=parseTime(c.time),body=c.msg||pick(c.type||'custom',i),days=(c.days||[]);
    if(!days.length)out.push({id:5000+i*10+7,title:c.label||'Lectio',body:body,schedule:{on:{hour:t.h,minute:t.m},allowWhileIdle:true},channelId:CH,smallIcon:'ic_stat_lectio'});
    else days.forEach(function(d){out.push({id:5000+i*10+d,title:c.label||'Lectio',body:body,schedule:{on:{weekday:d+1,hour:t.h,minute:t.m},allowWhileIdle:true},channelId:CH,smallIcon:'ic_stat_lectio'})});
  });
  return out;
}
var planning=Promise.resolve();
function replan(){
  planning=planning.then(async function(){
    var P=plugin();if(!P)return;
    await clearAll(P);
    if(!R.on)return;
    if(!(await ensurePermission(false)))return;
    try{await P.createChannel({id:CH,name:'Reminders',description:'Bible reading reminders',importance:4})}catch(e){}
    var list=R.mode==='auto'?planAuto():planCustom();
    if(list.length)try{await P.schedule({notifications:list})}catch(e){if(window.console)console.error('reminders',e)}
  }).catch(function(){});
  return planning;
}

/* ---------- settings card ---------- */
var DAYS=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
var card;
function summary(c){return(c.time||'')+' · '+((c.days&&c.days.length)?c.days.map(function(d){return DAYS[d]}).join(' '):'every day')}
function render(el){
  card=el;
  var P=plugin(),h='<h3>Reminders</h3>';
  if(!native)h+='<p class="note">Reminders work in the Android app. You can set them up here, and they start once you install the app.</p>';
  h+='<button type="button" class="tgl" data-r="master" aria-pressed="'+R.on+'"><span>Daily reminders</span><i></i></button>';
  if(R.on){
    h+='<div class="seg" role="group"><button type="button" data-r="mode" data-m="auto" aria-pressed="'+(R.mode==='auto')+'">Auto</button><button type="button" data-r="mode" data-m="custom" aria-pressed="'+(R.mode==='custom')+'">Custom</button></div>';
    if(R.mode==='auto'){
      h+='<p class="muted">Lectio reminds you to read, shows you today’s verse, invites you to the daily quiz and asks you to save your progress. If you have already read today, it skips the reading and progress reminders.</p>';
      h+='<label class="field">Preferred reading time<input type="time" id="rTime" value="'+esc(R.readTime)+'"></label>';
      h+='<ul class="vlist"><li><span><b>Read your Bible</b><small>'+esc(R.readTime)+'</small></span></li><li><span><b>Verse of the day</b><small>12:30</small></span></li><li><span><b>Daily quiz</b><small>18:30</small></span></li><li><span><b>Save your progress</b><small>20:30</small></span></li></ul>';
    }else{
      h+='<div class="list">'+(R.custom.length?R.custom.map(function(c,i){
        return'<div class="li"><div class="row2"><div><div class="t">'+esc(c.label||TYPES[c.type]||'Reminder')+'</div><div class="meta">'+esc(summary(c))+'</div></div><button type="button" class="tgl" style="width:auto" data-r="ctoggle" data-i="'+i+'" aria-pressed="'+!!c.on+'" aria-label="On or off"><i></i></button></div><div class="acts"><button class="btn" data-r="cedit" data-i="'+i+'">Edit</button><button class="btn" data-r="cdel" data-i="'+i+'">Delete</button></div></div>';
      }).join(''):'<p class="muted">No reminders yet. Add the times that suit you.</p>')+'</div>';
      h+='<button type="button" class="btn main" data-r="cadd">Add a reminder</button>';
    }
    if(native)h+='<button type="button" class="btn" data-r="test">Send a test notification</button>';
  }
  el.innerHTML=h;
}
function editor(i){
  var c=i==null?{type:'read',label:'',time:'07:00',days:[],msg:'',on:true}:Object.assign({},R.custom[i]);
  var h='<label class="field">Type<select id="cType">'+Object.keys(TYPES).map(function(k){return'<option value="'+k+'"'+(k===c.type?' selected':'')+'>'+TYPES[k]+'</option>'}).join('')+'</select></label>';
  h+='<label class="field">Label (optional)<input id="cLabel" type="text" maxlength="40" value="'+esc(c.label||'')+'"></label>';
  h+='<label class="field">Time<input id="cTime" type="time" value="'+esc(c.time)+'"></label>';
  h+='<div class="sec-t">Days (none selected = every day)</div><div class="chips" id="cDays">'+DAYS.map(function(d,k){return'<button type="button" class="chip" data-d="'+k+'" aria-pressed="'+((c.days||[]).indexOf(k)>-1)+'">'+d+'</button>'}).join('')+'</div>';
  h+='<label class="field">Message (optional)<input id="cMsg" type="text" maxlength="120" value="'+esc(c.msg||'')+'" placeholder="Leave empty for a friendly default"></label>';
  var m=UI.modal({title:i==null?'New reminder':'Edit reminder',body:h,actions:[{label:'Cancel'},{label:'Save',kind:'main',on:function(){
    var days=[];m.body.querySelectorAll('#cDays [aria-pressed="true"]').forEach(function(b){days.push(+b.dataset.d)});
    var item={type:m.body.querySelector('#cType').value,label:m.body.querySelector('#cLabel').value.trim(),time:m.body.querySelector('#cTime').value||'07:00',days:days,msg:m.body.querySelector('#cMsg').value.trim(),on:c.on!==false};
    if(i==null)R.custom.push(item);else R.custom[i]=item;
    save();replan();render(card);
  }}]});
  m.body.querySelector('#cDays').addEventListener('click',function(e){var b=e.target.closest('[data-d]');if(b)b.setAttribute('aria-pressed',String(b.getAttribute('aria-pressed')!=='true'))});
}
L.addSettingsCard({id:'reminders',order:60,render:render});

document.addEventListener('click',async function(e){
  var b=e.target.closest&&e.target.closest('#sc-reminders [data-r]');if(!b)return;
  var k=b.dataset.r,i=+b.dataset.i;
  if(k==='master'){
    if(!R.on){
      R.on=true;
      if(native&&!(await ensurePermission(true))){R.on=false;save();render(card);UI.modal({title:'Notifications are off',body:'<p class="mtext">Allow notifications for Lectio in Android Settings > Apps > Lectio > Notifications, then turn reminders on again.</p>',actions:[{label:'OK',kind:'main'}]});return}
    }else R.on=false;
    save();replan();render(card);
  }else if(k==='mode'){R.mode=b.dataset.m;save();replan();render(card)}
  else if(k==='cadd')editor(null);
  else if(k==='cedit')editor(i);
  else if(k==='cdel'){if(await UI.confirm('Delete this reminder?',{ok:'Delete',danger:true})){R.custom.splice(i,1);save();replan();render(card)}}
  else if(k==='ctoggle'){R.custom[i].on=!R.custom[i].on;save();replan();render(card)}
  else if(k==='test'){
    var P=plugin();if(!P)return;
    try{await P.schedule({notifications:[{id:1999,title:'Lectio',body:'This is how your reminders will look.',schedule:{at:new Date(Date.now()+5000)},channelId:CH,smallIcon:'ic_stat_lectio'}]});L.toast('Test notification in 5 seconds')}catch(er){L.toast('Could not send a test')}
  }
});
document.addEventListener('change',function(e){
  if(e.target.id==='rTime'){R.readTime=e.target.value||'07:00';save();replan();render(card)}
});

/* a chapter was marked read today: skip today's remaining read / progress reminders */
L.on('progress',function(){
  var t=UI.fmt.dayKey(Date.now()),prev=L.lsGet('lectio-lastchap');
  var n=L.progress.chaptersDone();
  if(prev!==null&&+prev!==n&&n>+prev){L.lsSet('lectio-lastread',t);replan()}
  L.lsSet('lectio-lastchap',String(n));
});
L.on('ready',function(){replan()});
})();
