import sys; sys.path.insert(0,'test')
from harness import app
with app(width=360,height=740) as (page,base):
    page.goto(base); page.wait_for_timeout(700)
    page.evaluate("Lectio.openReader(5,3,1)"); page.wait_for_timeout(800)
    page.evaluate("window.scrollTo(0,900)"); page.wait_for_timeout(700)
    v=page.evaluate("JSON.parse(localStorage.getItem('lectio-reader-v1')).last"); print('saved',v)
    page.reload(); page.wait_for_timeout(2500)
    print('restored view',page.evaluate("Lectio.view"), 'scrollY',page.evaluate("window.scrollY"))
    page.evaluate("Lectio.go('home')"); page.evaluate("Lectio.go('lib')"); page.evaluate("Lectio.go('notes')"); page.evaluate("Lectio.go('prayerwall')")
    seq=[]
    for i in range(5):
        page.evaluate("Lectio.goBack()"); seq.append(page.evaluate("Lectio.view"))
    print(seq)
    page.evaluate("Lectio.go('home')"); page.evaluate("Lectio.openReader()"); page.wait_for_timeout(800)
    print('continue y',page.evaluate("window.scrollY"))
    print(page.errors)
