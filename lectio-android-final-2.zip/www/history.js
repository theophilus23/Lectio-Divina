/* History page: how far this reading round is, and every finished round (start, finish, length).
   Data comes from the core: L.rounds (count), L.roundStart ({s,est}), L.history (collection of {id:'round-N', n, s, e, name}).
   The Start / Pick a date buttons carry data-track attributes; app.js handles those clicks and emits 'track'. */
(function(){
'use strict';
var L=window.Lectio,UI=L.ui,esc=L.esc;
var TOTAL=window.TOTAL_CH;
var el=null;

var page=L.registerView({
  id:'history',title:'History',
  menu:{label:'History',icon:'clock',group:'read',order:4},
  show:function(e){el=e;render()}
});
el=page;

/* the list shown on screen: real history items, newest first, plus placeholders for older rounds that have no dates */
function allRounds(){
  var items=L.history.list().filter(function(i){return i&&i.n}),have={};
  items.forEach(function(i){have[i.n]=1});
  var out=items.slice();
  for(var n=1;n<=L.rounds;n++)if(!have[n])out.push({id:'round-'+n,n:n,s:0,e:0,name:'',missing:true});
  return out.sort(function(a,b){return b.n-a.n});
}
function duration(r){
  if(!r.s||!r.e)return'';
  var d=UI.fmt.days(r.s,r.e);
  return d<1?'Less than a day':d+(d===1?' day':' days');
}
function shareText(r){
  return'Bible reading round '+r.n+(r.name?' – '+r.name:'')+'\n'
    +(r.s?'Started: '+UI.fmt.dt(r.s)+'\n':'')+'Finished: '+UI.fmt.dt(r.e)
    +(duration(r)?'\nTook: '+duration(r):'')+'\n\nShared from Lectio';
}

function summary(){
  var t=L.progress.totals(),pct=Math.round(t.ch/TOTAL*100),rs=L.roundStart||{s:0},auto=L.settings.autoTrack!==false;
  var h='<div class="hsum">'
    +'<div class="box"><b>'+L.rounds+'</b><span>'+(L.rounds===1?'round':'rounds')+' completed</span></div>'
    +'<div class="box"><b>'+pct+'%</b><span>'+t.ch+' of '+TOTAL+' chapters, round '+(L.rounds+1)+'</span></div>'
    +'<div class="box wide"><span style="margin:0">Current round progress</span><div class="hbar"><i style="width:'+pct+'%"></i></div>';
  if(rs.s){
    h+='<div class="htrack"><span>Started <b>'+esc(UI.fmt.dt(rs.s))+'</b>'+(rs.est?' (estimated)':'')+'</span>'
      +'<button type="button" class="linkbtn" data-track="change">Change</button></div>';
  }else if(!auto&&t.ch<TOTAL){
    h+='<p class="note" style="margin-top:10px">Auto-tracking is off. Tell the app when you began this round.</p>'
      +'<div class="htrack"><button class="btn main" data-track="now">Start now</button><button class="btn" data-track="pick">Pick a date</button></div>';
  }else{
    h+='<p class="note" style="margin-top:10px">The start time is saved when you mark your first chapter.</p>';
  }
  return h+'</div></div>';
}
function card(r){
  if(r.missing)return'<div class="li" data-id="'+esc(r.id)+'"><div class="row2"><span class="t">Round '+r.n+'</span><span class="tag">no dates</span></div>'
    +'<div class="meta">Round '+r.n+' - dates were not recorded.</div>'
    +'<div class="acts"><button type="button" class="btn" data-a="edit">'+UI.icon('edit',16)+' Add dates</button></div></div>';
  return'<div class="li" data-id="'+esc(r.id)+'"><div class="row2"><span class="t">Round '+r.n+'</span><span class="tag green">Completed</span></div>'
    +'<div class="rd-dates"><div><span>Started</span>'+(r.s?esc(UI.fmt.dt(r.s)):'Not recorded')+'</div><div><span>Finished</span>'+(r.e?esc(UI.fmt.dt(r.e)):'Not recorded')+'</div></div>'
    +'<div class="meta">'+[duration(r),r.name?'Read by '+esc(r.name):''].filter(Boolean).join(' · ')+'</div>'
    +'<div class="acts"><button type="button" class="iconbtn" data-a="edit" aria-label="Edit dates">'+UI.icon('edit',18)+'</button>'
    +'<button type="button" class="iconbtn" data-a="share" aria-label="Share">'+UI.icon('share',18)+'</button>'
    +'<button type="button" class="iconbtn" data-a="del" aria-label="Delete">'+UI.icon('trash',18)+'</button></div></div>';
}
function render(){
  if(!el||el.hidden)return;
  var rounds=allRounds();
  el.innerHTML='<div class="head"><div class="eyebrow">Bible reading history</div><h1 class="who">'+esc(L.readerName())+'</h1></div>'
    +summary()
    +'<div class="h2">Completed rounds</div>'
    +(rounds.length?'<div class="list">'+rounds.map(card).join('')+'</div>'
      :'<div class="empty">No finished rounds yet.<br>When you mark the last chapter of the Bible, your round appears here with its start and finish dates.</div>');
}

function find(id){return allRounds().filter(function(r){return r.id===id})[0]}
/* edit start and finish in one dialog */
function edit(r){
  var m=UI.modal({title:'Round '+r.n,body:
    '<label class="field">Started<input type="datetime-local" id="hs" value="'+(r.s?UI.fmt.dtLocal(r.s):'')+'"></label>'
    +'<label class="field">Finished<input type="datetime-local" id="he" value="'+(r.e?UI.fmt.dtLocal(r.e):'')+'"></label>'
    +'<p class="note">Leave Started empty if you do not know it.</p>',
    actions:[{label:'Cancel'},{kind:'main',label:'Save',on:function(){
      var s=m.body.querySelector('#hs').value,e=m.body.querySelector('#he').value;
      var st=s?new Date(s).getTime():0,en=e?new Date(e).getTime():0;
      if(!en){UI.toast('Choose when you finished');return false}
      if(st&&st>en){UI.toast('The start must be before the finish');return false}
      var old=L.history.get(r.id)||{};
      L.history.put(Object.assign({},old,{id:r.id,n:r.n,s:st,e:en,name:old.name||L.displayName()}));
      UI.toast('Dates saved');
    }}]});
}
el.addEventListener('click',function(e){
  var b=e.target.closest('[data-a]');if(!b)return;
  var li=b.closest('[data-id]'),r=li&&find(li.dataset.id);if(!r)return;
  if(b.dataset.a==='edit')edit(r);
  else if(b.dataset.a==='share')UI.share({title:'Round '+r.n,text:shareText(r)});
  else if(b.dataset.a==='del'){
    UI.confirm('Delete the record of round '+r.n+'? Your chapters stay marked.',{ok:'Delete',danger:true}).then(function(y){
      if(y&&L.history.get(r.id)){L.history.remove(r.id);UI.toast('Deleted')}
    });
  }
});
['progress','track','identity','settings'].forEach(function(n){L.on(n,render)});
L.history.on(render);
})();
