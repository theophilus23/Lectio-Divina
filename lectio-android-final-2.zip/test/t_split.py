import sys; sys.path.insert(0,'test')
from harness import app
with app(width=360,height=740) as (page,base):
    page.goto(base); page.wait_for_timeout(700)
    page.evaluate("Lectio.openReader(42,3)"); page.wait_for_timeout(700)
    page.screenshot(path='/tmp/s0.png')
    page.evaluate("Lectio.bars.run('page:split')"); page.wait_for_timeout(700); page.screenshot(path='/tmp/s1.png')
    page.click('[data-p=b] [data-a=more]'); page.wait_for_timeout(300); page.screenshot(path='/tmp/s2.png')
    page.click('text=Show Notes here'); page.wait_for_timeout(400); page.screenshot(path='/tmp/s3.png')
    print(page.errors)
