/* Bible data layer: the list of versions (from bibles/manifest.json plus any the user imported on the phone),
   loading books, verse references, and the book/chapter/verse picker.  Exposed as Lectio.bible.
   The reader, notes, search, quiz and saved-verses pages all use this. */
(function(){
'use strict';
var L=window.Lectio,$=L.$,esc=L.esc,UI=L.ui;
var P=window.LectioParse;

/* ================= versions ================= */
/* Fallback list, used until (or if) bibles/manifest.json cannot be read. */
var FALLBACK=[
  {id:'kjv',name:'King James Version',short:'KJV',lang:'en-US',base:'bibles/kjv/',builtin:true}
];
var shipped=FALLBACK.slice();      /* versions bundled in the app */
var custom=[];                      /* versions imported on this phone */
try{custom=JSON.parse(L.lsGet('lectio-trans-v1')||'[]')||[]}catch(e){custom=[]}
function saveCustom(){L.lsSet('lectio-trans-v1',JSON.stringify(custom))}
function versions(){return shipped.concat(custom)}
function version(id){var a=versions();for(var i=0;i<a.length;i++)if(a[i].id===id)return a[i];return a[0]}
function hasVersion(id){return versions().some(function(v){return v.id===id})}
function isTel(v){return!!v&&/^te/i.test(v.lang||'')}
var LANGS={en:'English',te:'Telugu',hi:'Hindi',ta:'Tamil',kn:'Kannada',ml:'Malayalam',mr:'Marathi',bn:'Bengali',gu:'Gujarati',pa:'Punjabi',or:'Odia',ur:'Urdu',ne:'Nepali',es:'Spanish',fr:'French',de:'German',pt:'Portuguese',ru:'Russian',zh:'Chinese',ko:'Korean',ja:'Japanese',ar:'Arabic',id:'Indonesian',sw:'Swahili'};
function langName(lang){var k=String(lang||'en').slice(0,2).toLowerCase();return LANGS[k]||String(lang||'')}

var manifestReady=fetch('bibles/manifest.json',{cache:'no-cache'}).then(function(r){if(!r.ok)throw new Error('no manifest');return r.json()}).then(function(m){
  var list=(m&&m.versions||[]).filter(function(v){return v&&v.id&&v.name}).map(function(v){
    return{id:String(v.id),name:String(v.name),short:String(v.short||v.id).slice(0,10),lang:v.lang||'en-US',base:'bibles/'+(v.dir||v.id)+'/',builtin:true,books:v.books}
  });
  if(list.length){
    shipped=list;
    custom=custom.filter(function(c){return!shipped.some(function(s){return s.id===c.id})});
    L.emit('versions');
  }
}).catch(function(){});

/* ================= loading books ================= */
/* A book is an array of chapters, each an array of verse strings:  book[chapter-1][verse-1] */
var cache={},order=[];
var CACHE_MAX=90;
function loadBook(tid,b,opt){
  var k=tid+':'+b;
  if(cache[k])return cache[k];
  var t=version(tid),pr;
  pr=t.base
    ?fetch(t.base+b+'.json').then(function(r){if(!r.ok)throw new Error('missing');return r.json()})
    :LStore.get('bibles',k).then(function(v){if(!v)throw new Error('missing');return v});
  if(opt&&opt.keep===false)return pr;     /* used by Search so a full scan does not fill memory */
  cache[k]=pr;order.push(k);
  pr.catch(function(){delete cache[k]});
  while(order.length>CACHE_MAX){var old=order.shift();delete cache[old]}
  return pr;
}
function chapter(tid,b,c){return loadBook(tid,b).then(function(bk){return bk[c-1]||null}).catch(function(){return null})}
/* texts of verses v1..v2 (inclusive) of one version, as an array of strings */
function verses(tid,b,c,v1,v2){
  return chapter(tid,b,c).then(function(ch){
    var out=[];if(!ch)return out;
    for(var v=v1;v<=(v2||v1);v++)out.push(ch[v-1]||'');
    return out;
  });
}
function chapterCount(b){return BOOKS[b].c}
/* number of verses in a chapter for a version (0 if the version has no text there) */
function verseCount(tid,b,c){return chapter(tid,b,c).then(function(ch){return ch?ch.length:0})}

/* ================= references ================= */
function refName(b,c,v1,v2){
  var s=BOOKS[b].n+' '+c;
  if(v1)s+=':'+v1+(v2&&v2!==v1?'-'+v2:'');
  return s;
}
/* [16,17,18,20] -> "John 3:16-18, 20" */
function refList(b,c,list){
  var a=list.slice().sort(function(x,y){return x-y}),runs=[],s=a[0],p=a[0];
  for(var i=1;i<=a.length;i++){
    if(a[i]===p+1){p=a[i];continue}
    runs.push(s===p?String(s):s+'-'+p);s=a[i];p=a[i];
  }
  return BOOKS[b].n+' '+c+':'+runs.join(', ');
}
/* "John 3:16", "1 cor 13", "ps 23:1-3" -> {b,c,v1,v2}  (v1/v2 missing for a whole chapter) or null */
function parseRef(text){
  var m=String(text||'').trim().match(/^(.+?)\s+(\d{1,3})(?:\s*[:.]\s*(\d{1,3})(?:\s*[-–]\s*(\d{1,3}))?)?$/);
  if(!m)return null;
  var b=P.bookIndex(m[1]);if(b<0)return null;
  var c=+m[2];if(c<1||c>BOOKS[b].c)return null;
  var r={b:b,c:c};
  if(m[3]){r.v1=+m[3];r.v2=m[4]?+m[4]:r.v1;if(r.v2<r.v1)r.v2=r.v1}
  return r;
}

/* ================= picker: version, book, chapter (and verses) =================
   pick({verses:true|false, tid, b, c, title}) -> Promise<{tid,short,b,c,v1,v2,ref,text}|null>
   With verses:false it closes as soon as a chapter is tapped and returns {tid,b,c}. */
function pick(o){
  o=o||{};
  return new Promise(function(res){
    var st={tid:o.tid&&hasVersion(o.tid)?o.tid:versions()[0].id,b:o.b!=null?o.b:0,c:o.c||1,step:'chapter',v1:0,v2:0,n:0,txt:[],vers:(o.vers||[]).filter(hasVersion),parOpen:false,bookOpen:false};
    var place=o.place||'reader',lay=L.bookLayout?L.bookLayout.get(place):'dropdown';
    if(lay!=='dropdown'&&o.b==null)st.bookOpen=true;
    if(o.parallel&&!st.vers.length)st.vers=[st.tid];
    var result=null;
    var m=UI.modal({title:o.title||(o.verses?'Choose a verse':'Go to'),wide:true,onClose:function(){res(result)},body:'<div id="pkBox"></div>',actions:o.verses?[{label:'Cancel'},{label:'Use this verse',kind:'main',on:function(){
      if(!st.v1){L.toast('Tap a verse first');return false}
      var ids=[];for(var v=st.v1;v<=st.v2;v++)ids.push(v);
      var vtxt=st.txt.slice(st.v1-1,st.v2),vmulti=vtxt.length>1;
      result={tid:st.tid,short:version(st.tid).short,b:st.b,c:st.c,v1:st.v1,v2:st.v2,ref:refName(st.b,st.c,st.v1,st.v2),text:vtxt.map(function(t,i){return vmulti?(st.v1+i)+' '+t:t}).join(' ')};
    }}]:null});
    var box=m.body.querySelector('#pkBox');
    function draw(){
      var vs=versions(),h='';
      var bookSel='<label class="field">Book<select id="pkB"><optgroup label="Old Testament">'+BOOKS.slice(0,OT_N).map(function(b,i){return'<option value="'+i+'"'+(i===st.b?' selected':'')+'>'+esc(b.n)+'</option>'}).join('')+'</optgroup><optgroup label="New Testament">'+BOOKS.slice(OT_N).map(function(b,i){return'<option value="'+(i+OT_N)+'"'+(i+OT_N===st.b?' selected':'')+'>'+esc(b.n)+'</option>'}).join('')+'</optgroup></select></label>';
      if(lay!=='dropdown')bookSel='<div class="field"><span>Book</span><button type="button" class="btn pkbook" id="pkBook" aria-expanded="'+st.bookOpen+'"><span>'+esc(BOOKS[st.b].n)+'</span><span>'+(st.bookOpen?'▴':'▾')+'</span></button></div>';
      var verSel='<label class="field">Version<select id="pkV">'+vs.map(function(v){return'<option value="'+esc(v.id)+'"'+(v.id===st.tid?' selected':'')+'>'+esc(v.name)+'</option>'}).join('')+'</select></label>';
      var swapBtn=(o.onSwap&&st.vers.length>1)?'<button type="button" class="btn pkswap" id="pkSwap" aria-label="Swap version order" title="Swap version order">⇅</button>':'';
      if(o.parallel){
        var names=st.vers.slice(1).map(function(id){return version(id).short});
        h+='<div class="grid2">'+verSel+'<div class="field"><span>Add versions</span><div class="row" style="gap:6px"><button type="button" class="btn pkpar" id="pkPar" aria-expanded="'+st.parOpen+'" style="flex:1" aria-label="Add versions">＋ '+(names.length?esc(names.join(' + ')):'Add')+'</button>'+swapBtn+'</div></div></div>';
        h+=bookSel;
      }else h+='<div class="grid2">'+verSel+bookSel+'</div>';
      if(lay!=='dropdown'&&st.bookOpen)h+='<div class="pkbooks">'+L.bookLayout.html(place,{selected:[st.b]})+'</div>';
      if(lay!=='dropdown'&&st.bookOpen){}
      else if(st.step==='chapter'){
        h+='<div class="sec-t">Chapter</div><div class="pickgrid">';
        for(var c=1;c<=BOOKS[st.b].c;c++)h+='<button type="button" data-c="'+c+'" aria-pressed="'+(c===st.c)+'">'+c+'</button>';
        h+='</div>';
      }else{
        if(st.v1){
          var s=st.txt.slice(st.v1-1,st.v2).join(' ');if(s.length>240)s=s.slice(0,240)+'…';
          h+='<div class="vq"><div class="r">'+esc(refName(st.b,st.c,st.v1,st.v2))+' · '+esc(version(st.tid).short)+'</div><div class="x">'+esc(s)+'</div></div>';
        }else h+='<div class="vq"><div class="x" style="opacity:.6">Tap a verse to preview it here.</div></div>';
        h+='<div class="row"><button type="button" class="btn" id="pkBack">‹ Chapters</button><b>'+esc(BOOKS[st.b].n)+' '+st.c+'</b></div>';
        h+='<div class="sec-t">Tap a verse, then another to make a range</div><div class="pickgrid verses">';
        for(var v=1;v<=st.n;v++)h+='<button type="button" data-v="'+v+'" aria-pressed="'+(v===st.v1&&v===st.v2)+'"'+(st.v1&&v>=st.v1&&v<=st.v2?' class="inrange"':'')+'>'+v+'</button>';
        h+='</div>';
      }
      h+='<div style="height:14px"></div>';
      box.innerHTML=h;
    }
    /* a second dialog: one drop-down per extra version */
    function addVers(){
      var extra=st.vers.slice(1).filter(function(id){return hasVersion(id)&&id!==st.tid});
      if(!extra.length)extra=[''];
      var vm=UI.modal({title:'Add versions',body:'<div id="avBox"></div><button type="button" class="btn" id="avAdd">＋ Add another</button><p class="note">Up to 3 more versions beside '+esc(version(st.tid).short)+'.</p>',actions:[{label:'Cancel'},{label:'Done',kind:'main',on:function(){
        var picked=extra.filter(function(x,i,a){return x&&x!==st.tid&&a.indexOf(x)===i});
        st.vers=[st.tid].concat(picked);draw();
      }}]});
      var bx=vm.body.querySelector('#avBox'),add=vm.body.querySelector('#avAdd');
      function dv(){
        bx.innerHTML=extra.map(function(id,i){
          return'<label class="field">Version '+(i+2)+'<select data-i="'+i+'"><option value="">None</option>'+versions().filter(function(v){return v.id!==st.tid}).map(function(v){return'<option value="'+esc(v.id)+'"'+(v.id===id?' selected':'')+'>'+esc(v.name)+'</option>'}).join('')+'</select></label>';
        }).join('');
        add.hidden=extra.length>=3;
      }
      dv();
      bx.addEventListener('change',function(e){var i=e.target.dataset.i;if(i!=null)extra[+i]=e.target.value});
      add.addEventListener('click',function(){if(extra.length<3){extra.push('');dv()}});
    }
    /* a second dialog to put the chosen versions in the order they are shown */
    function arrange(){
      var list=st.vers.slice();
      var am=UI.modal({title:'Arrange versions',body:'<div id="arList"></div><p class="note">The top version is the main one; the others follow below it.</p>',actions:[{label:'Cancel'},{label:'Done',kind:'main',on:function(){
        st.vers=list.slice();st.tid=list[0];draw();if(o.onSwap)o.onSwap(st.vers.slice());
      }}]});
      var box2=am.body.querySelector('#arList');
      function d2(){
        box2.innerHTML=list.map(function(id,i){
          return'<div class="arrow-row" style="display:flex;align-items:center;gap:8px;padding:8px 0;border-bottom:1px solid var(--line)"><b style="flex:1">'+esc(version(id).name)+' <small class="muted">'+esc(version(id).short)+'</small></b>'+
          '<button type="button" class="btn" data-mv="'+i+'" data-d="-1" '+(i===0?'disabled':'')+'>▲</button><button type="button" class="btn" data-mv="'+i+'" data-d="1" '+(i===list.length-1?'disabled':'')+'>▼</button></div>';
        }).join('');
      }
      d2();
      box2.addEventListener('click',function(e){
        var b=e.target.closest('[data-mv]');if(!b)return;
        var i=+b.dataset.mv,j=i+ +b.dataset.d,t=list[i];list[i]=list[j];list[j]=t;d2();
      });
    }
    function toVerses(){
      return chapter(st.tid,st.b,st.c).then(function(ch){
        if(!ch||!ch.length){L.toast('This version has no text for '+refName(st.b,st.c));return}
        st.txt=ch;st.n=ch.length;st.step='verse';st.v1=0;st.v2=0;draw();
      });
    }
    box.addEventListener('change',function(e){
      if(e.target.id==='pkV'){st.tid=e.target.value;if(o.parallel){st.vers=[st.tid].concat(st.vers.slice(1).filter(function(x){return x!==st.tid}));draw()}if(st.step==='verse')toVerses();}
      else if(e.target.id==='pkB'){st.b=+e.target.value;st.c=1;st.step='chapter';draw()}
    });
    box.addEventListener('click',function(e){
      var t=e.target.closest('button');if(!t)return;
      if(t.id==='pkPar'){addVers();return}
      if(t.id==='pkBook'){st.bookOpen=!st.bookOpen;draw();return}
      if(t.dataset.b!=null){st.b=+t.dataset.b;st.c=1;st.step='chapter';st.bookOpen=false;draw();return}
      if(t.id==='pkSwap'){arrange();return}
      if(t.id==='pkOpts'){m.close();if(o.onOptions)o.onOptions();return}
      if(t.dataset.pv){var i=st.vers.indexOf(t.dataset.pv);if(i>-1)st.vers.splice(i,1);else if(st.vers.length<4)st.vers.push(t.dataset.pv);else L.toast('Up to 4 versions together');draw();return}
      if(t.dataset.c){
        st.c=+t.dataset.c;
        if(!o.verses){result={tid:st.tid,b:st.b,c:st.c};if(o.parallel){result.vers=st.vers.slice();result.vers[0]=st.tid}m.close();return}
        toVerses();
      }else if(t.dataset.v){
        var v=+t.dataset.v;
        if(!st.v1||st.v2!==st.v1){st.v1=st.v2=v}
        else if(v<st.v1){st.v2=st.v1;st.v1=v}
        else st.v2=v;
        draw();
      }else if(t.id==='pkBack'){st.step='chapter';draw()}
    });
    draw();
  });
}

/* ================= settings card: Bible versions + importing a file on the phone ================= */
var verBusy=false,verMsg='';
var IMPORT_LANGS=[['en-US','English'],['te-IN','Telugu'],['hi-IN','Hindi'],['ta-IN','Tamil'],['kn-IN','Kannada'],['ml-IN','Malayalam'],['mr-IN','Marathi'],['bn-IN','Bengali'],['es-ES','Spanish'],['fr-FR','French'],['de-DE','German'],['pt-BR','Portuguese'],['ru-RU','Russian'],['zh-CN','Chinese'],['ko-KR','Korean'],['ja-JP','Japanese'],['ar-SA','Arabic'],['id-ID','Indonesian'],['sw-KE','Swahili']];
function readFile(f){
  if(f.text)return f.text();
  return new Promise(function(res,rej){var r=new FileReader();r.onload=function(){res(r.result)};r.onerror=rej;r.readAsText(f)});
}
function renderVersions(){
  var el=$('verCard');if(!el)return;
  var h='<h3>Bible versions</h3>';
  h+='<ul class="vlist">'+versions().map(function(t){
    return'<li><span><b>'+esc(t.name)+'</b><small>'+esc(langName(t.lang))+' · '+(t.builtin?'In the app for everyone':'Imported on this phone only')+'</small></span>'+(t.builtin?'':'<button type="button" class="linkbtn" data-delver="'+esc(t.id)+'">Remove</button>')+'</li>';
  }).join('')+'</ul>';
  h+='<p class="muted">To add a Bible for <b>every</b> user (NIV, more languages), put the files in the project and rebuild. See README, “Adding Bible versions”. To try a file just on this phone, import it here.</p>';
  h+='<label class="field">Name<input id="verName" type="text" placeholder="NIV" maxlength="24"></label>';
  h+='<label class="field">Language<select id="verLang">'+IMPORT_LANGS.map(function(l){return'<option value="'+l[0]+'">'+l[1]+'</option>'}).join('')+'</select></label>';
  h+='<input id="verFile" type="file" accept=".json,application/json" multiple hidden>';
  h+='<div class="row"><button class="btn main" id="verPick" type="button"'+(verBusy?' disabled':'')+'>'+(verBusy?'Importing…':'Choose JSON file(s)')+'</button></div>';
  h+='<p class="note" id="verMsg">'+esc(verMsg)+'</p>';
  el.innerHTML=h;
}
$('verCard').addEventListener('click',function(e){
  var t=e.target.closest('button');if(!t)return;
  if(t.id==='verPick'){
    if(!$('verName').value.trim()){verMsg='Type a name first, for example NIV.';$('verMsg').textContent=verMsg;return}
    $('verFile').click();
  }else if(t.dataset.delver){
    var id=t.dataset.delver;
    custom=custom.filter(function(x){return x.id!==id});saveCustom();
    for(var i=0;i<66;i++){LStore.del('bibles',id+':'+i).catch(function(){});delete cache[id+':'+i]}
    verMsg='Removed.';renderVersions();L.emit('versions');
  }
});
$('verCard').addEventListener('change',function(e){
  if(e.target.id!=='verFile')return;
  var files=Array.prototype.slice.call(e.target.files||[]);e.target.value='';
  if(!files.length)return;
  var name=$('verName').value.trim()||'Imported',lang=$('verLang').value;
  verBusy=true;verMsg='';renderVersions();
  var out={};
  files.reduce(function(p,f){
    return p.then(function(){return readFile(f)}).then(function(txt){P.parseBible(JSON.parse(txt),out,P.bookFromFileName(f.name))});
  },Promise.resolve()).then(function(){
    var idx=Object.keys(out).map(Number);
    if(!idx.length)throw new Error('none');
    var id='c'+Date.now().toString(36),count=0;
    return Promise.all(idx.map(function(i){
      out[i].forEach(function(c){count+=c.length});
      return LStore.set('bibles',id+':'+i,out[i]);
    })).then(function(){
      custom.push({id:id,name:name,short:name.slice(0,8),lang:lang});saveCustom();
      verMsg='Added '+name+': '+idx.length+' of 66 books, '+count.toLocaleString()+' verses.'+(idx.length<66?' Missing books will show a dash.':'');
      L.emit('versions');
    });
  }).catch(function(){
    verMsg='That file could not be read as a Bible. Use a JSON file with books, chapters and verses.';
  }).then(function(){verBusy=false;renderVersions()});
});
L.onShow.push(function(name){if(name==='settings')renderVersions()});

L.bible={versions:versions,version:version,hasVersion:hasVersion,isTel:isTel,langName:langName,ready:manifestReady,
  loadBook:loadBook,chapter:chapter,verses:verses,chapterCount:chapterCount,verseCount:verseCount,
  refName:refName,refList:refList,parseRef:parseRef,pick:pick};
})();
