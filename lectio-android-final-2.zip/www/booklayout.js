/* Book layouts: one place that decides how a list of Bible books is drawn, and a settings card (Settings > Book layouts)
   where each place in the app can use its own layout, or all of them the same. Stored in Lectio.settings.bookLayouts
   ({place: layout}, only places that differ from their default) and Lectio.settings.bookOrder ('bible' | 'az').
   Exposed as Lectio.bookLayout:  get(place), html(place, {selected, order}), and the settings card helpers. */
(function(){
'use strict';
var L=window.Lectio,esc=L.esc;

var AB='Gen,Exod,Lev,Num,Deut,Josh,Judg,Ruth,1 Sam,2 Sam,1 Kgs,2 Kgs,1 Chr,2 Chr,Ezra,Neh,Esth,Job,Ps,Prov,Eccl,Song,Isa,Jer,Lam,Ezek,Dan,Hos,Joel,Amos,Obad,Jonah,Mic,Nah,Hab,Zeph,Hag,Zech,Mal,Matt,Mark,Luke,John,Acts,Rom,1 Cor,2 Cor,Gal,Eph,Phil,Col,1 Thess,2 Thess,1 Tim,2 Tim,Titus,Phlm,Heb,Jas,1 Pet,2 Pet,1 John,2 John,3 John,Jude,Rev'.split(',');

var LAYOUTS={tiles:'Tiles',pills:'Abbreviations',names:'Full names',dropdown:'Dropdown'};
var PLACES=[
  {id:'lib',name:'Bible page',desc:'The library of all 66 books',layouts:['tiles','pills','names'],def:'tiles'},
  {id:'reader',name:'Reader: Go to',desc:'Choosing a book and chapter while reading',layouts:['pills','names','tiles','dropdown'],def:'pills'},
  {id:'notes',name:'Notes: adding a verse',desc:'Picking a verse to put in a note',layouts:['pills','names','tiles','dropdown'],def:'pills'},
  {id:'prayers',name:'Prayer points: adding a verse',desc:'Picking a verse for a prayer',layouts:['pills','names','tiles','dropdown'],def:'pills'},
  {id:'plans',name:'Reading plans: choosing books',desc:'Books to include in your own plan',layouts:['pills','names','tiles'],def:'pills'}
];
function place(id){for(var i=0;i<PLACES.length;i++)if(PLACES[i].id===id)return PLACES[i];return null}
function store(){var s=L.settings;if(!s.bookLayouts||typeof s.bookLayouts!=='object')s.bookLayouts={};return s.bookLayouts}
function get(id){var p=place(id);if(!p)return'pills';var v=store()[id];return v&&p.layouts.indexOf(v)>-1?v:p.def}
function order(){return L.settings.bookOrder==='az'?'az':'bible'}
function commit(){L.commitSettings()}
function set(id,lay){var p=place(id);if(!p||p.layouts.indexOf(lay)<0)return;var s=store();if(lay===p.def)delete s[id];else s[id]=lay;commit()}
/* one layout for every place; a place that cannot show it (for example the Bible page has no dropdown) keeps its own */
function setAll(lay){var s=store();PLACES.forEach(function(p){if(p.layouts.indexOf(lay)<0)return;if(lay===p.def)delete s[p.id];else s[p.id]=lay});commit()}
function reset(id){delete store()[id];commit()}
function resetAll(){L.settings.bookLayouts={};L.settings.bookOrder='bible';commit()}
function setOrder(o){L.settings.bookOrder=o==='az'?'az':'bible';commit()}
function isDef(id){var p=place(id);return get(id)===p.def}

function readCount(b){var n=0;for(var c=1;c<=BOOKS[b].c;c++)if(L.chapterRead(b,c))n++;return n}
function label(lay,i){return lay==='pills'?AB[i]:BOOKS[i].n}
function btn(lay,i,sel,prog){
  var b=BOOKS[i],n=prog?readCount(i):0,full=n===b.c,pct=prog?Math.round(100*n/b.c):0;
  return'<button type="button" class="blb'+(full?' done':'')+'" data-b="'+i+'" aria-pressed="'+(sel.indexOf(i)>-1)+'" aria-label="'+esc(b.n)+(prog?', '+n+' of '+b.c+' chapters read':'')+'" style="--p:'+pct+'%">'
    +'<span class="nm">'+esc(label(lay,i))+'</span>'+(lay==='tiles'&&prog?'<span class="ct">'+n+'/'+b.c+'</span>':'')+'</button>';
}
/* markup for a book chooser in this place. o.selected = array of book indexes to show as chosen; o.progress (default true) draws read progress */
function html(id,o){
  o=o||{};var lay=get(id),sel=o.selected||[],prog=o.progress!==false,idx=[],h='';
  if(lay==='dropdown')lay='pills';
  function grp(t,list){return(t?'<div class="blh">'+t+'</div>':'')+'<div class="blg">'+list.map(function(i){return btn(lay,i,sel,prog)}).join('')+'</div>'}
  var all=BOOKS.map(function(b,i){return i});
  if(order()==='az'){var a=all.slice().sort(function(x,y){return label(lay,x).localeCompare(label(lay,y),undefined,{numeric:true})});h=grp('',a)}
  else h=grp('Old Testament',all.slice(0,OT_N))+grp('New Testament',all.slice(OT_N));
  return'<div class="bl bl-'+lay+'">'+h+'</div>';
}
var SAMPLE=[0,1,18,19,39,42,44,65];
function sample(lay){var h=SAMPLE.map(function(i){return btn(lay==='dropdown'?'pills':lay,i,[],false)}).join('');return'<div class="bl bl-'+(lay==='dropdown'?'pills':lay)+' blsample"><div class="blg">'+h+'</div></div>'}

/* ---- settings card ---- */
var cardEl=L.addSettingsCard({id:'booklayout',order:31,render:renderCard});
function renderCard(el){
  var h='<h3>Book layouts</h3><p class="note">Choose how books are shown in each place, or use one layout everywhere.</p>';
  h+='<div class="blall"><div class="sec-t">All places</div><div class="seg" role="group" aria-label="Layout for all places">'+['tiles','pills','names'].map(function(k){return'<button type="button" data-all="'+k+'">'+LAYOUTS[k]+'</button>'}).join('')+'</div></div>';
  h+='<div class="blall"><div class="sec-t">Order</div><div class="seg" role="group" aria-label="Book order"><button type="button" data-ord="bible" aria-pressed="'+(order()==='bible')+'">Bible order</button><button type="button" data-ord="az" aria-pressed="'+(order()==='az')+'">A to Z</button></div><p class="note">Applies to the choosers in notes, prayers, plans and the reader.</p></div>';
  PLACES.forEach(function(p){
    var cur=get(p.id);
    h+='<div class="blplace" data-place="'+p.id+'"><div class="blpt"><span><b>'+esc(p.name)+'</b><small>'+esc(p.desc)+' · starts as '+LAYOUTS[p.def].toLowerCase()+'</small></span><button type="button" class="linkbtn" data-reset="'+p.id+'"'+(isDef(p.id)?' disabled':'')+'>Reset</button></div>'
      +'<div class="seg" role="group" aria-label="Layout for '+esc(p.name)+'">'+p.layouts.map(function(k){return'<button type="button" data-set="'+p.id+':'+k+'" aria-pressed="'+(k===cur)+'">'+LAYOUTS[k]+'</button>'}).join('')+'</div>'
      +(cur==='dropdown'?'<p class="note">A drop-down list of books.</p>':sample(cur))+'</div>';
  });
  h+='<button type="button" class="linkbtn" id="blResetAll">Reset every place to its starting layout</button>';
  el.innerHTML=h;
  /* the "all places" buttons are pressed only when every place that can show that layout already uses it */
  Array.prototype.forEach.call(el.querySelectorAll('[data-all]'),function(b){var k=b.dataset.all;b.setAttribute('aria-pressed',String(PLACES.every(function(p){return p.layouts.indexOf(k)<0||get(p.id)===k})))});
  el.onclick=function(e){
    var t=e.target.closest('button');if(!t)return;
    if(t.dataset.set){var q=t.dataset.set.split(':');set(q[0],q[1])}
    else if(t.dataset.all){setAll(t.dataset.all)}
    else if(t.dataset.reset){reset(t.dataset.reset)}
    else if(t.dataset.ord){setOrder(t.dataset.ord)}
    else if(t.id==='blResetAll'){resetAll()}
    else return;
    renderCard(el);
  };
}

L.bookLayout={PLACES:PLACES,LAYOUTS:LAYOUTS,AB:AB,get:get,set:set,setAll:setAll,reset:reset,resetAll:resetAll,html:html,sample:sample};
})();
