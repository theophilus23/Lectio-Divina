import sys,json; sys.path.insert(0,'test')
from harness import app
with app(width=360,height=740) as (page,base):
    page.goto(base); page.wait_for_timeout(700)
    # notes
    page.evaluate("Lectio.go('notes')"); page.wait_for_timeout(300)
    page.evaluate("Lectio.notes.act('new')"); page.wait_for_timeout(300)
    print('templates:',page.inner_text('.umodal')[:200].replace('\n',' | '))
    page.click('.umodal >> text=Bible study'); page.wait_for_timeout(500)
    print('note view:',page.inner_text('#v-notes')[:250].replace('\n',' | '))
    print('notes coll',page.evaluate("Lectio.coll('notes').list().length"))
    # add verse to note via API
    r=page.evaluate("typeof Lectio.notes.addVerse")
    print('addVerse',r)
    # prayers
    page.evaluate("Lectio.go('mypray')"); page.wait_for_timeout(300)
    page.click('#v-mypray [data-act=new]'); page.wait_for_timeout(300)
    print('prayer form:',page.inner_text('.umodal')[:200].replace('\n',' | '))
    page.screenshot(path='/tmp/pr.png')
    # history / saved
    page.evaluate("Lectio.go('history')"); page.wait_for_timeout(300); print('history:',page.inner_text('#v-history')[:250].replace('\n',' | '))
    page.evaluate("Lectio.go('saved')"); page.wait_for_timeout(300); print('saved:',page.inner_text('#v-saved')[:200].replace('\n',' | '))
    print(page.errors)
