import sys; sys.path.insert(0,'test')
from harness import app
with app(width=360,height=740) as (page,base):
    page.goto(base); page.wait_for_timeout(600)
    page.evaluate("Lectio.go('quiz')"); page.wait_for_timeout(200)
    page.click('[data-act=daily]')
    for i in range(10):
        page.click('.qo >> nth=%d'%(i%4)); page.wait_for_timeout(750)
    page.wait_for_timeout(500)
    page.screenshot(path='/tmp/q1.png')
    print(page.inner_text('.qdone')[:120])
    page.screenshot(path='/tmp/qm.png')
    inp=page.query_selector('.umodal input')
    if inp: inp.fill('Tester'); page.click('.umodal .uacts button >> nth=-1'); page.wait_for_timeout(500)
    page.click('[data-act=board]'); page.wait_for_timeout(500)
    print(page.inner_text('#v-quiz')[:300])
    page.click('[data-tab=home]'); page.click('[data-act=practice]'); page.click('.qo >> nth=0'); page.wait_for_timeout(100)
    page.screenshot(path='/tmp/q2.png')
    print(page.errors)
