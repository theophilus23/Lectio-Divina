#!/usr/bin/env python3
"""Songs of Zion track maker (runs on your computer, not in the app).

 1. reads the melodies people shared (Firestore collection song_melodies, or a JSON file),
 2. joins the melodies of each song into one consensus melody (transposes and time-aligns them first),
 3. finds the key, tempo and a simple chord per bar,
 4. renders two MP3 files per song: a guide track (accompaniment + soft lead playing the melody) and an instrumental,
 5. writes manifest.json, which the app reads.

 python3 make_tracks.py --source json --file melodies.json --out out
 python3 make_tracks.py --source firestore --key serviceAccountKey.json --out out [--dump melodies.json]
Needs numpy, scipy, ffmpeg (and firebase-admin for --source firestore). See README.md."""
import argparse, json, math, os, subprocess, sys, wave
import numpy as np
from scipy.signal import fftconvolve

FPS = 10
SR = 44100
SHARP = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B']
FLAT = ['C','Db','D','Eb','E','F','Gb','G','Ab','A','Bb','B']
FLAT_KEYS = {(5,0),(10,0),(3,0),(8,0),(1,0),(6,0),(2,1),(7,1),(0,1),(5,1),(10,1),(3,1)}   # (tonic pc, minor?)

# ---------------------------------------------------------------- melodies
def decode(rec):
    r = rec['rle']; a = []
    for i in range(0, len(r) - 1, 2):
        a += [int(r[i])] * int(r[i + 1])
    return np.array(a, dtype=float)

def pc_hist(x):
    h = np.zeros(12)
    for m in x[x > 0]:
        h[int(m) % 12] += 1
    return h / (h.sum() or 1)

def best_shift(h, ref):
    return max(range(-6, 6), key=lambda s: float(np.dot(np.roll(h, s), ref)))

def dtw_align(ref, x):
    """For every frame of ref, the index of the frame of x that matches it (asymmetric DTW, slopes 0..2)."""
    n, m = len(ref), len(x)
    INF = 1e9
    def cost(i):
        r = ref[i]
        if r == 0:
            return np.where(x == 0, 0.0, 3.0)
        d = np.abs(x - r) % 12
        d = np.minimum(d, 12 - d)
        return np.where(x == 0, 3.0, np.minimum(d, 6.0))
    D = np.full((n, m), INF, dtype=np.float32)
    B = np.zeros((n, m), dtype=np.int8)
    c0 = cost(0)
    lim = max(2, int(m * 0.2))
    D[0, :lim] = c0[:lim] + 0.05 * np.arange(lim)
    idx = np.arange(m)
    for i in range(1, n):
        prev = D[i - 1]
        s1 = np.concatenate(([INF], prev[:-1]))
        s2 = np.concatenate(([INF, INF], prev[:-2])) + 0.4
        s0 = prev + 0.4
        st = np.stack([s1, s0, s2])
        k = st.argmin(0)
        D[i] = cost(i) + st[k, idx]
        B[i] = k
    j = int(np.argmin(D[n - 1, int(m * 0.8):])) + int(m * 0.8)
    path = np.zeros(n, dtype=int)
    for i in range(n - 1, 0, -1):
        path[i] = j
        j = max(0, j - (1 if B[i, j] == 0 else 0 if B[i, j] == 1 else 2))
    path[0] = j
    return path

def consensus(melodies):
    """melodies: list of frame arrays (0 = silence). Returns (consensus frames, number used)."""
    xs = [m for m in melodies if (m > 0).mean() > 0.15 and len(m) >= 8 * FPS]
    if not xs:
        return None, 0
    if len(xs) == 1:
        return xs[0].copy(), 1
    hs = [pc_hist(x) for x in xs]
    score = [np.mean([max(float(np.dot(np.roll(hs[i], s), hs[j])) for s in range(-6, 6)) for j in range(len(xs)) if j != i]) for i in range(len(xs))]
    r = int(np.argmax(score))
    ref = xs[r].copy()
    rmed = np.median(ref[ref > 0])
    aligned = [ref]
    for i, x in enumerate(xs):
        if i == r:
            continue
        x = x.copy()
        s = best_shift(hs[i], hs[r])
        x[x > 0] += s
        med = np.median(x[x > 0])
        x[x > 0] += 12 * round((rmed - med) / 12)
        aligned.append(x[dtw_align(ref, x)])
    A = np.stack(aligned)
    out = np.zeros(A.shape[1])
    for t in range(A.shape[1]):
        v = A[:, t]
        vv = v[v > 0]
        if len(vv) and len(vv) * 2 >= len(v):
            rr = ref[t] if ref[t] > 0 else np.median(vv)
            vv = vv + 12 * np.round((rr - vv) / 12)
            out[t] = round(float(np.median(vv)))
    return out, len(xs)

def to_notes(frames):
    """frames -> list of [start_s, dur_s, midi]; short blips are absorbed."""
    runs = []
    for i, v in enumerate(frames):
        if runs and runs[-1][0] == v:
            runs[-1][2] += 1
        else:
            runs.append([v, i, 1])
    for _ in range(2):
        for k in range(len(runs)):
            if runs[k][2] < 2 and 0 < k < len(runs) - 1 and runs[k][0] != 0:
                runs[k][0] = runs[k - 1][0]
        merged = []
        for r in runs:
            if merged and merged[-1][0] == r[0]:
                merged[-1][2] += r[2]
            else:
                merged.append(list(r))
        runs = merged
    return [[r[1] / FPS, r[2] / FPS, int(r[0])] for r in runs if r[0] > 0]

# ---------------------------------------------------------------- music analysis
KS_MAJ = [6.35,2.23,3.48,2.33,4.38,4.09,2.52,5.19,2.39,3.66,2.29,2.88]
KS_MIN = [6.33,2.68,3.52,5.38,2.60,3.53,2.54,4.75,3.98,2.69,3.34,3.17]
def detect_key(notes):
    h = np.zeros(12)
    for s, d, m in notes:
        h[m % 12] += d
    best = None
    for t in range(12):
        for minor, prof in ((0, KS_MAJ), (1, KS_MIN)):
            c = np.corrcoef(h, np.roll(prof, t))[0, 1]
            if best is None or c > best[0]:
                best = (c, t, minor)
    return best[1], best[2]

def detect_tempo(notes):
    on = np.array([n[0] for n in notes])
    if len(on) < 4:
        return 80.0
    best = None
    for bpm in np.arange(56, 121, 1.0):
        p = 60.0 / bpm / 2
        sc = float(np.sum(np.cos(2 * np.pi * (on - on[0]) / p))) * math.exp(-((bpm - 80) / 40) ** 2)
        if best is None or sc > best[0]:
            best = (sc, bpm)
    return best[1]

def chord_set(tonic, minor):
    if minor:
        spec = [(0, 'm'), (5, 'm'), (7, ''), (8, ''), (3, ''), (10, '')]
    else:
        spec = [(0, ''), (2, 'm'), (4, 'm'), (5, ''), (7, ''), (9, 'm')]
    return [((tonic + d) % 12, q, d) for d, q in spec]

TRANS = {(0,5):.25,(5,7):.35,(7,0):.7,(9,5):.3,(5,0):.35,(7,9):.3,(0,9):.25,(0,7):.2,(2,7):.35,(9,2):.25,(8,7):.3,(3,8):.2,(10,3):.2,(8,10):.2,(10,0):.3}
def harmonise(notes, bars, beats_per_bar, beat, tonic, minor):
    cs = chord_set(tonic, minor)
    blen = beat * beats_per_bar
    W = np.zeros((bars, 12))
    for s, d, m in notes:
        b = int(s // blen)
        if b < bars:
            w = d / beat
            if abs(s - b * blen) < beat * 0.3:
                w *= 1.5
            W[b, m % 12] += w
    def emit(b, c):
        root, q, _ = c
        tones = {root, (root + (3 if q == 'm' else 4)) % 12, (root + 7) % 12}
        return sum(W[b, p] * (1.0 if p in tones else -0.6) for p in range(12)) + 0.3 * W[b, root]
    n = len(cs)
    V = np.full((bars, n), -1e9); P = np.zeros((bars, n), dtype=int)
    for j, c in enumerate(cs):
        V[0, j] = emit(0, c) + (1.0 if c[2] == 0 else 0)
    for b in range(1, bars):
        for j, c in enumerate(cs):
            best = max(range(n), key=lambda i: V[b - 1, i] + (0 if i == j else TRANS.get((cs[i][2], c[2]), -0.25)))
            V[b, j] = V[b - 1, best] + (0 if best == j else TRANS.get((cs[best][2], c[2]), -0.25)) + emit(b, c)
            P[b, j] = best
    for j, c in enumerate(cs):
        V[bars - 1, j] += 2.0 if c[2] == 0 else (0.4 if c[2] == 7 else 0)
    j = int(np.argmax(V[bars - 1])); seq = [j]
    for b in range(bars - 1, 0, -1):
        j = P[b, j]; seq.append(j)
    return [cs[j] for j in reversed(seq)]

def chord_name(c, flat):
    return (FLAT if flat else SHARP)[c[0]] + c[1]

# ---------------------------------------------------------------- synthesis
def env_exp(n, rate):
    return np.exp(-np.arange(n) / SR * rate)

def piano(midi, dur, vel=1.0):
    f = 440 * 2 ** ((midi - 69) / 12)
    n = int(SR * (dur + 1.0)); t = np.arange(n) / SR
    y = np.zeros(n)
    for h in range(1, 9):
        if f * h > 9000:
            break
        y += (1 / h ** 1.2) * np.sin(2 * np.pi * f * h * (1 + 0.0004 * h * h) * t) * np.exp(-t * (1.4 + f / 500 + 0.6 * h))
    a = int(0.004 * SR)
    y[:a] *= np.linspace(0, 1, a)
    return y * vel

def pad(midis, dur):
    n = int((dur + 0.7) * SR); t = np.arange(n) / SR
    L = np.zeros(n); R = np.zeros(n)
    for m in midis:
        f = 440 * 2 ** ((m - 69) / 12)
        for det, wl, wr in ((0.997, 1.0, 0.3), (1.003, 0.3, 1.0), (1.0, 0.5, 0.5)):
            w = np.sin(2 * np.pi * f * det * t) + 0.25 * np.sin(4 * np.pi * f * det * t) + 0.08 * np.sin(6 * np.pi * f * det * t)
            L += w * wl; R += w * wr
    e = np.minimum(1, t / 0.45) * np.minimum(1, np.maximum(0, (dur + 0.7 - t)) / 0.7)
    k = e / (3 * len(midis))
    return L * k, R * k

def bass(midi, dur):
    f = 440 * 2 ** ((midi - 69) / 12)
    n = int(SR * (dur + 0.3)); t = np.arange(n) / SR
    y = np.sin(2 * np.pi * f * t) + 0.4 * np.sin(4 * np.pi * f * t) + 0.15 * np.sin(6 * np.pi * f * t)
    e = np.minimum(1, t / 0.01) * np.exp(-t * 1.1) * np.minimum(1, np.maximum(0, dur + 0.3 - t) / 0.25)
    return y * e

def lead(midi, dur):
    f = 440 * 2 ** ((midi - 69) / 12)
    n = int(SR * (dur + 0.12)); t = np.arange(n) / SR
    vib = 1 + 0.003 * np.minimum(1, np.maximum(0, t - 0.15) / 0.2) * np.sin(2 * np.pi * 5.2 * t)
    ph = 2 * np.pi * np.cumsum(f * vib) / SR
    y = np.sin(ph) + 0.25 * np.sin(2 * ph) + 0.1 * np.sin(3 * ph)
    e = np.minimum(1, t / 0.06) * np.minimum(1, np.maximum(0, dur + 0.12 - t) / 0.1)
    return y * e

def put(buf, y, start, gain=1.0, pan=0.0):
    i = int(start * SR)
    if i >= buf.shape[1]:
        return
    seg = y[:buf.shape[1] - i]
    buf[0, i:i + len(seg)] += seg * gain * (1 - max(0, pan))
    buf[1, i:i + len(seg)] += seg * gain * (1 + min(0, pan))

def render(notes, chords, beat, bpb, intro_bars, with_lead, flat_unused=None):
    blen = beat * bpb
    total = (intro_bars + len(chords)) * blen + 3.0
    buf = np.zeros((2, int(total * SR) + SR))
    # lead octave: bring the melody around MIDI 67
    meds = np.median([n[2] for n in notes])
    shift = 12 * round((67 - meds) / 12)
    for b in range(intro_bars + len(chords)):
        c = chords[max(0, b - intro_bars)]
        t0 = b * blen
        root = 48 + (c[0] % 12)
        if root > 54: root -= 12
        third = 3 if c[1] == 'm' else 4
        tones = [root + 12, root + 12 + third, root + 12 + 7]
        L, R = pad([root + 12, root + 12 + third, root + 19], blen)
        i = int(t0 * SR); n = min(len(L), buf.shape[1] - i)
        buf[0, i:i + n] += 0.35 * L[:n]; buf[1, i:i + n] += 0.35 * R[:n]
        put(buf, bass(root - 12 + 12, beat * 1.9), t0, 0.5)
        if bpb == 4:
            put(buf, bass(root, beat * 1.9), t0 + 2 * beat, 0.38)
        pat = [0, 1, 2, 3, 2, 1, 2, 3] if bpb == 4 else [0, 1, 2, 3, 2, 1]
        arp = [root + 12, root + 12 + third, root + 19, root + 24]
        steps = int(bpb * 2)
        for k in range(steps):
            note = arp[pat[k % len(pat)]]
            vel = 0.55 if k % 2 == 0 else 0.4
            put(buf, piano(note, beat * 0.6), t0 + k * beat / 2, vel * (0.8 if with_lead else 1.0), pan=0.15 if k % 2 else -0.15)
    if with_lead:
        for s, d, m in notes:
            put(buf, lead(m + shift, min(d, 3.0)), intro_bars * blen + s, 0.55)
    # reverb
    rng = np.random.default_rng(7)
    ir = [rng.standard_normal(int(1.3 * SR)) * np.exp(-np.arange(int(1.3 * SR)) / SR * 3.2) for _ in range(2)]
    wet = np.stack([fftconvolve(buf[c], ir[c])[:buf.shape[1]] for c in range(2)])
    wet *= 0.0016
    out = buf + 0.9 * wet
    fade = int(1.8 * SR)
    end = int(total * SR)
    out = out[:, :end]
    out[:, -fade:] *= np.linspace(1, 0, fade)
    out /= max(1e-9, np.abs(out).max()) / 0.89
    return out

BITRATE = '96k'
def write_mp3(path, y):
    wav = path[:-4] + '.wav'
    with wave.open(wav, 'wb') as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((np.clip(y.T, -1, 1) * 32767).astype('<i2').tobytes())
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', wav, '-codec:a', 'libmp3lame', '-b:a', BITRATE, path], check=True)
    os.remove(wav)

# ---------------------------------------------------------------- pipeline
def make_song(n, recs, outdir, ov, min_by):
    mels = [decode(r) for r in recs]
    cons, used = consensus(mels)
    if cons is None or used < min_by:
        return None
    notes = to_notes(cons)
    if len(notes) < 6:
        return None
    key = ov.get('key')
    if key:
        minor = 1 if key.endswith('m') else 0
        nm = key[:-1] if minor else key
        tonic = SHARP.index(nm) if nm in SHARP else FLAT.index(nm)
    else:
        tonic, minor = detect_key(notes)
    bpm = float(ov.get('bpm') or detect_tempo(notes))
    bpb = int(str(ov.get('meter', '4/4')).split('/')[0])
    beat = 60.0 / bpm
    pickup = float(ov.get('pickup', 0))
    t0 = notes[0][0] - pickup * beat
    for x in notes:
        x[0] = max(0.0, x[0] - t0)
    q = beat / 2
    for x in notes:
        x[0] = round(x[0] / q) * q
        x[1] = max(q, round(x[1] / q) * q)
    for a, b in zip(notes, notes[1:]):
        a[1] = min(a[1], max(q, b[0] - a[0]))
    end = max(a[0] + a[1] for a in notes)
    bars = max(2, int(math.ceil(end / (beat * bpb))))
    chords = harmonise(notes, bars, bpb, beat, tonic, minor)
    flat = (tonic, minor) in FLAT_KEYS
    names = [chord_name(c, flat) for c in chords]
    os.makedirs(os.path.join(outdir, 'zion'), exist_ok=True)
    base = 'zion/%03d' % n
    write_mp3(os.path.join(outdir, base + '-guide.mp3'), render(notes, chords, beat, bpb, 1, True))
    write_mp3(os.path.join(outdir, base + '-inst.mp3'), render(notes, chords, beat, bpb, 1, False))
    return {'guide': base + '-guide.mp3', 'inst': base + '-inst.mp3', 'key': (FLAT if flat else SHARP)[tonic] + ('m' if minor else ''),
            'bpm': round(bpm), 'meter': '%d/4' % bpb, 'by': used, 'chords': names, 'dur': round((bars + 1) * beat * bpb + 3)}

def load_source(a):
    if a.source == 'json':
        return json.load(open(a.file))
    import firebase_admin
    from firebase_admin import credentials, firestore
    firebase_admin.initialize_app(credentials.Certificate(a.key))
    db = firestore.client()
    docs = [d.to_dict() for d in db.collection('song_melodies').where('sec', '==', 'zion').stream()]
    if a.dump:
        json.dump(docs, open(a.dump, 'w'))
    return docs

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--source', choices=['json', 'firestore'], default='json')
    ap.add_argument('--file'); ap.add_argument('--key'); ap.add_argument('--dump')
    ap.add_argument('--out', default='out')
    ap.add_argument('--min-contributors', type=int, default=1)
    ap.add_argument('--overrides', default='overrides.json', help='optional {"3":{"bpm":72,"meter":"3/4","key":"G","pickup":1}}')
    ap.add_argument('--bitrate', default='96k', help='MP3 bitrate; 64k makes files about a third smaller')
    ap.add_argument('--songs', help='only these song numbers, e.g. 3,23')
    a = ap.parse_args()
    global BITRATE
    BITRATE = a.bitrate
    docs = [d for d in load_source(a) if str(d.get('song', '')).startswith('zion:')]
    by = {}
    for d in docs:
        by.setdefault(int(d['song'].split(':')[1]), []).append(d)
    ov = json.load(open(a.overrides)) if os.path.exists(a.overrides) else {}
    only = {int(x) for x in a.songs.split(',')} if a.songs else None
    mpath = os.path.join(a.out, 'manifest.json')
    man = json.load(open(mpath)) if os.path.exists(mpath) else {'v': 1, 'songs': {}}
    os.makedirs(a.out, exist_ok=True)
    for n in sorted(by):
        if only and n not in only:
            continue
        r = make_song(n, by[n], a.out, ov.get(str(n), {}), a.min_contributors)
        print('zion %d: %s' % (n, ('ok, %d melodies, %s %s bpm %d' % (r['by'], r['key'], r['meter'], r['bpm'])) if r else 'skipped (not enough usable melodies)'))
        if r:
            man['songs'][str(n)] = r
    json.dump(man, open(mpath, 'w'), separators=(',', ':'))
    print('manifest:', mpath, len(man['songs']), 'songs')

if __name__ == '__main__':
    main()
