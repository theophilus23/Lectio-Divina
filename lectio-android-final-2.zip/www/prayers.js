/* My Prayer Points page: a personal list of things to pray for, with categories, verses and answered prayers.
   Two synced lists:
     L.coll('prayers')    { id, title, text (details), cat (category id), verses:[{tid,short,b,c,v1,v2,ref,text}],
                            ts (created), ed (last edited by the user), u (last change of any kind, set by coll.put),
                            ans (0|1), at (answered time, 0 if not), testimony,
                            n (times prayed), last (last prayed time, 0 if never) }
     L.coll('prayercats') { id, name, ts }   only the user's own categories; the defaults below are built in.
   A point's `cat` holds a category id, so renaming a custom category never breaks its points.
   Other scripts: if window.Lectio.prayerwall.compose exists, "Post to prayer wall" uses it. */
(function(){
'use strict';
var L=window.Lectio,UI=L.ui,esc=L.esc;
var prayers=L.coll('prayers'),cats=L.coll('prayercats');

/* built-in categories (cannot be deleted or renamed). Add one here to extend. */
var DEFAULT_CATS=[
  {id:'family',name:'Family'},{id:'health',name:'Health'},{id:'church',name:'Church'},{id:'nation',name:'Nation'},
  {id:'work',name:'Work & Study'},{id:'finances',name:'Finances'},{id:'thanks',name:'Thanksgiving'},{id:'others',name:'Others'}
];
var FALLBACK='others';

var S={tab:'pray',cat:'all'};   /* tab: 'pray' (unanswered) | 'ans' (answered); cat: 'all' or a category id */
var el=null;

/* ---------- helpers ---------- */
function allCats(){
  var custom=cats.list().sort(function(a,b){return(a.ts||0)-(b.ts||0)});
  return DEFAULT_CATS.slice(0,-1).concat(custom,[DEFAULT_CATS[DEFAULT_CATS.length-1]]);   /* Others stays last */
}
function catName(id){
  var c=allCats().filter(function(c){return c.id===id})[0];
  return c?c.name:'Others';
}
function isDefault(id){return DEFAULT_CATS.some(function(c){return c.id===id})}
function catOf(p){return allCats().some(function(c){return c.id===p.cat})?p.cat:FALLBACK}
function mkVerse(r){
  return{tid:String(r.tid||''),short:String(r.short||''),b:+r.b||0,c:+r.c||1,v1:+r.v1||0,v2:+r.v2||+r.v1||0,ref:String(r.ref||''),text:String(r.text||'')};
}
function plural(n,w){return n+' '+w+(n===1?'':'s')}
function byTab(ans){return prayers.list().filter(function(p){return !!p.ans===ans})}

/* ---------- share text ---------- */
function pointText(p){
  var t=[p.title,'Prayer point · '+catName(catOf(p)),''];
  if(p.text)t.push(p.text,'');
  (p.verses||[]).forEach(function(v){t.push(v.ref+(v.short?' ('+v.short+')':'')+' '+v.text)});
  if((p.verses||[]).length)t.push('');
  if(p.ans){
    t.push('ANSWERED on '+UI.fmt.date(p.at||p.u));
    if(p.testimony)t.push(p.testimony);
    t.push('');
  }
  t.push('Shared from Lectio');
  return t.join('\n');
}

/* ---------- page ---------- */
function render(){
  var open=byTab(false),done=byTab(true),list=S.tab==='ans'?done:open;
  var h='<div class="head"><div class="eyebrow">Pray</div><h1>Prayer points</h1><p>Write down what you are praying for, and come back to give thanks when God answers.</p></div>';
  h+='<div class="seg p-seg"><button type="button" data-tab="pray" aria-pressed="'+(S.tab==='pray')+'">Praying ('+open.length+')</button>'+
     '<button type="button" data-tab="ans" aria-pressed="'+(S.tab==='ans')+'">Answered ('+done.length+')</button></div>';
  /* category chips with the number of points in this tab */
  var count={};list.forEach(function(p){var c=catOf(p);count[c]=(count[c]||0)+1});
  if(S.cat!=='all'&&!allCats().some(function(c){return c.id===S.cat}))S.cat='all';
  h+='<div class="p-tabs"><button type="button" class="ptab" data-cat="all" aria-pressed="'+(S.cat==='all')+'">All ('+list.length+')</button>'+
    allCats().map(function(c){
      return'<button type="button" class="ptab" data-cat="'+esc(c.id)+'" aria-pressed="'+(S.cat===c.id)+'">'+esc(c.name)+(count[c.id]?' ('+count[c.id]+')':'')+'</button>';
    }).join('')+'<button type="button" class="ptab p-manage" data-act="cats">Categories…</button></div>';
  var shown=list.filter(function(p){return S.cat==='all'||catOf(p)===S.cat})
    .sort(function(a,b){return S.tab==='ans'?(b.at||0)-(a.at||0):(b.u||0)-(a.u||0)});
  h+='<div class="list p-list">';
  if(!shown.length){
    if(list.length)h+='<div class="empty">Nothing in this category yet.</div>';
    else if(S.tab==='ans')h+='<div class="empty">No answered prayers yet.<br>When God answers one, mark it answered and it will be kept here to encourage you.</div>';
    else h+='<div class="empty">No prayer points yet.<br>Tap the + button to write down something to pray about.</div>';
  }else h+=shown.map(card).join('');
  h+='</div>'+(S.tab==='pray'?'<form class="p-quick" id="pQuick"><span class="p-plus">'+UI.icon('plus',20)+'</span><input id="pQ" maxlength="120" placeholder="Add prayer…" autocomplete="off"></form>':'')+(S.tab==='ans'?'':'<button type="button" class="fab" data-act="new" aria-label="Add prayer point">'+UI.icon('plus',26)+'</button>');
  el.innerHTML=h;
}
var EMOJI=['🙏','❤️','🙌','😇','💯','🕊️','✝️','🔥','😢','🙂','🤗','😷'];
function card(p){
  var h='<div class="li p-card'+(p.ans?' p-ans':'')+'" data-id="'+esc(p.id)+'">';
  h+='<div class="p-top"><button type="button" class="p-circ" data-do="'+(p.ans?'unans':'ans')+'" aria-pressed="'+(!!p.ans)+'" aria-label="'+(p.ans?'Mark as still praying':'Mark as answered')+'">'+(p.ans?UI.icon('check',16):'')+'</button>';
  h+='<div class="p-main"><div class="t">'+esc(p.title)+'</div><span class="tag'+(p.ans?' green':'')+'">'+esc(catName(catOf(p)))+'</span></div>';
  h+='<button type="button" class="iconbtn" data-do="more" aria-label="More">'+UI.icon('more',20)+'</button></div>';
  if(p.text)h+='<div class="body">'+esc(p.text)+'</div>';
  (p.verses||[]).forEach(function(v){
    h+='<div class="vq"><div class="r">'+esc(v.ref)+(v.short?' · '+esc(v.short):'')+'</div><div class="x">'+esc(v.text)+'</div></div>';
  });
  if(p.ans){
    h+='<div class="p-testi"><b>Answered '+esc(UI.fmt.dt(p.at||p.u))+'</b>'+(p.testimony?'<div>'+esc(p.testimony)+'</div>':'')+'</div>';
  }
  var rx=p.rx||{};
  h+='<div class="p-rx">'+Object.keys(rx).filter(function(k){return rx[k]>0}).map(function(k){return'<button type="button" class="chip" data-rx="'+esc(k)+'">'+esc(k)+' '+rx[k]+'</button>'}).join('')+
    '<button type="button" class="chip p-addrx" data-do="react" aria-label="Add reaction">'+UI.icon('plus',14)+'</button></div>';
  h+='<div class="meta">Added '+esc(UI.fmt.dt(p.ts||p.u))+(p.ed&&p.ed-(p.ts||0)>60000?' · Edited '+esc(UI.fmt.dt(p.ed)):'')+
    (p.n?' · Prayed '+plural(p.n,'time')+', last '+esc(UI.fmt.dt(p.last)):'')+'</div></div>';
  return h;
}
function react(p,e){
  var rx=Object.assign({},p.rx||{});rx[e]=(rx[e]||0)+1;save(p,{rx:rx});render();
}
function pickReaction(p){
  var m=UI.modal({title:'React',sheet:true,body:'<div class="p-emoji">'+EMOJI.map(function(e){return'<button type="button" data-e="'+e+'">'+e+'</button>'}).join('')+'</div>'});
  m.body.addEventListener('click',function(ev){var b=ev.target.closest('[data-e]');if(!b)return;m.close();react(p,b.dataset.e)});
}
function moreMenu(p){
  UI.actionSheet({title:p.title,items:[
    {label:'Prayed'+(p.n?' ('+p.n+')':''),icon:'pray',on:function(){doAction(p.id,'pray')}},
    {label:'Share',icon:'share',on:function(){doAction(p.id,'share')}},
    {label:'Edit',icon:'edit',on:function(){doAction(p.id,'edit')}},
    {label:'Delete',icon:'trash',danger:true,on:function(){doAction(p.id,'del')}}
  ]});
}

/* ---------- actions on one point ---------- */
function save(p,changes){return prayers.put(Object.assign({},p,changes))}
function doAction(id,what){
  var p=prayers.get(id);if(!p)return;
  if(what==='pray'){save(p,{n:(p.n||0)+1,last:Date.now()});L.toast('Prayed. Amen.')}
  else if(what==='ans'){
    UI.prompt({title:'Thank God!',label:'Testimony (optional): how did God answer?',multiline:true,ok:'Mark answered',allowEmpty:true}).then(function(t){
      if(t==null)return;
      save(p,{ans:1,at:Date.now(),testimony:t});S.tab='ans';render();L.toast('Marked as answered');
    });return;
  }
  else if(what==='unans'){save(p,{ans:0,at:0,testimony:''});S.tab='pray';L.toast('Back in your praying list')}
  else if(what==='edit'){openEditor(p);return}
  else if(what==='share')sharePoint(p);
  else if(what==='del'){
    UI.confirm('Delete “'+p.title+'”? This cannot be undone.',{ok:'Delete',danger:true}).then(function(ok){
      if(ok){prayers.remove(id);render();L.toast('Deleted')}
    });return;
  }
  render();
}
function sharePoint(p){
  var items=[
    {label:'Share',icon:'share',on:function(){UI.share({title:p.title,text:pointText(p)})}},
    {label:'Copy text',icon:'copy',on:function(){UI.copy(pointText(p)).then(function(ok){L.toast(ok?'Copied':'Could not copy')})}}
  ];
  var pw=window.Lectio.prayerwall;
  if(pw&&typeof pw.compose==='function'){
    items.push({label:'Post to prayer wall',icon:'people',on:function(){
      pw.compose({title:p.title,text:[p.text].concat((p.verses||[]).map(function(v){return v.ref+' '+v.text})).filter(Boolean).join('\n\n'),cat:catName(catOf(p))});
    }});
  }
  UI.actionSheet({title:'Share prayer point',items:items});
}

/* ---------- add / edit (one dialog) ---------- */
function openEditor(p){
  var d={title:p?p.title:'',text:p?p.text||'':'',cat:p?catOf(p):(S.cat!=='all'?S.cat:'family'),verses:p?(p.verses||[]).slice():[]};
  var m=UI.modal({title:p?'Edit prayer point':'New prayer point',wide:true,body:'<div class="p-form"></div>',actions:[
    {label:'Cancel'},
    {label:'Save',kind:'main',on:function(){
      d.title=m.body.querySelector('#pTitle').value.trim();
      d.text=m.body.querySelector('#pText').value.trim();
      d.cat=m.body.querySelector('#pCat').value;
      if(!d.title){L.toast('Give it a title first');return false}
      var now=Date.now();
      if(p)save(p,{title:d.title,text:d.text,cat:d.cat,verses:d.verses,ed:now});
      else prayers.put({title:d.title,text:d.text,cat:d.cat,verses:d.verses,ts:now,ed:now,ans:0,at:0,testimony:'',n:0,last:0});
      S.tab=p&&p.ans?'ans':'pray';render();L.toast('Saved');
    }}
  ]});
  var form=m.body.querySelector('.p-form');
  function draw(){
    /* keep what was typed while the verse list is redrawn */
    var t=form.querySelector('#pTitle'),x=form.querySelector('#pText'),c=form.querySelector('#pCat');
    if(t)d.title=t.value;if(x)d.text=x.value;if(c)d.cat=c.value;
    form.innerHTML='<label class="field">Title<input type="text" id="pTitle" maxlength="120" placeholder="e.g. Healing for my mother" value="'+esc(d.title)+'"></label>'+
      '<label class="field">Details (optional)<textarea class="ta" id="pText" rows="4" maxlength="2000" placeholder="What exactly are you praying for?">'+esc(d.text)+'</textarea></label>'+
      '<label class="field">Category<select id="pCat">'+allCats().map(function(c){return'<option value="'+esc(c.id)+'"'+(c.id===d.cat?' selected':'')+'>'+esc(c.name)+'</option>'}).join('')+'</select></label>'+
      '<div class="sec-t">Verses (optional)</div>'+
      d.verses.map(function(v,i){
        return'<div class="p-vrow"><div class="vq"><div class="r">'+esc(v.ref)+(v.short?' · '+esc(v.short):'')+'</div><div class="x">'+esc(v.text)+'</div></div>'+
          '<button type="button" class="iconbtn" data-rmv="'+i+'" aria-label="Remove verse">'+UI.icon('x',18)+'</button></div>';
      }).join('')+
      '<button type="button" class="btn p-addv" data-addv="1">'+UI.icon('plus',16)+' Add verse</button>';
  }
  form.addEventListener('click',function(e){
    var b=e.target.closest('button');if(!b)return;
    if(b.dataset.rmv!=null){draw();d.verses.splice(+b.dataset.rmv,1);draw()}
    else if(b.dataset.addv){
      draw();
      L.bible.pick({verses:true,place:'prayers'}).then(function(r){if(r){d.verses.push(mkVerse(r));draw()}});
    }
  });
  draw();
  if(!p)setTimeout(function(){var t=form.querySelector('#pTitle');if(t)t.focus()},80);
}

/* ---------- manage categories ---------- */
function openCats(){
  var m=UI.modal({title:'Categories',body:'<div class="p-cats"></div>',actions:[{label:'Done',kind:'main'}],onClose:render});
  var box=m.body.querySelector('.p-cats');
  function draw(){
    box.innerHTML='<p class="mtext">Your own categories can be renamed or deleted. If you delete one, its prayer points move to Others.</p>'+
      allCats().map(function(c){
        var n=prayers.list().filter(function(p){return catOf(p)===c.id}).length;
        return'<div class="p-crow"><div class="p-cname">'+esc(c.name)+'<small>'+plural(n,'point')+(isDefault(c.id)?' · built in':'')+'</small></div>'+
          (isDefault(c.id)?'':'<button type="button" class="iconbtn" data-ren="'+esc(c.id)+'" aria-label="Rename">'+UI.icon('edit',18)+'</button>'+
          '<button type="button" class="iconbtn" data-del="'+esc(c.id)+'" aria-label="Delete category">'+UI.icon('trash',18)+'</button>')+'</div>';
      }).join('')+'<button type="button" class="btn main p-addc" data-new="1">'+UI.icon('plus',16)+' New category</button>';
  }
  function nameTaken(n,exceptId){return allCats().some(function(c){return c.id!==exceptId&&c.name.toLowerCase()===n.toLowerCase()})}
  box.addEventListener('click',function(e){
    var b=e.target.closest('button');if(!b)return;
    if(b.dataset.new){
      UI.prompt({title:'New category',label:'Name',ok:'Create',max:30}).then(function(n){
        if(n==null)return;
        if(nameTaken(n)){L.toast('That category already exists');return}
        cats.put({name:n,ts:Date.now()});draw();
      });
    }else if(b.dataset.ren){
      var c=cats.get(b.dataset.ren);if(!c)return;
      UI.prompt({title:'Rename category',label:'Name',value:c.name,ok:'Rename',max:30}).then(function(n){
        if(n==null)return;
        if(nameTaken(n,c.id)){L.toast('That category already exists');return}
        cats.put(Object.assign({},c,{name:n}));draw();
      });
    }else if(b.dataset.del){
      var c2=cats.get(b.dataset.del);if(!c2)return;
      UI.confirm('Delete “'+c2.name+'”? Its prayer points will move to Others.',{ok:'Delete',danger:true}).then(function(ok){
        if(!ok)return;
        prayers.list().filter(function(p){return p.cat===c2.id}).forEach(function(p){save(p,{cat:FALLBACK})});
        cats.remove(c2.id);if(S.cat===c2.id)S.cat='all';draw();
      });
    }
  });
  draw();
}

/* ---------- register ---------- */
el=L.registerView({
  id:'mypray',title:'Prayer points',
  menu:{label:'Prayer points',icon:'pray',group:'pray',order:10},
  show:function(){render()}
});
el.addEventListener('click',function(e){
  var t=e.target.closest('button');if(!t||!el.contains(t))return;
  if(t.dataset.tab){S.tab=t.dataset.tab;S.cat='all';render();return}
  if(t.dataset.cat){S.cat=t.dataset.cat;render();return}
  if(t.dataset.act==='new'){openEditor(null);return}
  if(t.dataset.act==='cats'){openCats();return}
  if(t.dataset.rx){var c0=t.closest('.p-card'),p0=c0&&prayers.get(c0.dataset.id);if(p0)react(p0,t.dataset.rx);return}
  if(t.dataset.do){var c=t.closest('.p-card'),p1=c&&prayers.get(c.dataset.id);if(!p1)return;
    if(t.dataset.do==='more')moreMenu(p1);else if(t.dataset.do==='react')pickReaction(p1);else doAction(c.dataset.id,t.dataset.do)}
});
el.addEventListener('submit',function(e){
  if(e.target.id!=='pQuick')return;e.preventDefault();
  var i=e.target.querySelector('#pQ'),v=i.value.trim();if(!v)return;
  var now=Date.now();
  prayers.put({title:v,text:'',cat:S.cat!=='all'?S.cat:'family',verses:[],ts:now,ed:now,ans:0,at:0,testimony:'',n:0,last:0});
  render();var q=el.querySelector('#pQ');if(q)q.focus();
});
/* refresh when another phone changes something (not while a dialog is open) */
function refresh(){if(L.view==='mypray'&&!document.body.classList.contains('modalopen'))render()}
prayers.on(function(src){if(src==='sync')refresh()});
cats.on(function(src){if(src==='sync')refresh()});
})();
