#!/usr/bin/env python3
"""Upload the out/ folder (MP3s + manifest.json) to a Cloudflare R2 bucket. Unchanged files are skipped.
Set R2_ACCOUNT_ID, R2_ACCESS_KEY_ID, R2_SECRET_ACCESS_KEY, R2_BUCKET first.   python3 upload_r2.py --out out"""
import argparse, hashlib, os, sys
import boto3

def md5(p):
    h = hashlib.md5()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--out', default='out'); a = ap.parse_args()
    try:
        acc, kid, sec, bucket = [os.environ[k] for k in ('R2_ACCOUNT_ID', 'R2_ACCESS_KEY_ID', 'R2_SECRET_ACCESS_KEY', 'R2_BUCKET')]
    except KeyError as e:
        sys.exit('missing environment variable ' + str(e))
    s3 = boto3.client('s3', endpoint_url='https://%s.r2.cloudflarestorage.com' % acc, aws_access_key_id=kid, aws_secret_access_key=sec, region_name='auto')
    files = []
    for root, _, fs in os.walk(a.out):
        for f in fs:
            if f.endswith(('.mp3', '.json')):
                files.append(os.path.join(root, f))
    files.sort(key=lambda p: p.endswith('manifest.json'))      # manifest last, so it never points at missing files
    up = skip = 0
    for p in files:
        key = os.path.relpath(p, a.out).replace(os.sep, '/')
        try:
            etag = s3.head_object(Bucket=bucket, Key=key)['ETag'].strip('"')
        except Exception:
            etag = None
        if etag == md5(p):
            skip += 1; continue
        mp3 = key.endswith('.mp3')
        s3.upload_file(p, bucket, key, ExtraArgs={'ContentType': 'audio/mpeg' if mp3 else 'application/json',
                       'CacheControl': 'public, max-age=31536000, immutable' if mp3 else 'public, max-age=300'})
        up += 1; print('uploaded', key)
    print('done: %d uploaded, %d unchanged' % (up, skip))

if __name__ == '__main__':
    main()
