import sys; sys.path.insert(0,'test')
from harness import app
with app(width=360,height=740) as (page,base):
    page.goto(base); page.wait_for_timeout(1200)
    page.screenshot(path='/tmp/s_home.png')
    page.evaluate("Lectio.go('settings')"); page.wait_for_timeout(800)
    page.screenshot(path='/tmp/s_set.png')
    print(page.errors)
