/* Saved verses page: verses saved from Today or the Bible reader, plus highlights.
   Data: L.coll('saved') items {id, src:'today'|'bible', ref, b,c,v1,v2, tx:[{s,t}], ts}
         L.coll('hl')    items {id, b,c,v, col:'y|g|b|p|o|v', tx:[{s,t}], ts} */
(function(){
'use strict';
var L=window.Lectio,UI=L.ui,esc=L.esc;
var savedC=L.coll('saved'),hlC=L.coll('hl');
var COLS=['y','g','b','p','o','v','r','t','l','c','m','k'],COLNAME={y:'Yellow',g:'Green',b:'Blue',p:'Pink',o:'Orange',v:'Violet',r:'Red',t:'Teal',l:'Lime',c:'Sky',m:'Magenta',k:'Grey'};
var st={tab:'all',col:'',q:''},el=null;

el=L.registerView({
  id:'saved',title:'Saved verses',
  menu:{label:'Saved verses',icon:'bookmark',group:'study',order:5},
  show:function(e){el=e;st.q="";st.focus=false;render()}
});

function refOf(it){return it.ref||(it.b!=null?L.bible.refName(it.b,it.c,it.v1||it.v,it.v2||it.v1||it.v):'')}
/* book/chapter/verse for "Open in reader", from the stored numbers or by parsing the reference text */
function locate(it){
  if(it.b!=null&&it.c)return{b:it.b,c:it.c,v:it.v1||it.v||0};
  var p=L.bible.parseRef(it.ref||'');
  return p?{b:p.b,c:p.c,v:p.v1||0}:null;
}
function txHtml(it){
  return(it.tx||[]).map(function(x){return'<p class="sv-tx"><span class="tag">'+esc(x.s)+'</span>'+esc(x.t)+'</p>'}).join('');
}
function plain(it){
  var tx=it.tx||[],ref=refOf(it);
  if(tx.length===1)return ref+' ('+tx[0].s+')\n'+tx[0].t;
  return ref+'\n'+tx.map(function(x){return'('+x.s+') '+x.t}).join('\n');
}
function match(it){
  if(!st.q)return true;
  var s=(refOf(it)+' '+(it.tx||[]).map(function(x){return x.t}).join(' ')).toLowerCase();
  return s.indexOf(st.q.toLowerCase())>-1;
}
function savedList(){
  return savedC.list().filter(function(i){return(st.tab==='all'||i.src===(st.tab==='today'?'today':'bible'))&&match(i)})
    .sort(function(a,b){return(b.ts||0)-(a.ts||0)});
}
function hlList(){
  return hlC.list().filter(function(i){return(!st.col||i.col===st.col)&&match(Object.assign({ref:L.bible.refName(i.b,i.c,i.v,i.v)},i))})
    .sort(function(a,b){return(b.ts||0)-(a.ts||0)});
}

function vtags(it){return(it.tx||[]).map(function(x){return x.s}).filter(function(v,n,a){return v&&a.indexOf(v)===n}).map(function(v){return'<span class="tag">'+esc(v)+'</span>'}).join('')}
var DELB='<button type="button" class="iconbtn jdel" data-a="del" aria-label="Remove">'+UI.icon('trash',18)+'</button>';
function savedCard(it){
  return'<div class="li sv-card" data-id="'+esc(it.id)+'"><div class="row2"><span class="sv-ref">'+esc(refOf(it))+'</span>'+vtags(it)+DELB+'</div>'
    +txHtml(it).replace(/<span class="tag">[^<]*<\/span>/g,'')+'<div class="meta">'+esc(UI.fmt.dt(it.ts))+'</div>'
    +'<div class="acts"><button type="button" class="iconbtn" data-a="copy" aria-label="Copy with reference">'+UI.icon('copy',18)+'</button>'
    +'<button type="button" class="iconbtn" data-a="share" aria-label="Share">'+UI.icon('share',18)+'</button></div></div>';
}
function hlCard(it){
  return'<div class="li hlcard sv-card hl-'+esc(it.col)+'" data-id="'+esc(it.id)+'"><div class="row2"><span class="sv-ref">'+esc(L.bible.refName(it.b,it.c,it.v,it.v))+'</span>'+vtags(it)+'<span class="tag">'+(COLNAME[it.col]||'Highlight')+'</span>'+DELB+'</div>'
    +txHtml(it).replace(/<span class="tag">[^<]*<\/span>/g,'')+'<div class="meta">'+esc(UI.fmt.dt(it.ts))+'</div>'
    +'<div class="acts"><button type="button" class="iconbtn" data-a="color" aria-label="Change colour">'+UI.icon('highlight',18)+'</button>'
    +'<button type="button" class="iconbtn" data-a="copy" aria-label="Copy with reference">'+UI.icon('copy',18)+'</button>'
    +'<button type="button" class="iconbtn" data-a="share" aria-label="Share">'+UI.icon('share',18)+'</button></div></div>';
}

function render(){
  if(!el||el.hidden)return;
  var all=savedC.list(),nT=all.filter(function(i){return i.src==='today'}).length,nB=all.length-nT,nH=hlC.list().length;
  var tabs=[['all','All saved',all.length],['today',"Today's",nT],['bible','Bible',nB],['hl','Highlights',nH]];
  var h='<div class="head"><div class="eyebrow">Your collection</div><h1>Saved verses</h1></div>'
    +'<div class="seg stabs" role="group" aria-label="Show">'+tabs.map(function(t){return'<button type="button" data-tab="'+t[0]+'" aria-pressed="'+(st.tab===t[0])+'">'+t[1]+' ('+t[2]+')</button>'}).join('')+'</div>'
    +'<div class="sfilter"><input type="search" id="svq" placeholder="Search saved text or reference" value="'+esc(st.q)+'" aria-label="Search"></div>';
  if(st.tab==='hl'){
    h+='<div class="hlfilter" role="group" aria-label="Colour"><button type="button" class="chip" data-col="" aria-pressed="'+(!st.col)+'">All</button>'
      +COLS.map(function(c){return'<button type="button" class="dot hl-'+c+'" data-col="'+c+'" aria-pressed="'+(st.col===c)+'" aria-label="'+COLNAME[c]+'"></button>'}).join('')+'</div>';
  }
  var items=st.tab==='hl'?hlList():savedList();
  h+='<div class="list" id="svList">'+(items.length?items.map(st.tab==='hl'?hlCard:savedCard).join(''):emptyMsg())+'</div>';
  el.innerHTML=h;
  /* keep typing focus after a re-render */
  if(st.focus){var i=el.querySelector('#svq');i.focus();i.setSelectionRange(i.value.length,i.value.length)}
}
function emptyMsg(){
  if(st.q||st.col)return'<div class="empty">Nothing matches.</div>';
  if(st.tab==='hl')return'<div class="empty">No highlights yet.<br>Press and hold a verse in the reader, then choose a colour.</div>';
  return'<div class="empty">No saved verses yet.<br>Tap Save on the Today page, or select a verse in the reader and tap Save.</div>';
}
function item(id){return st.tab==='hl'?hlC.get(id):savedC.get(id)}

el.addEventListener('input',function(e){
  if(e.target.id!=='svq')return;
  st.q=e.target.value.trim();st.focus=true;
  var s=el.querySelector('#svList'),items=st.tab==='hl'?hlList():savedList();
  s.innerHTML=items.length?items.map(st.tab==='hl'?hlCard:savedCard).join(''):emptyMsg();   /* only the list repaints, so the box keeps focus */
});
el.addEventListener('click',function(e){
  var b=e.target.closest('[data-tab],[data-col],[data-a]');
  if(!b){var cd=e.target.closest('.sv-card');if(!cd)return;b={dataset:{a:'open'},closest:function(q){return cd.closest(q)}}}
  st.focus=false;
  if(b.dataset.tab){st.tab=b.dataset.tab;st.col='';render();return}
  if(b.dataset.col!==undefined&&!b.dataset.a){st.col=b.dataset.col;render();return}
  var li=b.closest('[data-id]'),it=li&&item(li.dataset.id);if(!it)return;
  var a=b.dataset.a,hl=st.tab==='hl';
  var text=hl?plain(Object.assign({ref:L.bible.refName(it.b,it.c,it.v,it.v)},it)):plain(it);
  if(a==='open'){var loc=hl?{b:it.b,c:it.c,v:it.v}:locate(it);if(loc){var sh=it.tx&&it.tx[0]&&it.tx[0].s,vv=sh&&L.bible.versions().filter(function(x){return x.short===sh})[0];L.openReader(loc.b,loc.c,loc.v,vv&&vv.id)}}
  else if(a==='copy')UI.copy(text).then(function(ok){UI.toast(ok?'Copied with reference':'Could not copy')});
  else if(a==='share')UI.share({title:text.split('\n')[0],text:text+'\n\nShared from Lectio'});
  else if(a==='del')UI.confirm(hl?'Remove this highlight?':'Remove this saved verse?',{ok:'Remove',danger:true}).then(function(y){
    if(y){(hl?hlC:savedC).remove(it.id);UI.toast('Removed')}
  });
  else if(a==='color')UI.actionSheet({title:'Highlight colour',items:COLS.map(function(c){
    return{label:COLNAME[c],on:function(){hlC.put(Object.assign({},it,{col:c}))}};
  })});
});
savedC.on(render);hlC.on(render);
})();
