import sys; sys.path.insert(0,'test')
from harness import app
with app(width=360,height=740) as (page,base):
    page.goto(base); page.wait_for_timeout(700)
    page.evaluate("Lectio.openReader(42,3)"); page.wait_for_timeout(700)
    page.click('.vs[data-v="1"]'); page.wait_for_timeout(200)
    if not page.evaluate("document.body.classList.contains('selecting')"):
        page.evaluate("document.querySelector('.vs[data-v=\"1\"]').dispatchEvent(new PointerEvent('pointerdown',{bubbles:true}))"); page.wait_for_timeout(700)
    print('selecting',page.evaluate("document.body.classList.contains('selecting')"))
    page.screenshot(path='/tmp/l0.png')
    page.click('[data-vb=look]'); page.wait_for_timeout(300); page.click('.chip[data-w]'); page.wait_for_timeout(1500)
    print('view',page.evaluate("Lectio.view"),'results',page.evaluate("document.querySelectorAll('#sout *').length>0"))
    page.screenshot(path='/tmp/l1.png'); print(page.errors)
