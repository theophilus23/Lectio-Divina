/* Profile page: picture, name, streak / progress / completed times, saved items by type, and the account (sign in, sync). */
(function(){
'use strict';
var L=window.Lectio,UI=L.ui,esc=L.esc,AV='lectio-avatar';
var S={tab:'activity',f:'all'};
var el=null;
function avatar(){try{return localStorage.getItem(AV)||''}catch(e){return''}}
function dayKey(d){return d.getFullYear()+'-'+('0'+(d.getMonth()+1)).slice(-2)+'-'+('0'+d.getDate()).slice(-2)}
function activity(){try{return JSON.parse(L.lsGet('lectio-activity')||'{}')}catch(e){return{}}}
function streaks(){
  var a=activity(),d=new Date(),cur=0,best=0,run=0,i;
  /* current streak: today may still be empty */
  var t=new Date(d);if(!a[dayKey(t)])t.setDate(t.getDate()-1);
  while(a[dayKey(t)]){cur++;t.setDate(t.getDate()-1)}
  var keys=Object.keys(a).sort(),prev=null;
  keys.forEach(function(k){
    var dt=new Date(k+'T00:00:00');
    if(prev&&Math.round((dt-prev)/864e5)===1)run++;else run=1;
    if(run>best)best=run;prev=dt;
  });
  return{cur:cur,best:best,days:keys.length};
}
function initials(n){return(n||'R').trim().split(/\s+/).map(function(w){return w[0]}).slice(0,2).join('').toUpperCase()}
function head(){
  var n=L.readerName(),img=avatar(),t=L.progress.totals(),pct=Math.round(t.ch/1189*100),st=streaks();
  return'<div class="pf-head"><div class="pf-av"'+(img?' style="background-image:url('+img+')"':'')+'>'+(img?'':'<span>'+esc(initials(n))+'</span>')+'<button type="button" class="pf-cam" data-a="pic" aria-label="Change picture">'+UI.icon('image',16)+'</button></div>'+
   '<div class="pf-name">'+esc(n)+'</div><div class="pf-sub">'+(L.user&&!L.user.isAnonymous?esc(L.user.email||''):'Guest on this phone')+'</div>'+
   '<div class="pf-stats"><div><b>'+st.cur+'</b><span>Day streak</span></div><div><b>'+pct+'%</b><span>Bible read</span></div><div><b>'+L.rounds+'</b><span>Completed</span></div></div></div>';
}
function tabs(){
  return'<div class="pf-tabs">'+[['activity','Activity'],['saved','Saved'],['profile','Profile']].map(function(x){return'<button type="button" data-tab="'+x[0]+'" aria-pressed="'+(S.tab===x[0])+'">'+x[1]+'</button>'}).join('')+'</div>';
}
function actTab(){
  var t=L.progress.totals(),st=streaks(),a=activity(),h='';
  var bars='',d=new Date(),mx=1,i,days=[];
  for(i=6;i>=0;i--){var x=new Date(d);x.setDate(x.getDate()-i);var v=a[dayKey(x)]||0;days.push([x,v]);if(v>mx)mx=v}
  days.forEach(function(p){bars+='<div class="pf-bar"><i style="height:'+Math.round(p[1]/mx*100)+'%"'+(p[1]?'':' class="z"')+'></i><span>'+'SMTWTFS'[p[0].getDay()]+'</span></div>'});
  h+='<div class="pf-card"><div class="pf-row"><span>Current streak</span><b>'+st.cur+(st.cur===1?' day':' days')+'</b></div><div class="pf-row"><span>Best streak</span><b>'+st.best+(st.best===1?' day':' days')+'</b></div><div class="pf-row"><span>Days read</span><b>'+st.days+'</b></div></div>';
  h+='<div class="pf-card"><div class="pf-t">This week</div><div class="pf-bars">'+bars+'</div></div>';
  h+='<div class="pf-card"><div class="pf-t">Progress</div><div class="pf-row"><span>Chapters read</span><b>'+t.ch+' of 1189</b></div><div class="pf-row"><span>Books complete</span><b>'+t.bk+' of 66</b></div><div class="pf-prog"><i style="width:'+Math.round(t.ch/1189*100)+'%"></i></div></div>';
  var hist=L.history.list().filter(function(i){return i&&i.n}).sort(function(a,b){return b.n-a.n});
  h+='<div class="pf-card"><div class="pf-t">Completed Bible</div>'+(hist.length?hist.map(function(r){return'<div class="pf-row"><span>Round '+r.n+(r.s?' · started '+esc(UI.fmt.date(r.s)):'')+'</span><b>'+(r.e?esc(UI.fmt.date(r.e)):'')+'</b></div>'}).join(''):'<p class="muted" style="margin:6px 0 0">'+(L.rounds?'Bible completed '+L.rounds+' time'+(L.rounds===1?'':'s')+'.':'Finish the last chapter to complete your first round.')+'</p>')+'</div>';
  return h;
}
function items(){
  var out=[],f=S.f;
  function vt(i){return(i.tx||[]).map(function(x){return x.t}).join(' ')}
  if(f==='all'||f==='notes')L.coll('notes').list().forEach(function(n){out.push({k:'Note',ts:n.u||n.ts||0,t:n.title||'Untitled note',x:((n.blocks||[]).filter(function(b){return b.t==='text'})[0]||{}).x||'',go:function(){L.go('notes')}})});
  if(f==='all'||f==='saved')L.coll('saved').list().forEach(function(i){var ref=i.ref||(i.b!=null?L.bible.refName(i.b,i.c,i.v1,i.v2):'');out.push({k:'Saved',ts:i.ts||0,t:ref,x:vt(i),go:function(){L.openReader(i.b,i.c,i.v1)}})});
  if(f==='all'||f==='hl')L.coll('hl').list().forEach(function(i){out.push({k:'Highlight',ts:i.ts||0,t:L.bible.refName(i.b,i.c,i.v,i.v),x:vt(i),go:function(){L.openReader(i.b,i.c,i.v)}})});
  if(f==='all'||f==='plans')L.coll('plans').list().forEach(function(p){out.push({k:'Plan',ts:p.made||p.start||0,t:p.name||'Reading plan',x:(p.days||0)+' days',go:function(){L.go('plans')}})});
  return out.sort(function(a,b){return b.ts-a.ts});
}
function savedTab(){
  var F=[['all','All'],['hl','Highlights'],['notes','Notes'],['saved','Saved verses'],['plans','Plans']];
  var h='<div class="chips hscroll pf-chips">'+F.map(function(x){return'<button type="button" class="chip" data-f="'+x[0]+'" aria-pressed="'+(S.f===x[0])+'">'+x[1]+'</button>'}).join('')+'</div>';
  S.list=items();
  h+=S.list.length?'<div class="pf-list">'+S.list.map(function(i,n){return'<button type="button" class="pf-it" data-it="'+n+'"><div class="pf-ih"><b>'+esc(i.t)+'</b><span class="tag">'+i.k+'</span></div>'+(i.x?'<p>'+esc(i.x.slice(0,140))+'</p>':'')+'</button>'}).join('')+'</div>':'<p class="empty">Nothing here yet.</p>';
  return h;
}
function profTab(){
  var u=L.user,signed=u&&!u.isAnonymous,h='<div class="pf-card"><label class="field">Name<input id="pfName" type="text" maxlength="40" value="'+esc(L.displayName())+'" placeholder="Your name"></label><div class="row"><button type="button" class="btn main" data-a="savename">Save name</button></div></div>';
  if(!L.fb.on)h+='<div class="pf-card"><p class="muted" style="margin:0">Cloud sign-in is off. Your progress, notes and prayers are saved on this phone.</p></div>';
  else if(!signed)h+='<div class="pf-card"><p class="muted">Sign in to back up your progress, notes and prayers and read on any device.</p><div class="row"><button type="button" class="btn main" data-a="signin">Sign in</button><button type="button" class="btn" data-a="signup">Create account</button></div></div>';
  else h+='<div class="pf-card"><p class="muted" style="margin:0 0 10px">'+esc(u.email||'')+'</p><div class="row"><button type="button" class="btn" data-a="sync">Sync now</button><button type="button" class="btn" data-a="signout">Sign out</button></div></div>';
  if(avatar())h+='<button type="button" class="linkbtn" data-a="rmpic">Remove picture</button>';
  return h;
}
function render(){
  if(!el)return;
  el.innerHTML=head()+tabs()+'<div class="pf-body">'+(S.tab==='activity'?actTab():S.tab==='saved'?savedTab():profTab())+'</div>';
}
function pick(){
  var inp=document.createElement('input');inp.type='file';inp.accept='image/*';
  inp.onchange=function(){
    var f=inp.files&&inp.files[0];if(!f)return;
    var u=URL.createObjectURL(f),im=new Image();
    im.onload=function(){
      var s=256,c=document.createElement('canvas');c.width=c.height=s;
      var m=Math.min(im.naturalWidth,im.naturalHeight),sx=(im.naturalWidth-m)/2,sy=(im.naturalHeight-m)/2;
      c.getContext('2d').drawImage(im,sx,sy,m,m,0,0,s,s);URL.revokeObjectURL(u);
      try{localStorage.setItem(AV,c.toDataURL('image/jpeg',.85))}catch(e){L.toast('Could not save the picture')}
      render();
    };
    im.onerror=function(){URL.revokeObjectURL(u);L.toast('Choose an image file')};
    im.src=u;
  };
  inp.click();
}
el=L.registerView({id:'profile',title:'Profile',menu:{label:'Profile',icon:'people',group:'app',order:5},show:function(){S.tab='activity';render()}});
el.addEventListener('click',function(e){
  var b=e.target.closest('button');if(!b)return;
  if(b.dataset.tab){S.tab=b.dataset.tab;render();return}
  if(b.dataset.f){S.f=b.dataset.f;render();return}
  if(b.dataset.it){var it=S.list[+b.dataset.it];if(it)it.go();return}
  var a=b.dataset.a;if(!a)return;
  if(a==='pic')pick();
  else if(a==='rmpic'){try{localStorage.removeItem(AV)}catch(x){}render()}
  else if(a==='savename'){var v=el.querySelector('#pfName').value.trim();if(!v){L.toast('Enter a name');return}L.setName(v);L.toast('Saved');render()}
  else if(a==='signin')L.openAuth('signin');
  else if(a==='signup')L.openAuth('signup');
  else if(a==='sync')L.syncNow(true);
  else if(a==='signout'){var p=L.signOut();if(p)p.then(function(){L.toast('Signed out. Progress stays on this phone.');render()})}
});
L.on('identity',function(){if(L.view==='profile')render()});
})();
