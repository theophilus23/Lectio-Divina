import sys; sys.path.insert(0,'test')
from harness import app
with app(width=360,height=740) as (page,base):
    page.goto(base); page.wait_for_timeout(1200)
    page.screenshot(path='/tmp/today1.png')
    for i in (3,7,11):
        page.evaluate("(i)=>{window.__fv&&0}",i)
    print(page.evaluate("(()=>{const t=document.getElementById('vtext');return [t.style.fontSize,t.scrollHeight,t.parentNode.clientHeight,document.documentElement.scrollHeight,innerHeight]})()"))
    page.set_viewport_size({'width':412,'height':900}); page.wait_for_timeout(500); page.screenshot(path='/tmp/today2.png')
    print(page.errors)
