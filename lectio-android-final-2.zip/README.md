# Lectio (Android)

Bible reading tracker with a built-in Bible reader (KJV and Telugu, parallel view), auto-scroll, audio, per-page background photos, sign-in, cloud sync, and font and colour settings. The app is the single page in `www/index.html`, packaged for Android with Capacitor. Progress is saved on the phone only.

## Build the APK on your computer
Needs Node 20+, JDK 21 and Android Studio (for the Android SDK).

    npm install
    npx cap add android      # skip if the android folder already exists
    npx cap sync android
    cd android && ./gradlew assembleDebug

The APK is at `android/app/build/outputs/apk/debug/app-debug.apk`. Copy it to your phone and install it.
To run from Android Studio instead: `npx cap open android`.

## Build the APK without installing anything
Push this folder to a GitHub repo, open Actions, run "Build APK", and download `lectio-debug-apk`.

## Changing things
- UI and verses: edit `www/index.html`, then `npx cap sync android`.
- Verses are KJV. NIV is licensed, so replace the `VERSES` list only if you have permission.
- Fonts are bundled in `www/fonts`, so the app looks the same offline.
- App icon: replace the files in `android/app/src/main/res/mipmap-*` or use `@capacitor/assets`.

## Files
- `www/index.html`, `styles.css`, `app.js`, `data.js`: the app.
- `www/fonts` and `fonts.css`: 18 bundled font families (offline).
- `www/vendor`: Firebase SDK (compat build) so sync works without a CDN.
- `www/firebase-config.js`: your Firebase keys. New zips do not include this file, so unzipping never overwrites your keys. If it is missing, copy `firebase-config.example.js` to that name.
- `firestore.rules`: security rules to paste into the Firebase console.

After changing anything in `www`, run `npx cap sync android` and run the app again.
After pulling a new version of this project, run `npm install` first (a plugin was added for the back button).

## Bible reader, audio and backgrounds (version 2.0)
- `www/bibles/<id>/`: one JSON file per book (`0.json` = Genesis … `65.json` = Revelation), `[chapter][verse]` arrays. 62 versions: KJV plus 61 converted from github.com/sajeevavahini/bibles (XML to JSON; see `www/bibles/manifest.json`).
- NIV is copyrighted and is not included. Settings > Bible versions can import your own licensed copy (a JSON file, or several per-book files). It is stored on the phone only.
- `www/reader.js`: reader, parallel view, text size and pinch zoom, auto-scroll (delay per pixel, 1 to 200 ms), audio, version import.
- `www/bg.js` and `www/store.js`: per-page background photos, kept on the phone (not synced to the cloud).
- Audio uses Android's own text-to-speech (`@capacitor-community/text-to-speech`) and a foreground service (`@capawesome-team/capacitor-android-foreground-service`) so it keeps playing when the app is minimised. The manifest changes are already made in `android/app/src/main/AndroidManifest.xml`.
- Telugu audio needs a Telugu voice on the phone: Android Settings > System > Languages > Text-to-speech output > Google > install voice data.

After unzipping a new version: `npm install`, then `npx cap sync android`, then rebuild and reinstall.

## Adding Bible versions (NIV, other languages)
Only add versions you have the right to use. KJV and the Telugu Old Version are public domain; NIV and many modern translations are licensed, so use them for private reading only, or get permission before publishing the app.

1. Make a folder `bible-sources/<id>/`, for example `bible-sources/niv/`. Use a short lowercase id (`niv`, `hi`, `ta`).
2. Put your JSON files in it: one file per book (name them `Genesis.json`, `1.json` for Genesis, or any name that contains the book name) or one file with the whole Bible. Common layouts are recognised automatically (`{"book":..,"chapters":[{"chapter":1,"verses":[{"verse":1,"text":".."}]}]}`, lists of chapters, flat verse rows).
3. Copy `bible-sources/_example/info.json` into the folder and edit it:
   `{ "id": "niv", "name": "New International Version", "short": "NIV", "lang": "en-US" }`
   `lang` decides the voice for audio (TTS): `en-US`, `en-GB`, `hi-IN`, `ta-IN`, `te-IN`, `ml-IN`, `kn-IN`, `es-ES`, and so on. The phone needs that voice installed.
4. Run `npm run bibles`. It writes `www/bibles/<id>/0.json ... 65.json` and updates `www/bibles/manifest.json`. It tells you which books were missing.
   One-off without an info file: `node tools/add-bible.js path/to/folder --id niv --name "New International Version" --short NIV --lang en-US`
5. `npx cap sync android` and rebuild. The version shows up automatically in the version menu, the parallel menu, search and the quiz; audio works with it. The GitHub build runs `npm run bibles` for you, so committing `bible-sources` is enough.

To add a version on one phone only, without rebuilding: Settings > Bible versions > Import (stored on that phone).
For a non-Latin script, pick a font for it in Settings > Fonts (per-translation fonts).

## Pages in version 3
Reading plans (calendar), reading history, saved verses and highlights, notes with templates, prayer points, prayer wall, quiz (daily challenge, practice, leaderboard), word search, reminders, reader layout and per-translation fonts and colours. Developers: see `docs/DEV-GUIDE.md`. The community page is planned for a later version.

## Songs (version 3.1)
Menu > Songs. Sections: Songs of Zion (818, 25 categories, Bible references, romanized), Telugu, Malayalam, Tamil, Hindi, Bengali, Kannada, Others (Nyishi), Chords (571 Malayalam songs with guitar and piano diagrams, transpose), and Mine (favourites and recent).
- `www/songs/songs.js` list, search, sections. `reader.js` reader, display panel, slide mode, chords. `rec.js` record yourself (up to 10 takes per song, saved on the phone). `songs.css`.
- `www/songs/data/*.js`: the song data, one index and one body file per section, loaded when the section opens. `www/songs/img`: chord diagrams. `www/songfonts.css` + `www/fonts`: Malayalam, Tamil, Hindi, Bengali, Kannada fonts.
- Settings (Aa button in the reader, or Settings > Songs): fonts per language, size (pinch too), line and letter spacing, theme, colour of each part, photo background, chorus style and position, romanized view, chord size, auto-scroll delay.
- Hindi (about 260) and Kannada (about 110) songs stored in old font encodings show a note instead of lyrics. Tamil songs in the old Bamini encoding (1,051) were converted to Unicode.
- Recording: each take has a Download button (on the phone it opens the share sheet so you can save it to Files or Drive; this needs `@capacitor/filesystem`, so run `npm install` first). Choosing a take marks it as your best and analyses it on the phone (`songs/melody.js`, YIN pitch tracking) into a small note pattern. Tapping Share (after a consent prompt) writes only that pattern to Firestore `song_melodies/<song>_<uid>`; no audio is uploaded. Paste the new rule from `firestore.rules` (also in `rules-parts/songmelodies.rules.txt`) into the Firebase console. Merging many users' melodies and generating the backing track is not built.
- Recording needs the microphone permission (added to AndroidManifest.xml). After unzipping: `npx cap sync android`, rebuild and reinstall.

## Songs of Zion tracks (version 3.2)
* `tools/zion-tracks/` – scripts you run on your own computer: `make_tracks.py` (shared melodies → consensus tune → key/tempo/chords → guide + instrumental MP3 + manifest.json) and `upload_r2.py` (to Cloudflare R2). Read `tools/zion-tracks/README.md`.
* App: set `tracksBase` in `www/songs/config.js` to your R2 public URL (trailing slash). A **Listen** strip (Track / Instrumental) then appears on every Zion song that has a track. Empty = hidden. The bucket needs the CORS rule from the tools README. Run `npx cap sync android` afterwards.
* Zion songs have no chord data; chords are derived from the melody.
