/* Reads Bible JSON in many common shapes and turns it into Lectio's own format:
   out[bookIndex] = [ chapter1Verses[], chapter2Verses[], ... ]  (bookIndex 0..65, Genesis..Revelation)
   Used by the app (Settings > Bible versions > import) and by tools/add-bible.js (adds a version to the app for everyone). */
(function(root,factory){
  if(typeof module==='object'&&module.exports)module.exports=factory();
  else root.LectioParse=factory();
})(typeof self!=='undefined'?self:this,function(){
'use strict';
var NAMES=["Genesis","Exodus","Leviticus","Numbers","Deuteronomy","Joshua","Judges","Ruth","1 Samuel","2 Samuel","1 Kings","2 Kings","1 Chronicles","2 Chronicles","Ezra","Nehemiah","Esther","Job","Psalms","Proverbs","Ecclesiastes","Song of Solomon","Isaiah","Jeremiah","Lamentations","Ezekiel","Daniel","Hosea","Joel","Amos","Obadiah","Jonah","Micah","Nahum","Habakkuk","Zephaniah","Haggai","Zechariah","Malachi","Matthew","Mark","Luke","John","Acts","Romans","1 Corinthians","2 Corinthians","Galatians","Ephesians","Philippians","Colossians","1 Thessalonians","2 Thessalonians","1 Timothy","2 Timothy","Titus","Philemon","Hebrews","James","1 Peter","2 Peter","1 John","2 John","3 John","Jude","Revelation"];
function normName(s){return String(s).toLowerCase().replace(/[^a-z0-9]/g,'')}
var CANON={};NAMES.forEach(function(n,i){CANON[normName(n)]=i});
var ALIAS={songofsongs:21,songofsolomon:21,canticles:21,canticleofcanticles:21,psalm:18,psalms:18,revelations:65,revelationofjohn:65,apocalypse:65,qoheleth:20,
  /* usual 3-letter codes (USFM and others) */
  gen:0,exo:1,lev:2,num:3,deu:4,jos:5,jdg:6,rut:7,'1sa':8,'2sa':9,'1ki':10,'2ki':11,'1ch':12,'2ch':13,ezr:14,neh:15,est:16,job:17,psa:18,pro:19,ecc:20,sng:21,sos:21,sol:21,isa:22,jer:23,lam:24,eze:25,ezk:25,dan:26,hos:27,joe:28,joel:28,amo:29,oba:30,jon:31,mic:32,nah:33,hab:34,zep:35,hag:36,zec:37,mal:38,
  mat:39,mrk:40,mar:40,luk:41,jhn:42,joh:42,act:43,rom:44,'1co':45,'2co':46,gal:47,eph:48,php:49,phi:49,col:50,'1th':51,'2th':52,'1ti':53,'2ti':54,tit:55,phm:56,phlm:56,heb:57,jas:58,jam:58,'1pe':59,'2pe':60,'1jo':61,'2jo':62,'3jo':63,jud:64,jde:64,rev:65,
  gn:0,ex:1,lv:2,nm:3,dt:4,jsh:5,jg:6,rt:7,'1sm':8,'2sm':9,'1kg':10,'2kg':11,'1chr':12,'2chr':13,ne:15,es:16,ps:18,prv:19,pr:19,ec:20,is:22,jr:23,ez:25,dn:26,ho:27,jl:28,am:29,ob:30,jnh:31,mi:32,na:33,hb:34,zp:35,hg:36,zc:37,ml:38,mt:39,mk:40,lk:41,jn:42,ac:43,ro:44,rm:44,ga:47,ep:48,pp:49,cl:50,tt:55,hebrews:57,jm:58,jd:64,rv:65};
function bookIndex(name){
  var k=normName(name);
  if(CANON[k]!=null)return CANON[k];
  if(ALIAS[k]!=null)return ALIAS[k];
  var m=k.replace(/^(first|1st)/,'1').replace(/^(second|2nd)/,'2').replace(/^(third|3rd)/,'3');
  if(CANON[m]!=null)return CANON[m];
  if(ALIAS[m]!=null)return ALIAS[m];
  m=k.replace(/^iii/,'3').replace(/^ii/,'2').replace(/^i(?=[a-z])/,'1');
  if(CANON[m]!=null)return CANON[m];
  if(ALIAS[m]!=null)return ALIAS[m];
  return -1;
}
/* A file name such as "01_Genesis.json", "Genesis.json", "1.json", "gen.json" -> book index, or -1 */
function bookFromFileName(fname){
  var stem=String(fname).replace(/^.*[\\/]/,'').replace(/\.[a-z0-9]+$/i,'');
  var i=bookIndex(stem);if(i>=0)return i;
  var m=stem.match(/^(\d{1,3})[\s._-]+(.+)$/);
  if(m){i=bookIndex(m[2]);if(i>=0)return i}
  m=stem.match(/^(.+?)[\s._-]+(\d{1,3})$/);
  if(m){i=bookIndex(m[1]);if(i>=0)return i}
  return -1;
}
function clean(t){return String(t==null?'':t).replace(/<[^>]*>/g,'').replace(/\s+/g,' ').replace(/^#\s*/,'').trim()}
function versesFrom(x){
  var arr=[];
  if(Array.isArray(x)){
    x.forEach(function(v,i){
      if(typeof v==='string')arr[i]=v;
      else if(v&&typeof v==='object'){var n=parseInt(v.verse||v.v||v.number||(i+1),10);arr[n-1]=v.text||v.t||v.value||''}
    });
  }else if(x&&typeof x==='object'){
    Object.keys(x).forEach(function(k){var n=parseInt(k,10);if(n>0){var v=x[k];arr[n-1]=typeof v==='string'?v:((v&&(v.text||v.t))||'')}});
  }
  var out=[];for(var i=0;i<arr.length;i++)out.push(clean(arr[i]));
  return out;
}
function chaptersFrom(x){
  var chs=[];
  if(Array.isArray(x)){
    x.forEach(function(c,i){
      var n=(c&&typeof c==='object'&&!Array.isArray(c)&&c.chapter!=null)?parseInt(c.chapter,10):(i+1);
      chs[n-1]=versesFrom((c&&!Array.isArray(c)&&c.verses)?c.verses:c);
    });
  }else if(x&&typeof x==='object'){
    Object.keys(x).forEach(function(k){var n=parseInt(k,10);if(n>0)chs[n-1]=versesFrom(x[k])});
  }
  for(var i=0;i<chs.length;i++)if(!chs[i])chs[i]=[];
  return chs;
}
function rowsToBooks(rows,out){
  var acc={};
  rows.forEach(function(r){
    var bk=r.book!=null?r.book:(r.book_name!=null?r.book_name:(r.bookname!=null?r.bookname:r.b));
    var ch=+(r.chapter!=null?r.chapter:r.c),vs=+(r.verse!=null?r.verse:r.v);
    var tx=r.text!=null?r.text:(r.t!=null?r.t:r.value);
    var i=/^\d+$/.test(String(bk))?(+bk-1):bookIndex(bk);
    if(i<0||i>65||!ch||!vs)return;
    var b=acc[i]=acc[i]||[],c=b[ch-1]=b[ch-1]||[];
    c[vs-1]=clean(tx);
  });
  Object.keys(acc).forEach(function(i){
    var b=acc[i];for(var c=0;c<b.length;c++){b[c]=b[c]||[];for(var v=0;v<b[c].length;v++)if(b[c][v]==null)b[c][v]=''}
    out[i]=b;
  });
}
/* j = parsed JSON. out = object that receives out[bookIndex]. hint = book index (0..65) from the file name, used when the JSON itself does not say which book it is. */
function parseBible(j,out,hint){
  function put(i,chs){if(i>=0&&i<66&&chs&&chs.length)out[i]=chs}
  function nameOf(o){var n=o.name||o.book||o.title||o.book_name||o.bookname;if(n&&typeof n==='object')n=n.english||n.name||n.en;return n}
  var h=(hint==null||hint<0)?-1:hint;
  if(Array.isArray(j)){
    var f=j[0];
    if(f&&typeof f==='object'&&!Array.isArray(f)&&('chapters' in f)){
      j.forEach(function(bk,p){
        var nm=nameOf(bk),i=nm?bookIndex(nm):-1;
        if(i<0&&j.length===66)i=p;
        put(i,chaptersFrom(bk.chapters));
      });
    }else if(f&&typeof f==='object'&&!Array.isArray(f)&&(f.verse!=null||f.v!=null||f.text!=null)&&(f.chapter!=null||f.c!=null)){rowsToBooks(j,out)}
    else if(Array.isArray(f)||typeof f==='string'||(f&&typeof f==='object')){
      /* one book written as a list of chapters */
      put(h,chaptersFrom(j));
    }
  }else if(j&&typeof j==='object'){
    if(j.resultset&&j.resultset.row){
      rowsToBooks(j.resultset.row.map(function(r){var f=r.field||[];return{book:f[1],chapter:f[2],verse:f[3],text:f[4]}}),out);
    }else if(Array.isArray(j.books)){parseBible(j.books,out)}
    else if(Array.isArray(j.chapters)||(j.chapters&&typeof j.chapters==='object')){
      var nm=nameOf(j),i=nm?bookIndex(nm):h;
      put(i>=0?i:h,chaptersFrom(j.chapters));
    }
    else{
      var named=false;
      Object.keys(j).forEach(function(k){var i=bookIndex(k);if(i>=0){named=true;put(i,chaptersFrom(j[k]))}});
      if(!named&&h>=0)put(h,chaptersFrom(j));
    }
  }
}
return{NAMES:NAMES,bookIndex:bookIndex,bookFromFileName:bookFromFileName,parseBible:parseBible,clean:clean};
});
