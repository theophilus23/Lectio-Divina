import sys; sys.path.insert(0,'test')
from harness import app
with app(width=360,height=740) as (page,base):
    page.goto(base); page.wait_for_timeout(600)
    page.evaluate("Lectio.go('prayerwall')"); page.wait_for_timeout(300)
    page.click('#pwNew'); page.wait_for_timeout(300)
    inp=page.query_selector('.umodal input'); inp.fill('Tester'); page.click('.umodal .uacts button >> nth=-1'); page.wait_for_timeout(500)
    page.fill('#pwT','Healing for mum'); page.fill('#pwX','Please pray'); page.click('.umodal .uacts button >> nth=-1'); page.wait_for_timeout(600)
    page.click('[data-r=pray]'); page.wait_for_timeout(300)
    print(page.inner_text('.pwc')[:200])
    page.screenshot(path='/tmp/pw.png')
    page.click('[data-a=ans]'); page.wait_for_timeout(300)
    page.fill('.umodal textarea','Healed!'); page.click('.umodal .uacts button >> nth=-1'); page.wait_for_timeout(600)
    print(page.inner_text('#v-prayerwall')[:300]); print(page.errors)
