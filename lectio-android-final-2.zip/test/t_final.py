import sys; sys.path.insert(0,'test')
from harness import app
with app(width=360,height=740) as (page,base):
    page.goto(base); page.wait_for_timeout(900)
    page.screenshot(path='/tmp/home.png')
    page.evaluate("Lectio.openReader(42,3,16,'te')"); page.wait_for_timeout(900)
    print('vers',page.evaluate("JSON.parse(localStorage.getItem('lectio-reader-v1')).vers"))
    page.evaluate("Lectio.go('settings')"); page.wait_for_timeout(600)
    page.evaluate("document.getElementById('rqSz').scrollIntoView()"); page.wait_for_timeout(300)
    page.evaluate("window.scrollBy(0,350)"); page.wait_for_timeout(300)
    page.screenshot(path='/tmp/set.png')
    print(page.errors)
