/* Record yourself singing a song: up to 10 takes per song, play them back, save the ones you like, choose your best one.
   Saved takes stay on this phone (IndexedDB, the same 'imgs' store Lectio already uses for photos). Nothing is uploaded from here. */
(function(){
'use strict';
var L=window.Lectio,UI=L.ui,esc=L.esc,S=window.LSongs;
UI.icons.download='M12 3v12 M7 10l5 5 5-5 M5 21h14';
var MAX=10,MAXSEC=600,KEY='lectio-songs-rec';
var st={model:null,key:'',el:null,rec:null,stream:null,chunks:[],t0:0,tmr:0,recording:false,takes:[],mem:{},audio:null,playing:'',host:null,mime:''};
var ICO={rec:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="7"/></svg>',stop:'<svg viewBox="0 0 24 24"><rect x="6" y="6" width="12" height="12" rx="2.5"/></svg>',
  play:'<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>',pause:'<svg viewBox="0 0 24 24"><path d="M7 5h4v14H7z M13 5h4v14h-4z"/></svg>'};
function meta(){try{return JSON.parse(L.lsGet(KEY)||'{}')||{}}catch(e){return{}}}
function putMeta(m){L.lsSet(KEY,JSON.stringify(m))}
function fmt(s){s=Math.round(s);return Math.floor(s/60)+':'+String(s%60).padStart(2,'0')}
function bkey(id){return'rec:'+st.key+':'+id}

/* takes of the current song = saved ones (from storage) + unsaved ones (this session) */
function loadTakes(){
  var m=meta()[st.key]||{takes:[],pick:''};
  st.takes=m.takes.map(function(t){return Object.assign({saved:true},t)}).concat(st.mem[st.key]||[]);
}
S.recSong=function(model){
  if(st.recording)stopRec(true);
  haltPlay();
  st.model=model;st.key=model.sec.id+':'+S.sid(model.sec,model.it);
  loadTakes();if(st.el&&!st.el.hidden)paint();
};
S.isRecording=function(){return st.recording};

function ensure(host){
  if(st.el&&st.host===host)return;
  st.host=host;
  var e=document.createElement('section');e.className='sg-panel sg-rec';e.hidden=true;
  e.innerHTML='<div class="grab"><b>Record yourself</b><button type="button" class="sg-ib" data-r="close" aria-label="Close"><svg viewBox="0 0 24 24"><path d="M6 6l12 12 M18 6L6 18"/></svg></button></div><div class="sg-pbody"></div>';
  host.appendChild(e);st.el=e;
  e.addEventListener('click',onClick);
}
S.openRec=function(model,host){
  ensure(host);
  if(model&&model!==st.model)S.recSong(model);
  var sp=host.querySelector('.sg-panel:not(.sg-rec)');if(sp)sp.hidden=true;
  st.el.hidden=false;host.style.setProperty('--sg-ph','60%');host.classList.add('sg-pop');paint();
};
S.closeRec=function(force){
  if(!st.el||st.el.hidden)return false;
  if(st.recording){stopRec(true)}
  haltPlay();
  st.el.hidden=true;st.host.style.removeProperty('--sg-ph');st.host.classList.remove('sg-pop');
  return true;
};

function paint(){
  var body=st.el.querySelector('.sg-pbody'),y=body.scrollTop,n=st.takes.length;
  var pick=(meta()[st.key]||{}).pick;
  var h='<div class="sg-rmain"><button type="button" class="sg-rbtn'+(st.recording?' on':'')+'" data-r="toggle" aria-label="'+(st.recording?'Stop':'Record')+'">'+(st.recording?ICO.stop:ICO.rec)+'</button>'
    +'<div class="sg-rtxt"><div class="sg-rtime" id="sgRt">'+(st.recording?fmt((Date.now()-st.t0)/1000):'0:00')+'</div><div class="sg-rsub">'+(st.recording?'Recording… tap to stop':'Tap the red button and sing')+'</div></div>'
    +'<div class="sg-rcnt"><b>'+n+'</b> / '+MAX+'<small>takes</small></div></div>';
  if(!n)h+='<p class="sg-pnote" style="text-align:center;padding:10px 0">No takes yet. Sing the whole song, or just the part you know best.</p>';
  else{
    h+='<div class="sg-takes">';
    st.takes.forEach(function(t,i){
      var chosen=t.saved&&pick===t.id;
      h+='<div class="sg-take'+(chosen?' sg-best':'')+'" data-id="'+t.id+'"><button type="button" class="pl" data-r="play" aria-label="Play">'+(st.playing===t.id?ICO.pause:ICO.play)+'</button>'
        +'<div class="tx"><b>Take '+(i+1)+' · '+fmt(t.dur)+'</b><span>'+(chosen?'★ Your best take':t.saved?'Saved · '+Math.max(1,Math.round(t.size/1024))+' KB':'Not saved yet')+'</span></div>'
        +(t.saved?'<button type="button" class="ac'+(chosen?' on':'')+'" data-r="pick">'+(chosen?'Chosen':'Choose')+'</button>':'<button type="button" class="ac main" data-r="save">Save</button>')
        +'<button type="button" class="ac" data-r="dl" aria-label="Download take">'+UI.icon('download',17)+'</button>'
        +'<button type="button" class="ac" data-r="del" aria-label="Delete take">'+UI.icon('trash',17)+'</button></div>';
    });
    h+='</div>';
    if(n>1)h+='<div class="sg-prow"><button type="button" class="btn" data-r="dlall">Download all takes ('+n+')</button></div>';
    if(st.takes.some(function(t){return!t.saved}))h+='<div class="sg-prow"><button type="button" class="btn main" data-r="saveall">Save all new takes</button></div>';
  }
  if(pick){
    var me=(meta()[st.key]||{}).mel,ok=me&&me.take===pick;
    h+='<div class="sg-mel"><b>Your melody</b>';
    if(st.analyzing)h+='<p>Listening to your best take…</p>';
    else if(ok){
      h+='<p>Found '+me.notes+(me.notes===1?' note':' notes')+', key '+esc(me.key)+', '+fmt(me.dur)+'. Only this small note pattern ('+Math.max(1,Math.round(JSON.stringify(me.rle).length/1024*10)/10)+' KB) is used. Your voice and audio are never sent.</p>'
        +'<div class="sg-prow">'+(me.shared?'<button type="button" class="btn" data-r="unshare">Stop sharing</button><span class="sg-shared">Shared ✓</span>':'<button type="button" class="btn main" data-r="share">Share melody to help train this song</button>')+'</div>';
    }else h+='<p>No clear melody found in this take. Try singing a bit louder and closer to the phone, then choose it again.</p><div class="sg-prow"><button type="button" class="btn" data-r="reanalyze">Try again</button></div>';
    h+='</div>';
  }
  h+='<p class="sg-pnote">Takes stay on this phone. Save the ones you like, then choose your best one. Only a saved take can be chosen. Sharing sends only the melody pattern, and only if you tap Share.</p>';
  body.innerHTML=h;body.scrollTop=y;
}

/* ---------- recording ---------- */
function pickMime(){
  var c=['audio/webm;codecs=opus','audio/ogg;codecs=opus','audio/mp4','audio/webm'];
  for(var i=0;i<c.length;i++)if(window.MediaRecorder&&MediaRecorder.isTypeSupported&&MediaRecorder.isTypeSupported(c[i]))return c[i];
  return'';
}
function startRec(){
  if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia||!window.MediaRecorder){L.toast('Recording is not supported on this device');return}
  if(st.takes.length>=MAX){L.toast('You already have '+MAX+' takes. Delete one to record again.');return}
  haltPlay();
  navigator.mediaDevices.getUserMedia({audio:{echoCancellation:false,noiseSuppression:false,autoGainControl:false}}).then(function(stream){
    st.stream=stream;st.chunks=[];st.mime=pickMime();
    var r;try{r=new MediaRecorder(stream,st.mime?{mimeType:st.mime,audioBitsPerSecond:48000}:undefined)}catch(e){r=new MediaRecorder(stream)}
    st.rec=r;st.t0=Date.now();st.recording=true;st.discard=false;
    r.ondataavailable=function(e){if(e.data&&e.data.size)st.chunks.push(e.data)};
    r.onstop=function(){
      var dur=(Date.now()-st.t0)/1000;
      stream.getTracks().forEach(function(t){t.stop()});
      if(st.discard||!st.chunks.length||dur<1){st.recording=false;if(st.el&&!st.el.hidden)paint();return}
      var blob=new Blob(st.chunks,{type:r.mimeType||st.mime||'audio/webm'});
      var t={id:Date.now().toString(36)+Math.random().toString(36).slice(2,5),t:Date.now(),dur:dur,size:blob.size,mime:blob.type,blob:blob,url:URL.createObjectURL(blob),saved:false};
      (st.mem[st.key]=st.mem[st.key]||[]).push(t);
      st.recording=false;loadTakes();if(st.el&&!st.el.hidden)paint();
    };
    r.start(1000);
    clearInterval(st.tmr);
    st.tmr=setInterval(function(){
      var s=(Date.now()-st.t0)/1000,el=st.el&&st.el.querySelector('#sgRt');if(el)el.textContent=fmt(s);
      if(s>=MAXSEC){stopRec(false);L.toast('Stopped at '+fmt(MAXSEC))}
    },250);
    paint();
  }).catch(function(e){
    L.toast(e&&e.name==='NotAllowedError'?'Allow the microphone to record':'Could not start the microphone');
  });
}
function stopRec(discard){
  clearInterval(st.tmr);
  if(!st.recording||!st.rec)return;
  st.discard=!!discard;
  try{st.rec.stop()}catch(e){st.recording=false}
  if(discard)st.recording=false;
}

/* ---------- playback ---------- */
function haltPlay(){if(st.audio){try{st.audio.pause()}catch(e){}}st.playing='';}
function playTake(t){
  if(st.playing===t.id){haltPlay();paint();return}
  haltPlay();
  var go=function(url){
    if(!st.audio){st.audio=new Audio();st.audio.onended=function(){st.playing='';if(st.el&&!st.el.hidden)paint()}}
    st.audio.src=url;st.playing=t.id;st.audio.play().catch(function(){st.playing='';L.toast('Could not play this take');paint()});paint();
  };
  if(t.url)return go(t.url);
  LStore.get('imgs',bkey(t.id)).then(function(b){
    if(!b){L.toast('This take is missing');return}
    t.url=URL.createObjectURL(b);go(t.url);
  }).catch(function(){L.toast('Could not read this take')});
}

/* ---------- melody: analyse on the phone, share only the note pattern ---------- */
function analyse(t){
  if(!S.melody)return;
  var key=st.key;st.analyzing=true;paint();
  blobOf(t).then(function(b){return S.melody(b)}).then(function(r){
    var m=meta(),e=m[key];
    if(e&&e.pick===t.id){
      if(r.voiced<10)delete e.mel;
      else e.mel={take:t.id,rle:r.rle,fps:r.fps,dur:r.dur,key:r.key,notes:r.notes,shared:false};
      putMeta(m);
    }
  }).catch(function(){L.toast('Could not analyse this take')}).then(function(){st.analyzing=false;if(st.el&&!st.el.hidden)paint()});
}
function docId(uid){return st.key.replace(/[^A-Za-z0-9]+/g,'-').slice(0,120)+'_'+uid}
function remote(on){
  var fb=L.fb;
  if(!fb||!fb.on||!L.user)return Promise.resolve();
  var ref=fb.db.collection('song_melodies').doc(docId(L.user.uid));
  if(on===false)return ref.delete().catch(function(){});
  return ref.set(on);
}
function share(){
  var m=meta(),e=m[st.key],me=e&&e.mel;if(!me)return;
  if(!L.fb||!L.fb.on){L.toast('Sharing needs the cloud sign-in, which is not set up in this build');return}
  UI.confirm('Share the note pattern of this take to help build a track for this song? No audio and no voice is sent, only the notes you sang. You can stop sharing any time.',{ok:'Share'}).then(function(ok){
    if(!ok)return;
    return L.ensureIdentity().then(function(id){
      if(!id){L.toast('Sign in or continue as guest to share');return}
      return remote({uid:id.uid,song:st.key,title:st.model.title,sec:st.model.sec.id,rle:me.rle,fps:me.fps,dur:me.dur,key:me.key,notes:me.notes,v:1,ts:Date.now()}).then(function(){
        var m2=meta(),e2=m2[st.key];if(e2&&e2.mel){e2.mel.shared=true;putMeta(m2)}
        paint();L.toast('Melody shared. Thank you!');
      });
    });
  }).catch(function(){L.toast('Could not share. Check your connection.')});
}
function unshare(){
  remote(false).then(function(){
    var m=meta(),e=m[st.key];if(e&&e.mel){e.mel.shared=false;putMeta(m)}
    paint();L.toast('Stopped sharing');
  });
}

/* ---------- download ---------- */
function blobOf(t){
  if(t.blob)return Promise.resolve(t.blob);
  return LStore.get('imgs',bkey(t.id)).then(function(b){if(!b)throw new Error('missing');return b});
}
function fileName(t,n){
  var base=(st.model.title||'song').replace(/[\\/:*?"<>|\s]+/g,'_').slice(0,40)||'song';
  var ext=/mp4|aac/.test(t.mime||'')?'m4a':/ogg/.test(t.mime||'')?'ogg':'webm';
  return base+'-take'+n+'.'+ext;
}
function toB64(b){return new Promise(function(res,rej){var r=new FileReader();r.onload=function(){res(String(r.result).split(',')[1])};r.onerror=rej;r.readAsDataURL(b)})}
function download(t,n,quiet){
  return blobOf(t).then(function(b){
    var name=fileName(t,n),C=window.Capacitor,P=C&&C.Plugins;
    if(C&&C.isNativePlatform&&C.isNativePlatform()&&P&&P.Filesystem&&P.Share){
      return toB64(b).then(function(data){
        return P.Filesystem.writeFile({path:'recordings/'+name,data:data,directory:'CACHE',recursive:true});
      }).then(function(r){return P.Share.share({title:name,url:r.uri,dialogTitle:'Save or send recording'})});
    }
    var a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=name;document.body.appendChild(a);a.click();
    setTimeout(function(){URL.revokeObjectURL(a.href);a.remove()},1500);
    if(!quiet)L.toast('Downloaded '+name);
  });
}

/* ---------- save / choose / delete ---------- */
function saveTake(t){
  if(!window.LStore){L.toast('Storage not available');return Promise.reject()}
  var key=st.key;
  return LStore.set('imgs','rec:'+key+':'+t.id,t.blob).then(function(){
    var m=meta(),e=m[key]=m[key]||{takes:[],pick:''};
    e.takes.push({id:t.id,t:t.t,dur:t.dur,size:t.size,mime:t.mime});
    putMeta(m);
    st.mem[key]=(st.mem[key]||[]).filter(function(x){return x.id!==t.id});
    if(st.key===key)loadTakes();
  });
}
function onClick(e){
  var b=e.target.closest('[data-r]');if(!b)return;
  var a=b.dataset.r,row=b.closest('.sg-take'),t=row&&st.takes.filter(function(x){return x.id===row.dataset.id})[0];
  if(a==='close'){S.closeRec();return}
  if(a==='toggle'){st.recording?stopRec(false):startRec();return}
  if(a==='play'&&t){playTake(t);return}
  if(a==='save'&&t){saveTake(t).then(function(){paint();L.toast('Take saved')}).catch(function(){});return}
  if(a==='saveall'){
    var un=st.takes.filter(function(x){return!x.saved});
    un.reduce(function(p,x){return p.then(function(){return saveTake(x)})},Promise.resolve()).then(function(){paint();L.toast('Saved')}).catch(function(){});return;
  }
  if(a==='dl'&&t){download(t,st.takes.indexOf(t)+1).catch(function(){L.toast('Could not download this take')});return}
  if(a==='dlall'){
    st.takes.reduce(function(p,x,i){return p.then(function(){return download(x,i+1,true)})},Promise.resolve()).catch(function(){L.toast('Could not download')});return;
  }
  if(a==='share'){share();return}
  if(a==='unshare'){unshare();return}
  if(a==='reanalyze'){var pk=(meta()[st.key]||{}).pick,tt=st.takes.filter(function(x){return x.id===pk})[0];if(tt)analyse(tt);return}
  if(a==='pick'&&t){
    var m=meta(),e2=m[st.key];if(!e2)return;
    var was=e2.mel&&e2.mel.shared;
    e2.pick=e2.pick===t.id?'':t.id;
    if(e2.mel&&e2.mel.take!==e2.pick){if(was)remote(false);delete e2.mel}
    putMeta(m);paint();
    L.toast(e2.pick?'Chosen as your best take':'Choice cleared');
    if(e2.pick)analyse(t);
    return;
  }
  if(a==='del'&&t){
    UI.confirm(t.saved?'Delete this saved take from your phone?':'Delete this take?',{ok:'Delete',danger:true}).then(function(ok){
      if(!ok)return;
      if(st.playing===t.id)haltPlay();
      if(t.saved){
        var m=meta(),e3=m[st.key];
        if(e3){e3.takes=e3.takes.filter(function(x){return x.id!==t.id});if(e3.pick===t.id){if(e3.mel&&e3.mel.shared)remote(false);e3.pick='';delete e3.mel}putMeta(m)}
        LStore.del('imgs',bkey(t.id)).catch(function(){});
      }else{
        st.mem[st.key]=(st.mem[st.key]||[]).filter(function(x){return x.id!==t.id});
        if(t.url)URL.revokeObjectURL(t.url);
      }
      loadTakes();paint();
    });
  }
}
})();
