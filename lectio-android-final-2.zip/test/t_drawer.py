import sys; sys.path.insert(0,'test')
from harness import app
with app(width=360,height=740) as (page,base):
    page.goto(base); page.wait_for_timeout(800)
    page.click('#tabSet'); page.wait_for_timeout(500)
    page.screenshot(path='/tmp/dr1.png')
    print('open',page.evaluate("[Lectio.view,!document.getElementById('drawer').hidden,getComputedStyle(document.querySelector('main')).transform]"))
    page.evaluate("Lectio.goBack()"); page.wait_for_timeout(500)
    print('closed',page.evaluate("[document.getElementById('drawer').hidden,document.querySelector('main').style.transform]"))
    # synthetic swipe from edge
    page.evaluate("""()=>{function tv(t,x,y){var o=new Touch({identifier:1,target:document.body,clientX:x,clientY:y});document.dispatchEvent(new TouchEvent(t,{touches:t==='touchend'?[]:[o],changedTouches:[o],bubbles:true}))}
      tv('touchstart',5,300);tv('touchmove',60,302);tv('touchmove',200,304);tv('touchend',200,304)}""")
    page.wait_for_timeout(500)
    print('swiped open',page.evaluate("!document.getElementById('drawer').hidden"))
    page.evaluate("""()=>{function tv(t,x,y){var o=new Touch({identifier:1,target:document.body,clientX:x,clientY:y});document.dispatchEvent(new TouchEvent(t,{touches:t==='touchend'?[]:[o],changedTouches:[o],bubbles:true}))}
      tv('touchstart',250,300);tv('touchmove',200,302);tv('touchmove',60,304);tv('touchend',60,304)}""")
    page.wait_for_timeout(600)
    print('swiped closed',page.evaluate("document.getElementById('drawer').hidden"))
    page.evaluate("Lectio.go('settings')"); page.wait_for_timeout(500); page.screenshot(path='/tmp/hub.png')
    page.click('[data-sec=sc-readerlayout]'); page.wait_for_timeout(600); page.evaluate("window.scrollBy(0,300)"); page.screenshot(path='/tmp/rd.png')
    page.evaluate("Lectio.goBack()"); print('hub back',page.evaluate("[Lectio.view,document.getElementById('sHub').hidden]"))
    page.click('[data-sec=sc-dock]'); page.click('#dkOn'); print('dock hidden',page.evaluate("document.getElementById('fdock').hidden"))
    print(page.errors)
