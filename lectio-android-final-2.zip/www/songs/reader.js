/* Song reader: lyrics, chords (transpose + diagrams), display settings panel (fonts, sizes, colours, photo background),
   auto-scroll, pinch zoom, slide mode. Opened from songs.js through LSongs.open({rows,pos}). */
(function(){
'use strict';
var L=window.Lectio,UI=L.ui,esc=L.esc,S=window.LSongs,set=S.settings;
var R={root:null,ctx:null,cur:null,model:null,tr:0,tab:'text',play:false,acc:0,last:0,slide:0,slides:[],wl:null,bgUrl:null};

/* ================= colour helpers ================= */
function h2r(h){h=h.replace('#','');if(h.length===3)h=h.replace(/./g,'$&$&');return[parseInt(h.slice(0,2),16),parseInt(h.slice(2,4),16),parseInt(h.slice(4,6),16)]}
function r2h(r){return'#'+r.map(function(v){return Math.max(0,Math.min(255,Math.round(v))).toString(16).padStart(2,'0')}).join('')}
function mix(a,b,t){var x=h2r(a),y=h2r(b);return r2h([x[0]+(y[0]-x[0])*t,x[1]+(y[1]-x[1])*t,x[2]+(y[2]-x[2])*t])}
function lum(h){var c=h2r(h).map(function(v){v/=255;return v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4)});return .2126*c[0]+.7152*c[1]+.0722*c[2]}
function rgba(h,a){var c=h2r(h);return'rgba('+c[0]+','+c[1]+','+c[2]+','+a+')'}
var THEMES=[['app','App',null,null],['paper','Paper','#F7F2E7','#2B2218'],['sepia','Sepia','#EEDFBF','#3B2C18'],['sage','Sage','#E2EADC','#1E2B22'],
  ['night','Night','#12172A','#E6E9F3'],['black','Black','#000000','#D9D9D9'],['custom','Custom',null,null]];
function themeCols(){
  if(set.theme==='app')return null;
  if(set.theme==='custom')return{bg:set.cbg,fg:set.cfg};
  for(var i=0;i<THEMES.length;i++)if(THEMES[i][0]===set.theme)return{bg:THEMES[i][2],fg:THEMES[i][3]};
  return null;
}

/* ================= chords ================= */
var SH=['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'],FL=['C','Db','D','Eb','E','F','Gb','G','Ab','A','Bb','B'];
var PC={C:0,D:2,E:4,F:5,G:7,A:9,B:11};
var FLATKEYS={F:1,Bb:1,Eb:1,Ab:1,Db:1,Gb:1,Dm:1,Gm:1,Cm:1,Fm:1,Bbm:1,Ebm:1};
function pcOf(l,a){return((PC[l]+(a==='#'?1:a==='b'?-1:0))%12+12)%12}
var CRE=/^([A-G])([#b]?)([^\/]*)(?:\/([A-G])([#b]?))?$/;
function tpName(name,n,flat){
  if(!n)return name;
  var m=CRE.exec(name);if(!m)return name;
  var N=flat?FL:SH,r=N[(pcOf(m[1],m[2])+n+120)%12];
  var s=r+m[3];
  if(m[4])s+='/'+N[(pcOf(m[4],m[5])+n+120)%12];
  return s;
}
function useFlat(){
  var k=R.model&&R.model.key;if(!k)return false;
  var tk=tpName(k,R.tr,false);
  var kk=CRE.exec(k);
  var tgt=tpName(kk?kk[1]+kk[2]+(kk[3]==='m'?'m':''):k,R.tr,FLATKEYS[k]?true:false);
  if(R.tr===0)return !!FLATKEYS[k];
  var nk=/^[A-G][#b]?m?/.exec(tgt);nk=nk?nk[0]:tgt;
  return !!FLATKEYS[nk]||(tgt.indexOf('b')>0&&tgt.indexOf('#')<0&&!!FLATKEYS[nk]);
}
function keyAfter(){
  var k=R.model&&R.model.key;if(!k)return'';
  if(!R.tr)return k;
  var m=/^([A-G])([#b]?)(m?)/.exec(k);if(!m)return k;
  var base=m[1]+m[2],fl=FLATKEYS[k];
  var pc=(pcOf(m[1],m[2])+R.tr+120)%12;
  var sharpName=SH[pc]+m[3],flatName=FL[pc]+m[3];
  return FLATKEYS[flatName]?flatName:(FLATKEYS[sharpName]?sharpName:(SH[pc].length>1&&FL[pc].length>1?(fl?flatName:sharpName):sharpName));
}
function chordLine(line,tr,flat){
  var parts=line.split(/(\[[^\]]*\])/),segs=[{c:'',t:parts[0]}],i;
  for(i=1;i<parts.length;i+=2)segs.push({c:parts[i].slice(1,-1),t:parts[i+1]||''});
  var h='';
  segs.forEach(function(s){
    if(!s.c&&!s.t)return;
    var nm=s.c?tpName(s.c.trim(),tr,flat):'';
    h+='<span class="sg-seg"><span class="c"'+(nm?' data-ch="'+esc(nm)+'"':'')+'>'+esc(nm)+'</span><span class="t">'+esc(s.t)+'</span></span>';
  });
  return h;
}
function chordsIn(blocks,flat){
  var seen={},out=[];
  blocks.forEach(function(b){b.lines.forEach(function(l){
    (l.match(/\[[^\]]*\]/g)||[]).forEach(function(m){
      var nm=tpName(m.slice(1,-1).trim(),R.tr,flat);if(CRE.test(nm)&&!seen[nm]){seen[nm]=1;out.push(nm)}
    });
  })});
  return out;
}
var ROOTF={'C':'c','C#':'csharp','Db':'db','D':'d','D#':'dsharp','Eb':'eb','E':'e','F':'f','F#':'fsharp','Gb':'gb','G':'g','G#':'gsharp','Ab':'ab','A':'a','A#':'asharp','Bb':'bb','B':'b'};
function chordFiles(name){
  var m=CRE.exec(name);if(!m)return null;
  var rs=m[1]+m[2];
  if(!ROOTF[rs])rs=SH[pcOf(m[1],m[2])];
  var q=m[3],base='',exact=true;
  if(q===''||q==='M'||q==='maj')base='';
  else if(q==='m'||q==='min'||q==='-')base='m';
  else if(q==='7')base='7';
  else{exact=false;base=/^(m|min)(?!aj)/.test(q)||/^dim|^m7b5/.test(q)?'m':/^7/.test(q)?'7':''}
  var r=ROOTF[rs];
  return{root:r,base:base,exact:exact,main:r+base,alt:base===''?r+'2':null,shown:rs+(base==='m'?'m':base==='7'?'7':''),asked:name};
}
function showChord(name){
  var f=chordFiles(name);
  if(!f){L.toast('No diagram for '+name);return}
  var img=function(inst,code,cls){return'<img class="'+cls+'" alt="'+esc(name)+' '+inst+'" src="'+S.base+'img/'+inst+'/'+code+'.jpg">'};
  var h='<div class="sg-diag"><div class="nm">'+esc(name)+'</div>';
  if(!f.exact)h+='<p class="sg-pnote" style="text-align:center">No exact diagram for '+esc(name)+'. Showing the closest shape: '+esc(f.shown)+'.</p>';
  h+='<div class="seg" style="width:100%" id="sgInst"><button type="button" data-i="guitar" aria-pressed="'+(set.inst==='guitar')+'">Guitar</button><button type="button" data-i="piano" aria-pressed="'+(set.inst==='piano')+'">Piano</button></div><div id="sgDg"></div></div>';
  var m=UI.modal({title:'Chord',body:h,sheet:true});
  var paint=function(){
    var g=m.body.querySelector('#sgDg');
    if(set.inst==='guitar'){
      g.innerHTML='<div class="alts"><figure>'+img('guitar',f.main,'gt')+'<figcaption>Shape 1</figcaption></figure>'+(f.alt?'<figure>'+img('guitar',f.alt,'gt')+'<figcaption>Shape 2 (higher)</figcaption></figure>':'')+'</div>';
    }else{
      g.innerHTML='<div class="alts"><figure>'+img('piano',f.main,'pn')+'</figure>'+(f.alt?'<figure>'+img('piano',f.alt,'pn')+'<figcaption>Inversion</figcaption></figure>':'')+'</div>';
    }
    Array.prototype.forEach.call(m.body.querySelectorAll('#sgInst button'),function(b){b.setAttribute('aria-pressed',String(b.dataset.i===set.inst))});
  };
  m.body.querySelector('#sgInst').onclick=function(e){var b=e.target.closest('[data-i]');if(!b)return;set.inst=b.dataset.i;S.save();paint()};
  paint();
}

/* ================= song model ================= */
var LABRE=/^(\d{1,2})(?:\s*[.)]\s*|\s+)(\S[\s\S]*)$/,LONE=/^(\d{1,2})\s*[.)]?\s*$/,CHRE=/^(పల్లవి|చరణం|Pallavi|Chorus|Charanam|Refrain)\s*[:：\-]\s*([\s\S]*)$/i;
function parseBlocks(str){
  var out=[];
  (str||'').split('\f').forEach(function(s){
    var lines=s.split('\n'),f=lines[0]||'',m,lab='',t='u';
    if((m=CHRE.exec(f))){lab=m[1];t='c';lines[0]=m[2]}
    else if((m=LABRE.exec(f))){lab=m[1];t='v';lines[0]=m[2]}
    else if((m=LONE.exec(f))){lab=m[1];t='v';lines.shift()}
    lines=lines.filter(function(x){return x.trim()});
    if(lines.length)out.push({t:t,lab:lab,lines:lines});
  });
  if(out.some(function(b){return b.t==='v'}))out.forEach(function(b){if(b.t==='u')b.t='c'});
  return out;
}
function zionBlocks(g,mode){
  if(!g)return[];
  var st=(g.s||[]).map(function(l,i){return{t:'v',lab:String((g.sn||[])[i]||i+1),lines:l}});
  var c=g.c?{t:'c',lab:'',tag:'పల్లవి',lines:g.c}:null,out=[];
  if(mode==='top'){if(c)out.push(c);out=out.concat(st)}
  else if(mode==='end'){out=st.slice();if(c)out.push(c)}
  else if(mode==='first'){st.forEach(function(b,i){out.push(b);if(i===0&&c)out.push(c)});if(!st.length&&c)out.push(c)}
  else{st.forEach(function(b){out.push(b);if(c)out.push(c)});if(!st.length&&c)out.push(c)}
  if(g.a)out.push({t:'c',lab:'',tag:'Alt. chorus',lines:g.a});
  if(g.x)out.push({t:'c',lab:'',tag:'Additional chorus',lines:g.x});
  return out;
}
function buildModel(sec,it,body,idx){
  var m={sec:sec,it:it,kind:sec.zion?'zion':sec.chords?'chords':'gen',title:it.t,sub:'',no:'',meta:[],nat:[],rom:[],eng:[],note:'',scr:null,key:it.k||'',y:body.y||'',sc:sec.sc};
  if(sec.zion){
    var cat=null;(idx.cats||[]).forEach(function(c){if(c.c===it.c)cat=c});
    m.no='No. '+it.n;m.sub=it.r;
    if(cat)m.meta.push({t:cat.en+' · '+cat.te});
    if(it.b)m.meta.push({t:it.b});
    m.nat=zionBlocks(body.g,set.zionChorus);m.rom=zionBlocks(body.ro,set.zionChorus);
    if(body.en&&set.eng)m.eng=zionBlocks(body.en,'end');
    if(body.sc&&body.sc.length)m.scr={refs:body.br||[],texts:body.sc};
  }else if(sec.chords){
    m.no='Chords';m.sc='en';
    if(it.k)m.meta.push({t:'Key '+it.k,k:1});
    if(it.bpm)m.meta.push({t:it.bpm+' BPM'});
    if(it.ts)m.meta.push({t:it.ts});
    if(it.by)m.meta.push({t:'Chords: '+it.by});
    m.nat=parseBlocks(body.c);m.rom=[];m.sub='';
  }else{
    m.sub=it.r&&it.r!==it.t?it.r:'';
    if(sec.id==='nyishi'||(sec.sc!=='te'&&!/[^\u0000-ɏ\s\d\W]/.test(it.t)&&false))m.sc='en';
    m.nat=parseBlocks(body.l);m.rom=parseBlocks(body.r);
    if(sec.id==='nyishi')m.sc='en';
    if(it.k)m.meta.push({t:'Key '+it.k,k:1});
    if(body.g)m.meta.push({t:body.g.split(',').join(' · ')});
    if(body.c)m.note='<b>©</b> '+esc(body.c);
    if(body.n)m.note=(m.note?m.note+'<br>':'')+esc(body.n);
    if(body.x)m.note='<b>Lyrics unavailable.</b> This song is stored in an older font format that could not be converted to readable text yet.'+(m.note?'<br>'+m.note:'');
  }
  return m;
}
function effView(m){
  var hn=m.nat.length>0,hr=m.rom.length>0,v=set.view;
  if(m.kind==='chords')return'native';
  if(v==='both'&&hn&&hr)return'both';
  if(v==='rom'&&hr)return'rom';
  if(v==='native'&&hn)return'native';
  return hn?'native':'rom';
}
function plainText(m){
  var v=effView(m),bl=v==='rom'?m.rom:m.nat,out=[m.title];
  bl.forEach(function(b){out.push('');if(b.lab&&b.t==='v')out.push(b.lab+'.');b.lines.forEach(function(l){out.push(l.replace(/\[[^\]]*\]/g,''))})});
  return out.join('\n');
}

/* ================= rendering ================= */
function blockHtml(b,rb,m,flat,asSlide){
  var chords=m.kind==='chords',sc=m.sc,h='';
  var lines=b.lines.map(function(l){
    if(chords)return'<p class="sg-cl sg-f-en'+(set.chords?'':' nochord')+'">'+chordLine(l,R.tr,flat)+'</p>';
    return'<p class="sg-ln sg-f-'+sc+'">'+esc(l)+'</p>';
  }).join('');
  var rl='';
  if(rb)rl='<div class="sg-rg">'+rb.lines.map(function(l){return'<p class="sg-ln r">'+esc(l)+'</p>'}).join('')+'</div>';
  if(asSlide)return(b.t==='c'&&b.tag?'<div class="lab">'+esc(b.tag)+'</div>':(b.lab&&b.t==='v'?'<div class="lab">'+esc(b.lab)+'</div>':''))+lines+rl;
  return'<section class="sg-b '+(b.t==='c'?'c':'v')+'"><span class="n">'+(b.t==='v'?esc(b.lab):'')+'</span><div class="x">'+(b.tag?'<span class="tag">'+esc(b.tag)+'</span>':'')+lines+rl+'</div></section>';
}
function viewBlocks(m){
  var v=effView(m);
  if(v==='rom')return{main:m.rom,pair:null,sc:'en'};
  if(v==='both'){
    var ok=m.nat.length===m.rom.length;
    return{main:m.nat,pair:ok?m.rom:null,extra:ok?null:m.rom,sc:m.sc};
  }
  return{main:m.nat,pair:null,sc:m.sc};
}
function renderSong(keepScroll){
  var m=R.model,flat=useFlat(),vb=viewBlocks(m),sc=R.root.querySelector('.sg-scroll'),y=sc.scrollTop;
  var saveSc=m.sc;
  var scr=m.sc;if(effView(m)==='rom')m.sc='en';
  var tc=(m.sec.id==='nyishi'||m.sec.chords||effView(m)==='rom')?'en':m.sc;
  var h='<div class="sg-h">'+(m.no?'<span class="no">'+esc(m.no)+'</span>':'')+'<h2 class="sg-f-'+tc+'">'+esc(m.title)+'</h2>'+(m.sub?'<div class="sub">'+esc(m.sub)+'</div>':'')+'</div>';
  var meta=m.meta.slice();
  if(m.kind==='chords'&&m.key)meta[0]={t:'Key '+keyAfter(),k:1};
  if(m.y)meta.push({t:'▶ Video',vid:1});
  if(meta.length)h+='<div class="sg-meta">'+meta.map(function(x){return'<span'+(x.k?' class="k"':'')+(x.vid?' data-vid="1" style="cursor:pointer"':'')+'>'+esc(x.t)+'</span>'}).join('')+'</div>';
  if(m.kind==='chords'){
    var used=chordsIn(vb.main,flat);
    h+='<div class="sg-cbar"><button type="button" class="pill" data-a="chords" aria-pressed="'+set.chords+'">Chords</button>'
      +'<span class="grp"><button type="button" data-a="tdn" aria-label="Lower key">−</button><b>'+(R.tr?(R.tr>0?'+':'')+R.tr:'Original')+'</b><button type="button" data-a="tup" aria-label="Raise key">+</button></span>'
      +(R.tr?'<button type="button" class="pill" data-a="t0">Reset</button>':'')+'</div>';
    if(used.length)h+='<div class="sg-used" aria-label="Chords in this song">'+used.map(function(c){return'<button type="button" data-ch="'+esc(c)+'">'+esc(c)+'</button>'}).join('')+'</div>';
  }
  h+='<div class="sg-rule"></div>';
  if(!vb.main.length)h+='<div class="sg-note">'+(m.note&&/unavailable/.test(m.note)?'':'<b>No lyrics in this song.</b>')+'</div>';
  vb.main.forEach(function(b,i){h+=blockHtml(b,vb.pair?vb.pair[i]:null,m,flat)});
  if(vb.extra&&vb.extra.length){
    h+='<div class="sg-eng"><div class="sg-b c"><span class="n"></span><div class="x"><span class="tag">Romanized</span>'+vb.extra.map(function(b){return b.lines.map(function(l){return'<p class="sg-ln r">'+esc(l)+'</p>'}).join('')+'<div style="height:.6em"></div>'}).join('')+'</div></div></div>';
  }
  if(m.eng&&m.eng.length){
    var saved=m.sc;m.sc='en';
    h+='<div class="sg-eng"><span class="no" style="font-family:var(--sg-f-en);font-size:.66rem;letter-spacing:.14em;font-weight:700;color:var(--sg-num)">ENGLISH</span>'+m.eng.map(function(b){return blockHtml(b,null,m,flat)}).join('')+'</div>';
    m.sc=saved;
  }
  if(m.scr){
    h+='<div class="sg-scr"><div class="e">Scripture</div>'+(m.scr.refs.length?'<p><b>'+esc(m.scr.refs.join(' · '))+'</b></p>':'')+m.scr.texts.map(function(t){return'<p>'+esc(t)+'</p>'}).join('')+'</div>';
  }
  if(m.note)h+='<div class="sg-note">'+m.note+'</div>';
  var pos=R.ctx.pos,n=R.ctx.rows.length;
  h+='<div class="sg-navr"><button type="button" data-a="prev"'+(pos<=0?' disabled':'')+'>‹ Previous</button><button type="button" data-a="next"'+(pos>=n-1?' disabled':'')+'>Next ›</button></div>';
  var a=R.root.querySelector('.sg-song');
  a.className='sg-song sg-cs-'+set.chorusStyle+(set.nums?'':' sg-nn');
  a.innerHTML=h;
  m.sc=saveSc;
  sc.scrollTop=keepScroll?y:0;
  paintBar();
}
function paintBar(){
  var m=R.model,r=R.root;
  r.querySelector('.ttl').textContent=m.sec.zion?'Songs of Zion · '+m.it.n:m.sec.short;
  var f=r.querySelector('[data-a="fav"]');f.setAttribute('aria-pressed',String(S.isFav(m.sec,m.it)));
  r.querySelector('[data-a="slides"]').hidden=false;
}

/* ================= apply settings to the reader ================= */
function applyReader(){
  if(!R.root)return;
  var s=R.root.style,tc=themeCols(),c=set.col;
  var P=['--sg-bg','--sg-fg','--sg-mut','--sg-line','--sg-surf','--sg-acc','--sg-num','--sg-cho','--sg-rom','--sg-chd'];
  P.forEach(function(p){s.removeProperty(p)});
  var bg=null,fg=null;
  if(tc){
    bg=tc.bg;fg=tc.fg;
    s.setProperty('--sg-bg',bg);s.setProperty('--sg-fg',fg);s.setProperty('--sg-mut',mix(fg,bg,.45));s.setProperty('--sg-line',rgba(fg,.16));
    s.setProperty('--sg-surf',mix(bg,fg,.07));s.setProperty('--sg-acc',lum(bg)>.36?'#8A6819':'#D6B268');
  }
  if(c.text)s.setProperty('--sg-fg',c.text);
  if(c.title)s.setProperty('--sg-acc',c.title);
  if(c.num)s.setProperty('--sg-num',c.num);
  if(c.chorus)s.setProperty('--sg-cho',c.chorus);
  if(c.rom)s.setProperty('--sg-rom',c.rom);
  if(c.chord)s.setProperty('--sg-chd',c.chord);
  s.setProperty('--sg-fs',set.size+'px');s.setProperty('--sg-lh',String(set.lh));s.setProperty('--sg-ls',set.ls+'px');
  s.setProperty('--sg-fw',set.bold?'700':'400');s.setProperty('--sg-al',set.align);s.setProperty('--sg-gap',set.gap+'px');
  s.setProperty('--sg-rs',String(set.romScale/100));s.setProperty('--sg-cs',String(set.chordScale/100));
  S.applyFonts();
  applyBg();
}
function applyBg(){
  var l=R.root.querySelector('.sg-bgl');
  if(!set.bgimg){l.hidden=true;return}
  var go=function(url){
    if(!url){l.hidden=true;return}
    l.hidden=false;
    var i=l.querySelector('.i');i.style.backgroundImage='url("'+url+'")';i.style.filter=set.blur?'blur('+set.blur+'px)':'none';
    l.querySelector('.d').style.opacity=String(set.dim/100);
  };
  if(R.bgUrl)return go(R.bgUrl);
  if(!window.LStore)return go(null);
  LStore.get('imgs','songs-bg').then(function(b){R.bgUrl=b?URL.createObjectURL(b):null;go(R.bgUrl)}).catch(function(){go(null)});
}
function shrink(file){
  return new Promise(function(res,rej){
    var u=URL.createObjectURL(file),im=new Image();
    im.onload=function(){
      var k=Math.min(1,1600/Math.max(im.width,im.height)),c=document.createElement('canvas');
      c.width=Math.round(im.width*k);c.height=Math.round(im.height*k);
      c.getContext('2d').drawImage(im,0,0,c.width,c.height);URL.revokeObjectURL(u);
      c.toBlob(function(b){b?res(b):rej(new Error('no blob'))},'image/jpeg',.82);
    };
    im.onerror=function(){rej(new Error('bad image'))};im.src=u;
  });
}

/* ================= panel ================= */
var TABS=[['text','Text'],['col','Colours'],['bg','Background'],['show','Show'],['scroll','Scroll']];
function rng(id,label,min,max,step,val,unit){return'<label class="rng">'+label+'<b id="v_'+id+'">'+val+(unit||'')+'</b><input type="range" data-k="'+id+'" data-r="'+id+'" min="'+min+'" max="'+max+'" step="'+step+'" value="'+val+'"></label>'}
function segH(key,opts,val){return'<div class="seg" data-g="'+key+'">'+opts.map(function(o){return'<button type="button" data-v="'+o[0]+'" aria-pressed="'+(String(val)===String(o[0]))+'">'+o[1]+'</button>'}).join('')+'</div>'}
function tglH(key,label,on){return'<button type="button" class="tgl" data-t="'+key+'" aria-pressed="'+on+'"><span>'+label+'</span><i></i></button>'}
function colRow(key,label){
  var c=set.col[key],cur=c||'#888888';
  return'<div class="sg-cr"><span>'+label+'</span><input type="color" data-c="'+key+'" value="'+cur+'"><button type="button" data-ca="'+key+'"'+(c?'':' disabled')+'>Auto</button></div>';
}
function panelHtml(){
  var m=R.model,h='';
  if(R.tab==='text'){
    var scs=[];if(m.sc!=='en')scs.push(m.sc);scs.push('en');
    scs.forEach(function(sc){
      var cur=set.fonts[sc];
      h+='<div><div class="lbl">Font · '+S.scriptNames[sc]+'</div><select data-f="'+sc+'">'+S.fontSets[sc].map(function(f){return'<option value="'+esc(f.id)+'"'+(f.id===cur?' selected':'')+'>'+esc(f.name)+'</option>'}).join('')+'</select></div>';
    });
    h+='<div><div class="lbl">Text size</div><div class="row" style="flex-wrap:nowrap"><button type="button" class="btn" data-sz="-1">A−</button><div style="flex:1">'+rng('size','Size',14,64,1,set.size,' px')+'</div><button type="button" class="btn" data-sz="1">A+</button></div><p class="sg-pnote">Tip: pinch the song with two fingers to resize.</p></div>';
    h+=rng('lh','Line spacing',1.2,2.6,.05,set.lh)+rng('ls','Letter spacing',-1,6,.25,set.ls,' px')+rng('gap','Space between stanzas',4,70,2,set.gap,' px');
    h+=tglH('bold','Bold text',set.bold)+'<div><div class="lbl">Alignment</div>'+segH('align',[['left','Left'],['center','Centre']],set.align)+'</div>';
  }else if(R.tab==='col'){
    h+='<div><div class="lbl">Theme</div><div class="sg-sw">'+THEMES.map(function(t){
      var bg=t[2]||(t[0]==='app'?'var(--bg)':set.cbg),fg=t[3]||(t[0]==='app'?'var(--fg)':set.cfg);
      return'<button type="button" data-th="'+t[0]+'" aria-pressed="'+(set.theme===t[0])+'"><i style="background:'+bg+';color:'+fg+'">Aa</i>'+t[1]+'</button>';
    }).join('')+'</div></div>';
    if(set.theme==='custom')h+='<div class="sg-cr"><span>Background</span><input type="color" data-cc="cbg" value="'+set.cbg+'"></div><div class="sg-cr"><span>Text</span><input type="color" data-cc="cfg" value="'+set.cfg+'"></div>';
    h+='<div><div class="lbl">Colour of each part</div>'+colRow('text','Lyrics')+colRow('title','Titles and accent')+colRow('num','Verse numbers')+colRow('chorus','Chorus')+colRow('rom','Romanized text')+(m.kind==='chords'?colRow('chord','Chords'):'')+'</div>';
  }else if(R.tab==='bg'){
    h+='<div><div class="lbl">Photo behind the lyrics</div><div class="sg-prow"><button type="button" class="btn main" data-a="pick">Choose photo</button><button type="button" class="btn" data-a="nobg"'+(set.bgimg?'':' disabled')+'>Remove</button></div><input type="file" id="sgFile" accept="image/*" hidden><p class="sg-pnote" style="margin-top:8px">The photo stays on this phone. Raise “Cover” if the text is hard to read.</p></div>';
    h+=rng('dim','Cover (hides the photo)',0,95,1,set.dim,'%')+rng('blur','Blur',0,20,1,set.blur,' px');
  }else if(R.tab==='show'){
    h+='<div><div class="lbl">Language shown</div>'+segH('view',[['auto','Auto'],['native','Original'],['rom','Romanized'],['both','Both']],set.view)+'</div>';
    h+=rng('romScale','Romanized text size',55,100,1,set.romScale,'%');
    h+=tglH('nums','Verse numbers',set.nums);
    h+='<div><div class="lbl">Chorus style</div>'+segH('chorusStyle',[['bar','Bar'],['italic','Italic'],['indent','Indent'],['bold','Bold'],['plain','Plain']],set.chorusStyle)+'</div>';
    if(m.kind==='zion')h+='<div><div class="lbl">Chorus position</div>'+segH('zionChorus',[['every','After each'],['first','After first'],['top','Top'],['end','End']],set.zionChorus)+'</div>'+tglH('eng','Show English refrain',set.eng);
    if(m.kind==='chords')h+=tglH('chords','Show chords',set.chords)+rng('chordScale','Chord size',55,110,1,set.chordScale,'%')+'<div><div class="lbl">Chord diagrams</div>'+segH('inst',[['guitar','Guitar'],['piano','Piano']],set.inst)+'</div>';
  }else{
    h+=rng('delay','Auto-scroll delay per pixel',1,200,1,set.delay,' ms')+'<p class="sg-pnote">Smaller is faster. 1 ms is very fast. You can also change it with the − and + buttons while it scrolls.</p>'+tglH('wake','Keep the screen on while reading',set.wake);
    h+='<div class="sg-prow"><button type="button" class="btn" data-a="reset">Reset all song settings</button></div>';
  }
  return h;
}
function renderPanel(keepScroll){
  var p=R.root.querySelector('.sg-panel'),b=p.querySelector('.sg-pbody'),y=b.scrollTop;
  p.querySelector('.sg-ptabs').innerHTML=TABS.map(function(t){return'<button type="button" data-tab="'+t[0]+'" aria-pressed="'+(R.tab===t[0])+'">'+t[1]+'</button>'}).join('');
  b.innerHTML=panelHtml();
  if(keepScroll)b.scrollTop=y;
}
function openPanel(tab){
  if(tab)R.tab=tab;
  var p=R.root.querySelector('.sg-panel');p.hidden=false;R.root.classList.add('sg-pop');
  renderPanel();
}
function closePanel(){var p=R.root.querySelector('.sg-panel');if(p.hidden)return false;p.hidden=true;R.root.classList.remove('sg-pop');return true}
function chg(structural){S.save();applyReader();if(structural)rebuild(true);S.refreshList&&S.refreshList()}
function rebuild(keep){
  var r=R.ctx.rows[R.ctx.pos],sec=S.secById(r.s),idx=S.getIdxSync(r.s);
  R.model=buildModel(sec,idx.items[r.i],R.body,idx);
  renderSong(keep);
}
function panelEvents(p){
  p.addEventListener('click',function(e){
    var t;
    if((t=e.target.closest('[data-tab]'))){R.tab=t.dataset.tab;renderPanel();return}
    if(e.target.closest('[data-x]')){closePanel();return}
    if((t=e.target.closest('[data-g]'))){var b=e.target.closest('[data-v]');if(!b)return;var k=t.dataset.g,v=b.dataset.v;
      set[k]=(k==='lh'||k==='size')?+v:v;chg(['view','chorusStyle','zionChorus'].indexOf(k)>=0);
      if(k==='chorusStyle'||k==='align')R.root.querySelector('.sg-song').className='sg-song sg-cs-'+set.chorusStyle+(set.nums?'':' sg-nn');
      renderPanel(true);return}
    if((t=e.target.closest('[data-t]'))){var k2=t.dataset.t;set[k2]=!set[k2];
      if(k2==='wake'){wake(R.root.hidden?false:set.wake)}
      chg(['eng','chords','nums'].indexOf(k2)>=0);renderPanel(true);return}
    if((t=e.target.closest('[data-th]'))){set.theme=t.dataset.th;chg(false);renderPanel(true);return}
    if((t=e.target.closest('[data-sz]'))){set.size=Math.max(14,Math.min(64,set.size+(+t.dataset.sz)*2));chg(false);renderPanel(true);return}
    if((t=e.target.closest('[data-ca]'))){set.col[t.dataset.ca]='';chg(false);renderPanel(true);return}
    if((t=e.target.closest('[data-a]'))){
      var a=t.dataset.a;
      if(a==='pick')p.querySelector('#sgFile').click();
      else if(a==='nobg'){set.bgimg=false;if(window.LStore)LStore.del('imgs','songs-bg').catch(function(){});R.bgUrl=null;chg(false);renderPanel(true)}
      else if(a==='reset'){
        UI.confirm('Reset fonts, sizes, colours and background for songs?',{ok:'Reset'}).then(function(ok){
          if(!ok)return;
          var keep=set.page;Object.keys(S.DEF).forEach(function(k){set[k]=JSON.parse(JSON.stringify(S.DEF[k]))});set.page=keep;
          if(window.LStore)LStore.del('imgs','songs-bg').catch(function(){});R.bgUrl=null;
          chg(true);renderPanel(true);
        });
      }
    }
  });
  p.addEventListener('input',function(e){
    var t=e.target;
    if(t.dataset.r){
      var k=t.dataset.r,v=+t.value;set[k]=v;
      var out=p.querySelector('#v_'+k);if(out)out.textContent=v+({size:' px',ls:' px',gap:' px',delay:' ms',dim:'%',romScale:'%',chordScale:'%',blur:' px'}[k]||'');
      applyReader();S.save();if(k==='delay'){var sp=R.root.querySelector('.sp b');if(sp)sp.textContent=v+' ms'}
    }else if(t.dataset.c){set.col[t.dataset.c]=t.value;applyReader();S.save();var b2=p.querySelector('[data-ca="'+t.dataset.c+'"]');if(b2)b2.disabled=false}
    else if(t.dataset.cc){set[t.dataset.cc]=t.value;applyReader();S.save()}
  });
  p.addEventListener('change',function(e){
    var t=e.target;
    if(t.dataset.f){set.fonts[t.dataset.f]=t.value;chg(false)}
    else if(t.id==='sgFile'&&t.files[0]){
      shrink(t.files[0]).then(function(b){return LStore.set('imgs','songs-bg',b)}).then(function(){
        R.bgUrl=null;set.bgimg=true;chg(false);renderPanel(true);L.toast('Background photo set');
      }).catch(function(){L.toast('Could not use that photo')});
      t.value='';
    }
  });
}

/* ================= auto-scroll, wake lock, pinch ================= */
function wake(on){
  try{
    if(on&&navigator.wakeLock&&!R.wl){navigator.wakeLock.request('screen').then(function(l){R.wl=l;l.addEventListener('release',function(){R.wl=null})}).catch(function(){})}
    else if(!on&&R.wl){R.wl.release();R.wl=null}
  }catch(e){}
}
function tick(ts){
  if(!R.play)return;
  var sc=R.root.querySelector('.sg-scroll');
  if(!R.last)R.last=ts;
  R.acc+=(ts-R.last)/Math.max(1,set.delay);R.last=ts;
  var px=Math.floor(R.acc);
  if(px>0){
    R.acc-=px;var b=sc.scrollTop;sc.scrollTop=b+px;
    if(sc.scrollTop+sc.clientHeight>=sc.scrollHeight-1){stopPlay();return}
  }
  requestAnimationFrame(tick);
}
function startPlay(){
  if(R.play)return;R.play=true;R.last=0;R.acc=0;
  var b=R.root.querySelector('.sg-play');b.classList.add('on');b.querySelector('.fb').innerHTML=pauseIco;
  R.root.querySelector('.sp b').textContent=set.delay+' ms';
  requestAnimationFrame(tick);
}
function stopPlay(){
  if(!R.play&&!R.root)return;R.play=false;
  if(!R.root)return;
  var b=R.root.querySelector('.sg-play');b.classList.remove('on');b.querySelector('.fb').innerHTML=playIco;
}
var playIco='<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>',pauseIco='<svg viewBox="0 0 24 24"><path d="M7 5h4v14H7z M13 5h4v14h-4z"/></svg>';

/* ================= slide mode ================= */
function buildSlides(){
  var m=R.model,flat=useFlat(),vb=viewBlocks(m),out=[];
  var scs=effView(m)==='rom'?'en':m.sc;
  var sv=m.sc;m.sc=scs;
  vb.main.forEach(function(b,i){out.push({html:blockHtml(b,vb.pair?vb.pair[i]:null,m,flat,true),chordy:m.kind==='chords'})});
  if(vb.extra)vb.extra.forEach(function(b){out.push({html:blockHtml(b,null,Object.assign({},m,{sc:'en'}),flat,true)})});
  m.sc=sv;
  return out;
}
function showSlide(i){
  var sl=R.root.querySelector('.sg-slides'),box=sl.querySelector('.sg-sl'),inn=box.querySelector('.in');
  R.slide=Math.max(0,Math.min(R.slides.length-1,i));
  var s=R.slides[R.slide];
  inn.innerHTML=s?s.html:'';box.classList.toggle('chordy',!!(s&&s.chordy));
  sl.querySelector('.cnt').textContent=(R.slide+1)+' / '+R.slides.length;
  sl.querySelector('[data-s="prev"]').disabled=R.slide===0;sl.querySelector('[data-s="next"]').disabled=R.slide>=R.slides.length-1;
  fitSlide();
}
function fitSlide(){
  var sl=R.root.querySelector('.sg-slides'),box=sl.querySelector('.sg-sl'),inn=box.querySelector('.in');
  var f=Math.min(64,Math.round(window.innerWidth/10)+22);
  for(;f>14;f-=2){
    box.style.setProperty('--slf',f+'px');
    if(inn.scrollHeight<=box.clientHeight-16&&inn.scrollWidth<=box.clientWidth+1)break;
  }
}
function openSlides(){
  R.slides=buildSlides();if(!R.slides.length){L.toast('Nothing to show');return}
  stopPlay();
  var sl=R.root.querySelector('.sg-slides');sl.hidden=false;
  sl.querySelector('.ttl').textContent=R.model.title;
  showSlide(0);
}
function closeSlides(){var sl=R.root.querySelector('.sg-slides');if(sl.hidden)return false;sl.hidden=true;return true}

/* ================= build DOM ================= */
function ensure(){
  if(R.root)return;
  var r=document.createElement('div');r.className='sg-reader';r.hidden=true;
  var I=function(n){return UI.icon(n,20)};
  r.innerHTML='<div class="sg-bgl" hidden><div class="i"></div><div class="d"></div></div>'
    +'<header class="sg-bar"><button type="button" class="sg-ib" data-a="close" aria-label="Back"><svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7"/></svg></button><div class="ttl"></div>'
    +'<button type="button" class="sg-ib" data-a="rec" aria-label="Record yourself singing"><svg viewBox="0 0 24 24"><path d="M12 3a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V6a3 3 0 0 0-3-3z M5 11a7 7 0 0 0 14 0 M12 18v3"/></svg></button>'
    +'<button type="button" class="sg-ib" data-a="slides" aria-label="Slide mode"><svg viewBox="0 0 24 24"><path d="M3 5h18v12H3z M8 21h8 M12 17v4"/></svg></button>'
    +'<button type="button" class="sg-ib fill" data-a="fav" aria-label="Favourite" aria-pressed="false">'+I('star')+'</button>'
    +'<button type="button" class="sg-ib" data-a="more" aria-label="Share">'+I('share')+'</button>'
    +'<button type="button" class="sg-ib" data-a="panel" aria-label="Display settings"><span class="aa">Aa</span></button></header>'
    +'<div class="sg-listen" hidden></div>'
    +'<div class="sg-scroll"><article class="sg-song"></article></div>'
    +'<div class="sg-play"><div class="sp"><button type="button" data-a="slow" aria-label="Slower">−</button><b></b><button type="button" data-a="fast" aria-label="Faster">+</button></div><button type="button" class="fb" data-a="play" aria-label="Auto-scroll">'+playIco+'</button></div>'
    +'<section class="sg-panel" hidden><div class="grab"><b>Song display</b><button type="button" class="sg-ib" data-x aria-label="Close"><svg viewBox="0 0 24 24"><path d="M6 6l12 12 M18 6L6 18"/></svg></button></div><div class="sg-ptabs"></div><div class="sg-pbody"></div></section>'
    +'<section class="sg-slides" hidden><div class="top"><button type="button" class="sg-ib" data-s="close" aria-label="Close slides"><svg viewBox="0 0 24 24"><path d="M6 6l12 12 M18 6L6 18"/></svg></button><div class="ttl"></div></div><div class="sg-sl"><div class="in"></div></div><div class="sg-slc"><button type="button" data-s="prev">‹ Back</button><span class="cnt"></span><button type="button" data-s="next">Next ›</button></div></section>';
  document.body.appendChild(r);R.root=r;
  panelEvents(r.querySelector('.sg-panel'));
  r.addEventListener('click',function(e){
    var t;
    if((t=e.target.closest('[data-s]'))){
      var s=t.dataset.s;
      if(s==='close')closeSlides();else if(s==='prev')showSlide(R.slide-1);else showSlide(R.slide+1);
      return;
    }
    if((t=e.target.closest('.sg-seg .c[data-ch]'))){showChord(t.dataset.ch);return}
    if((t=e.target.closest('[data-ch]'))&&t.closest('.sg-used')){showChord(t.dataset.ch);return}
    if(e.target.closest('[data-vid]')){window.open(R.model.y,'_blank');return}
    if((t=e.target.closest('[data-a]'))&&!e.target.closest('.sg-panel')){act(t.dataset.a)}
  });
  window.addEventListener('resize',function(){if(R.root&&!R.root.hidden&&!R.root.querySelector('.sg-slides').hidden)fitSlide()});
  document.addEventListener('keydown',function(e){
    if(R.root.hidden)return;
    var sl=R.root.querySelector('.sg-slides');
    if(!sl.hidden){if(e.key==='ArrowRight'||e.key===' ')showSlide(R.slide+1);else if(e.key==='ArrowLeft')showSlide(R.slide-1);else if(e.key==='Escape')closeSlides()}
  });
  /* slide swipe */
  var sx=0,sy=0;
  var sb=r.querySelector('.sg-sl');
  sb.addEventListener('touchstart',function(e){sx=e.touches[0].clientX;sy=e.touches[0].clientY},{passive:true});
  sb.addEventListener('touchend',function(e){
    var dx=e.changedTouches[0].clientX-sx,dy=e.changedTouches[0].clientY-sy;
    if(Math.abs(dx)>50&&Math.abs(dx)>Math.abs(dy)*1.4)showSlide(R.slide+(dx<0?1:-1));
    else if(Math.abs(dx)<10&&Math.abs(dy)<10){var w=sb.clientWidth;showSlide(R.slide+(e.changedTouches[0].clientX>w/2?1:-1))}
  },{passive:true});
  /* pinch to zoom + stop auto-scroll when the finger touches */
  var sc=r.querySelector('.sg-scroll'),d0=0,s0=0;
  var dist=function(t){return Math.hypot(t[0].clientX-t[1].clientX,t[0].clientY-t[1].clientY)};
  sc.addEventListener('touchstart',function(e){
    if(R.play)stopPlay();
    if(e.touches.length===2){d0=dist(e.touches);s0=set.size}
  },{passive:true});
  sc.addEventListener('touchmove',function(e){
    if(e.touches.length===2&&d0){
      e.preventDefault();
      set.size=Math.max(14,Math.min(64,Math.round(s0*dist(e.touches)/d0)));
      r.style.setProperty('--sg-fs',set.size+'px');
    }
  },{passive:false});
  sc.addEventListener('touchend',function(e){if(d0&&e.touches.length<2){d0=0;S.save();if(!r.querySelector('.sg-panel').hidden&&R.tab==='text')renderPanel(true)}},{passive:true});
  L.back.push(function(){
    if(!R.root||R.root.hidden)return false;
    if(closeSlides())return true;
    if(S.closeRec&&S.closeRec())return true;
    if(closePanel())return true;
    close();return true;
  });
}
function act(a){
  var p=R.ctx.pos;
  if(a==='close')close();
  else if(a==='fav'){var on=S.toggleFav(R.model.sec,R.model.it);R.root.querySelector('[data-a="fav"]').setAttribute('aria-pressed',String(on));S.refreshList&&S.refreshList();L.toast(on?'Added to favourites':'Removed from favourites')}
  else if(a==='panel'){if(S.isRecording&&S.isRecording()){L.toast('Stop recording first');return}if(S.closeRec)S.closeRec(true);if(R.root.querySelector('.sg-panel').hidden)openPanel();else closePanel()}
  else if(a==='slides')openSlides();
  else if(a==='rec'){if(S.openRec)S.openRec(R.model,R.root);else L.toast('Recorder not available')}
  else if(a==='play'){R.play?stopPlay():startPlay()}
  else if(a==='slow'){set.delay=Math.min(200,set.delay+(set.delay<20?2:6));S.save();R.root.querySelector('.sp b').textContent=set.delay+' ms'}
  else if(a==='fast'){set.delay=Math.max(1,set.delay-(set.delay<=20?2:6));S.save();R.root.querySelector('.sp b').textContent=set.delay+' ms'}
  else if(a==='prev'){if(p>0)loadPos(p-1)}
  else if(a==='next'){if(p<R.ctx.rows.length-1)loadPos(p+1)}
  else if(a==='chords'){set.chords=!set.chords;S.save();renderSong(true)}
  else if(a==='tup'||a==='tdn'){R.tr=(R.tr+(a==='tup'?1:-1)+12*3)%12;if(R.tr>6)R.tr-=12;renderSong(true)}
  else if(a==='t0'){R.tr=0;renderSong(true)}
  else if(a==='more'){
    var m=R.model,items=[{label:'Share lyrics',icon:'share',on:function(){UI.share({title:m.title,text:plainText(m)})}},{label:'Copy lyrics',icon:'copy',on:function(){UI.copy(plainText(m))}}];
    if(m.y)items.push({label:'Open video',icon:'globe',on:function(){window.open(m.y,'_blank')}});
    UI.actionSheet({title:m.title.slice(0,40),items:items});
  }
}

/* ================= open / close ================= */
S.getIdxSync=function(id){return S._idx(id)};
function loadPos(pos){
  var r=R.ctx.rows[pos];if(!r)return;
  var sec=S.secById(r.s);
  Promise.all([S.getIdx(sec),S.getBody(sec)]).then(function(a){
    var idx=a[0],it=idx.items[r.i];
    R.ctx.pos=pos;R.body=a[1][r.i]||{};R.tr=0;stopPlay();
    R.model=buildModel(sec,it,R.body,idx);
    S.pushRecent(sec,it);
    if(S.recSong)S.recSong(R.model);
    if(S.listenSong)S.listenSong(R.model,R.root.querySelector('.sg-listen'));
    renderSong(false);
    if(!R.root.querySelector('.sg-panel').hidden)renderPanel(true);
    var sl=R.root.querySelector('.sg-slides');if(!sl.hidden){R.slides=buildSlides();showSlide(0)}
  }).catch(function(){L.toast('Could not open this song')});
}
function close(){
  if(!R.root||R.root.hidden)return;
  stopPlay();closeSlides();closePanel();if(S.closeRec)S.closeRec(true);if(S.listenStop)S.listenStop();R.root.hidden=true;wake(false);
  if(S.refreshList)S.refreshList();
}
S.closeReader=function(){close()};
S.open=function(ctx){
  ensure();R.ctx={rows:ctx.rows,pos:ctx.pos};
  applyReader();R.root.hidden=false;wake(set.wake);
  loadPos(ctx.pos);
  if(ctx.panel){setTimeout(function(){openPanel(ctx.panel)},120)}
};
S.openPreview=function(sec){
  if(sec.mine)sec=S.secById('zion');
  Promise.all([S.getIdx(sec),S.getBody(sec)]).then(function(a){
    var idx=a[0],b=a[1],i=0;
    for(;i<idx.items.length;i++){var x=b[i];if(x&&(x.l||x.g||x.c||x.r))break}
    if(sec.zion){i=Math.min(22,idx.items.length-1)}
    S.open({rows:[{s:sec.id,i:i}],pos:0,panel:'text'});
  });
};
})();
