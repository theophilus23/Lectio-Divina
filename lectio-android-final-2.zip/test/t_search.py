import sys;sys.path.insert(0,'test')
from harness import app
with app(width=360,height=740) as (page,base):
    page.goto(base); page.wait_for_timeout(600)
    page.evaluate("Lectio.go('search')"); page.wait_for_timeout(300)
    page.fill('#sq','shepherd'); page.click('#sgo'); page.wait_for_timeout(6000)
    print(page.eval_on_selector_all('.sgroup .tag','e=>e.map(x=>x.textContent)'))
    page.screenshot(path='/tmp/claude-0/search.png')
    page.fill('#sq','దేవుడు'); page.select_option('#sscope','b0'); page.click('#sgo'); page.wait_for_timeout(2500)
    print(page.eval_on_selector_all('.sgroup .tag','e=>e.map(x=>x.textContent)'))
    page.fill('#sq','John 3:16'); page.click('#sgo'); page.wait_for_timeout(500); print('open btn', page.locator('[data-open]').count())
    print(page.errors)
