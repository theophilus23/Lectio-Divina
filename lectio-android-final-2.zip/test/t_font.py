import sys; sys.path.insert(0,'test')
from harness import app
with app(width=360,height=740) as (page,base):
    page.goto(base); page.wait_for_timeout(700)
    page.evaluate("Lectio.go('settings')"); page.wait_for_timeout(500)
    page.click('[data-sec=sc-appearance]'); page.wait_for_timeout(500)
    page.screenshot(path='/tmp/f0.png')
    try:
        page.click('text=Fonts'); page.wait_for_timeout(400)
    except Exception as e: print('no Fonts tab',str(e)[:60])
    page.screenshot(path='/tmp/f1.png'); print(page.errors)
