import sys; sys.path.insert(0,'test')
from harness import app
with app(width=360,height=740) as (page,base):
    page.goto(base); page.wait_for_timeout(1200)
    page.screenshot(path='/tmp/td360.png')
    page.set_viewport_size({'width':412,'height':900}); page.wait_for_timeout(400); page.screenshot(path='/tmp/td412.png')
    print(page.errors)
