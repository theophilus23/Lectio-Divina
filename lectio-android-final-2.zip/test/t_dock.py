import sys; sys.path.insert(0,'test')
from harness import app
with app(width=360,height=740) as (page,base):
    page.goto(base); page.evaluate("localStorage.setItem('lectio-fdock',JSON.stringify({x:150,y:350}))"); page.reload(); page.wait_for_timeout(1000)
    v=lambda: page.evaluate("Lectio.view")
    page.evaluate("Lectio.go('notes')"); page.wait_for_timeout(300)
    page.evaluate("Lectio.go('settings')"); page.wait_for_timeout(300)
    page.click('#fdock .fd-btn'); page.wait_for_timeout(400); print('tap back ->',v())
    def slide(dx,dy,hold=600):
        b=page.locator('#fdock .fd-btn').bounding_box(); x=b['x']+23;y=b['y']+23
        page.mouse.move(x,y); page.mouse.down(); page.wait_for_timeout(hold); page.mouse.move(x+dx,y+dy,steps=4); page.wait_for_timeout(150)
        tip=page.evaluate("document.querySelector('.fd-tip').textContent"); page.mouse.up(); page.wait_for_timeout(500); return tip
    page.evaluate("Lectio.go('notes')"); page.wait_for_timeout(300)
    print('hold release',slide(0,0),v())
    page.evaluate("Lectio.go('notes')"); page.wait_for_timeout(300)
    print('slide left',slide(-80,0),v())
    print('slide right',slide(80,0),v())
    print('slide up',slide(0,-80),v())
    print('slide dr',slide(60,60),v())
    page.evaluate("Lectio.go('notes')"); page.wait_for_timeout(300); page.evaluate("Lectio.openReader(0,1)"); page.wait_for_timeout(600)
    page.evaluate("Lectio.goBack()"); page.wait_for_timeout(300); print('reader back ->',v())
    page.evaluate("Lectio.go('home')"); page.evaluate("Lectio.go('lib')"); page.evaluate("Lectio.go('book',0)"); page.evaluate("Lectio.openReader(0,1)"); page.wait_for_timeout(500)
    page.evaluate("Lectio.goBack()"); page.wait_for_timeout(300); print('bible>chapters>reader back ->',v())
    page.screenshot(path='/tmp/today3.png')
    print(page.errors)
