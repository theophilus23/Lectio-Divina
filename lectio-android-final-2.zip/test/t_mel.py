import sys; sys.path.insert(0,'test')
from harness import app
INIT="""navigator.mediaDevices.getUserMedia=async function(){const ac=new AudioContext();const d=ac.createMediaStreamDestination();const o=ac.createOscillator();o.type='sawtooth';const g=ac.createGain();g.gain.value=.4;o.connect(g);g.connect(d);
const seq=[440,494,523,587];let i=0;o.frequency.value=seq[0];o.start();setInterval(()=>{i=(i+1)%4;o.frequency.value=seq[i]},700);return d.stream};"""
with app(width=390,height=800,init_script=INIT,permissions=['microphone']) as (page,base):
    page.goto(base);page.wait_for_timeout(800);page.evaluate("Lectio.go('songs')");page.wait_for_timeout(900)
    page.click('.sg-row >> nth=2');page.wait_for_timeout(900);page.click('[data-a="rec"]')
    page.click('[data-r="toggle"]');page.wait_for_timeout(3200);page.click('[data-r="toggle"]');page.wait_for_timeout(700)
    r=page.evaluate("""async()=>{const t=document.querySelector('.sg-take');const a=document.querySelector('audio');return 0}""")
    res=page.evaluate("""async()=>{const rec=await new Promise(r=>{const mr=null;r(null)});return null}""")
    # analyse the recorded blob directly
    out=page.evaluate("""async()=>{
      const ac=new AudioContext();const d=ac.createMediaStreamDestination();const o=ac.createOscillator();o.type='sawtooth';o.connect(d);o.frequency.value=440;o.start();
      const mr=new MediaRecorder(d.stream);const ch=[];mr.ondataavailable=e=>ch.push(e.data);mr.start();
      setTimeout(()=>o.frequency.value=523.25,1000);
      await new Promise(r=>setTimeout(r,2000));mr.stop();await new Promise(r=>mr.onstop=r);
      const m=await LSongs.melody(new Blob(ch,{type:'audio/webm'}));return m}""")
    print(out)
    print('ERR',page.errors)
