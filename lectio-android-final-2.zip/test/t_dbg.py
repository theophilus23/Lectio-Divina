import sys; sys.path.insert(0, 'test')
from harness import app
with app(width=390,height=800) as (page, base):
    page.goto(base); page.wait_for_timeout(800)
    page.evaluate("Lectio.go('songs')"); page.wait_for_timeout(1000)
    page.click('.sg-row >> nth=2'); page.wait_for_timeout(800)
    page.click('[data-a="panel"]'); page.wait_for_timeout(600)
    print(page.evaluate("(()=>{const i=document.querySelector('.sg-pbody input[type=range]');return [i.outerHTML,i.hidden,i.style.cssText,getComputedStyle(i).display]})()"))
