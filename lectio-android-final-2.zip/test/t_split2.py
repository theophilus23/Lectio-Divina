import sys; sys.path.insert(0,'test')
from harness import app
with app(width=360,height=740) as (page,base):
    page.goto(base); page.wait_for_timeout(700)
    page.add_style_tag(content="#fdock{display:none!important}")
    page.evaluate("()=>Lectio.go('split')"); page.wait_for_timeout(900)
    page.screenshot(path='/tmp/sp1.png')
    print(page.evaluate("()=>[...document.querySelectorAll('.spill .sch')].map(x=>x.textContent)"))
    # swipe via synthetic touch events
    page.evaluate("""()=>{const b=document.querySelector('[data-body=a]');
      const mk=(t,x,y)=>{const o={identifier:1,target:b,clientX:x,clientY:y};return new TouchEvent(t,{bubbles:true,touches:t=='touchend'?[]:[new Touch(o)],changedTouches:[new Touch(o)]})};
      b.dispatchEvent(mk('touchstart',250,300));b.dispatchEvent(mk('touchend',100,305));}""")
    page.wait_for_timeout(700)
    print(page.evaluate("()=>[...document.querySelectorAll('.spill .sch')].map(x=>x.textContent)"))
    page.click('[data-t=scroll]'); page.wait_for_timeout(1200)
    print('scrollTop',page.evaluate("()=>document.querySelector('[data-body=a]').scrollTop"))
    page.click('[data-t=scroll]')
    page.click('[data-t=play]'); page.wait_for_timeout(800)
    print('speaking',page.evaluate("()=>[document.querySelectorAll('.sv.sp').length, speechSynthesis.speaking]"))
    page.click('[data-t=play]')
    page.evaluate("()=>Lectio.splitView.bump('z+');Lectio.splitView.bump('z+')")
    page.screenshot(path='/tmp/sp2.png')
    # settings
    page.evaluate("()=>Lectio.go('settings')"); page.wait_for_timeout(500)
    print(page.errors)
