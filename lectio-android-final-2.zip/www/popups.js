/* Popups: main menu (anchored top-right), History sheet, Library sheet, and the verse log behind History */
(function(){
var L=window.Lectio,UI=L.ui,esc=L.esc;
var KEY='lectio-vlog-v1';
function load(){try{return JSON.parse(L.lsGet(KEY)||'[]')}catch(e){return[]}}
var vlog={
  list:load,
  add:function(e){
    var a=load();e.t=Date.now();
    a=a.filter(function(x){return!(x.k===e.k&&x.b===e.b&&x.c===e.c&&x.q===e.q)});
    a.unshift(e);L.lsSet(KEY,JSON.stringify(a.slice(0,80)));
  },
  clear:function(){L.lsSet(KEY,'[]')}
};
L.vlog=vlog;

/* per-version reading progress: which chapters were read in which Bible version.
   Chapters read before this existed (no version recorded) count as read in every version. */
var VK='lectio-vprog-v1';
function vload(){try{return JSON.parse(L.lsGet(VK)||'{}')}catch(e){return{}}}
var vprog={
  has:function(tid,b,c){var d=vload();return!!(d[tid]&&d[tid][b]&&d[tid][b].indexOf(c)>-1)},
  any:function(b,c){var d=vload();return Object.keys(d).some(function(t){return d[t][b]&&d[t][b].indexOf(c)>-1})},
  read:function(tid,b,c){return L.chapterRead(b,c)&&(vprog.has(tid,b,c)||!vprog.any(b,c))},
  mark:function(tid,b,c,on){
    var d=vload(),a=(d[tid]=d[tid]||{})[b]=d[tid][b]||[],i=a.indexOf(c);
    if(on&&i<0)a.push(c);
    if(!on){
      if(i>-1)a.splice(i,1);
      else if(!vprog.any(b,c)){ /* legacy chapter: unmarking it in one version moves the record to the other versions */
        L.bible.versions().forEach(function(v){if(v.id!==tid){var x=(d[v.id]=d[v.id]||{})[b]=d[v.id][b]||[];if(x.indexOf(c)<0)x.push(c)}});
      }
    }
    L.lsSet(VK,JSON.stringify(d));
    return on||vprog.any(b,c)||false;
  },
  count:function(tid){var n=0;for(var b=0;b<BOOKS.length;b++)for(var c=1;c<=BOOKS[b].c;c++)if(vprog.read(tid,b,c))n++;return n},
  total:function(){return BOOKS.reduce(function(a,b){return a+b.c},0)}
};
L.vprog=vprog;

function menu(anchor){
  if(document.querySelector('.umodal.menupop'))return;
  var rows=L.bars?L.bars.rows('menu'):[];
  var m=UI.modal({title:false,cls:'menupop',body:'<div class="alist">'+rows.map(function(r,i){
    return'<button type="button" class="aitem" data-i="'+i+'">'+(L.bars.icon(r.icon,20))+'<span>'+esc(r.label)+'</span></button>'}).join('')+'</div>'});
  m.body.addEventListener('click',function(e){
    var b=e.target.closest('[data-i]');if(!b)return;
    var r=rows[+b.dataset.i];m.close();L.bars.run(r.link);
  });
}
function ago(t){return UI.fmt.ago?UI.fmt.ago(t):new Date(t).toLocaleDateString()}
function history(){
  var a=vlog.list(),h='';
  if(!a.length)h='<p class="muted">Nothing yet. Verses you open or search will show here.</p>';
  else h='<div class="alist">'+a.map(function(e,i){
    var ttl=e.k==='open'?L.bible.refName(e.b,e.c):'“'+esc(e.q)+'”';
    return'<button type="button" class="aitem" data-i="'+i+'">'+UI.icon(e.k==='open'?'book':'search',20)+'<span>'+esc(e.k==='open'?ttl:e.q)+'</span><small>'+esc(e.k==='open'?'opened':'searched')+' · '+esc(ago(e.t))+'</small></button>'}).join('')+'</div>';
  var m=UI.modal({title:'History',sheet:true,body:h+'<div class="prow"><button type="button" class="btn" data-rounds>Reading rounds</button>'+(a.length?'<button type="button" class="btn" data-clear>Clear</button>':'')+'</div>'});
  m.body.addEventListener('click',function(e){
    if(e.target.closest('[data-rounds]')){m.close();L.go('history');return}
    if(e.target.closest('[data-clear]')){vlog.clear();m.close();return}
    var b=e.target.closest('[data-i]');if(!b)return;var x=a[+b.dataset.i];m.close();
    if(x.k==='open')L.openReader(x.b,x.c);else{L.go('search')}
  });
}
function library(){
  var vs=L.bible.versions(),cur=(L.reader&&L.reader.version&&L.reader.version())||vs[0].id;
  var m=UI.modal({title:'Library',sheet:true,body:'<div class="alist">'+vs.map(function(v){
    return'<button type="button" class="aitem vprow" data-v="'+esc(v.id)+'">'+UI.icon('book',20)+'<span>'+esc(v.name)+'<i class="vpbar"><b style="width:'+Math.round(vprog.count(v.id)/vprog.total()*100)+'%"></b></i></span><small>'+vprog.count(v.id)+' / '+vprog.total()+' \u00b7 '+esc(v.short)+'</small></button>'}).join('')+'</div><div class="prow"><button type="button" class="btn" data-go="search">Search</button><button type="button" class="btn" data-go="plans">Plans</button><button type="button" class="btn" data-open>Bible page</button></div>'});
  m.body.addEventListener('click',function(e){
    var g=e.target.closest('[data-go]');if(g){m.close();L.go(g.dataset.go);return}
    if(e.target.closest('[data-open]')){m.close();L.go('lib');return}
    var b=e.target.closest('[data-v]');if(!b)return;m.close();L.openReader(null,null,0,b.dataset.v);
  });
}
L.pop={menu:menu,history:history,library:library};
})();
