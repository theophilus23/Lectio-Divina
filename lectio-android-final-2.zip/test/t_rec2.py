import sys; sys.path.insert(0,'test')
from harness import app
INIT="navigator.mediaDevices.getUserMedia=async function(){const ac=new AudioContext();const o=ac.createOscillator();const d=ac.createMediaStreamDestination();o.connect(d);o.start();return d.stream};"
with app(width=390,height=800,init_script=INIT,permissions=['microphone'],accept_downloads=True) as (page,base):
    page.goto(base);page.wait_for_timeout(800);page.evaluate("Lectio.go('songs')");page.wait_for_timeout(900)
    page.click('.sg-row >> nth=2');page.wait_for_timeout(900);page.click('[data-a="rec"]')
    for i in range(2):
        page.click('[data-r="toggle"]');page.wait_for_timeout(1500);page.click('[data-r="toggle"]');page.wait_for_timeout(600)
    page.click('[data-r="saveall"]');page.wait_for_timeout(500)
    with page.expect_download() as d: page.click('.sg-take >> nth=0 >> [data-r="dl"]')
    print(d.value.suggested_filename, len(open(d.value.path(),'rb').read()))
    print('ERR',page.errors)
