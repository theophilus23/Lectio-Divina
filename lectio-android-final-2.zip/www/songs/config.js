/* Where the generated Songs of Zion tracks live (your Cloudflare R2 public URL, with a trailing slash).
   Leave empty to hide the Listen option. Example: 'https://pub-1234567890abcdef.r2.dev/' */
window.LSONGS_CONFIG={tracksBase:''};
