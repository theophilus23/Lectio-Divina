import sys,json; sys.path.insert(0,'test')
from harness import app
with app(width=360,height=740) as (page,base):
    page.goto(base); page.wait_for_timeout(600)
    page.evaluate("Lectio.openSettings('sc-appearance')"); page.wait_for_timeout(400)
    S=lambda: json.loads(page.evaluate("JSON.stringify({f:Lectio.settings.fonts,c:Lectio.settings.colors,tf:Lectio.settings.tfonts,tc:Lectio.settings.tcolors})"))
    page.click('#apTab [data-tab=colors]')
    secs=page.eval_on_selector_all('#apChips [data-sec]','e=>e.map(x=>x.dataset.sec)'); print('secs',secs)
    # change two colours
    for sec in ['bg','chapter']:
        page.click('#apChips [data-sec=%s]'%sec)
        page.click('#apOpts .sw[data-color]:nth-of-type(4)')
        page.click('#apApply'); page.wait_for_timeout(150)
    print('after set',S()['c'])
    page.click('#apChips [data-sec=chapter]'); page.click('#apReset'); page.click('#apApply'); page.wait_for_timeout(150)
    print('after reset chapter',S()['c'])
    # per-translation
    vs=[s for s in secs if s in ('kjv','te')] or [s for s in secs if s not in ('bg','chapter')][-2:]
    print('version secs',vs)
    for v in ['kjv','te']:
        if 't:'+v in secs:
            page.click('#apChips [data-sec="t:%s"]'%v); page.click('#apOpts .sw[data-color]:nth-of-type(%d)'%(5 if v=='kjv' else 7)); page.click('#apApply'); page.wait_for_timeout(100)
    print('tcolors',S()['tc'])
    page.click('#apChips [data-sec="t:kjv"]'); page.click('#apReset'); page.click('#apApply'); page.wait_for_timeout(100)
    print('after kjv reset',S()['tc'], 'bg kept', S()['c'])
    print(page.errors)
