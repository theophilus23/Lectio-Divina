import sys;sys.path.insert(0,'test')
from harness import app
INIT="""window.__sched=[];window.Capacitor={isNativePlatform:()=>true,Plugins:{LocalNotifications:{checkPermissions:async()=>({display:'granted'}),requestPermissions:async()=>({display:'granted'}),getPending:async()=>({notifications:[]}),cancel:async()=>{},createChannel:async()=>{},schedule:async(o)=>{window.__sched=window.__sched.concat(o.notifications)}}}};"""
with app(width=360,height=740,init_script=INIT) as (page,base):
    page.goto(base); page.wait_for_timeout(500)
    page.evaluate("Lectio.go('settings')"); page.wait_for_timeout(300)
    page.click('[data-sec=sc-reminders]'); page.wait_for_timeout(300)
    page.click('#sc-reminders [data-r=master]'); page.wait_for_timeout(500)
    print('auto scheduled', page.evaluate("__sched.length"), page.evaluate("__sched[0].body"))
    page.click('[data-m=custom]'); page.click('[data-r=cadd]'); page.click('.umodal .btn.main'); page.wait_for_timeout(500)
    print('custom', page.evaluate("__sched.slice(-1)[0].schedule"))
    page.locator('#sc-reminders').scroll_into_view_if_needed(); page.screenshot(path='/tmp/claude-0/rem.png')
    print(page.errors)
