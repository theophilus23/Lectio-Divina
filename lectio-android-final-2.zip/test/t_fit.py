import sys; sys.path.insert(0,'test')
from harness import app
views=['home','lib','read','notes','quiz','prayers','settings','search','plans','prayerwall','history','split']
for (w,h) in [(360,740),(820,1100)]:
    with app(width=w,height=h) as (page,base):
        page.goto(base); page.wait_for_timeout(700)
        for v in views:
            if v=='read': page.evaluate("Lectio.openReader(42,3)")
            else: page.evaluate("Lectio.go('%s')"%v)
            page.wait_for_timeout(450)
            sh=page.evaluate("document.documentElement.scrollHeight"); ov=page.evaluate("document.documentElement.scrollWidth>innerWidth")
            print(w,v,'height',sh,'/',h,'hscroll' if ov else '')
        page.evaluate("Lectio.openReader(42,3)"); page.wait_for_timeout(500); page.screenshot(path='/tmp/fit_%d.png'%w)
        print(page.errors)
