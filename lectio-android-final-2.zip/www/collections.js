/* Small synced collections (notes, prayer points, saved verses, highlights, history ...).
   Each item is a plain object with an `id` and an `u` (last change time, ms). Deleted items stay behind as tombstones {id,u,x:1}
   so a delete on one phone also reaches the others. Everything is kept in localStorage; app.js merges with the cloud copy
   (users/{uid}/stores/{name}) whenever the user is signed in. */
(function(){
'use strict';
var PREFIX='lectio-c-',reg={};
function lsGet(k){try{return window.localStorage.getItem(k)}catch(e){return null}}
function lsSet(k,v){try{window.localStorage.setItem(k,v)}catch(e){}}
function uid(){return Date.now().toString(36)+Math.random().toString(36).slice(2,8)}
var TOMB_MS=90*24*3600*1000;

function make(name){
  if(reg[name])return reg[name];
  var items={},subs=[],loaded=false;
  function load(){
    if(loaded)return;loaded=true;
    try{items=JSON.parse(lsGet(PREFIX+name)||'{}')||{}}catch(e){items={}}
  }
  function persist(){
    var now=Date.now();
    Object.keys(items).forEach(function(k){if(items[k].x&&now-items[k].u>TOMB_MS)delete items[k]});
    lsSet(PREFIX+name,JSON.stringify(items));
  }
  function emit(src){subs.slice().forEach(function(f){try{f(src)}catch(e){}})}
  var c={
    name:name,
    /* live items, as an array (not sorted) */
    list:function(){load();return Object.keys(items).map(function(k){return items[k]}).filter(function(i){return!i.x})},
    get:function(id){load();var i=items[id];return i&&!i.x?i:null},
    /* add or replace. `obj.id` is kept if given, otherwise a new id is made. Returns the stored item. */
    put:function(obj){
      load();
      var it=Object.assign({},obj);
      it.id=it.id||uid();it.u=Date.now();delete it.x;
      items[it.id]=it;persist();emit('local');
      if(window.Lectio&&window.Lectio.pushSoon)window.Lectio.pushSoon();
      return it;
    },
    remove:function(id){
      load();
      if(!items[id])return;
      items[id]={id:id,u:Date.now(),x:1};persist();emit('local');
      if(window.Lectio&&window.Lectio.pushSoon)window.Lectio.pushSoon();
    },
    on:function(fn){subs.push(fn);return function(){var i=subs.indexOf(fn);if(i>-1)subs.splice(i,1)}},
    /* ---- used by app.js for syncing ---- */
    raw:function(){load();return items},
    /* merge items from the cloud; returns true if anything changed here */
    merge:function(remote){
      load();var changed=false;
      Object.keys(remote||{}).forEach(function(k){
        var r=remote[k];if(!r||typeof r!=='object')return;
        var l=items[k];
        if(!l||(+r.u||0)>(+l.u||0)){items[k]=r;changed=true}
      });
      if(changed){persist();emit('sync')}
      return changed;
    },
    clear:function(){items={};loaded=true;persist();emit('clear')}
  };
  reg[name]=c;return c;
}
window.LColl={
  make:make,
  uid:uid,
  names:function(){return Object.keys(reg)},
  all:function(){return Object.keys(reg).map(function(k){return reg[k]})},
  clearAll:function(){
    Object.keys(reg).forEach(function(k){reg[k].clear()});
    try{Object.keys(window.localStorage).forEach(function(k){if(k.indexOf(PREFIX)===0&&!reg[k.slice(PREFIX.length)])window.localStorage.removeItem(k)})}catch(e){}
  }
};
})();
