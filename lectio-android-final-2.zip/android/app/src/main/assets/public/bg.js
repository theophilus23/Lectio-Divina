/* Per-page background photos. Images are shrunk and kept on this phone (IndexedDB); the dim and blur settings are small and kept in localStorage. */
(function(){
'use strict';
var L=window.Lectio,$=L.$;
var PAGES=[['home','Today'],['lib','Library'],['book','Chapters'],['read','Reader'],['settings','Settings']];
var VIEW2PAGE={home:'home',lib:'lib',book:'book',read:'read',settings:'settings',auth:'settings'};
var cfg={},cur='home',urls={},curView='home';
try{cfg=JSON.parse(L.lsGet('lectio-bg-v1')||'{}')||{}}catch(e){cfg={}}
function save(){L.lsSet('lectio-bg-v1',JSON.stringify(cfg))}
function conf(p){return cfg[p]||(cfg[p]={has:false,dim:40,blur:0})}

function getUrl(p){
  if(urls[p])return Promise.resolve(urls[p]);
  return LStore.get('imgs',p).then(function(b){
    if(!b)return null;
    urls[p]=URL.createObjectURL(b);return urls[p];
  }).catch(function(){return null});
}
function dropUrl(p){if(urls[p]){try{URL.revokeObjectURL(urls[p])}catch(e){}delete urls[p]}}

/* paint the page background layer for the visible page */
function paint(el,dim,bl,url){
  if(!url){el.hidden=true;return}
  el.hidden=false;
  el.querySelector('.bgimg').style.backgroundImage='url("'+url+'")';
  el.querySelector('.bgimg').style.filter=bl?'blur('+bl+'px)':'none';
  el.querySelector('.bgdim').style.opacity=String(dim/100);
}
function applyView(view){
  curView=view;
  var p=VIEW2PAGE[view]||'home',c=conf(p),layer=$('bgLayer');
  if(!c.has){layer.hidden=true;document.body.classList.remove('hasbg');return}
  getUrl(p).then(function(u){
    if(curView!==view)return;
    paint(layer,c.dim,c.blur,u);
    document.body.classList.toggle('hasbg',!!u);
  });
}

/* shrink a picked photo so it loads fast and stays small */
function shrink(file){
  return new Promise(function(res,rej){
    var max=1600;
    function draw(src,w,h){
      var s=Math.min(1,max/Math.max(w,h)),cw=Math.round(w*s),ch=Math.round(h*s);
      var cv=document.createElement('canvas');cv.width=cw;cv.height=ch;
      cv.getContext('2d').drawImage(src,0,0,cw,ch);
      cv.toBlob(function(b){b?res(b):rej(new Error('encode'))},'image/jpeg',0.85);
    }
    if(window.createImageBitmap){
      createImageBitmap(file).then(function(bm){draw(bm,bm.width,bm.height)}).catch(viaImg);
    }else viaImg();
    function viaImg(){
      var u=URL.createObjectURL(file),im=new Image();
      im.onload=function(){draw(im,im.naturalWidth,im.naturalHeight);URL.revokeObjectURL(u)};
      im.onerror=function(){URL.revokeObjectURL(u);rej(new Error('image'))};
      im.src=u;
    }
  });
}

/* ---- settings card ---- */
function render(){
  var c=conf(cur),h='<h3>Backgrounds</h3><p class="muted">Pick a photo from your phone for each page. Each page keeps its own photo, dimming and blur. Photos stay on this phone.</p>';
  h+='<div class="chips" role="group" aria-label="Page">'+PAGES.map(function(p){return'<button type="button" class="chip" data-page="'+p[0]+'" aria-pressed="'+(p[0]===cur)+'">'+p[1]+(conf(p[0]).has?' ●':'')+'</button>'}).join('')+'</div>';
  h+='<div class="bgprev" id="bgPrev"><div class="bgimg"></div><div class="bgdim"></div><span class="bgnone"'+(c.has?' hidden':'')+'>No photo for this page</span></div>';
  h+='<div class="row"><button class="btn main" id="bgPick" type="button">Choose photo</button><button class="btn" id="bgRemove" type="button"'+(c.has?'':' disabled')+'>Remove</button></div>';
  h+='<label class="rng">Dimming <b id="bgDimV">'+c.dim+'%</b><input id="bgDim" type="range" min="0" max="90" step="1" value="'+c.dim+'"'+(c.has?'':' disabled')+'></label>';
  h+='<label class="rng">Blur <b id="bgBlurV">'+c.blur+' px</b><input id="bgBlur" type="range" min="0" max="20" step="1" value="'+c.blur+'"'+(c.has?'':' disabled')+'></label>';
  h+='<button class="btn" id="bgAll" type="button"'+(c.has?'':' disabled')+'>Use this photo on all pages</button>';
  h+='<input type="file" id="bgFile" accept="image/*" hidden>';
  $('bgCard').innerHTML=h;
  paintPrev();
}
function paintPrev(){
  var c=conf(cur),el=$('bgPrev');if(!el)return;
  if(!c.has){el.querySelector('.bgimg').style.backgroundImage='none';el.querySelector('.bgdim').style.opacity='0';return}
  getUrl(cur).then(function(u){
    if(!u||!$('bgPrev'))return;
    el.querySelector('.bgimg').style.backgroundImage='url("'+u+'")';
    el.querySelector('.bgimg').style.filter=c.blur?'blur('+Math.round(c.blur/3)+'px)':'none';
    el.querySelector('.bgdim').style.opacity=String(c.dim/100);
  });
}
function live(){
  if((VIEW2PAGE[curView]||'home')===cur)applyView(curView);
}
var card=$('bgCard');
card.addEventListener('click',function(e){
  var pg=e.target.closest('[data-page]');
  if(pg){cur=pg.dataset.page;render();return}
  var t=e.target.closest('button');if(!t)return;
  if(t.id==='bgPick')$('bgFile').click();
  else if(t.id==='bgRemove'){
    LStore.del('imgs',cur).catch(function(){});dropUrl(cur);
    conf(cur).has=false;save();render();live();L.toast('Photo removed');
  }else if(t.id==='bgAll'){
    var src=conf(cur);
    LStore.get('imgs',cur).then(function(b){
      if(!b)return;
      return Promise.all(PAGES.map(function(p){
        if(p[0]===cur)return;
        dropUrl(p[0]);cfg[p[0]]={has:true,dim:src.dim,blur:src.blur};
        return LStore.set('imgs',p[0],b);
      }));
    }).then(function(){save();render();live();L.toast('Photo set on all pages')}).catch(function(){L.toast('Could not save the photo')});
  }
});
card.addEventListener('input',function(e){
  var c=conf(cur);
  if(e.target.id==='bgDim'){c.dim=+e.target.value;$('bgDimV').textContent=c.dim+'%';save();paintPrev();live()}
  else if(e.target.id==='bgBlur'){c.blur=+e.target.value;$('bgBlurV').textContent=c.blur+' px';save();paintPrev();live()}
});
card.addEventListener('change',function(e){
  if(e.target.id!=='bgFile')return;
  var f=e.target.files&&e.target.files[0];e.target.value='';
  if(!f)return;
  if(!/^image\//.test(f.type)){L.toast('Choose an image file');return}
  shrink(f).then(function(b){
    return LStore.set('imgs',cur,b);
  }).then(function(){
    dropUrl(cur);var c=conf(cur);c.has=true;if(c.dim==null)c.dim=40;save();render();live();L.toast('Photo saved');
  }).catch(function(){L.toast('Could not read that photo')});
});

L.onShow.push(function(name){
  applyView(name);
  if(name==='settings')render();
});
})();
