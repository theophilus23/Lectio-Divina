/* Community: a church / group profile with its OWN walls, separate from the open prayer wall.
   communities/{code}                  profile: name, about, emoji, pin (announcement), owner, admins[], pubPrayers, pubTestimonies
   communities/{code}/prayers          requests (gender m|f); seen by admins (+ the author) unless pubPrayers is on
   communities/{code}/testimonies      testimonies; seen by admins (+ the author) unless pubTestimonies is on
   communities/{code}/links            YouTube videos / channel / social posts / other links, added by admins, always public
   communities/{code}/invites/{code}   admin invite codes (owner makes them)
   Which communities I follow is a small synced list: L.coll('mycomm'). */
(function(){
'use strict';
var L=window.Lectio,esc=L.esc,UI=L.ui;
var mine=L.coll('mycomm');
var S={mode:'list',cid:'',c:null,tab:'prayers',g:'all',rows:null,err:'',busy:false,mineOnly:false};
var GEN=[['m','Men'],['f','Women']];
var LT=[['video','YouTube video'],['channel','YouTube channel'],['social','Social post'],['link','Other link']];
var el=L.registerView({id:'community',title:'Community',menu:{label:'Community',icon:'people',group:'pray',order:9},
  show:function(){if(S.mode==='detail'&&S.cid)openCommunity(S.cid,true);else{S.mode='list';draw()}},leave:function(){}});

function uid(){return L.user?L.user.uid:null}
function db(){return L.fb.db}
function isAdmin(){return !!(S.c&&uid()&&(S.c.admins||[]).indexOf(uid())>-1)}
function isOwner(){return !!(S.c&&uid()&&S.c.owner===uid())}
function genName(g){return g==='m'?'Men':g==='f'?'Women':''}
function portalUrl(code){
  var id=(window.LECTIO_FIREBASE||{}).projectId;
  return id?'https://'+id+'.web.app/?c='+encodeURIComponent(code):'';
}
function newCode(){var a='ABCDEFGHJKLMNPQRSTUVWXYZ23456789',s='';for(var i=0;i<6;i++)s+=a[Math.floor(Math.random()*a.length)];return s}
function cleanUrl(u){u=String(u||'').trim();if(!u)return'';if(!/^https?:\/\//i.test(u))u='https://'+u;try{var x=new URL(u);return/^https?:$/.test(x.protocol)?x.href:''}catch(e){return''}}
function ytId(u){var m=String(u).match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?(?:.*&)?v=|shorts\/|live\/|embed\/))([\w-]{11})/);return m?m[1]:''}
function guessType(u){
  if(ytId(u))return'video';
  if(/youtube\.com\/(@|channel\/|c\/|user\/)/i.test(u))return'channel';
  if(/facebook\.|fb\.com|instagram\.|twitter\.|x\.com|threads\.|t\.me|whatsapp\.|tiktok\./i.test(u))return'social';
  return'link';
}
function typeName(t){var x=LT.filter(function(a){return a[0]===t})[0];return x?x[1]:'Link'}
function host(u){try{return new URL(u).hostname.replace(/^www\./,'')}catch(e){return u}}

/* ================= screens ================= */
function draw(){S.mode==='detail'?drawDetail():drawList()}
function drawList(){
  var list=mine.list().sort(function(a,b){return(b.u||0)-(a.u||0)});
  var h='<div class="head"><div class="eyebrow">Your church or group</div><h1>Community</h1><p>Each community has its own prayer requests and testimonies, kept private to its leaders unless they choose to share them.</p></div>';
  h+='<div class="row cm-acts"><button type="button" class="btn main" data-a="create">Create a community</button><button type="button" class="btn" data-a="join">Join with a code</button></div>';
  if(!L.fb.on)h+='<p class="empty">Community needs the online setup (Firebase). See FIREBASE_SETUP.md.</p>';
  else if(!list.length)h+='<p class="empty">No communities yet.<br>Create one for your church, or enter the code a leader shared with you.</p>';
  else h+='<div class="list">'+list.map(function(c){
    return'<button type="button" class="li cm-row" data-open="'+esc(c.id)+'"><span class="cm-av">'+esc(c.emoji||'✝')+'</span><span class="cm-t"><b>'+esc(c.name||c.id)+'</b><small>Code '+esc(c.id)+(c.role==='admin'?' · Leader':'')+'</small></span>'+UI.icon('chevron',16)+'</button>'}).join('')+'</div>';
  el.innerHTML=h;
}
async function openCommunity(code,quiet){
  code=String(code||'').trim().toUpperCase();
  if(!code)return;
  if(!L.fb.on){L.toast('Needs the online setup');return}
  S.mode='detail';S.cid=code;if(!quiet){S.tab='prayers';S.g='all'}S.rows=null;S.err='';
  el.innerHTML='<p class="empty">Loading…</p>';
  try{
    if(!L.user)await L.fb.auth.signInAnonymously();
    var d=await db().collection('communities').doc(code).get();
    if(!d.exists){S.mode='list';L.toast('No community with that code');drawList();return}
    S.c=Object.assign({id:d.id},d.data());
  }catch(e){S.mode='list';L.toast('Could not open. Check your connection.');drawList();return}
  remember();drawDetail();loadTab();
}
function remember(){
  if(!S.c)return;
  mine.put({id:S.c.id,name:S.c.name,emoji:S.c.emoji||'',role:isAdmin()?'admin':'member'});
}
function drawDetail(){
  var c=S.c;if(!c){drawList();return}
  var adm=isAdmin();
  var h='<button type="button" class="back" data-a="list">'+UI.icon('chevron',16).replace('class="ic"','class="ic n-flip"')+'Communities</button>';
  h+='<div class="card cm-prof"><div class="cm-top"><span class="cm-av big">'+esc(c.emoji||'✝')+'</span><div><h1 class="cm-name">'+esc(c.name)+'</h1><div class="muted">Code <b>'+esc(c.id)+'</b>'+(adm?' · you lead this':'')+'</div></div></div>';
  if(c.about)h+='<p class="cm-about">'+esc(c.about).replace(/\n/g,'<br>')+'</p>';
  if(c.pin)h+='<div class="cm-pin"><b>Announcement</b><p>'+esc(c.pin).replace(/\n/g,'<br>')+'</p></div>';
  h+='<div class="row cm-acts"><button type="button" class="btn" data-a="qr">'+UI.icon('qr',16)+' QR code</button>'+(adm?'<button type="button" class="btn" data-a="manage">Manage</button>':'<button type="button" class="btn" data-a="leave">Leave</button>')+'</div>'+(adm?'':'<div class="linkrow"><button type="button" class="linkbtn" data-a="claim">Have a leader code? Become a leader</button></div>')+'</div>';
  h+='<div class="seg cm-tabs">'+[['prayers','Prayers'],['testi','Testimonies'],['links','Links']].map(function(t){return'<button type="button" data-tab="'+t[0]+'" aria-pressed="'+(S.tab===t[0])+'">'+t[1]+'</button>'}).join('')+'</div>';
  h+='<div id="cmBody"></div>';
  el.innerHTML=h;drawBody();
}
function shownFlag(){return S.tab==='prayers'?!!S.c.pubPrayers:S.tab==='testi'?!!S.c.pubTestimonies:true}
function drawBody(){
  var box=el.querySelector('#cmBody');if(!box)return;
  var adm=isAdmin(),h='';
  if(S.tab==='links'){
    if(adm)h+='<button type="button" class="btn main cm-post" data-a="addlink">+ Add a link</button>';
    if(S.rows===null)h+='<p class="empty">Loading…</p>';
    else if(!S.rows.length)h+='<p class="empty">'+(adm?'Share your YouTube videos, channel and social posts here.':'No links yet.')+'</p>';
    else h+='<div class="list">'+S.rows.map(linkCard).join('')+'</div>';
    box.innerHTML=h;return;
  }
  var pray=S.tab==='prayers';
  h+='<button type="button" class="btn main cm-post" data-a="post">'+(pray?'Post a prayer request':'Share a testimony')+'</button>';
  var pub=shownFlag();
  if(adm)h+='<label class="row cm-vis"><span><b>Show to everyone</b><small>'+(pub?'Everyone with the code can read these.':'Only you and the other leaders can read these.')+'</small></span><input type="checkbox" data-a="vis"'+(pub?' checked':'')+'></label>';
  else if(!pub)h+='<p class="note cm-priv">'+(pray?'Prayer requests here go to the community leaders.':'Testimonies here go to the community leaders.')+' You can see and delete your own below.</p>';
  h+='<div class="seg cm-gen">'+[['all','Everyone']].concat(GEN).map(function(t){return'<button type="button" data-g="'+t[0]+'" aria-pressed="'+(S.g===t[0])+'">'+t[1]+'</button>'}).join('')+'</div>';
  if(S.err)h+='<p class="empty">'+esc(S.err)+'</p>';
  else if(S.rows===null)h+='<p class="empty">Loading…</p>';
  else{
    var rows=S.rows.filter(function(r){return S.g==='all'||r.g===S.g});
    if(!rows.length)h+='<p class="empty">Nothing here yet.</p>';
    else h+='<div class="list">'+rows.map(postCard).join('')+'</div>';
  }
  box.innerHTML=h;
}
function postCard(r){
  var me=uid(),mineP=me&&r.uid===me,adm=isAdmin(),rc=r.r||{},n=Object.keys(rc).length;
  var h='<div class="li cm-post-c" data-id="'+esc(r.id)+'"><div class="row2"><b class="t">'+esc(r.title||(S.tab==='prayers'?'Prayer request':'Testimony'))+'</b><span class="tag">'+genName(r.g)+'</span></div>';
  h+='<div class="meta muted">'+esc(r.name||'Anonymous')+' · '+UI.fmt.ago(r.t)+(mineP?' · yours':'')+'</div>';
  if(r.text)h+='<div class="body">'+esc(r.text).replace(/\n/g,'<br>')+'</div>';
  h+='<div class="acts"><button type="button" class="chip" data-a="pray" aria-pressed="'+(!!(me&&rc[me]))+'">'+(S.tab==='prayers'?'🙏 Praying':'🙌 Amen')+(n?' '+n:'')+'</button>';
  if(mineP||adm)h+='<button type="button" class="btn danger" data-a="del">'+(mineP?'Delete':'Remove')+'</button>';
  h+='</div></div>';return h;
}
function linkCard(r){
  var id=r.type==='video'?ytId(r.url):'',adm=isAdmin();
  return'<div class="li cm-link" data-id="'+esc(r.id)+'">'
    +(id?'<a class="cm-thumb" href="'+esc(r.url)+'" target="_blank" rel="noopener"><img alt="" loading="lazy" src="https://img.youtube.com/vi/'+id+'/mqdefault.jpg"><span>▶</span></a>':'')
    +'<div class="row2"><b class="t">'+esc(r.title||host(r.url))+'</b><span class="tag">'+esc(typeName(r.type))+'</span></div>'
    +(r.note?'<div class="body">'+esc(r.note)+'</div>':'')
    +'<div class="acts"><a class="btn main" href="'+esc(r.url)+'" target="_blank" rel="noopener">Open '+esc(host(r.url))+'</a>'+(adm?'<button type="button" class="btn danger" data-a="dellink">Remove</button>':'')+'</div></div>';
}

/* ================= data ================= */
async function loadTab(){
  var tab=S.tab,col=tab==='links'?'links':tab==='testi'?'testimonies':'prayers';
  S.rows=null;S.err='';drawBody();
  var ref=db().collection('communities').doc(S.cid).collection(col),rows=[];
  async function run(q){var s=await q.get();s.forEach(function(d){var x=d.data();x.id=d.id;rows.push(x)})}
  try{
    if(col==='links'||isAdmin()||shownFlag())await run(ref.limit(200));
    else await run(ref.where('uid','==',uid()||'-').limit(100));
  }catch(e){
    /* the leaders switched it off, or I am not allowed to list everything: fall back to my own posts */
    rows=[];
    try{await run(ref.where('uid','==',uid()||'-').limit(100))}catch(e2){S.err='Could not load. Check your connection.'}
  }
  rows.sort(function(a,b){return(b.t||0)-(a.t||0)});
  if(tab===S.tab){S.rows=rows;drawBody()}
}
async function compose(){
  var id=await L.ensureIdentity({reason:'to post here'});if(!id)return;
  var pray=S.tab==='prayers',g0=L.lsGet('lectio-gender')||'';
  var m=UI.modal({title:pray?'Post a prayer request':'Share a testimony',body:
    '<div class="field">I am<div class="seg" id="cmG">'+GEN.map(function(x){return'<button type="button" data-g="'+x[0]+'" aria-pressed="'+(g0===x[0])+'">'+x[1]+'</button>'}).join('')+'</div></div>'+
    '<label class="field">Title<input id="cmT" maxlength="80" placeholder="'+(pray?'What should we pray for?':'What did God do?')+'"></label>'+
    '<label class="field">Details<textarea id="cmX" class="ta" rows="5" maxlength="'+(pray?1500:2000)+'"></textarea></label>'+
    '<label class="row"><span>Post without my name</span><input type="checkbox" id="cmA"></label>'+
    '<p class="note">'+(shownFlag()?'Everyone in this community can read this.':'Only the community leaders can read this.')+'</p>',
    actions:[{label:'Cancel'},{label:'Post',kind:'main',keep:true,on:async function(close,mod){
      var gb=mod.body.querySelector('#cmG [aria-pressed=true]'),g=gb?gb.dataset.g:'';
      var t=mod.body.querySelector('#cmT').value.trim(),x=mod.body.querySelector('#cmX').value.trim();
      if(!g){L.toast('Choose Men or Women');return}
      if(!x){L.toast('Write something first');return}
      try{
        await db().collection('communities').doc(S.cid).collection(pray?'prayers':'testimonies').add({uid:id.uid,t:Date.now(),g:g,title:t.slice(0,80),text:x.slice(0,pray?1500:2000),name:mod.body.querySelector('#cmA').checked?'Anonymous':String(id.name||'Member').slice(0,40),r:{}});
        L.lsSet('lectio-gender',g);close();L.toast('Posted');remember();loadTab();
      }catch(e){L.toast('Could not post. Try again.')}
    }}]});
  m.body.addEventListener('click',function(e){var b=e.target.closest('#cmG button');if(!b)return;m.body.querySelectorAll('#cmG button').forEach(function(x){x.setAttribute('aria-pressed',String(x===b))})});
}
async function addLink(){
  var m=UI.modal({title:'Add a link',body:
    '<label class="field">Link (YouTube, Facebook, Instagram, any page)<input id="lkU" type="url" inputmode="url" placeholder="https://…"></label>'+
    '<label class="field">Title<input id="lkT" maxlength="100" placeholder="Sunday service"></label>'+
    '<div class="field">Type<div class="chips" id="lkType">'+LT.map(function(t,i){return'<button type="button" class="chip" data-t="'+t[0]+'" aria-pressed="false">'+t[1]+'</button>'}).join('')+'</div><small class="muted">Left unchosen, it is picked from the link.</small></div>'+
    '<label class="field">Note (optional)<input id="lkN" maxlength="200"></label>',
    actions:[{label:'Cancel'},{label:'Add',kind:'main',keep:true,on:async function(close,mod){
      var u=cleanUrl(mod.body.querySelector('#lkU').value);
      if(!u){L.toast('Enter a web link');return}
      var tb=mod.body.querySelector('#lkType [aria-pressed=true]'),type=tb?tb.dataset.t:guessType(u);
      try{
        await db().collection('communities').doc(S.cid).collection('links').add({url:u,title:mod.body.querySelector('#lkT').value.trim().slice(0,100),type:type,note:mod.body.querySelector('#lkN').value.trim().slice(0,200),t:Date.now(),by:uid()});
        close();L.toast('Link added');loadTab();
      }catch(e){L.toast('Could not add. Only leaders can add links.')}
    }}]});
  m.body.addEventListener('click',function(e){var b=e.target.closest('#lkType button');if(!b)return;var on=b.getAttribute('aria-pressed')==='true';m.body.querySelectorAll('#lkType button').forEach(function(x){x.setAttribute('aria-pressed','false')});b.setAttribute('aria-pressed',String(!on))});
}
async function createCommunity(){
  if(!L.user||L.user.isAnonymous){L.toast('Sign in to your account first. That keeps you in charge of the community.');return}
  var m=UI.modal({title:'Create a community',body:
    '<label class="field">Name of the church or group<input id="ccN" maxlength="60" placeholder="Grace Fellowship"></label>'+
    '<label class="field">About<textarea id="ccA" class="ta" rows="4" maxlength="600" placeholder="Where and when you meet, who you are…"></textarea></label>'+
    '<label class="field">Symbol (one emoji, optional)<input id="ccE" maxlength="4" placeholder="✝"></label>',
    actions:[{label:'Cancel'},{label:'Create',kind:'main',keep:true,on:async function(close,mod){
      var name=mod.body.querySelector('#ccN').value.trim();if(!name){L.toast('Add a name');return}
      try{
        var code='',tries=0;
        do{code=newCode();var ex=await db().collection('communities').doc(code).get();if(!ex.exists)break}while(++tries<6);
        await db().collection('communities').doc(code).set({name:name.slice(0,60),about:mod.body.querySelector('#ccA').value.trim().slice(0,600),emoji:mod.body.querySelector('#ccE').value.trim().slice(0,4),pin:'',owner:uid(),admins:[uid()],pubPrayers:false,pubTestimonies:false,t:Date.now()});
        close();L.toast('Community created');openCommunity(code);
      }catch(e){L.toast('Could not create. Try again.')}
    }}]});
}
async function joinCommunity(){
  var v=await UI.prompt({title:'Join a community',label:'Enter the code from your church (or scan its QR code with your phone camera).',placeholder:'ABC123',ok:'Open',max:10});
  if(v)openCommunity(v);
}
/* ================= leaders ================= */
function manage(){
  var c=S.c,m=UI.actionSheet({title:'Manage',items:[
    {label:'Edit profile',icon:'edit',on:editProfile},
    {label:'Announcement',icon:'bell',on:editPin},
    isOwner()?{label:'Invite another leader',icon:'people',on:inviteAdmin}:null,
    {label:'Share the QR code',icon:'qr',on:qr}
  ].filter(Boolean)});
}
async function editProfile(){
  var c=S.c,m=UI.modal({title:'Edit profile',body:
    '<label class="field">Name<input id="epN" maxlength="60" value="'+esc(c.name)+'"></label>'+
    '<label class="field">About<textarea id="epA" class="ta" rows="4" maxlength="600">'+esc(c.about||'')+'</textarea></label>'+
    '<label class="field">Symbol<input id="epE" maxlength="4" value="'+esc(c.emoji||'')+'"></label>',
    actions:[{label:'Cancel'},{label:'Save',kind:'main',keep:true,on:async function(close,mod){
      var f={name:mod.body.querySelector('#epN').value.trim().slice(0,60),about:mod.body.querySelector('#epA').value.trim().slice(0,600),emoji:mod.body.querySelector('#epE').value.trim().slice(0,4)};
      if(!f.name){L.toast('Add a name');return}
      try{await db().collection('communities').doc(c.id).update(f);Object.assign(c,f);remember();close();drawDetail();loadTab()}catch(e){L.toast('Could not save')}
    }}]});
}
async function editPin(){
  var v=await UI.prompt({title:'Announcement',label:'Shown at the top of the community. Leave empty to remove it.',value:S.c.pin||'',multiline:true,ok:'Save',max:400});
  if(v===null)return;
  try{await db().collection('communities').doc(S.cid).update({pin:v.trim().slice(0,400)});S.c.pin=v.trim().slice(0,400);drawDetail();loadTab()}catch(e){L.toast('Could not save')}
}
async function inviteAdmin(){
  var a='ABCDEFGHJKLMNPQRSTUVWXYZ23456789',code='';for(var i=0;i<8;i++)code+=a[Math.floor(Math.random()*a.length)];
  try{await db().collection('communities').doc(S.cid).collection('invites').doc(code).set({t:Date.now(),by:uid()})}catch(e){L.toast('Could not make a code');return}
  UI.modal({title:'Leader invite code',body:'<p class="muted" style="margin-top:0">Give this code to someone you trust. In Community they choose <b>Join with a code</b>, open this community, then tap <b>Become a leader</b> and enter it. Leaders can read the private walls, add links, and remove posts.</p><div class="cm-code">'+esc(code)+'</div>',
    actions:[{label:'Copy',on:function(){UI.copy(code).then(function(ok){L.toast(ok?'Copied':'Could not copy')});return false}},{label:'Share',kind:'main',on:function(){UI.share({title:'Leader code',text:'Leader code for '+S.c.name+' ('+S.cid+'): '+code});return false}}]});
}
async function claimAdmin(){
  var v=await UI.prompt({title:'Become a leader',label:'Enter the invite code a leader gave you.',ok:'Continue',max:12});
  if(!v)return;
  var id=await L.ensureIdentity({reason:'to become a leader'});if(!id)return;
  if(L.user.isAnonymous){L.toast('Sign in to your account first so you keep your role.');return}
  try{
    var code=v.trim().toUpperCase();
    await db().collection('communities').doc(S.cid).update({admins:firebase.firestore.FieldValue.arrayUnion(uid()),claim:code});
    L.toast('You are now a leader');openCommunity(S.cid,true);
  }catch(e){L.toast('That code did not work')}
}
function qr(){
  var url=portalUrl(S.cid),c=S.c;
  if(!url){UI.modal({title:'QR code',body:'<p class="mtext">This needs the online setup (Firebase). See FIREBASE_SETUP.md.</p>',actions:[{label:'OK'}]});return}
  var m=UI.modal({title:c.name,sheet:true,body:
    '<p class="muted" style="margin-top:0">Anyone who scans this lands on '+esc(c.name)+'’s page. No app needed. They can post a prayer request or a testimony, and see the links you share.</p>'+
    '<div id="cmQr" class="cm-qr"></div><p class="note" style="word-break:break-all;text-align:center">'+esc(url)+'</p>',
    actions:[{label:'Copy link',on:function(){UI.copy(url).then(function(ok){L.toast(ok?'Link copied':'Could not copy')});return false}},
      {label:'Save image',on:function(){saveQr(m.body.querySelector('#cmQr svg'),c);return false}},
      {label:'Share',kind:'main',on:function(){UI.share({title:c.name,text:c.name+': post a prayer request or testimony, no app needed.\n'+url});return false}}]});
  try{var q=qrcode(0,'M');q.addData(url);q.make();m.body.querySelector('#cmQr').innerHTML=q.createSvgTag({cellSize:6,margin:2})}catch(e){m.body.querySelector('#cmQr').textContent='Could not draw the QR code.'}
}
/* download the QR as a PNG with the community name above it, ready to print */
function saveQr(svg,c){
  if(!svg)return;
  var xml=new XMLSerializer().serializeToString(svg),img=new Image();
  img.onload=function(){
    var W=720,pad=40,qs=W-pad*2,cv=document.createElement('canvas');cv.width=W;cv.height=W+120;
    var g=cv.getContext('2d');g.fillStyle='#fff';g.fillRect(0,0,cv.width,cv.height);
    g.fillStyle='#222';g.font='600 40px Georgia,serif';g.textAlign='center';g.fillText(c.name,W/2,70,W-60);
    g.font='24px sans-serif';g.fillStyle='#666';g.fillText('Scan to post a prayer request or testimony',W/2,108,W-60);
    g.imageSmoothingEnabled=false;g.drawImage(img,pad,130,qs,qs);
    cv.toBlob(function(b){
      var f=new File([b],'community-'+c.id+'.png',{type:'image/png'});
      if(navigator.canShare&&navigator.canShare({files:[f]})){navigator.share({files:[f],title:c.name}).catch(function(){})}
      else{var a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=f.name;document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove()},500)}
    },'image/png');
  };
  img.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(xml.indexOf('xmlns=')<0?xml.replace('<svg','<svg xmlns="http://www.w3.org/2000/svg"'):xml);
}
/* ================= events ================= */
el.addEventListener('click',async function(e){
  var t=e.target.closest('button,input[data-a]');if(!t)return;
  if(t.dataset.open){openCommunity(t.dataset.open);return}
  var a=t.dataset.a;
  if(t.dataset.tab){S.tab=t.dataset.tab;S.g='all';drawDetail();loadTab();return}
  if(t.dataset.g!==undefined&&t.closest('.cm-gen')){S.g=t.dataset.g;drawBody();return}
  if(a==='create')createCommunity();
  else if(a==='join')joinCommunity();
  else if(a==='list'){S.mode='list';S.cid='';S.c=null;drawList()}
  else if(a==='qr')qr();
  else if(a==='manage')manage();
  else if(a==='leave')UI.confirm('Leave '+S.c.name+'? Your posts stay.',{ok:'Leave'}).then(function(y){if(y){mine.remove(S.cid);S.mode='list';drawList()}});
  else if(a==='post')compose();
  else if(a==='addlink')addLink();
  else if(a==='vis'){
    var f=S.tab==='prayers'?'pubPrayers':'pubTestimonies',on=t.checked;
    try{await db().collection('communities').doc(S.cid).update({[f]:on});S.c[f]=on;L.toast(on?'Now visible to everyone':'Now private to leaders');loadTab()}catch(x){t.checked=!on;L.toast('Could not change')}
  }
  else if(a==='pray'||a==='del'||a==='dellink'){
    var li=t.closest('[data-id]'),r=li&&(S.rows||[]).filter(function(x){return x.id===li.dataset.id})[0];if(!r)return;
    var col=S.tab==='links'?'links':S.tab==='testi'?'testimonies':'prayers',ref=db().collection('communities').doc(S.cid).collection(col).doc(r.id);
    if(a==='pray'){
      var id=await L.ensureIdentity({reason:'to react'});if(!id)return;
      var FV=firebase.firestore.FieldValue;r.r=r.r||{};
      try{if(r.r[id.uid]){await ref.update({['r.'+id.uid]:FV.delete()});delete r.r[id.uid]}else{await ref.update({['r.'+id.uid]:'🙏'});r.r[id.uid]='🙏'}drawBody()}catch(x){L.toast('Could not save')}
    }else{
      var ok=await UI.confirm(a==='dellink'?'Remove this link?':'Delete this post?',{ok:'Delete',danger:true});if(!ok)return;
      try{await ref.delete();S.rows=S.rows.filter(function(x){return x!==r});drawBody();L.toast('Removed')}catch(x){L.toast('Could not remove')}
    }
  }
});
/* "Become a leader" lives in the Manage-less view: a small link for members */
el.addEventListener('click',function(e){var t=e.target.closest('[data-a="claim"]');if(t)claimAdmin()});
L.community={open:function(code){S.mode='detail';S.cid=String(code||'').toUpperCase();L.go('community')},claim:claimAdmin};
})();
