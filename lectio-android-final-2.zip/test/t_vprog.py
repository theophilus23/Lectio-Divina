import sys; sys.path.insert(0,'test')
from harness import app
with app(width=360,height=740) as (page,base):
    page.goto(base); page.wait_for_timeout(700)
    page.evaluate("Lectio.openReader(42,3)"); page.wait_for_timeout(600)
    page.click('#rMark'); page.wait_for_timeout(200)
    print('KJV read:',page.inner_text('#rMark'),'global',page.evaluate("Lectio.chapterRead(42,3)"))
    page.evaluate("Lectio.openReader(42,3,0,'te')"); page.wait_for_timeout(600)
    print('Telugu view:',page.inner_text('#rMark'))
    page.click('#rMark'); page.wait_for_timeout(200)
    page.click('#rMark'); page.wait_for_timeout(200)  # unmark telugu
    print('after unmark te:',page.inner_text('#rMark'),'global',page.evaluate("Lectio.chapterRead(42,3)"))
    page.evaluate("Lectio.openReader(42,3,0,'kjv')"); page.wait_for_timeout(500)
    print('KJV still:',page.inner_text('#rMark'))
    page.evaluate('Lectio.pop.library()'); page.wait_for_timeout(300); page.screenshot(path='/tmp/v0.png')
    print(page.errors)
