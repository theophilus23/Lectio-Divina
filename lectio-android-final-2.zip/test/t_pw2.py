import sys; sys.path.insert(0,'test')
from harness import app
with app(width=360,height=740) as (page,base):
    page.goto(base); page.wait_for_timeout(600)
    page.evaluate("window.__mock.signInAs('Leo')"); page.wait_for_timeout(300)
    page.evaluate("Lectio.go('prayerwall')"); page.wait_for_timeout(400)
    page.evaluate("Lectio.prayerwall.compose({title:'Healing',text:'Pray for mom',cat:'Health'})"); page.wait_for_timeout(300)
    page.fill('#pwT','Healing for mom'); page.click('.umodal button.main'); page.wait_for_timeout(600)
    page.click('[data-a=react]'); page.wait_for_timeout(200); page.click('[data-e="🙏"]'); page.wait_for_timeout(300)
    page.click('[data-a=ans]'); page.wait_for_timeout(200)
    page.keyboard.type('Thank you all'); page.click('.umodal button.main'); page.wait_for_timeout(600)
    print(page.inner_text('#v-prayerwall')[:400]); print(page.errors)
    page.screenshot(path='/tmp/pw.png')
