import sys; sys.path.insert(0,'test')
from harness import app
with app(width=390,height=800) as (page, base):
    page.goto(base); page.wait_for_timeout(800)
    page.add_style_tag(content="#fdock{display:none!important}")
    page.evaluate("Lectio.go('songs')"); page.wait_for_timeout(1200)
    page.fill('#v-songs input >> visible=true','225'); page.wait_for_timeout(800)
    page.click('.sg-row >> nth=0'); page.wait_for_timeout(1000)
    page.screenshot(path='/tmp/z225.png')
    print(page.errors)
