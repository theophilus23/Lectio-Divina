/* Same project as the app. Copy your real www/firebase-config.js here and rename it
   firebase-config.js (this file, like that one, is gitignored — see FIREBASE_SETUP.md). */
window.LECTIO_FIREBASE = {
  apiKey: "PASTE_API_KEY",
  authDomain: "PASTE_PROJECT_ID.firebaseapp.com",
  projectId: "PASTE_PROJECT_ID",
  storageBucket: "PASTE_PROJECT_ID.appspot.com",
  messagingSenderId: "PASTE_SENDER_ID",
  appId: "PASTE_APP_ID"
};
