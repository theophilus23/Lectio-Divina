import sys,os,json
sys.path.insert(0,'test')
from harness import app
MAN={"versions":[{"id":"kjv","name":"King James Version","short":"KJV","lang":"en-US","dir":"kjv"},{"id":"te","name":"Telugu","short":"తెలుగు","lang":"te-IN","dir":"te"},{"id":"k2","name":"KJV copy","short":"K2","lang":"en-US","dir":"kjv"}]}
with app(width=360,height=740) as (page,base):
    page.route('**/bibles/manifest.json',lambda r:r.fulfill(body=json.dumps(MAN),content_type='application/json'))
    page.goto(base); page.wait_for_timeout(800)
    page.evaluate('Lectio.go("settings")'); page.wait_for_timeout(200)
    print('menu',page.eval_on_selector_all('.ditem','e=>e.map(x=>x.textContent)'))
    page.screenshot(path='/tmp/claude-0/menu.png')
    for v in ['history','saved','notes','mypray','settings']:
        page.evaluate(f"Lectio.go('{v}')"); page.wait_for_timeout(400)
        page.screenshot(path=f'/tmp/claude-0/p_{v}.png')
    page.evaluate("Lectio.openReader(42,3)"); page.wait_for_timeout(800)
    page.screenshot(path='/tmp/claude-0/reader.png')
    # long press verse
    box=page.locator('.vs').nth(2).bounding_box()
    page.mouse.move(box['x']+100,box['y']+10); page.mouse.down(); page.wait_for_timeout(700); page.mouse.up(); page.wait_for_timeout(300)
    page.screenshot(path='/tmp/claude-0/reader_sel.png')
    print('vbar hidden?',page.evaluate("document.getElementById('vbar')&&document.getElementById('vbar').hidden"))
    print('ERRORS',page.errors)
