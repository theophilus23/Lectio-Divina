import sys,os,threading,socketserver,http.server,functools; sys.path.insert(0,'test')
from harness import MOCK,FAKECFG,ROOT
from playwright.sync_api import sync_playwright
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=os.path.join(ROOT,'portal')))
port=srv.server_address[1]; threading.Thread(target=srv.serve_forever,daemon=True).start()
with sync_playwright() as p:
    b=p.chromium.launch(args=['--no-sandbox']); pg=b.new_page(viewport={'width':390,'height':800}); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/vendor/firebase-app-compat.js',lambda r:r.fulfill(body=MOCK,content_type='application/javascript'))
    pg.route('**/vendor/firebase-auth-compat.js',lambda r:r.fulfill(body='',content_type='application/javascript'))
    pg.route('**/vendor/firebase-firestore-compat.js',lambda r:r.fulfill(body='',content_type='application/javascript'))
    pg.route('**/firebase-config.js',lambda r:r.fulfill(body=FAKECFG,content_type='application/javascript'))
    pg.add_init_script("window.addEventListener('DOMContentLoaded',()=>{})")
    pg.goto('http://127.0.0.1:%d/index.html?c=ABC234'%port); pg.wait_for_timeout(300)
    # seed after mock loads, then reload client logic by re-navigating is not possible: seed via init script instead
    pg.add_init_script("var _t=setInterval(()=>{if(window.__mock){clearInterval(_t);window.__mock.seed('communities/ABC234',{name:'Grace Fellowship',about:'Sundays 9am',owner:'x',admins:['x'],pin:'Camp on Friday',pubPrayers:false})}},1)")
    pg.goto('http://127.0.0.1:%d/index.html?c=ABC234'%port); pg.wait_for_timeout(1200)
    print('name:',pg.inner_text('#cmName') if pg.is_visible('#cmName') else 'hidden')
    pg.click('#cmGen [data-g=f]'); pg.fill('#fText','Please pray for my mother'); pg.click('#btnPost'); pg.wait_for_timeout(800)
    print('thanks visible',pg.is_visible('#vThanks'),pg.inner_text('#vThanks h2'))
    print(pg.evaluate("Object.keys(__mock.dump('communities/ABC234/prayers'))").__len__(),'prayer doc(s)')
    pg.screenshot(path='/tmp/pc.png'); print(errs); b.close()
srv.shutdown()
