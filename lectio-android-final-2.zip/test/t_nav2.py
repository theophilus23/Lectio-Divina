import sys; sys.path.insert(0,'test')
from harness import app
with app(width=360,height=740) as (page,base):
    page.goto(base); page.wait_for_timeout(800)
    page.add_style_tag(content="#fdock{display:none!important}")
    v=lambda: page.evaluate("()=>Lectio.view")
    page.evaluate("()=>Lectio.openReader(42,3)"); page.wait_for_timeout(600)
    page.evaluate("()=>Lectio.go('notes')"); page.wait_for_timeout(300)
    page.evaluate("()=>Lectio.go('settings')"); page.wait_for_timeout(300)
    print(v())
    page.evaluate("()=>Lectio.goBack()"); page.wait_for_timeout(300); print('1',v())
    page.evaluate("()=>Lectio.goBack()"); page.wait_for_timeout(300); print('2',v())
    page.evaluate("()=>Lectio.goBack()"); page.wait_for_timeout(300); print('3',v())
    # split
    page.evaluate("()=>Lectio.go('split')"); page.wait_for_timeout(500)
    page.evaluate("()=>Lectio.go('settings')"); page.wait_for_timeout(300)
    page.evaluate("()=>Lectio.goBack()"); page.wait_for_timeout(600); print('split back',v())
    page.evaluate("()=>Lectio.goBack()"); page.wait_for_timeout(600); print('then',v())
    print(page.errors)
