/* Bible reader: versions, parallel view, text size and pinch zoom, auto-scroll, audio (text to speech), and importing your own Bible versions. */
(function(){
'use strict';
var L=window.Lectio,$=L.$,esc=L.esc;
var Cap=window.Capacitor||{};
var native=!!(Cap.isNativePlatform&&Cap.isNativePlatform());
function plug(n){try{return(Cap.Plugins&&Cap.Plugins[n])||(native&&Cap.registerPlugin?Cap.registerPlugin(n):null)}catch(e){return null}}

/* ================= versions ================= */
var BUILTIN=[
  {id:'kjv',name:'King James Version',short:'KJV',lang:'en-US',base:'bibles/kjv/'},
  {id:'te',name:'Telugu (Old Version)',short:'తెలుగు',lang:'te-IN',base:'bibles/te/'}
];
var custom=[];
try{custom=JSON.parse(L.lsGet('lectio-trans-v1')||'[]')||[]}catch(e){custom=[]}
function allT(){return BUILTIN.concat(custom)}
function tById(id){var a=allT();for(var i=0;i<a.length;i++)if(a[i].id===id)return a[i];return a[0]}
function saveCustom(){L.lsSet('lectio-trans-v1',JSON.stringify(custom))}
var bookCache={};
function loadBook(tid,b){
  var k=tid+':'+b;
  if(!bookCache[k]){
    var t=tById(tid);
    bookCache[k]=t.base
      ?fetch(t.base+b+'.json').then(function(r){if(!r.ok)throw new Error('missing');return r.json()})
      :LStore.get('bibles',k).then(function(v){if(!v)throw new Error('missing');return v});
    bookCache[k].catch(function(){delete bookCache[k]});
  }
  return bookCache[k];
}

/* ================= preferences ================= */
var P={a:'kjv',b:'te',parallel:false,side:false,size:20,nums:true,ms:30,autoNext:true,autoMark:false,read:'a',rate:1,pitch:1,voices:{},last:{b:0,c:1}};
try{var sv=JSON.parse(L.lsGet('lectio-reader-v1')||'{}');Object.keys(sv).forEach(function(k){P[k]=sv[k]})}catch(e){}
if(!P.voices||typeof P.voices!=='object')P.voices={};
function saveP(){L.lsSet('lectio-reader-v1',JSON.stringify(P))}
function clamp(v,a,b){return Math.max(a,Math.min(b,v))}

var pos={b:clamp(+P.last.b||0,0,65),c:1};
pos.c=clamp(+P.last.c||1,1,BOOKS[pos.b].c);
function savePos(){P.last={b:pos.b,c:pos.c};saveP()}
function step(d){
  var b=pos.b,c=pos.c+d;
  if(c<1){if(b===0)return false;b--;c=BOOKS[b].c}
  else if(c>BOOKS[b].c){if(b===BOOKS.length-1)return false;b++;c=1}
  pos={b:b,c:c};savePos();L.curBook=b;return true;
}

/* ================= rendering ================= */
var tok=0,data=[],V=$('vRead');
function activeIds(){
  var ids=[P.a];
  if(P.parallel&&P.b&&P.b!==P.a)ids.push(P.b);
  return ids.filter(function(id){return allT().some(function(t){return t.id===id})});
}
function isTe(t){return/^te/i.test(t.lang)}
function render(){
  var my=++tok,b=pos.b,c=pos.c,ids=activeIds();
  if(!ids.length){P.a='kjv';ids=['kjv']}
  $('rBook').textContent=BOOKS[b].n;
  $('rCh').textContent=c;
  document.title='Lectio · '+BOOKS[b].n+' '+c;
  return Promise.all(ids.map(function(id){return loadBook(id,b).catch(function(){return null})})).then(function(books){
    if(my!==tok)return;
    data=ids.map(function(id,i){return{t:tById(id),verses:books[i]?(books[i][c-1]||[]):null}});
    var n=0;data.forEach(function(d){if(d.verses)n=Math.max(n,d.verses.length)});
    var par=data.length>1,h='';
    if(par)h+='<div class="vlab">'+data.map(function(d){return'<span>'+esc(d.t.short)+'</span>'}).join('')+'</div>';
    if(!n)h+='<p class="rempty">This version has no text for '+esc(BOOKS[b].n)+' '+c+'.</p>';
    for(var v=1;v<=n;v++){
      h+='<div class="vs" data-v="'+v+'"><span class="vn">'+(P.nums?v:'')+'</span><div class="vcols">';
      data.forEach(function(d,i){
        var tx=d.verses?(d.verses[v-1]||''):'';
        h+='<p class="vt'+(i?' vt2':'')+(isTe(d.t)?' tel':'')+'" lang="'+(isTe(d.t)?'te':'en')+'">'+(tx?esc(tx):'<span class="dash">—</span>')+'</p>';
      });
      h+='</div></div>';
    }
    var rt=$('rText');
    rt.className='rtext'+(par?' par'+(P.side?' side':''):'');
    rt.innerHTML=h;
    refreshMark();
    $('rPrev').disabled=(b===0&&c===1);
    $('rNext').disabled=(b===BOOKS.length-1&&c===BOOKS[b].c);
  });
}
function refreshMark(){
  var on=L.chapterRead(pos.b,pos.c),m=$('rMark');
  m.textContent=on?'Read ✓':'Mark as read';
  m.classList.toggle('on',on);
}
function setSize(px,persist){
  P.size=Math.round(clamp(px,12,48)*2)/2;
  V.style.setProperty('--rsize',P.size+'px');
  var e=$('szV');if(e)e.textContent=P.size+' px';
  var r=$('szR');if(r&&+r.value!==P.size)r.value=P.size;
  if(persist)saveP();
}
setSize(P.size,false);

function openReader(b,c){
  if(b!=null){pos={b:b,c:c}}
  L.curBook=pos.b;savePos();
  L.go('read');
}
L.openReader=openReader;
function goChapter(d,keepAudio){
  if(!step(d))return;
  var wasAudio=S.on,wasScroll=A.on;
  render().then(function(){
    window.scrollTo(0,0);
    if(wasAudio&&keepAudio!==false)play(1);
    if(wasScroll){A.last=0;A.acc=0}
  });
  updateFg();
}
$('rPrev').onclick=function(){goChapter(-1)};
$('rNext').onclick=function(){goChapter(1)};
$('rMark').onclick=function(){
  var on=!L.chapterRead(pos.b,pos.c);
  L.setChapterRead(pos.b,pos.c,on);refreshMark();
  L.toast(on?BOOKS[pos.b].n+' '+pos.c+' marked as read':'Marked unread');
};
$('rBack').onclick=function(){L.goBack()};
$('rTitle').onclick=function(){L.goBack()};
$('rMinus').onclick=function(){setSize(P.size-1,true)};
$('rPlus').onclick=function(){setSize(P.size+1,true)};

/* ---- pinch to zoom the text ---- */
(function(){
  var d0=0,s0=0,raf=0,next=0;
  function dist(t){return Math.hypot(t[0].clientX-t[1].clientX,t[0].clientY-t[1].clientY)}
  V.addEventListener('touchstart',function(e){if(e.touches.length===2){d0=dist(e.touches);s0=P.size}},{passive:true});
  V.addEventListener('touchmove',function(e){
    if(e.touches.length!==2||!d0)return;
    e.preventDefault();
    next=s0*dist(e.touches)/d0;
    if(!raf)raf=requestAnimationFrame(function(){raf=0;setSize(next,false)});
  },{passive:false});
  function end(e){if(d0&&e.touches.length<2){d0=0;saveP()}}
  V.addEventListener('touchend',end);V.addEventListener('touchcancel',end);
})();

/* ================= auto-scroll ================= */
var A={on:false,raf:0,last:0,acc:0,hold:false,touch:false,endAt:0};
var wl=null;
function keepAwake(on){
  try{
    if(on&&navigator.wakeLock&&!wl){navigator.wakeLock.request('screen').then(function(l){wl=l;l.addEventListener('release',function(){wl=null})}).catch(function(){})}
    else if(!on&&wl){wl.release().catch(function(){});wl=null}
  }catch(e){}
}
function startScroll(){
  if(S.on)stopAudio();
  A.on=true;A.last=0;A.acc=0;A.endAt=0;A.hold=false;
  keepAwake(true);refreshDock();
  A.raf=requestAnimationFrame(scrollFrame);
}
function stopScroll(){
  if(!A.on)return;
  A.on=false;cancelAnimationFrame(A.raf);keepAwake(false);refreshDock();renderSheetSoft();
}
function scrollFrame(t){
  if(!A.on)return;
  var held=A.hold||A.touch;
  if(A.last&&!held){
    A.acc+=Math.min(t-A.last,100)/P.ms;
    var px=Math.floor(A.acc);
    if(px>0){A.acc-=px;window.scrollBy(0,px)}
  }
  A.last=t;
  var atEnd=window.innerHeight+window.scrollY>=document.documentElement.scrollHeight-2;
  if(atEnd&&!held){
    if(!A.endAt)A.endAt=t;
    else if(t-A.endAt>1200){A.endAt=0;scrollEnded()}
  }else A.endAt=0;
  A.raf=requestAnimationFrame(scrollFrame);
}
function scrollEnded(){
  if(P.autoMark){L.setChapterRead(pos.b,pos.c,true);refreshMark()}
  A.hold=true;
  if(P.autoNext&&step(1)){
    render().then(function(){window.scrollTo(0,0);A.last=0;A.acc=0;A.hold=false});
  }else{A.hold=false;stopScroll();L.toast(P.autoNext?'End of the Bible':'End of chapter')}
}
document.addEventListener('touchstart',function(){A.touch=true},{passive:true});
document.addEventListener('touchend',function(){setTimeout(function(){A.touch=false},700)},{passive:true});
document.addEventListener('touchcancel',function(){setTimeout(function(){A.touch=false},700)},{passive:true});

/* ================= audio (text to speech) ================= */
var TTSP=native?plug('TextToSpeech'):null,FGS=native?plug('ForegroundService'):null;
var voices=null,webVoices=[];
var engine=null;
if(TTSP){
  engine={
    kind:'native',
    voices:function(){return TTSP.getSupportedVoices().then(function(r){return r.voices||[]})},
    speak:function(o){
      var op={text:o.text,lang:o.lang,rate:o.rate,pitch:o.pitch,volume:1,queueStrategy:o.add?1:0};
      if(o.voice&&voices){for(var i=0;i<voices.length;i++)if(voices[i].voiceURI===o.voice){op.voice=i;break}}
      return TTSP.speak(op);
    },
    stop:function(){return TTSP.stop()}
  };
}else if(window.speechSynthesis){
  engine={
    kind:'web',
    voices:function(){
      return new Promise(function(res){
        var get=function(){webVoices=speechSynthesis.getVoices()||[];return webVoices.map(function(v){return{voiceURI:v.voiceURI,name:v.name,lang:v.lang}})};
        var l=get();if(l.length)return res(l);
        speechSynthesis.onvoiceschanged=function(){res(get())};
        setTimeout(function(){res(get())},800);
      });
    },
    speak:function(o){
      return new Promise(function(res,rej){
        if(!o.add)speechSynthesis.cancel();
        var u=new SpeechSynthesisUtterance(o.text);u.lang=o.lang;u.rate=o.rate;u.pitch=o.pitch;
        for(var i=0;i<webVoices.length;i++)if(webVoices[i].voiceURI===o.voice){u.voice=webVoices[i];break}
        u.onend=function(){res()};u.onerror=function(e){rej(e)};
        speechSynthesis.speak(u);
      });
    },
    stop:function(){speechSynthesis.cancel();return Promise.resolve()}
  };
}
function loadVoices(){
  if(voices)return Promise.resolve(voices);
  if(!engine)return Promise.resolve([]);
  return engine.voices().then(function(v){voices=v;return v}).catch(function(){voices=[];return voices});
}
function langKey(lang){return String(lang||'en').slice(0,2).toLowerCase()}
function voiceFor(lang){return P.voices[langKey(lang)]||null}

/* foreground service keeps playback going when the app is minimised */
var FG={on:false,id:4217};
function fgBody(){return 'Reading '+BOOKS[pos.b].n+' '+pos.c}
function fgOpts(){return{id:FG.id,title:'Lectio',body:fgBody(),smallIcon:'ic_stat_lectio',serviceType:2,silent:true}}
function startFg(){
  if(!FGS||FG.on)return Promise.resolve();
  return FGS.checkPermissions().then(function(p){
    if(p&&p.display!=='granted')return FGS.requestPermissions();
  }).catch(function(){}).then(function(){
    return FGS.startForegroundService(fgOpts()).then(function(){FG.on=true}).catch(function(){});
  });
}
function updateFg(){if(FGS&&FG.on)FGS.updateForegroundService(fgOpts()).catch(function(){})}
function stopFg(){if(FGS&&FG.on){FG.on=false;FGS.stopForegroundService().catch(function(){})}}

var S={on:false,paused:false,sess:0,v:1,list:[],needVoice:''};
function readMode(){return data.length>1?P.read:'a'}
function buildList(){
  var out=[],n=0,mode=readMode();
  data.forEach(function(d){if(d.verses)n=Math.max(n,d.verses.length)});
  for(var v=1;v<=n;v++){
    data.forEach(function(d,i){
      var role=i===0?'a':'b';
      if(!d.verses||!d.verses[v-1])return;
      if(mode==='both'||mode===role)out.push({v:v,text:d.verses[v-1],lang:d.t.lang});
    });
  }
  return out;
}
function highlight(v){
  S.v=v;
  var old=document.querySelector('.vs.now');if(old)old.classList.remove('now');
  var el=document.querySelector('.vs[data-v="'+v+'"]');
  if(el){el.classList.add('now');try{el.scrollIntoView({block:'center',behavior:'smooth'})}catch(e){}}
  var s=$('aStatus');if(s)s.textContent=statusText();
}
function statusText(){
  if(S.needVoice)return'No voice installed for '+S.needVoice+'.';
  var n=document.querySelectorAll('.vs').length;
  if(S.on)return'Reading verse '+S.v+' of '+n;
  if(S.paused)return'Paused at verse '+S.v;
  return'Ready';
}
function fatal(err){
  var m=String(err&&(err.message||err)||'');
  return/not supported|unavailable|not available|not yet initialized/i.test(m);
}
function play(fromV){
  if(!engine){L.toast('This phone has no speech engine available');return}
  stopScroll();
  S.needVoice='';
  var sess=++S.sess;S.on=true;S.paused=false;
  Promise.resolve(engine.stop()).catch(function(){});
  refreshDock();renderSheetSoft();
  loadVoices().then(function(){
    if(sess!==S.sess)return;
    return startFg();
  }).then(function(){
    if(sess!==S.sess)return;
    var list=buildList(),start=-1;
    for(var i=0;i<list.length;i++)if(list[i].v>=fromV){start=i;break}
    if(start<0){chapterEnded(sess);return}
    S.list=list;
    highlight(list[start].v);
    list.forEach(function(u,i){
      if(i<start)return;
      engine.speak({text:u.text,lang:u.lang,rate:P.rate,pitch:P.pitch,voice:voiceFor(u.lang),add:i>start})
        .then(function(){advance(sess,list,i)})
        .catch(function(err){
          if(sess!==S.sess)return;
          if(fatal(err)){
            S.needVoice=isTe({lang:u.lang})?'Telugu':(u.lang||'this language');
            stopAudio();renderSheetSoft();
            L.toast('No '+S.needVoice+' voice found. See the Audio panel.');
            return;
          }
          advance(sess,list,i);
        });
    });
  });
}
function advance(sess,list,i){
  if(sess!==S.sess)return;
  if(i+1<list.length)highlight(list[i+1].v);else chapterEnded(sess);
}
function chapterEnded(sess){
  if(sess!==S.sess)return;
  if(P.autoMark){L.setChapterRead(pos.b,pos.c,true);refreshMark()}
  if(P.autoNext&&step(1)){
    updateFg();
    render().then(function(){if(sess===S.sess){window.scrollTo(0,0);play(1)}});
  }else{stopAudio();L.toast('Finished')}
}
function stopAudio(keepPos){
  S.sess++;S.on=false;S.paused=false;
  if(engine)Promise.resolve(engine.stop()).catch(function(){});
  stopFg();
  var old=document.querySelector('.vs.now');if(old)old.classList.remove('now');
  refreshDock();renderSheetSoft();
}
function pauseAudio(){
  var v=S.v;stopAudio();S.paused=true;S.v=v;
  var el=document.querySelector('.vs[data-v="'+v+'"]');if(el)el.classList.add('now');
  refreshDock();renderSheetSoft();
}
var restartT=0;
function restartIfPlaying(){
  if(!S.on)return;
  clearTimeout(restartT);
  restartT=setTimeout(function(){if(S.on)play(S.v)},450);
}
V.addEventListener('click',function(e){
  var vs=e.target.closest&&e.target.closest('.vs');
  if(vs&&S.on)play(+vs.dataset.v);
});

/* ================= dock and sheets ================= */
var sheetName='';
function refreshDock(){
  var d=$('dock');
  d.querySelector('[data-sheet="scroll"]').classList.toggle('live',A.on);
  d.querySelector('[data-sheet="audio"]').classList.toggle('live',S.on);
  d.querySelectorAll('[data-sheet]').forEach(function(b){b.setAttribute('aria-pressed',String(b.dataset.sheet===sheetName))});
}
function openSheet(n){
  sheetName=(sheetName===n)?'':n;
  $('sheet').hidden=!sheetName;
  document.body.classList.toggle('sheetopen',!!sheetName);
  refreshDock();
  if(sheetName){
    if(sheetName==='audio')loadVoices().then(renderSheet);
    renderSheet();
  }
}
function closeSheet(){sheetName='';$('sheet').hidden=true;document.body.classList.remove('sheetopen');refreshDock()}
function renderSheetSoft(){if(sheetName)renderSheet()}
function seg(items,attr,cur){return'<div class="seg">'+items.map(function(i){return'<button type="button" '+attr+'="'+i[0]+'" aria-pressed="'+(i[0]===cur)+'"'+(i[2]?' disabled':'')+'>'+esc(i[1])+'</button>'}).join('')+'</div>'}
function chips(attr,cur){return'<div class="chips">'+allT().map(function(t){return'<button type="button" class="chip" '+attr+'="'+esc(t.id)+'" aria-pressed="'+(t.id===cur)+'">'+esc(t.short)+'</button>'}).join('')+'</div>'}
function tgl(act,label,on){return'<button type="button" class="tgl" data-act="'+act+'" aria-pressed="'+!!on+'"><span>'+label+'</span><i></i></button>'}
function rng(id,label,min,max,step,val,txt){return'<label class="rng">'+label+' <b id="'+id+'V">'+txt+'</b><input id="'+id+'" type="range" min="'+min+'" max="'+max+'" step="'+step+'" value="'+val+'"></label>'}

function voiceSelect(lang,label){
  var k=langKey(lang),list=(voices||[]).filter(function(v){return langKey(v.lang)===k});
  var cur=P.voices[k]||'';
  var h='<label class="field">'+esc(label)+' voice<select id="vo_'+k+'" data-voice="'+k+'"><option value="">Automatic</option>';
  list.forEach(function(v){
    var id=String(v.voiceURI||''),m=id.match(/x-([a-z0-9]+)-?(.*)$/i),short=m?(m[1]+(m[2]?' '+m[2]:'')):id;
    h+='<option value="'+esc(id)+'"'+(id===cur?' selected':'')+'>'+esc((v.name||v.lang)+' · '+short)+'</option>';
  });
  h+='</select></label>';
  if(!list.length)h+='<p class="note">No '+esc(label)+' voice found on this phone.'+(native?' <button type="button" class="linkbtn" data-act="installvoice">Open voice settings</button>':'')+'</p>';
  return h;
}
function renderSheet(){
  var s=$('sheet'),h='';
  if(sheetName==='text'){
    h='<h4>Bible text</h4><div class="lbl">Version</div>'+chips('data-va',P.a);
    h+=tgl('par','Parallel reading (two versions)',P.parallel);
    if(P.parallel){
      h+='<div class="lbl">Second version</div>'+chips('data-vb',P.b);
      h+='<div class="lbl">Layout</div>'+seg([['stack','One above the other'],['side','Side by side']],'data-layout',P.side?'side':'stack');
    }
    h+='<div class="lbl">Text size</div><div class="szrow"><button class="btn" id="szMinus" type="button" aria-label="Smaller">A−</button><input id="szR" type="range" min="12" max="48" step="0.5" value="'+P.size+'"><button class="btn" id="szPlus" type="button" aria-label="Larger">A+</button></div><p class="note">Size <b id="szV">'+P.size+' px</b>. You can also pinch with two fingers.</p>';
    h+=tgl('nums','Verse numbers',P.nums);
  }else if(sheetName==='scroll'){
    h='<h4>Auto-scroll</h4><button class="btn main wide big" data-act="scrollgo" type="button">'+(A.on?'Stop scrolling':'Start scrolling')+'</button>';
    h+=rng('msR','Delay per pixel',1,200,1,P.ms,P.ms+' ms');
    h+='<div class="ends"><span>1 ms · fastest</span><span>200 ms · slowest</span></div>';
    h+='<div class="szrow"><button class="btn" data-ms="-1" type="button">−1</button><div class="chips ctr">'+[1,5,10,20,40,80].map(function(m){return'<button type="button" class="chip" data-mspre="'+m+'" aria-pressed="'+(P.ms===m)+'">'+m+'</button>'}).join('')+'</div><button class="btn" data-ms="1" type="button">+1</button></div>';
    h+='<p class="note" id="msNote">About '+Math.round(1000/P.ms)+' px per second. Touching the screen pauses it.</p>';
    h+=tgl('next','Continue to the next chapter',P.autoNext)+tgl('mark','Mark chapters read when finished',P.autoMark);
  }else if(sheetName==='audio'){
    var par=data.length>1;
    h='<h4>Audio</h4><div class="transport"><button type="button" class="tbtn" data-act="vprev" aria-label="Previous verse">⏮</button><button type="button" class="tbtn big" data-act="playpause" aria-label="'+(S.on?'Pause':'Play')+'">'+(S.on?'⏸':'▶')+'</button><button type="button" class="tbtn" data-act="vnext" aria-label="Next verse">⏭</button></div>';
    h+='<p class="note ctr" id="aStatus">'+esc(statusText())+'</p>';
    if(par){h+='<div class="lbl">Read aloud</div>'+seg([['a',data[0].t.short],['b',data[1].t.short],['both','Both']],'data-read',P.read)}
    h+=rng('rateR','Speed',0.5,2,0.05,P.rate,P.rate.toFixed(2)+'×');
    h+=rng('pitchR','Pitch',0.5,2,0.05,P.pitch,P.pitch.toFixed(2));
    var seen={};
    data.forEach(function(d){var k=langKey(d.t.lang);if(seen[k])return;seen[k]=1;h+=voiceSelect(d.t.lang,isTe(d.t)?'Telugu':'English')});
    h+=tgl('next','Continue to the next chapter',P.autoNext)+tgl('mark','Mark chapters read when finished',P.autoMark);
    h+='<p class="note">'+(native?'Audio keeps playing when you minimise the app or turn the screen off. A small notification shows while it plays.':'Audio uses this browser’s voices. Background play works in the Android app.')+' Tap a verse while listening to jump to it.</p>';
  }
  s.innerHTML=h;
}
$('dock').addEventListener('click',function(e){
  var b=e.target.closest('[data-sheet]');if(b)openSheet(b.dataset.sheet);
});
var sh=$('sheet');
sh.addEventListener('click',function(e){
  var t=e.target.closest('button');if(!t)return;
  var d=t.dataset;
  if(d.va){P.a=d.va;if(P.b===P.a){var o=allT().filter(function(x){return x.id!==P.a})[0];if(o)P.b=o.id}saveP();renderSheet();render();restartIfPlaying()}
  else if(d.vb){P.b=d.vb;if(P.b===P.a){var o2=allT().filter(function(x){return x.id!==P.b})[0];if(o2)P.a=o2.id}saveP();renderSheet();render();restartIfPlaying()}
  else if(d.layout){P.side=d.layout==='side';saveP();renderSheet();render()}
  else if(d.read){P.read=d.read;saveP();renderSheet();restartIfPlaying()}
  else if(d.mspre){setMs(+d.mspre)}
  else if(d.ms){setMs(P.ms+(+d.ms))}
  else if(t.id==='szMinus')setSize(P.size-1,true);
  else if(t.id==='szPlus')setSize(P.size+1,true);
  else if(d.act==='par'){P.parallel=!P.parallel;if(P.parallel&&P.b===P.a){var o3=allT().filter(function(x){return x.id!==P.a})[0];if(o3)P.b=o3.id}saveP();renderSheet();render()}
  else if(d.act==='nums'){P.nums=!P.nums;saveP();renderSheet();render()}
  else if(d.act==='next'){P.autoNext=!P.autoNext;saveP();renderSheet()}
  else if(d.act==='mark'){P.autoMark=!P.autoMark;saveP();renderSheet()}
  else if(d.act==='scrollgo'){if(A.on)stopScroll();else{closeSheet();startScroll()}renderSheetSoft()}
  else if(d.act==='playpause'){if(S.on)pauseAudio();else play(S.paused?S.v:1)}
  else if(d.act==='vprev'){play(Math.max(1,S.v-1))}
  else if(d.act==='vnext'){play(S.v+1)}
  else if(d.act==='installvoice'&&TTSP){TTSP.openInstall().catch(function(){})}
});
function setMs(v){
  P.ms=clamp(Math.round(v),1,200);saveP();
  var r=$('msR');if(r)r.value=P.ms;
  var e=$('msRV');if(e)e.textContent=P.ms+' ms';
  var n=$('msNote');if(n)n.textContent='About '+Math.round(1000/P.ms)+' px per second. Touching the screen pauses it.';
  sh.querySelectorAll('[data-mspre]').forEach(function(b){b.setAttribute('aria-pressed',String(+b.dataset.mspre===P.ms))});
}
sh.addEventListener('input',function(e){
  var id=e.target.id;
  if(id==='szR')setSize(+e.target.value,true);
  else if(id==='msR')setMs(+e.target.value);
  else if(id==='rateR'){P.rate=+e.target.value;$('rateRV').textContent=P.rate.toFixed(2)+'×';saveP()}
  else if(id==='pitchR'){P.pitch=+e.target.value;$('pitchRV').textContent=P.pitch.toFixed(2);saveP()}
});
sh.addEventListener('change',function(e){
  var id=e.target.id;
  if(id==='rateR'||id==='pitchR')restartIfPlaying();
  else if(e.target.dataset&&e.target.dataset.voice){P.voices[e.target.dataset.voice]=e.target.value;saveP();restartIfPlaying()}
});

/* ================= view lifecycle ================= */
L.back.push(function(){
  if(L.view==='read'&&!$('sheet').hidden){closeSheet();return true}
  return false;
});
L.onShow.push(function(name){
  var inRead=name==='read';
  $('dock').hidden=!inRead;
  if(inRead){render().then(function(){window.scrollTo(0,0)});refreshDock()}
  else{
    closeSheet();stopScroll();if(S.on||S.paused)stopAudio();
    if(name==='home')refreshHome();
    if(name==='settings')renderVersions();
  }
});
function refreshHome(){
  $('readNow').textContent='Continue reading · '+BOOKS[pos.b].n+' '+pos.c;
}

/* ================= settings: Bible versions and import ================= */
function normName(s){return String(s).toLowerCase().replace(/[^a-z0-9]/g,'')}
var CANON={};BOOKS.forEach(function(b,i){CANON[normName(b.n)]=i});
var ALIAS={songofsongs:21,canticles:21,canticleofcanticles:21,psalm:18,revelations:65,revelationofjohn:65,apocalypse:65,qoheleth:20};
function bookIndex(name){
  var k=normName(name);
  if(CANON[k]!=null)return CANON[k];
  if(ALIAS[k]!=null)return ALIAS[k];
  var m=k.replace(/^(first|1st)/,'1').replace(/^(second|2nd)/,'2').replace(/^(third|3rd)/,'3');
  if(CANON[m]!=null)return CANON[m];
  m=k.replace(/^iii/,'3').replace(/^ii/,'2').replace(/^i/,'1');
  if(CANON[m]!=null)return CANON[m];
  return -1;
}
function clean(t){return String(t==null?'':t).replace(/<[^>]*>/g,'').replace(/\s+/g,' ').replace(/^#\s*/,'').trim()}
function versesFrom(x){
  var arr=[];
  if(Array.isArray(x)){
    x.forEach(function(v,i){
      if(typeof v==='string')arr[i]=v;
      else if(v&&typeof v==='object'){var n=parseInt(v.verse||v.v||v.number||(i+1),10);arr[n-1]=v.text||v.t||v.value||''}
    });
  }else if(x&&typeof x==='object'){
    Object.keys(x).forEach(function(k){var n=parseInt(k,10);if(n>0){var v=x[k];arr[n-1]=typeof v==='string'?v:((v&&(v.text||v.t))||'')}});
  }
  var out=[];for(var i=0;i<arr.length;i++)out.push(clean(arr[i]));
  return out;
}
function chaptersFrom(x){
  var chs=[];
  if(Array.isArray(x)){
    x.forEach(function(c,i){
      var n=(c&&typeof c==='object'&&!Array.isArray(c)&&c.chapter!=null)?parseInt(c.chapter,10):(i+1);
      chs[n-1]=versesFrom((c&&!Array.isArray(c)&&c.verses)?c.verses:c);
    });
  }else if(x&&typeof x==='object'){
    Object.keys(x).forEach(function(k){var n=parseInt(k,10);if(n>0)chs[n-1]=versesFrom(x[k])});
  }
  for(var i=0;i<chs.length;i++)if(!chs[i])chs[i]=[];
  return chs;
}
function rowsToBooks(rows,out){
  var acc={};
  rows.forEach(function(r){
    var bk=r.book!=null?r.book:(r.book_name!=null?r.book_name:(r.bookname!=null?r.bookname:r.b));
    var ch=+(r.chapter!=null?r.chapter:r.c),vs=+(r.verse!=null?r.verse:r.v);
    var tx=r.text!=null?r.text:(r.t!=null?r.t:r.value);
    var i=/^\d+$/.test(String(bk))?(+bk-1):bookIndex(bk);
    if(i<0||i>65||!ch||!vs)return;
    var b=acc[i]=acc[i]||[],c=b[ch-1]=b[ch-1]||[];
    c[vs-1]=clean(tx);
  });
  Object.keys(acc).forEach(function(i){
    var b=acc[i];for(var c=0;c<b.length;c++){b[c]=b[c]||[];for(var v=0;v<b[c].length;v++)if(b[c][v]==null)b[c][v]=''}
    out[i]=b;
  });
}
function parseBible(j,out){
  function put(i,chs){if(i>=0&&i<66&&chs&&chs.length)out[i]=chs}
  function nameOf(o){var n=o.name||o.book||o.title;if(n&&typeof n==='object')n=n.english||n.name||n.en;return n}
  if(Array.isArray(j)){
    var f=j[0];
    if(f&&typeof f==='object'&&!Array.isArray(f)&&('chapters' in f)){
      j.forEach(function(bk,p){
        var nm=nameOf(bk),i=nm?bookIndex(nm):-1;
        if(i<0&&j.length===66)i=p;
        put(i,chaptersFrom(bk.chapters));
      });
    }else if(f&&typeof f==='object'&&!Array.isArray(f)){rowsToBooks(j,out)}
  }else if(j&&typeof j==='object'){
    if(j.resultset&&j.resultset.row){
      rowsToBooks(j.resultset.row.map(function(r){var f=r.field||[];return{book:f[1],chapter:f[2],verse:f[3],text:f[4]}}),out);
    }else if(Array.isArray(j.books)){parseBible(j.books,out)}
    else if(j.chapters&&nameOf(j)){put(bookIndex(nameOf(j)),chaptersFrom(j.chapters))}
    else{Object.keys(j).forEach(function(k){var i=bookIndex(k);if(i>=0)put(i,chaptersFrom(j[k]))})}
  }
}
function readFile(f){
  if(f.text)return f.text();
  return new Promise(function(res,rej){var r=new FileReader();r.onload=function(){res(r.result)};r.onerror=rej;r.readAsText(f)});
}
var verBusy=false,verMsg='';
function renderVersions(){
  var el=$('verCard');if(!el)return;
  var h='<h3>Bible versions</h3>';
  h+='<ul class="vlist">'+allT().map(function(t){
    return'<li><span><b>'+esc(t.name)+'</b><small>'+(t.base?'Built in':'Imported on this phone')+'</small></span>'+(t.base?'':'<button type="button" class="linkbtn" data-delver="'+esc(t.id)+'">Remove</button>')+'</li>';
  }).join('')+'</ul>';
  h+='<p class="muted">KJV and Telugu are built in. NIV is copyrighted, so it is not included. If you have your own licensed copy as a JSON file, you can add it here. It stays on this phone.</p>';
  h+='<label class="field">Name<input id="verName" type="text" placeholder="NIV" maxlength="24"></label>';
  h+='<label class="field">Language<select id="verLang"><option value="en-US">English</option><option value="te-IN">Telugu</option></select></label>';
  h+='<input id="verFile" type="file" accept=".json,application/json" multiple hidden>';
  h+='<div class="row"><button class="btn main" id="verPick" type="button"'+(verBusy?' disabled':'')+'>'+(verBusy?'Importing…':'Choose JSON file(s)')+'</button></div>';
  h+='<p class="note" id="verMsg">'+esc(verMsg)+'</p>';
  el.innerHTML=h;
}
$('verCard').addEventListener('click',function(e){
  var t=e.target.closest('button');if(!t)return;
  if(t.id==='verPick'){
    if(!$('verName').value.trim()){verMsg='Type a name first, for example NIV.';$('verMsg').textContent=verMsg;return}
    $('verFile').click();
  }else if(t.dataset.delver){
    var id=t.dataset.delver;
    custom=custom.filter(function(x){return x.id!==id});saveCustom();
    for(var i=0;i<66;i++){LStore.del('bibles',id+':'+i).catch(function(){});delete bookCache[id+':'+i]}
    if(P.a===id)P.a='kjv';if(P.b===id)P.b='te';saveP();
    verMsg='Removed.';renderVersions();
  }
});
$('verCard').addEventListener('change',function(e){
  if(e.target.id!=='verFile')return;
  var files=Array.prototype.slice.call(e.target.files||[]);e.target.value='';
  if(!files.length)return;
  var name=$('verName').value.trim()||'Imported',lang=$('verLang').value;
  verBusy=true;verMsg='';renderVersions();
  var out={};
  files.reduce(function(p,f){
    return p.then(function(){return readFile(f)}).then(function(txt){parseBible(JSON.parse(txt),out)});
  },Promise.resolve()).then(function(){
    var idx=Object.keys(out).map(Number);
    if(!idx.length)throw new Error('none');
    var id='c'+Date.now().toString(36),verses=0;
    return Promise.all(idx.map(function(i){
      out[i].forEach(function(c){verses+=c.length});
      return LStore.set('bibles',id+':'+i,out[i]);
    })).then(function(){
      custom.push({id:id,name:name,short:name.slice(0,8),lang:lang});saveCustom();
      verMsg='Added '+name+': '+idx.length+' of 66 books, '+verses.toLocaleString()+' verses.'+(idx.length<66?' Missing books will show a dash.':'');
    });
  }).catch(function(){
    verMsg='That file could not be read as a Bible. Use a JSON file with books, chapters and verses.';
  }).then(function(){verBusy=false;renderVersions()});
});

L.goBack=L.goBack||function(){};
refreshHome();
})();
