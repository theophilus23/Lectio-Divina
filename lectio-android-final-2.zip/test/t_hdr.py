import sys; sys.path.insert(0,'test')
from harness import app
with app(width=390,height=760) as (page,base):
    page.goto(base); page.wait_for_timeout(800)
    page.screenshot(path='/tmp/hdr_home.png')
    page.evaluate("Lectio.openReader(0,1,1)"); page.wait_for_timeout(700)
    page.screenshot(path='/tmp/hdr_read.png')
    print('errors', page.errors)
