/* Split view: two panes (Bible | Bible in another version | Notes). Chapters and verses can be linked or unlinked. */
(function(){
var L=window.Lectio,UI=L.ui,esc=L.esc,KEY='lectio-split-v1';
var BK=BOOKS;
var S;
function load(){
  try{S=JSON.parse(L.lsGet(KEY)||'null')}catch(e){S=null}
  var vs=L.bible.versions(),p=(L.reader&&L.reader.pos&&L.reader.pos())||{b:0,c:1};
  var okv=function(t){return t&&L.bible.hasVersion(t)};
  if(S){if(!okv(S.a.tid))S.a.tid=vs[0].id;if(!okv(S.b.tid))S.b.tid=(vs[1]||vs[0]).id}
  if(!S)S={a:{k:'bible',tid:vs[0].id,b:p.b,c:p.c},b:{k:'bible',tid:(vs[1]||vs[0]).id,b:p.b,c:p.c},link:true,vlink:false};
}
function save(){L.lsSet(KEY,JSON.stringify(S))}
var el=L.registerView({id:'split',title:'Split view',show:function(){load();draw()},leave:function(){stopT();stopAS()}});
var ico={bible:'book',notes:'note'};
function pane(k){
  var p=S[k];
  return'<section class="spane" data-p="'+k+'"><div class="spill">'
   +'<button type="button" data-a="kind">'+UI.icon(ico[p.k],16)+'</button>'
   +(p.k==='bible'?'<button type="button" data-a="ch" class="sch"><b>'+esc(BK[p.b].n)+'</b> '+p.c+'</button><button type="button" data-a="ver" class="sver">'+esc(L.bible.version(p.tid).short)+'</button>':'<button type="button" data-a="ch" class="sch"><b>Notes</b></button>')
   +'<button type="button" data-a="more" aria-label="More">'+UI.icon('more',16)+'</button></div>'
   +'<div class="sbody" data-body="'+k+'"></div></section>';
}
var SZ={z:100,w:0,s:0},SZK='lectio-split-size';
try{var _z=JSON.parse(L.lsGet(SZK)||'null');if(_z)SZ=Object.assign(SZ,_z)}catch(e){}
function applySz(){
  el.style.setProperty('--ssz',(SZ.z/100)+'em');
  el.style.setProperty('--slh',(1.6+SZ.s*0.12).toFixed(2));
  el.style.setProperty('--spx',(8+SZ.w*-4)+'px');
  el.style.setProperty('--sgap',(0.6+SZ.s*0.2).toFixed(2)+'em');
}
function bumpSz(d){
  if(d==='z+')SZ.z=Math.min(200,SZ.z+10);else if(d==='z-')SZ.z=Math.max(70,SZ.z-10);
  else if(d==='w+')SZ.w=Math.min(3,SZ.w+1);else if(d==='w-')SZ.w=Math.max(-3,SZ.w-1);
  else if(d==='s+')SZ.s=Math.min(4,SZ.s+1);else if(d==='s-')SZ.s=Math.max(-3,SZ.s-1);
  L.lsSet(SZK,JSON.stringify(SZ));applySz();
}
L.splitView={bump:bumpSz,get:function(){return SZ}};
var I={prev:'<path d="M6 5v14M19 5l-9 7 9 7z"/>',next:'<path d="M18 5v14M5 5l9 7-9 7z"/>',play:'<path d="M7 4l13 8-13 8z"/>',pause:'<path d="M7 4h4v16H7zM13 4h4v16h-4z"/>',scroll:'<path d="M12 4v14M6 12l6 6 6-6"/>'};
function ib(a,n,l,on){return'<button type="button" class="sbtn" data-t="'+a+'" aria-label="'+l+'"'+(on?' aria-pressed="true"':'')+'><svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor" stroke="currentColor" stroke-width="'+(a==='scroll'?2.2:0)+'" stroke-linecap="round" stroke-linejoin="round"'+(a==='scroll'?' fill="none"':'')+'>'+n+'</svg></button>'}
function bar(){
  /* Listen (text to speech) buttons are hidden in split view for now; the code below is kept for a future update. */
  return'<div class="sbar">'+ib('scroll',I.scroll,'Start or stop auto-scroll',AS.on)
   +'<span class="sdiv"></span><button type="button" class="sbtn" data-t="slower" aria-label="Slower scroll"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 12h12"/></svg></button>'
   +'<span class="sspd" id="sSpd" aria-live="polite">'+spLabel()+'</span>'
   +'<button type="button" class="sbtn" data-t="faster" aria-label="Faster scroll"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 12h12M12 6v12"/></svg></button></div>';
}
function draw(){
  stopT();stopAS();
  el.innerHTML='<div class="splitwrap">'+bar()+pane('a')+pane('b')+'</div>';
  applySz();
  ['a','b'].forEach(fill);
}
/* ---- listen (text to speech) ---- */
var T={on:false,paused:false,k:'a',v:1,sess:0};
function tPane(){return S.a.k==='bible'?'a':(S.b.k==='bible'?'b':null)}
function mark(k,v){
  var box=el.querySelector('[data-body="'+k+'"]');if(!box)return;
  Array.prototype.forEach.call(box.querySelectorAll('.sv.sp'),function(x){x.classList.remove('sp')});
  var t=box.querySelector('.sv[data-v="'+v+'"]');
  if(t){t.classList.add('sp');var r=box.getBoundingClientRect(),q=t.getBoundingClientRect();if(q.top<r.top||q.bottom>r.bottom)box.scrollTop+=q.top-r.top-20}
}
function setBarBtns(){
  var b=el.querySelector('[data-t="play"]');if(!b)return;
  var pl=T.on&&!T.paused;b.setAttribute('aria-label',pl?'Pause':'Play');b.querySelector('svg').innerHTML=pl?I.pause:I.play;
}
function stopT(){T.sess++;T.on=false;T.paused=false;var e=L.tts&&L.tts.engine();if(e)try{e.stop()}catch(x){}setBarBtns()}
function speakFrom(v){
  var k=tPane();if(!k){UI.toast('Open a Bible pane to listen');return}
  var e=L.tts&&L.tts.engine();if(!e){UI.toast('Listening is not available on this device');return}
  var p=S[k],box=el.querySelector('[data-body="'+k+'"]'),els=box&&box.querySelectorAll('.sv');
  if(!els||!els.length){UI.toast('Chapter is still loading');return}
  stopT();var sess=T.sess;T.on=true;T.paused=false;T.k=k;setBarBtns();
  var lang=(L.bible.version(p.tid)||{}).lang||'en-US',n=els.length;
  function one(i){
    if(sess!==T.sess)return;
    if(i>n){ // chapter finished: go on to the next one
      var nx=nextCh(p,1);if(!nx){stopT();return}
      setCh(k,{b:nx.b,c:nx.c});
      setTimeout(function(){if(sess!==T.sess)return;T.on=false;speakFrom(1)},700);return;
    }
    T.v=i;mark(k,i);
    var txt=els[i-1].textContent.replace(/^\s*\d+\s*/,'');
    Promise.resolve(e.speak({text:txt,lang:lang,rate:L.tts.rate(),pitch:L.tts.pitch(),voice:L.tts.voice(lang),add:false}))
      .then(function(){one(i+1)}).catch(function(){if(sess===T.sess){UI.toast('No voice found for this language');stopT()}});
  }
  L.tts.load().then(function(){if(sess===T.sess)one(Math.max(1,Math.min(n,v)))});
}
function nextCh(p,d){
  var b=p.b,c=p.c+d;
  if(c>BK[b].c){b++;c=1;if(b>=BK.length)return null}
  else if(c<1){b--;if(b<0)return null;c=BK[b].c}
  return{b:b,c:c};
}
/* ---- auto-scroll ---- */
var AS={on:false,raf:0,last:0,acc:0},SPMIN=1,SPMAX=10;
function spd(){return Math.max(SPMIN,Math.min(SPMAX,SZ.sp||4))}
function spLabel(){var v=spd();return v<=SPMIN?'Speed '+v+' · min':v>=SPMAX?'Speed '+v+' · max':'Speed '+v}
function stopAS(){AS.on=false;cancelAnimationFrame(AS.raf);var b=el&&el.querySelector('[data-t="scroll"]');if(b)b.removeAttribute('aria-pressed')}
function tickAS(ts){
  if(!AS.on)return;
  var dt=Math.min(64,ts-(AS.last||ts));AS.last=ts;AS.acc+=dt*spd()*0.01;
  var px=Math.floor(AS.acc);
  if(px>=1){AS.acc-=px;
    Array.prototype.forEach.call(el.querySelectorAll('.sbody'),function(b){if(b.querySelector('.sv'))b.scrollTop+=px});
  }
  AS.raf=requestAnimationFrame(tickAS);
}
function startAS(){AS.on=true;AS.last=0;AS.acc=0;var b=el.querySelector('[data-t="scroll"]');if(b)b.setAttribute('aria-pressed','true');AS.raf=requestAnimationFrame(tickAS)}
/* ---- swipe to change chapter ---- */
var sw=null;
el.addEventListener('touchstart',function(e){
  var b=e.target.closest&&e.target.closest('.sbody');var t=e.touches[0];
  sw=b&&e.touches.length===1&&S[b.dataset.body].k==='bible'&&!e.target.closest('textarea,input')?{k:b.dataset.body,x:t.clientX,y:t.clientY}:null;
},{passive:true});
el.addEventListener('touchend',function(e){
  if(!sw)return;var t=e.changedTouches[0],dx=t.clientX-sw.x,dy=t.clientY-sw.y,k=sw.k;sw=null;
  if(Math.abs(dx)<70||Math.abs(dx)<Math.abs(dy)*2)return;
  var nx=nextCh(S[k],dx<0?1:-1);if(!nx){UI.toast(dx<0?'End of the Bible':'Start of the Bible');return}
  setCh(k,nx);
},{passive:true});
function refPane(){return S.a.k==='bible'?S.a:(S.b.k==='bible'?S.b:{b:0,c:1,tid:L.bible.versions()[0].id})}
function addNote(k){
  var box=el.querySelector('[data-body="'+k+'"]'),t=box.querySelector('.sntxt').value.trim(),vv=box.querySelector('.snv').value.trim();
  if(!t){UI.toast('Write something first');return}
  var rp=refPane(),m=vv.match(/^(\d+)(?:\s*[-–]\s*(\d+))?$/),v1=m?+m[1]:0,v2=m&&m[2]?+m[2]:v1;
  if(vv&&!m){UI.toast('Verse should be a number like 5 or 3-5');return}
  function put(vtxt){
    var v=L.bible.version(rp.tid),blocks=[];
    if(v1)blocks.push({t:'verse',tid:rp.tid,short:v.short,b:rp.b,c:rp.c,v1:v1,v2:v2,ref:L.bible.refName(rp.b,rp.c,v1,v2),text:vtxt});
    else blocks.push({t:'verse',tid:rp.tid,short:v.short,b:rp.b,c:rp.c,v1:0,v2:0,ref:BK[rp.b].n+' '+rp.c,text:''});
    blocks.push({t:'text',h:'',x:t});
    L.coll('notes').put({title:blocks[0].ref,cat:'General',ts:Date.now(),blocks:blocks});
    UI.toast('Note saved');fill(k);
  }
  if(v1)L.bible.chapter(rp.tid,rp.b,rp.c).then(function(vs){put((vs||[]).slice(v1-1,v2).join(' '))});else put('');
}
function fill(k){
  var p=S[k],box=el.querySelector('[data-body="'+k+'"]');if(!box)return;
  if(p.k==='notes'){
    var ref=refPane(),a=(L.coll('notes').list()||[]).filter(function(n){return(n.blocks||[]).some(function(x){return x.t==='verse'&&x.b===ref.b&&x.c===ref.c})});
    var h='<div class="snform"><div class="snref">'+esc(BK[ref.b].n)+' '+ref.c+' <input type="text" class="snv" inputmode="numeric" placeholder="verse" aria-label="Verse number (optional)" maxlength="7"></div>'
      +'<textarea class="ta sntxt" rows="3" placeholder="Write a note… (add a verse number to attach it to that verse)"></textarea>'
      +'<button type="button" class="btn main sngo" data-a="addnote">Save note</button></div>';
    h+=a.length?a.map(function(n){return'<button type="button" class="snote" data-n="'+esc(n.id)+'"><b>'+esc(n.title||'Untitled')+'</b><small>'+esc(((n.blocks||[]).filter(function(x){return x.t==='text'})[0]||{}).x||'')+'</small></button>'}).join(''):'<p class="muted">No notes on this chapter yet.</p>';
    box.innerHTML=h;
    return;
  }
  box.innerHTML='<p class="muted">Loading…</p>';
  L.bible.chapter(p.tid,p.b,p.c).then(function(vs){
    if(!vs){box.innerHTML='<p class="muted">This version has no text for '+esc(BK[p.b].n)+' '+p.c+'.</p>';return}
    box.innerHTML=vs.map(function(t,i){return'<p class="sv" data-v="'+(i+1)+'"><sup>'+(i+1)+'</sup> '+esc(t)+'</p>'}).join('');
    box.scrollTop=0;
  });
}
function firstV(box){var r=box.getBoundingClientRect(),els=box.querySelectorAll('.sv');for(var i=0;i<els.length;i++)if(els[i].getBoundingClientRect().bottom>r.top+4)return+els[i].dataset.v;return 1}
var syncing=false;
el.addEventListener('scroll',function(e){
  if(!S.vlink||syncing||!e.target.dataset||!e.target.dataset.body)return;
  var from=e.target.dataset.body,to=from==='a'?'b':'a',tb=el.querySelector('[data-body="'+to+'"]'),v=firstV(e.target),t=tb&&tb.querySelector('.sv[data-v="'+v+'"]');
  if(t){syncing=true;tb.scrollTop=t.offsetTop-tb.offsetTop;setTimeout(function(){syncing=false},80)}
},true);
function setCh(k,r){
  stopT();
  S[k].b=r.b;S[k].c=r.c;if(r.tid)S[k].tid=r.tid;
  if(S.link&&S[k==='a'?'b':'a'].k==='bible'){var o=k==='a'?'b':'a';S[o].b=r.b;S[o].c=r.c}
  save();draw();
}
el.addEventListener('click',function(e){
  var n=e.target.closest('[data-n]');if(n){L.go('notes');return}
  var tb=e.target.closest('[data-t]');
  if(tb){
    var a2=tb.dataset.t;
    if(a2==='play'){if(!T.on)speakFrom(1);else if(T.paused){T.paused=false;speakFrom(T.v)}else{var v0=T.v;stopT();T.v=v0;T.paused=true;T.on=true;setBarBtns()}}
    else if(a2==='next'||a2==='prev'){var cur=T.v||1,k0=tPane();if(!k0)return;var m=el.querySelectorAll('[data-body="'+k0+'"] .sv').length,nv=Math.max(1,Math.min(m,cur+(a2==='next'?1:-1)));if(T.on&&!T.paused)speakFrom(nv);else{T.v=nv;T.k=k0;mark(k0,nv)}}
    else if(a2==='scroll'){AS.on?stopAS():startAS()}
    else if(a2==='slower'||a2==='faster'){
      var nv=spd()+(a2==='faster'?1:-1);
      if(nv<SPMIN||nv>SPMAX){UI.toast(nv<SPMIN?'Slowest speed':'Fastest speed');return}
      SZ.sp=nv;L.lsSet(SZK,JSON.stringify(SZ));var sl=el.querySelector('#sSpd');if(sl)sl.textContent=spLabel();
    }
    return;
  }
  var b=e.target.closest('[data-a]');if(!b)return;
  var k=b.closest('[data-p]').dataset.p,p=S[k],a=b.dataset.a;
  if(a==='addnote'){addNote(k);return}
  if(a==='ch'&&p.k==='bible'){L.bible.pick({verses:false,tid:p.tid,b:p.b,c:p.c,title:'Go to',place:'reader'}).then(function(r){if(r)setCh(k,r)})}
  else if(a==='ver'){UI.actionSheet({title:'Version',items:L.bible.versions().map(function(v){return{label:(v.id===p.tid?'✓ ':'')+v.name,on:function(){p.tid=v.id;save();draw()}}})})}
  else if(a==='kind'||a==='more'){
    UI.actionSheet({title:'Pane',items:[
      {label:p.k==='bible'?'Show Notes here':'Show Bible here',icon:p.k==='bible'?'note':'book',on:function(){p.k=p.k==='bible'?'notes':'bible';save();draw()}},
      {label:S.link?'Unlink chapters':'Link chapters',icon:'swap',on:function(){S.link=!S.link;if(S.link&&S.b.k==='bible'){S.b.b=S.a.b;S.b.c=S.a.c}save();draw()}},
      {label:S.vlink?'Unlink verses':'Link verses',icon:'swap',on:function(){S.vlink=!S.vlink;save();UI.toast(S.vlink?'Verses linked':'Verses unlinked')}},
      {label:'Close split view',icon:'x',on:function(){stopT();stopAS();L.goBack()}}]});
  }
});
L.split={open:function(){L.go('split')}};
})();
