#!/usr/bin/env python3
"""Download manifest.json from R2 into out/ so a fresh machine adds to the existing list instead of replacing it."""
import os, sys, boto3
out = sys.argv[1] if len(sys.argv) > 1 else 'out'
s3 = boto3.client('s3', endpoint_url='https://%s.r2.cloudflarestorage.com' % os.environ['R2_ACCOUNT_ID'],
                  aws_access_key_id=os.environ['R2_ACCESS_KEY_ID'], aws_secret_access_key=os.environ['R2_SECRET_ACCESS_KEY'], region_name='auto')
os.makedirs(out, exist_ok=True)
s3.download_file(os.environ['R2_BUCKET'], 'manifest.json', os.path.join(out, 'manifest.json'))
