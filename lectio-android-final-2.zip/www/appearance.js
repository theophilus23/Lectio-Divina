/* Settings cards: Reading history (auto-track), Appearance (fonts + colours), Reader layout, Verse backgrounds.
   Also exposes Lectio.vbg.forVerse(), which the reader calls to get a background colour for each verse.
   Every card is a function render(el) that Settings calls each time it opens. Cards keep their state in small
   objects (ap = appearance, rl = reader layout, vb = verse backgrounds) so a click only repaints what changed. */
(function(){
'use strict';
var L=window.Lectio,UI=L.ui,esc=L.esc,T=L.theme;

function clone(o){return JSON.parse(JSON.stringify(o))}
/* JSON text with sorted keys, so two settings objects compare equal whatever order their keys were added in */
function stable(o){
  return JSON.stringify(o,function(k,v){
    if(v&&typeof v==='object'&&!Array.isArray(v)){var s={};Object.keys(v).sort().forEach(function(x){s[x]=v[x]});return s}
    return v;
  });
}
function settingsOpen(){return L.view==='settings'}
/* a version's chip label */
function vShort(v){return esc(v.short||v.id)}

/* ================= card: Reading history (order 20) ================= */
var trackEl=L.addSettingsCard({id:'tracking',order:20,render:renderTracking});
function renderTracking(el){
  var on=L.settings.autoTrack!==false,rs=L.roundStart||{s:0};
  var line;
  if(rs.s)line='Current round started <b>'+esc(UI.fmt.dt(rs.s))+'</b>'+(rs.est?' (estimated from the first chapter you marked)':'')+'.';
  else line=on?'The current round has not started yet. It starts when you mark your first chapter.':'The current round has not started yet. Press Start on the Today or History page.';
  el.innerHTML='<h3>Reading history</h3>'
    +'<button type="button" class="tgl" data-a="auto" aria-pressed="'+on+'"><span>Auto-track my Bible reading</span><i></i></button>'
    +'<p class="note"><b>On:</b> the app records by itself when each reading round starts and ends.<br><b>Off:</b> you press <b>Start</b> yourself on the Today or History page. The finish time is still saved when you mark the last chapter.</p>'
    +'<p class="note" style="color:var(--fg)">'+line+'</p>'
    +'<div class="row"><button type="button" class="btn" data-a="hist">Open History</button></div>';
  el.onclick=function(e){
    var b=e.target.closest('[data-a]');if(!b)return;
    if(b.dataset.a==='auto'){
      L.settings.autoTrack=!(L.settings.autoTrack!==false);
      L.commitSettings();L.emit('track');
      renderTracking(el);
    }else if(b.dataset.a==='hist')L.go('history');
  };
}
L.on('track',function(){if(settingsOpen())renderTracking(trackEl)});

/* ================= card: Appearance (order 30) ================= */
var FONT_SECS=[['all','Everything'],['verse','Verse'],['title','Titles & books'],['ui','App text'],['num','Numbers'],['read','Bible text (all versions)']];
var COLOR_SECS=[['bg','Page'],['book','Books'],['chapter','Chapters'],['done','Completed'],['accent','Accent'],['text','Text']];
var OLD_FONT_KEYS=['verse','title','ui','num','read'];   /* the five font sections that "Everything" changes */
var SEC_NOTE={
  fonts:{all:'Changes the five fonts below together. Bible versions with their own font are not touched.',
    verse:'The large verse on the Today page.',title:'Page titles and book names.',ui:'Buttons, menus and labels.',
    num:'Chapter and verse numbers.',read:'The Bible text in the reader, for every version that has no font of its own.'},
  colors:{bg:'The page background. Cards and lines adapt to it.',book:'Book tiles in the Library.',chapter:'Chapter tiles inside a book.',
    done:'Completed books, chapters and the main buttons.',accent:'Small highlights, labels and links.',text:'Main text colour.'}
};
var ap={el:null,draft:null,tab:'fonts',sec:'verse',texts:{}};

/* a section is either an old one ('verse', 'bg' ...) or a Bible version ('t:<id>') */
function tidOf(sec){return sec.indexOf('t:')===0?sec.slice(2):null}
function secsFor(tab){
  var base=tab==='fonts'?FONT_SECS:COLOR_SECS;
  return base.concat(L.bible.versions().map(function(v){return['t:'+v.id,v.short||v.id,true]}));
}
function apDirty(){
  var d=ap.draft,s=L.settings;
  return stable([d.fonts,d.colors,d.tfonts,d.tcolors])!==stable([s.fonts,s.colors,s.tfonts||{},s.tcolors||{}]);
}
/* is the selected section already at its default? (the Reset button is disabled then) */
function secIsDefault(){
  var d=ap.draft,t=tidOf(ap.sec);
  if(ap.tab==='fonts'){
    if(t)return!d.tfonts[t];
    if(ap.sec==='all')return OLD_FONT_KEYS.every(function(k){return d.fonts[k]===T.DEF_FONTS[k]});
    return d.fonts[ap.sec]===T.DEF_FONTS[ap.sec];
  }
  return t?!d.tcolors[t]:!d.colors[ap.sec];
}

var PV_HTML='<div class="pv" id="apPv" data-hl="bg">'
  +'<div class="pv-top"><span class="pv-brand" data-hl="title">Lect<b style="color:var(--gold)">i</b>o</span><span class="pv-tab" data-hl="ui text">Today</span></div>'
  +'<div data-hl="verse accent"><span class="pv-q" aria-hidden="true">&ldquo;</span><p class="pv-vt">The LORD is my shepherd; I shall not want.</p><span class="pv-ref">Psalm 23:1</span></div>'
  +'<div class="pv-books">'
  +'<div class="book done" data-hl="done title num"><span class="nm">Genesis</span><span class="ct">50/50</span><span class="bar"><i style="width:100%"></i></span><span class="tick"><svg viewBox="0 0 24 24"><path pathLength="1" d="M5 12.5l4.5 4.5L19 7.5"/></svg></span></div>'
  +'<div class="book" data-hl="book title num"><span class="nm">Exodus</span><span class="ct">12/40</span><span class="bar"><i style="width:30%"></i></span></div></div>'
  +'<div class="pv-chaps"><div class="chap done" data-hl="done num">1</div><div class="chap done" data-hl="done num">2</div><div class="chap done" data-hl="done num">3</div><div class="chap" data-hl="chapter num">4</div><div class="chap" data-hl="chapter num">5</div><div class="chap" data-hl="chapter num">6</div><div class="chap" data-hl="chapter num">7</div><div class="chap" data-hl="chapter num">8</div></div>'
  +'<p class="pv-read" data-hl="read">In the beginning God created the heaven and the earth.</p>'
  +'<div class="pv-row"><p class="pv-text" data-hl="ui text">Read a little every day.</p>'
  +'<span class="pv-btn" data-hl="ui text">Bible</span></div></div>'
  /* preview used when a Bible version chip is selected: Genesis 1:1 in that version's draft font and colour */
  +'<div class="pv" id="apPvT" hidden><div class="pv-top"><span class="pv-brand" id="apTName"></span><span class="pv-tab">Genesis 1:1</span></div><p class="pv-tr" id="apTText"></p></div>';

var addedAp=L.addSettingsCard({id:'appearance',order:30,render:renderAppearance});
function renderAppearance(el){
  ap.el=el;ap.draft=clone(L.settings);ap.draft.tfonts=ap.draft.tfonts||{};ap.draft.tcolors=ap.draft.tcolors||{};
  ap.tab='fonts';ap.sec='verse';
  el.innerHTML='<h3>Appearance</h3>'
    +'<div class="seg" id="apMode" role="group" aria-label="Theme">'
    +'<button type="button" data-mode="auto">Auto</button><button type="button" data-mode="light">Light</button><button type="button" data-mode="dark">Dark</button></div>'
    +'<div class="seg" id="apTab" role="group" aria-label="What to change"><button type="button" data-tab="fonts">Fonts</button><button type="button" data-tab="colors">Colours</button></div>'
    +PV_HTML
    +'<div class="chips jump" id="apChips" role="group" aria-label="Section"></div>'
    +'<p class="note" id="apNote"></p>'
    +'<div id="apOpts"></div>'
    +'<p class="note ap-dirty" id="apDirty" hidden>You have changes that are not saved yet. Tap Apply to keep them.</p>'
    +'<div class="row"><button class="btn main" id="apApply" type="button">Apply</button><button class="btn" id="apReset" type="button">Reset this one</button></div>'
    +'<button type="button" class="linkbtn" id="apResetAll">Reset all appearance</button>';
  el.onclick=apClick;
  el.oninput=apInput;
  apPaint();
}
function q(id){return ap.el.querySelector('#'+id)}

function apPaint(){
  if(!ap.el||!q('apChips'))return;
  Array.prototype.forEach.call(ap.el.querySelectorAll('#apMode button'),function(b){b.setAttribute('aria-pressed',String(b.dataset.mode===L.settings.mode))});
  Array.prototype.forEach.call(ap.el.querySelectorAll('#apTab button'),function(b){b.setAttribute('aria-pressed',String(b.dataset.tab===ap.tab))});
  apChips();apOpts();apPreview();
}
function apChips(){
  var box=q('apChips'),keep=box.scrollLeft;
  var secs=secsFor(ap.tab);
  if(!secs.some(function(s){return s[0]===ap.sec}))ap.sec=secs[0][0];   /* a version was removed */
  box.innerHTML=secs.map(function(s,i){
    var sep=(s[2]&&!secs[i-1][2])?'<span class="chipsep" aria-hidden="true"></span>':'';
    return sep+'<button type="button" class="chip" data-sec="'+esc(s[0])+'" aria-pressed="'+(s[0]===ap.sec)+'">'+esc(s[1])+'</button>';
  }).join('');
  box.scrollLeft=keep;
}
function fontBtn(f,on,sample){
  return'<button type="button" class="fopt" data-font="'+f.id+'" aria-pressed="'+on+'"><b style="font-family:'+f.css.replace(/"/g,"'")+'">'+sample+'</b><span>'+esc(f.name)+'</span><i aria-hidden="true">\u2713</i></button>';
}
function apOpts(){
  var d=ap.draft,t=tidOf(ap.sec),h='',note;
  if(ap.tab==='fonts'){
    if(t){
      var tel=L.bible.isTel(L.bible.version(t)),list=T&&window.fontsFor?window.fontsFor(tel):[];
      var cur=d.tfonts[t]||'';
      var defName=tel?T.fontById(window.TEL_DEFAULT).name:'Bible text font';
      h='<div class="fontlist"><button type="button" class="fopt" data-font="" aria-pressed="'+(!cur)+'"><b>Default</b><span>'+esc(defName)+'</span><i aria-hidden="true">\u2713</i></button>'
        +list.map(function(f){return fontBtn(f,cur===f.id,tel?'తెలుగు':'Aa 12')}).join('')+'</div>';
      note='Font used only when reading '+esc(L.bible.version(t).name)+'. Default uses '+(tel?'the standard Telugu font.':'the "Bible text (all versions)" font.');
    }else{
      var curF=ap.sec==='all'?null:d.fonts[ap.sec];
      var allSame=ap.sec==='all'&&OLD_FONT_KEYS.every(function(k){return d.fonts[k]===d.fonts.verse})?d.fonts.verse:null;
      h='<div class="fontlist">'+window.fontsFor(false).map(function(f){return fontBtn(f,ap.sec==='all'?allSame===f.id:curF===f.id,'Aa 12')}).join('')+'</div>';
      note=SEC_NOTE.fonts[ap.sec];
    }
  }else{
    var cv=t?(d.tcolors[t]||null):d.colors[ap.sec];
    h='<div class="swatches"><button type="button" class="sw def" data-color="" aria-pressed="'+(!cv)+'" aria-label="Automatic colour">Auto</button>'
      +T.SWATCHES.map(function(c){return'<button type="button" class="sw" data-color="'+c+'" style="background:'+c+'" aria-pressed="'+(!!cv&&cv.toLowerCase()===c.toLowerCase())+'" aria-label="'+c+'"></button>'}).join('')
      +'</div><label class="custom" style="margin-top:12px">Custom<input type="color" id="apCustom" value="'+(cv||'#1f8a5b')+'"></label>';
    note=t?'Text colour used only when reading '+esc(L.bible.version(t).name)+'. Auto follows the page text colour.':SEC_NOTE.colors[ap.sec];
  }
  q('apOpts').innerHTML=h;
  q('apNote').innerHTML=note||'';
}
/* the style a Bible version's text gets from the draft (same rule as L.theme.tstyle, but on the draft) */
function draftTStyle(tid,tel){
  var f=ap.draft.tfonts[tid],c=ap.draft.tcolors[tid];
  var fn=f&&window.FONTS.some(function(x){return x.id===f})?T.fontById(f).css:(tel?T.fontById(window.TEL_DEFAULT).css:null);
  return{font:fn,color:c||null};
}
function apPreview(){
  var pv=q('apPv'),pt=q('apPvT'),t=tidOf(ap.sec);
  T.applyVars(pv,ap.draft);T.applyVars(pt,ap.draft);
  pv.hidden=!!t;pt.hidden=!t;
  if(t){
    var v=L.bible.version(t),tel=L.bible.isTel(v),st=draftTStyle(t,tel),tx=q('apTText');
    q('apTName').textContent=v.short||v.id;
    tx.style.fontFamily=st.font||'var(--f-read)';
    tx.style.color=st.color||'';
    tx.lang=tel?'te':'';
    if(ap.texts[t]!==undefined)tx.textContent=ap.texts[t]||'No text for Genesis 1:1 in this version.';
    else{
      tx.textContent='Loading…';
      L.bible.verses(t,0,1,1,1).then(function(a){return a[0]||''}).catch(function(){return''}).then(function(s){
        ap.texts[t]=s;
        if(ap.el&&tidOf(ap.sec)===t&&q('apTText'))tx.textContent=s||'No text for Genesis 1:1 in this version.';
      });
    }
  }else{
    Array.prototype.forEach.call(pv.querySelectorAll('[data-hl]'),function(e){e.classList.toggle('hl',e.dataset.hl.split(' ').indexOf(ap.sec)>-1)});
    pv.classList.toggle('hl',ap.sec==='bg'&&ap.tab==='colors');
  }
  var dirty=apDirty();
  q('apApply').disabled=!dirty;q('apDirty').hidden=!dirty;
  q('apReset').disabled=secIsDefault();
}

function apClick(e){
  var d=ap.draft,t=tidOf(ap.sec),b;
  if((b=e.target.closest('[data-mode]'))){
    L.settings.mode=b.dataset.mode;L.commitSettings();apPaint();return;      /* the theme mode is applied at once */
  }
  if((b=e.target.closest('[data-tab]'))){
    ap.tab=b.dataset.tab;
    if(!t)ap.sec=ap.tab==='fonts'?'verse':'bg';       /* a Bible version chip stays selected when switching tab */
    apPaint();return;
  }
  if((b=e.target.closest('[data-sec]'))){ap.sec=b.dataset.sec;apChips();apOpts();apPreview();return}
  if((b=e.target.closest('[data-font]'))){
    var id=b.dataset.font;
    if(t){if(id)d.tfonts[t]=id;else delete d.tfonts[t]}
    else if(ap.sec==='all')OLD_FONT_KEYS.forEach(function(k){d.fonts[k]=id});
    else d.fonts[ap.sec]=id;
    apOpts();apPreview();return;
  }
  if((b=e.target.closest('[data-color]'))){
    var c=b.dataset.color;
    if(t){if(c)d.tcolors[t]=c;else delete d.tcolors[t]}
    else d.colors[ap.sec]=c||null;
    apOpts();apPreview();return;
  }
  if(e.target.closest('#apApply')){
    var s=L.settings;
    s.fonts=clone(d.fonts);s.colors=clone(d.colors);s.tfonts=clone(d.tfonts);s.tcolors=clone(d.tcolors);
    L.commitSettings();apPreview();UI.toast('Appearance saved');return;
  }
  if(e.target.closest('#apReset')){
    /* resets ONLY the selected section, and only in the preview until Apply */
    if(ap.tab==='fonts'){
      if(t)delete d.tfonts[t];
      else if(ap.sec==='all')OLD_FONT_KEYS.forEach(function(k){d.fonts[k]=T.DEF_FONTS[k]});
      else d.fonts[ap.sec]=T.DEF_FONTS[ap.sec];
    }else{
      if(t)delete d.tcolors[t];else d.colors[ap.sec]=null;
    }
    apOpts();apPreview();UI.toast('Reset in the preview. Tap Apply to keep it.');return;
  }
  if(e.target.closest('#apResetAll')){
    UI.confirm('Reset all fonts and colours (including every Bible version) to the defaults? You can still change your mind before tapping Apply.',{ok:'Reset all',danger:true}).then(function(yes){
      if(!yes||!ap.draft)return;
      ap.draft.fonts=clone(T.DEF_FONTS);ap.draft.colors=clone(T.DEF_COLORS);ap.draft.tfonts={};ap.draft.tcolors={};
      apOpts();apPreview();UI.toast('Everything reset in the preview. Tap Apply to keep it.');
    });
  }
}
function apInput(e){
  if(e.target.id!=='apCustom')return;
  var t=tidOf(ap.sec);
  if(t)ap.draft.tcolors[t]=e.target.value;else ap.draft.colors[ap.sec]=e.target.value;
  Array.prototype.forEach.call(ap.el.querySelectorAll('#apOpts .sw'),function(s){s.setAttribute('aria-pressed','false')});
  apPreview();
}
/* new Bible versions (imported or from the manifest) get their own chip */
L.on('versions',function(){if(ap.el&&q('apChips')&&settingsOpen()){apChips();apOpts();apPreview()}});

/* ================= card: Reader layout (order 40) ================= */
/* controls: [key, label, help, min, max, step, unit] */
var SLIDERS=[
  ['gx','Page side margin','Space between the screen edge and the text box.',0,40,1,'px'],
  ['px','Text box side padding','Space inside the text box, left and right.',0,40,1,'px'],
  ['py','Text box top and bottom padding','Space inside the text box, above and below the verses.',0,60,1,'px'],
  ['vx','Verse row side padding','Space inside each verse row (shows with verse backgrounds).',0,24,1,'px'],
  ['vy','Verse spacing','Space above and below each verse.',0,24,1,'px'],
  ['gap','Gap between verses','Space between one verse and the next. Shows as a gap between the coloured verse cards.',0,32,1,'px'],
  ['lh','Line height','Space between lines of text.',1.2,2.4,0.05,''],
  ['op','Text box background','0% is fully see-through, so your page background or photo shows.',0,100,1,'%'],
  ['radius','Corner radius','How round the text box corners are.',0,32,1,'px']
];
var SAMPLE_EN=['In the beginning God created the heaven and the earth.','And the earth was without form, and void; and darkness was upon the face of the deep. And the Spirit of God moved upon the face of the waters.','And God said, Let there be light: and there was light.'];
var rl={el:null,sample:null,t:0};
function readerFirstVersion(){
  try{var id=L.readerPrefs?L.readerPrefs.get().vers[0]:JSON.parse(L.lsGet('lectio-reader-v1')||'{}').vers[0];if(id&&L.bible.hasVersion(id))return L.bible.version(id)}catch(e){}
  return L.bible.versions()[0];
}
L.addSettingsCard({id:'readerlayout',order:40,render:renderLayout});
function renderLayout(el){
  rl.el=el;
  var r=L.settings.reader,rp=L.readerPrefs.get(),rv=readerFirstVersion(),rcol=L.settings.tcolors&&L.settings.tcolors[rv.id];
  var h='<h3>Reader</h3><p class="note">Changes show in the preview and in the reader straight away.</p>'
    +'<div class="rsticky"><div class="rprev"><div class="rpanel"><div class="rtext" id="rlText"></div></div></div></div>'
    +'<div class="rquick"><label>Version<select id="rqVer">'+L.bible.versions().map(function(v){return'<option value="'+esc(v.id)+'"'+(v.id===rv.id?' selected':'')+'>'+esc(v.name)+'</option>'}).join('')+'</select></label>'
    +'<label>Text colour<div class="rrow"><input type="color" id="rqCol" value="'+(rcol||'#444444')+'"><button type="button" class="btn" id="rqAuto">Auto</button></div></label>'
    +'<div class="seg" role="group" aria-label="Alignment" id="rlAlign">'+[['left','Left'],['center','Centre'],['right','Right'],['justify','Justify']].map(function(x){return'<button type="button" data-align="'+x[0]+'">'+x[1]+'</button>'}).join('')+'</div>'
    +'<button type="button" class="btn" id="rlReset" style="grid-column:1/-1">Reset layout</button></div>'
    ;
  function sl(keys){return keys.map(function(k){var s=SLIDERS.filter(function(x){return x[0]===k})[0];return'<label class="rng">'+s[1]+' <b id="rv-'+s[0]+'"></b><input type="range" data-k="'+s[0]+'" min="'+s[3]+'" max="'+s[4]+'" step="'+s[5]+'" value="'+r[s[0]]+'"><small>'+s[2]+'</small></label>'}).join('')}
  var tel=L.bible.isTel(rv),fl=window.fontsFor?window.fontsFor(tel):[],cf=(L.settings.tfonts||{})[rv.id]||'';
  h+='<div class="sec-t">Font and text</div><div class="opts fontrow" id="rqFonts"><button type="button" class="opt" data-rfont="" aria-pressed="'+(!cf)+'"><b>Default</b></button>'
    +fl.map(function(f){return'<button type="button" class="opt" data-rfont="'+f.id+'" aria-pressed="'+(cf===f.id)+'" style="font-family:'+f.css.replace(/"/g,"'")+'"><b>'+(tel?'తెలుగు':'Aa 12')+'</b><span style="font-family:var(--f-ui)">'+esc(f.name)+'</span></button>'}).join('')+'</div>'
    +'<div class="sec-t">Reading view</div>'
    +'<div class="seg" role="group" aria-label="Apply to" id="rvTarget"><button type="button" data-rt="reader" aria-pressed="true">Reader</button><button type="button" data-rt="split" aria-pressed="false">Split view</button></div>'
    +'<div class="rv-row" id="rvSzRow" hidden><span><b>Text size</b><small>Bigger or smaller letters in split view</small></span><span class="rv-btns"><button type="button" class="stpb" data-rv="z-" aria-label="Smaller text">A\u2212</button><button type="button" class="stpb" data-rv="z+" aria-label="Bigger text">A+</button></span></div>'
    +'<div class="rv-row"><span><b>Width</b><small>Make the text wider or narrower</small></span><span class="rv-btns"><button type="button" class="stpb" data-rv="w-" aria-label="Narrower">\u21E5\u21E4</button><button type="button" class="stpb" data-rv="w+" aria-label="Wider">\u21E4\u21E5</button></span></div>'
    +'<div class="rv-row"><span><b>Spacing</b><small>Space between lines and verses</small></span><span class="rv-btns"><button type="button" class="stpb" data-rv="s-" aria-label="Tighter">\u2195\u2193</button><button type="button" class="stpb" data-rv="s+" aria-label="Looser">\u2195\u2191</button></span></div>'
    +'<div class="sec-t">Text box</div>'
    +'<div class="rv-row"><span><b>Background</b><small>Let your page picture show through, or make it solid</small></span><span class="rv-btns"><button type="button" class="stpb" data-rv="o-" aria-label="More see-through">\u25CC</button><button type="button" class="stpb" data-rv="o+" aria-label="More solid">\u25CF</button></span></div>'
    +'<div class="rv-row"><span><b>Corners</b><small>Make the box corners squarer or rounder</small></span><span class="rv-btns"><button type="button" class="stpb" data-rv="r-" aria-label="Squarer">\u25A2</button><button type="button" class="stpb" data-rv="r+" aria-label="Rounder">\u25EF</button></span></div>'
    +'<div class="sec-t">Verse numbers</div><div class="seg" role="group" aria-label="Verse number style" id="rlNums"><button type="button" data-nums="col">Beside text</button><button type="button" data-nums="inline">Inline</button></div>'
    +'<button type="button" class="tgl" data-border="1" id="rlBorder"><span>Border around the text box</span><i></i></button>'
    +'<div class="sec-t">While reading</div>'
    +'<button type="button" class="tgl" data-pref="awake" id="rqAwake"><span>Keep screen on</span><i></i></button>'
    +'<div class="sec-t">Hide menu bar in the reader</div><div class="seg" id="rqHide">'+[['never','Never'],['always','Always'],['scroll','When scrolling']].map(function(x){return'<button type="button" data-hide="'+x[0]+'">'+x[1]+'</button>'}).join('')+'</div>';
  el.innerHTML=h;
  rl.target='reader';el.onclick=rlClick;el.oninput=rlInput;
  rlSync();rlPreview();
}
function rlSync(){
  var r=L.settings.reader,el=rl.el;
  SLIDERS.forEach(function(s){
    var v=r[s[0]],lab=el.querySelector('#rv-'+s[0]);
    if(lab)lab.textContent=(s[0]==='lh'?(+v).toFixed(2):v)+s[6];
  });
  Array.prototype.forEach.call(el.querySelectorAll('[data-align]'),function(b){b.setAttribute('aria-pressed',String(b.dataset.align===r.align))});
  Array.prototype.forEach.call(el.querySelectorAll('[data-nums]'),function(b){b.setAttribute('aria-pressed',String(b.dataset.nums===r.numStyle))});
  var rp=L.readerPrefs.get(),aw=el.querySelector('#rqAwake');if(aw)aw.setAttribute('aria-pressed',String(!!rp.awake));
  Array.prototype.forEach.call(el.querySelectorAll('[data-hide]'),function(b){b.setAttribute('aria-pressed',String(b.dataset.hide===rp.hideBar))});
  el.querySelector('#rlBorder').setAttribute('aria-pressed',String(!!r.border));
}
/* preview built from the real reader markup, so it looks exactly like the reader */
function rlPreview(){
  var box=rl.el&&rl.el.querySelector('#rlText');if(!box)return;
  var v=readerFirstVersion(),tel=L.bible.isTel(v),st=T.tstyle(v.id,tel);
  function paint(texts){
    if(!rl.el||!box.isConnected)return;
    box.style.fontFamily=st.font||'';box.style.color=st.color||'';
    box.innerHTML=texts.map(function(tx,i){
      return'<div class="vs"><span class="vn">'+(i+1)+'</span><div class="vcols"><p class="vt'+(tel?' tel':'')+'" lang="'+(tel?'te':'en')+'"><span class="vni">'+(i+1)+'</span>'+esc(tx)+'</p></div></div>';
    }).join('');
  }
  paint(SAMPLE_EN);
  L.bible.verses(v.id,0,1,1,3).then(function(a){if(a.length&&a.some(Boolean))paint(a.map(function(s,i){return s||SAMPLE_EN[i]}))}).catch(function(){});
}
function rlCommitSoon(){clearTimeout(rl.t);rl.t=setTimeout(function(){L.commitSettings()},300)}
function rlChange(){T.applyReaderLayout(L.settings.reader);rlSync();rlCommitSoon()}
function rlInput(e){
  if(e.target.id==='rqSz'){L.readerPrefs.set('size',+e.target.value);var sv=rl.el.querySelector('#rqSzV');if(sv)sv.textContent=e.target.value+' px';return}
  if(e.target.id==='rqCol'){var t=readerFirstVersion().id;L.settings.tcolors=L.settings.tcolors||{};L.settings.tcolors[t]=e.target.value;T.applyTheme(L.settings);rlPreview();rlCommitSoon();return}
  var k=e.target.dataset&&e.target.dataset.k;if(!k)return;
  L.settings.reader[k]=+e.target.value;rlChange();
}
function rlClick(e){
  var r=L.settings.reader,b;
  if((b=e.target.closest('[data-rt]'))){
    rl.target=b.dataset.rt;
    Array.prototype.forEach.call(rl.el.querySelectorAll('[data-rt]'),function(x){x.setAttribute('aria-pressed',String(x===b))});
    var zr=rl.el.querySelector('#rvSzRow');if(zr)zr.hidden=rl.target!=='split';
    Array.prototype.forEach.call(rl.el.querySelectorAll('[data-rv^="o"],[data-rv^="r"]'),function(x){x.closest('.rv-row').hidden=rl.target==='split'});
    return;
  }
  if((b=e.target.closest('[data-rv]'))){
    var d=b.dataset.rv,up=d[1]==='+';
    if(rl.target==='split'&&L.splitView&&'zws'.indexOf(d[0])>=0){L.splitView.bump(d);return}
    function bump(k,n,lo,hi){r[k]=Math.max(lo,Math.min(hi,Math.round(((+r[k]||0)+n)*100)/100))}
    if(d[0]==='o'){bump('op',up?10:-10,0,100)}
    else if(d[0]==='r'){bump('radius',up?4:-4,0,32)}
    else if(d[0]==='w'){var m=up?-3:3;bump('gx',m,0,40);bump('px',m,0,40);bump('vx',up?-1:1,0,24)}
    else{var m2=up?1:-1;bump('py',m2*3,0,60);bump('vy',m2*2,0,24);bump('gap',m2*2,0,32);bump('lh',m2*0.1,1.2,2.4)}
    rlChange();rlPreview();return;
  }
  if((b=e.target.closest('[data-rfont]'))){var tt=readerFirstVersion().id;L.settings.tfonts=L.settings.tfonts||{};if(b.dataset.rfont)L.settings.tfonts[tt]=b.dataset.rfont;else delete L.settings.tfonts[tt];T.applyTheme(L.settings);L.commitSettings();Array.prototype.forEach.call(rl.el.querySelectorAll('[data-rfont]'),function(x){x.setAttribute('aria-pressed',String(x===b))});rlPreview();return}
  if(e.target.closest('#rqAuto')){var t=readerFirstVersion().id;if(L.settings.tcolors)delete L.settings.tcolors[t];T.applyTheme(L.settings);L.commitSettings();renderLayout(rl.el);return}
  if(e.target.closest('#rqAwake')){var p=L.readerPrefs.get();L.readerPrefs.set('awake',!p.awake);rlSync();return}
  if((b=e.target.closest('[data-hide]'))){L.readerPrefs.set('hideBar',b.dataset.hide);rlSync();return}
  if((b=e.target.closest('[data-align]'))){r.align=b.dataset.align;rlChange();return}
  if((b=e.target.closest('[data-nums]'))){r.numStyle=b.dataset.nums;rlChange();return}
  if(e.target.closest('#rlBorder')){r.border=!r.border;rlChange();return}
  if(e.target.closest('#rlReset')){
    L.settings.reader=clone(T.DEF_READER);T.applyReaderLayout(L.settings.reader);L.commitSettings();
    renderLayout(rl.el);UI.toast('Reader layout reset');
  }
}
document.addEventListener('change',function(e){if(e.target&&e.target.id==='rqVer'){L.readerPrefs.set('version',e.target.value);renderLayout(rl.el)}});
L.on('versions',function(){if(rl.el&&settingsOpen()&&rl.el.querySelector('#rlText'))rlPreview()});

/* ================= verse backgrounds: colour engine ================= */
/* Each palette has a light-theme and a dark-theme list of 12 colours. Light colours are pale (dark text), dark colours are deep (light text).
   'gradient' entries are pairs of similar brightness so the text colour taken from the first colour stays readable. */
var PAL={
  soft:{label:'Soft',
    light:['#FDE7E4','#FCEBD3','#FFF6D1','#E6F4D7','#D8F0E4','#D6EFF2','#DCE8FA','#E5E0F7','#F3DFF2','#F9DFE8','#EDEAE2','#E2ECE9'],
    dark:['#3A2A33','#3B3226','#38361F','#2C3826','#243830','#233639','#26304D','#2F2A4A','#3C2A44','#432A38','#34322C','#27373A']},
  vivid:{label:'Vivid',
    light:['#FFB4A9','#FFCB85','#FFE066','#B9E769','#7FE0B0','#7CD6E6','#8FB8FF','#B7A4FF','#E6A1F2','#FF9EC0','#F5C26B','#9EE0D2'],
    dark:['#8C2F39','#9A5B1B','#8A7410','#4F7A1E','#1F7A55','#1B7283','#2A57A6','#5B3FB5','#8A3A9A','#A12E5E','#8A5A12','#1E7A70']},
  earth:{label:'Earth',
    light:['#EADBC8','#E3CDB0','#D9C2A0','#CFD3B0','#C3CBA3','#D8C4B8','#E6D5C3','#D1BFA3','#E9DCC1','#C9B79C','#DDD0B8','#D3C6A9'],
    dark:['#3B2F25','#4A3A28','#3F4026','#2F3B2A','#4A3030','#3A3328','#524132','#3C3A2A','#463726','#2F3A33','#4C3B30','#40382A']},
  night:{label:'Night',
    light:['#DDE3F5','#D7DCF0','#E1DDF2','#D3E2F0','#DAD6EE','#CFD9EC','#E3E6F4','#D5DDF3','#DCD3EE','#CBDDEB','#D9DFF0','#D2D4EA'],
    dark:['#18244A','#241C4D','#12304A','#2B2358','#173A4D','#33235A','#142A56','#262B5C','#1A3744','#3A2766','#133257','#222652']},
  gradient:{label:'Gradient',
    light:[['#FDE7E4','#FCEBD3'],['#FCEBD3','#FFF6D1'],['#E6F4D7','#D8F0E4'],['#D8F0E4','#D6EFF2'],['#D6EFF2','#DCE8FA'],['#DCE8FA','#E5E0F7'],['#E5E0F7','#F3DFF2'],['#F3DFF2','#F9DFE8'],['#F9DFE8','#FDE7E4'],['#FFF6D1','#E6F4D7'],['#EDEAE2','#E2ECE9'],['#E2ECE9','#DCE8FA']],
    dark:[['#3A2A33','#3B3226'],['#3B3226','#38361F'],['#2C3826','#243830'],['#243830','#233639'],['#233639','#26304D'],['#26304D','#2F2A4A'],['#2F2A4A','#3C2A44'],['#3C2A44','#432A38'],['#432A38','#3A2A33'],['#38361F','#2C3826'],['#34322C','#27373A'],['#27373A','#26304D']]}
};
/* '#abc', '#aabbcc' or 'rgb(1,2,3)' -> '#aabbcc', or null */
function toHex(s){
  s=String(s||'').trim();var m;
  if((m=s.match(/^#([0-9a-f]{3})$/i)))return'#'+m[1].split('').map(function(c){return c+c}).join('');
  if(/^#[0-9a-f]{6}$/i.test(s))return s;
  if((m=s.match(/^rgba?\(\s*(\d+)[ ,]+(\d+)[ ,]+(\d+)/i)))return'#'+[m[1],m[2],m[3]].map(function(n){return(+n).toString(16).padStart(2,'0')}).join('');
  return null;
}
/* is the page currently dark? Looks at the real --bg colour, so light, dark, auto and custom page colours all work */
function isDark(){
  var hex=toHex(getComputedStyle(document.documentElement).getPropertyValue('--bg'));
  if(hex)return T.lum(hex)<0.36;
  return!!(window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches);
}
/* small deterministic hash of 4 integers -> 0..2^32-1 */
function hash4(a,b,c,d){
  var h=Math.imul(a|0,2654435761)^Math.imul((b|0)+1,40503)^Math.imul((c|0)+1,69069)^Math.imul((d|0)+1,1103515245);
  h^=h>>>15;h=Math.imul(h,2246822519);h^=h>>>13;h=Math.imul(h,3266489917);h^=h>>>16;
  return h>>>0;
}
/* colour numbers for verses 1..SEQ_LEN of one chapter. A verse never gets the same number as the verse before it. */
var SEQ_LEN=200,seqCache={},seqCount=0;
function sequence(seed,b,c,n){
  var key=seed+':'+b+':'+c+':'+n;
  if(seqCache[key])return seqCache[key];
  if(seqCount>300){seqCache={};seqCount=0}
  var seq=[0],prev=-1;                      /* index 0 unused: verses start at 1 */
  for(var v=1;v<=SEQ_LEN;v++){
    var i=hash4(seed,b,c,v)%n;
    if(i===prev)i=(i+1)%n;
    seq.push(i);prev=i;
  }
  seqCount++;return(seqCache[key]=seq);
}
/* the colour for one verse from a palette -> {bg, fg} */
function colorFor(palette,dark,seed,b,c,v){
  var p=PAL[palette]||PAL.soft,list=dark?p.dark:p.light;
  var seq=sequence(seed,b,c,list.length);
  var i=v<=SEQ_LEN?seq[v]:hash4(seed,b,c,v)%list.length;
  var e=list[i];
  if(Array.isArray(e))return{bg:'linear-gradient(135deg,'+e[0]+','+e[1]+')',fg:T.readable(e[0])};
  return{bg:e,fg:T.readable(e)};
}
/* Public API for the reader.
   shownTids = ids of the Bible versions on screen. Returns null when verse backgrounds are off (or do not apply to these versions).
   All versions of one verse share a colour, because the colour depends only on seed + book + chapter + verse. */
L.vbg={
  forVerse:function(shownTids,b,c,v){
    var s=L.settings.vbg;
    if(!s||!s.on)return null;
    if(s.mode==='selected'){
      var sel=s.sel||[];
      if(!(shownTids||[]).some(function(t){return sel.indexOf(t)>-1}))return null;
    }
    return colorFor(s.palette,isDark(),+s.seed||1,b,c,v);
  }
};

/* ================= card: Verse backgrounds (order 45) ================= */
var vb={el:null};
L.addSettingsCard({id:'verbg',order:45,render:renderVbg});
function vbSave(){L.commitSettings();vbPaint()}
function renderVbg(el){
  vb.el=el;
  el.onclick=vbClick;
  vbPaint();
}
function vbPaint(){
  var el=vb.el;if(!el)return;
  var s=L.settings.vbg,dark=isDark(),vers=L.bible.versions();
  var h='<h3>Verse backgrounds</h3>'
    +'<button type="button" class="tgl" data-a="on" aria-pressed="'+!!s.on+'"><span>Random background for each verse</span><i></i></button>'
    +'<p class="note">Gives every verse in the reader its own soft colour. When you read versions side by side, all versions of a verse share one background.</p>';
  if(s.on){
    h+='<div class="sec-t">Apply to</div><div class="seg" role="group" aria-label="Apply to"><button type="button" data-a="mode" data-v="all" aria-pressed="'+(s.mode!=='selected')+'">All versions</button><button type="button" data-a="mode" data-v="selected" aria-pressed="'+(s.mode==='selected')+'">Selected versions</button></div>';
    if(s.mode==='selected'){
      h+='<div class="chips" role="group" aria-label="Versions">'+vers.map(function(v){return'<button type="button" class="chip" data-a="sel" data-v="'+esc(v.id)+'" aria-pressed="'+(s.sel.indexOf(v.id)>-1)+'">'+vShort(v)+'</button>'}).join('')+'</div>'
        +'<p class="note">'+(s.sel.length?'Backgrounds show whenever at least one of the versions on screen is ticked.':'Tick at least one version, or nothing will get a background.')+'</p>';
    }
    h+='<div class="sec-t">Colours</div><div class="vbpals">'+Object.keys(PAL).map(function(k){
      var list=(dark?PAL[k].dark:PAL[k].light).slice(0,6);
      return'<button type="button" class="vbpal" data-a="pal" data-v="'+k+'" aria-pressed="'+(s.palette===k)+'"><span class="vbstrip">'+list.map(function(c){
        var bg=Array.isArray(c)?'linear-gradient(135deg,'+c[0]+','+c[1]+')':c;return'<i style="background:'+bg+'"></i>';
      }).join('')+'</span><b>'+PAL[k].label+'</b></button>';
    }).join('')+'</div>';
    h+='<div class="vbprev" aria-hidden="true">'+[1,2,3,4].map(function(v){
      var c=colorFor(s.palette,dark,+s.seed||1,0,1,v);
      return'<div class="vbrow" style="background:'+c.bg+';color:'+c.fg+'"><span>'+v+'</span>'+['In the beginning God created the heaven and the earth.','And the earth was without form, and void.','And God said, Let there be light.','And God saw the light, that it was good.'][v-1]+'</div>';
    }).join('')+'</div>'
    +'<div class="row"><button type="button" class="btn" data-a="shuffle">Shuffle colours</button></div>';
  }
  el.innerHTML=h;
}
function vbClick(e){
  var b=e.target.closest('[data-a]');if(!b)return;
  var s=L.settings.vbg,a=b.dataset.a,v=b.dataset.v;
  if(a==='on')s.on=!s.on;
  else if(a==='mode')s.mode=v==='selected'?'selected':'all';
  else if(a==='sel'){var i=s.sel.indexOf(v);if(i>-1)s.sel.splice(i,1);else s.sel.push(v)}
  else if(a==='pal')s.palette=v;
  else if(a==='shuffle')s.seed=(+s.seed||1)+1;
  vbSave();
}
/* repaint when the theme changes (palette strips depend on light/dark) or versions change */
L.on('settings',function(){if(settingsOpen()&&vb.el)vbPaint()});
L.on('versions',function(){if(settingsOpen()&&vb.el)vbPaint()});
})();
