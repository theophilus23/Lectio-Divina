import sys,os
sys.path.insert(0,os.path.join(os.path.dirname(os.path.abspath(__file__))))
from harness import app
with app() as (page,base):
    page.goto(base); page.wait_for_timeout(800)
    print('errors:',page.errors)
    print('title', page.title(), 'view', page.evaluate("Lectio.view"))
    page.evaluate('Lectio.go("settings")'); page.wait_for_timeout(300)
    print('menu items', page.eval_on_selector_all('.ditem','e=>e.map(x=>x.textContent)'))
    page.screenshot(path='/tmp/claude-0/smoke.png')
