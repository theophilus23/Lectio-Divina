import sys, os, json; sys.path.insert(0, 'test')
from harness import app
SC='/tmp/claude-0/-home-claude/9ac21290-e598-5b5b-8a6d-943898313428/scratchpad'
OUT=SC+'/shots'
man=json.load(open(SC+'/out_test/manifest.json'))
def route(r):
    u=r.request.url
    if u.endswith('songs/config.js'):
        return r.fulfill(body="window.LSONGS_CONFIG={tracksBase:'https://tracks.test/'};",content_type='application/javascript')
    p=u.split('tracks.test/')[1]
    if p=='manifest.json': return r.fulfill(body=json.dumps(man),content_type='application/json',headers={'access-control-allow-origin':'*'})
    return r.fulfill(path=SC+'/out_test/'+p,content_type='audio/mpeg',headers={'access-control-allow-origin':'*'})
with app(width=390,height=800) as (page, base):
    page.route('**/songs/config.js',route); page.route('https://tracks.test/**',route)
    page.goto(base); page.wait_for_timeout(800)
    page.evaluate("Lectio.go('songs')"); page.wait_for_timeout(900)
    page.evaluate("LSongs.openByKey('zion','7')"); page.wait_for_timeout(1200)
    print('shown',page.evaluate("!document.querySelector('.sg-listen').hidden"), page.evaluate("document.querySelector('.sg-listen audio')&&document.querySelector('.sg-listen audio').src"))
    page.screenshot(path=OUT+'/tk1.png')
    page.click('.sg-listen [data-m=inst]'); page.wait_for_timeout(500)
    print('inst', page.evaluate("document.querySelector('.sg-listen audio').src"))
    print('dur', page.evaluate("new Promise(r=>{const a=document.querySelector('.sg-listen audio');a.preload='auto';a.load();a.onloadedmetadata=()=>r(a.duration);setTimeout(()=>r(-1),4000)})"))
    page.evaluate("LSongs.openByKey('zion','8')"); page.wait_for_timeout(1000)
    print('song8 hidden',page.evaluate("document.querySelector('.sg-listen').hidden"))
    print('ERR',page.errors)
