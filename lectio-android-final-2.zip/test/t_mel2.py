import sys; sys.path.insert(0,'test')
from harness import app
INIT="""navigator.mediaDevices.getUserMedia=async function(){const ac=new AudioContext();const d=ac.createMediaStreamDestination();const o=ac.createOscillator();o.type='sawtooth';o.connect(d);o.frequency.value=440;o.start();return d.stream};"""
with app(width=390,height=800,init_script=INIT,permissions=['microphone']) as (page,base):
    page.goto(base);page.wait_for_timeout(800);page.evaluate("Lectio.go('songs')");page.wait_for_timeout(900)
    page.click('.sg-row >> nth=2');page.wait_for_timeout(900);page.click('[data-a="rec"]')
    page.click('[data-r="toggle"]');page.wait_for_timeout(2500);page.click('[data-r="toggle"]');page.wait_for_timeout(600)
    page.click('[data-r="saveall"]');page.wait_for_timeout(400)
    page.click('[data-r="pick"]');page.wait_for_timeout(1500)
    page.screenshot(path='/tmp/claude-0/-home-claude/9ac21290-e598-5b5b-8a6d-943898313428/scratchpad/shots/m1.png')
    page.evaluate("window.__mock&&__mock.signInAs('Leo')");page.wait_for_timeout(500)
    page.click('[data-r="share"]');page.wait_for_timeout(500)
    page.click('.ucard .btn.main');page.wait_for_timeout(1200)
    print(page.evaluate("JSON.stringify(window.__mock.dump('song_melodies')).slice(0,300)"))
    print(page.inner_text('.sg-mel')[:200])
    print('ERR',page.errors)
