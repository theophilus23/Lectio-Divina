// node test/verify-quiz.js : checks every quiz reference exists in the KJV files
const fs=require('fs');global.window={};
const vm=require('vm');const ctx={window:global.window,console};vm.createContext(ctx);vm.runInContext(fs.readFileSync('www/data.js','utf8')+';this.__B=BOOKS;this.__V=VERSES',ctx);
const BOOKS=ctx.__B;global.VERSES=ctx.__V;
require('../www/quizdata.js');
const man=JSON.parse(fs.readFileSync('www/bibles/manifest.json','utf8'));const dir='kjv';
let bad=0;
for(const q of window.QUIZ){
  const m=q.ref.match(/^(.+?) (\d+)(?::(\d+))?/);if(!m){console.log('unparsed',q.id,q.ref);bad++;continue}
  const nm=m[1]==='Psalm'?'Psalms':m[1];const bi=BOOKS.findIndex(b=>b.n===nm);if(bi<0){console.log('book?',q.id,q.ref);bad++;continue}
  try{const f=JSON.parse(fs.readFileSync(`www/bibles/${dir}/${bi}.json`,'utf8'));const ch=f[m[2]-1];if(!ch||(m[3]&&!ch[m[3]-1])){console.log('missing',q.id,q.ref);bad++}}catch(e){console.log('file?',bi,e.message);bad++;break}
  if(q.o.length!==4||new Set(q.o).size!==4||!q.o[q.a]){console.log('options',q.id);bad++}
}
console.log(window.QUIZ.length,'questions,',bad,'problems');
