/* Listen strip for Songs of Zion: plays the generated guide track / instrumental when one exists for the song. */
(function(){
'use strict';
var S=window.LSongs;if(!S)return;
var CFG=window.LSONGS_CONFIG||{},BASE=CFG.tracksBase||'',CK='lectio-songs-tracks';
var man=null,loading=null,cur=null;
try{man=JSON.parse(localStorage.getItem(CK)||'null')}catch(e){}
function load(){
  if(!BASE)return Promise.resolve(null);
  if(loading)return loading;
  loading=fetch(BASE+'manifest.json',{cache:'no-cache'}).then(function(r){if(!r.ok)throw 0;return r.json()}).then(function(j){
    man=j;try{localStorage.setItem(CK,JSON.stringify(j))}catch(e){}return j;
  }).catch(function(){return man}).then(function(j){loading=null;return j});
  return loading;
}
function stop(){var a=cur&&cur.querySelector('audio');if(a){try{a.pause()}catch(e){}a.removeAttribute('src');try{a.load()}catch(e){}}if(cur){cur.hidden=true;cur.innerHTML=''}}
S.listenStop=stop;
S.listenSong=function(model,el){
  stop();cur=el;if(el)delete el.dataset.n;
  if(!BASE||!model||!model.sec||!model.sec.zion)return;
  var n=String(model.it&&model.it.n);
  function show(m){
    if(cur!==el||!m||!m.songs||!m.songs[n])return;
    var t=m.songs[n],mode='guide';
    if(el.dataset.n===n&&!el.hidden)return;el.dataset.n=n;
    el.hidden=false;
    el.innerHTML='<span class="lb">Listen</span><span class="tg"><button type="button" data-m="guide" aria-pressed="true">Track</button><button type="button" data-m="inst" aria-pressed="false">Instrumental</button></span>'
      +'<audio controls preload="none"></audio><span class="inf">Auto-made from '+t.by+' shared '+(t.by===1?'melody':'melodies')+' · key '+t.key+' · '+t.bpm+' bpm</span>';
    var au=el.querySelector('audio');au.src=BASE+t.guide;
    el.querySelector('.tg').onclick=function(e){
      var b=e.target.closest('button');if(!b||b.dataset.m===mode)return;
      mode=b.dataset.m;var was=!au.paused,at=au.currentTime;
      [].forEach.call(el.querySelectorAll('.tg button'),function(x){x.setAttribute('aria-pressed',x===b)});
      au.src=BASE+t[mode];au.currentTime=0;if(was)au.play().catch(function(){});
    };
  }
  show(man);load().then(show);
};
})();
