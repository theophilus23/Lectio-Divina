(function(){
'use strict';
var $=function(id){return document.getElementById(id)};
var CHECK='<svg viewBox="0 0 24 24"><path pathLength="1" d="M5 12.5l4.5 4.5L19 7.5"/></svg>';
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function lsGet(k){try{return window.localStorage.getItem(k)}catch(e){return null}}
function lsSet(k,v){try{window.localStorage.setItem(k,v)}catch(e){}}
var toastT;
function toast(msg){var t=$('toast');t.textContent=msg;t.classList.add('on');clearTimeout(toastT);toastT=setTimeout(function(){t.classList.remove('on')},2400)}

/* ================= progress (local) ================= */
var done=BOOKS.map(function(){return new Set()}), stamp=BOOKS.map(function(){return 0});
function progressObj(){
  var p={};
  done.forEach(function(s,i){if(stamp[i]>0||s.size)p[i]={c:Array.from(s).sort(function(a,b){return a-b}),t:stamp[i]||1}});
  return p;
}
function setProgress(p){
  done.forEach(function(s){s.clear()});stamp.fill(0);
  Object.keys(p||{}).forEach(function(k){
    var i=+k, r=p[k];if(!BOOKS[i]||!r)return;
    (r.c||[]).forEach(function(c){if(c>=1&&c<=BOOKS[i].c)done[i].add(c)});
    stamp[i]=+r.t||1;
  });
}
var rounds=0,roundsT=0;
function saveProgress(){lsSet('lectio-v2',JSON.stringify({p:progressObj(),r:{n:rounds,t:roundsT}}))}
function mergeRounds(r){if(r&&(+r.n||0)>rounds){rounds=+r.n;roundsT=+r.t||0;return true}return false}
function loadProgress(){
  try{
    var raw=lsGet('lectio-v2');
    if(raw){var o2=JSON.parse(raw);setProgress(o2.p);if(o2.r){rounds=+o2.r.n||0;roundsT=+o2.r.t||0}return}
    var old=lsGet('lectio-progress-v1');
    if(old){var o=JSON.parse(old),p={};Object.keys(o).forEach(function(k){p[k]={c:o[k],t:1}});setProgress(p)}
  }catch(e){}
}
function isDone(i){return done[i].size===BOOKS[i].c}
function totals(){var ch=0,bk=0;done.forEach(function(s,i){ch+=s.size;if(isDone(i))bk++});return{ch:ch,bk:bk}}
function mergeProgress(rp){
  var changed=false;
  Object.keys(rp||{}).forEach(function(k){
    var i=+k, r=rp[k];if(!BOOKS[i]||!r)return;
    if((+r.t||0)>(stamp[i]||0)){
      done[i].clear();(r.c||[]).forEach(function(c){if(c>=1&&c<=BOOKS[i].c)done[i].add(c)});
      stamp[i]=+r.t;changed=true;
    }
  });
  return changed;
}

/* ================= settings (fonts + colours) ================= */
var DEF_FONTS={verse:'cormorant',title:'cormorant',ui:'hanken',num:'cormorant',read:'lora'};
var DEF_COLORS={bg:null,book:null,chapter:null,done:null,accent:null,text:null};
var FONT_SECS=[['all','Everything'],['verse','Verse'],['title','Titles & books'],['ui','App text'],['num','Numbers'],['read','Bible text']];
var COLOR_SECS=[['bg','Page'],['book','Books'],['chapter','Chapters'],['done','Completed'],['accent','Accent'],['text','Text']];
var SWATCHES=['#0B1020','#101820','#14110F','#0E1A14','#1B1B1B','#000000','#1E2A4A','#2B1D3A','#3B2A20','#123B33','#4A1F2A','#2F3640','#FFFFFF','#F4F1EA','#EDEFF3','#E8F1EC','#F6E9EE','#FFF6DD','#E5EEFB','#EADFF5','#1F8A5B','#35C089','#2E7D32','#00A86B','#D6B268','#8A6819','#E4572E','#C2185B','#3B82F6','#7C4DFF','#F59E0B','#14B8A6','#9AA3B8','#5A6479'];
var ALLVARS=['--bg','--fg','--surface','--surface2','--line','--muted','--book','--book-fg','--chap','--chap-fg','--green','--green-fg','--gold','--gold-soft','--f-verse','--f-title','--f-ui','--f-num','--f-read','--verse-style'];

function clone(o){return JSON.parse(JSON.stringify(o))}
function fontById(id){for(var i=0;i<FONTS.length;i++)if(FONTS[i].id===id)return FONTS[i];return FONTS[0]}
function hex2rgb(h){h=h.replace('#','');return[parseInt(h.slice(0,2),16),parseInt(h.slice(2,4),16),parseInt(h.slice(4,6),16)]}
function rgb2hex(r){return'#'+r.map(function(v){return Math.max(0,Math.min(255,Math.round(v))).toString(16).padStart(2,'0')}).join('')}
function mix(a,b,t){var x=hex2rgb(a),y=hex2rgb(b);return rgb2hex([x[0]+(y[0]-x[0])*t,x[1]+(y[1]-x[1])*t,x[2]+(y[2]-x[2])*t])}
function hexA(h,a){var c=hex2rgb(h);return'rgba('+c[0]+','+c[1]+','+c[2]+','+a+')'}
function lum(h){var c=hex2rgb(h).map(function(v){v/=255;return v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4)});return .2126*c[0]+.7152*c[1]+.0722*c[2]}
function readable(h){return lum(h)>0.36?'#10151F':'#FFFFFF'}

function fontVars(f){
  var v={};
  v['--f-verse']=fontById(f.verse).css;
  v['--f-title']=fontById(f.title).css;
  v['--f-ui']=fontById(f.ui).css;
  v['--f-num']=fontById(f.num).css;
  v['--f-read']=fontById(f.read).css;
  v['--verse-style']=fontById(f.verse).it?'italic':'normal';
  return v;
}
function colorVars(c){
  var v={}, fg=null;
  if(c.bg){
    fg=c.text||(lum(c.bg)>0.36?'#121A2E':'#ECEFF7');
    v['--bg']=c.bg;v['--fg']=fg;
    v['--surface']=mix(c.bg,fg,.07);v['--surface2']=mix(c.bg,fg,.14);
    v['--line']=hexA(fg,.14);v['--muted']=mix(fg,c.bg,.42);
    v['--book']=v['--surface'];v['--chap']=v['--surface'];
    v['--book-fg']=fg;v['--chap-fg']=fg;
  }else if(c.text){v['--fg']=c.text}
  if(c.book){v['--book']=c.book;v['--book-fg']=readable(c.book)}
  if(c.chapter){v['--chap']=c.chapter;v['--chap-fg']=readable(c.chapter)}
  if(c.done){v['--green']=c.done;v['--green-fg']=readable(c.done)}
  if(c.accent){v['--gold']=c.accent;v['--gold-soft']=hexA(c.accent,.15)}
  return v;
}
function applyVars(el,s){
  ALLVARS.forEach(function(n){el.style.removeProperty(n)});
  var v=Object.assign({},fontVars(s.fonts),colorVars(s.colors));
  Object.keys(v).forEach(function(n){el.style.setProperty(n,v[n])});
}
function applyTheme(s){
  var r=document.documentElement;
  applyVars(r,s);
  if(s.mode==='light'||s.mode==='dark')r.setAttribute('data-theme',s.mode);else r.removeAttribute('data-theme');
}

var settings={mode:'auto',fonts:clone(DEF_FONTS),colors:clone(DEF_COLORS)}, settingsT=0;
function loadSettings(){
  try{
    var raw=lsGet('lectio-settings-v1');if(!raw)return;
    var o=JSON.parse(raw);setSettings(o.d);settingsT=+o.t||0;
  }catch(e){}
}
function setSettings(d){
  if(!d)return;
  settings={
    mode:(d.mode==='light'||d.mode==='dark')?d.mode:'auto',
    fonts:Object.assign(clone(DEF_FONTS),d.fonts||{}),
    colors:Object.assign(clone(DEF_COLORS),d.colors||{})
  };
  Object.keys(settings.fonts).forEach(function(k){if(!DEF_FONTS[k]||!FONTS.some(function(f){return f.id===settings.fonts[k]}))settings.fonts[k]=DEF_FONTS[k]});
}
function saveSettings(){settingsT=Date.now();lsSet('lectio-settings-v1',JSON.stringify({d:settings,t:settingsT}))}

/* ================= Firebase: account + sync ================= */
var CFG=window.LECTIO_FIREBASE||(typeof firebaseConfig!=='undefined'?firebaseConfig:{});
var fb={on:false,err:'',reason:'',auth:null,db:null}, user=null, sync={state:'idle',at:null}, pushT=null, lastResume=0;
(function initFirebase(){
  if(!window.firebase){fb.reason='sdk';return}
  if(!CFG.apiKey){fb.reason='nocfg';return}
  if(/PASTE/.test(CFG.apiKey+(CFG.projectId||'')+(CFG.appId||''))){fb.reason='placeholder';return}
  try{
    firebase.initializeApp(CFG);
    fb.auth=firebase.auth();fb.db=firebase.firestore();
    try{fb.db.settings({experimentalAutoDetectLongPolling:true,merge:true})}catch(e){}
    fb.on=true;
  }catch(e){fb.err='Firebase setup problem: '+(e&&e.message||e)}
})();
function userName(){return user&&(user.displayName||(user.email||'').split('@')[0])||''}
function firstName(){return userName().trim().split(/\s+/)[0]||''}

async function syncNow(manual){
  if(!fb.on||!user)return;
  sync.state='syncing';renderAccount();
  try{
    var ref=fb.db.collection('users').doc(user.uid);
    var snap=await ref.get();
    var rd=snap.exists?snap.data():{};
    var chP=mergeProgress(rd.p||{});
    if(mergeRounds(rd.rounds))chP=true;
    var chS=false;
    if(rd.settings&&(+rd.settings.t||0)>settingsT){setSettings(rd.settings.d);settingsT=+rd.settings.t;lsSet('lectio-settings-v1',JSON.stringify({d:settings,t:settingsT}));chS=true}
    if(chP){saveProgress()}
    await ref.set({name:userName(),email:user.email||'',p:progressObj(),rounds:{n:rounds,t:roundsT},settings:{d:settings,t:settingsT},updated:firebase.firestore.FieldValue.serverTimestamp()});
    sync.state='ok';sync.at=new Date();
    if(chS)applyTheme(settings);
    if(chP||chS)refreshViews();
    if(manual)toast('Synced');
  }catch(e){
    sync.state=(e&&(e.code==='unavailable'||/network|offline/i.test(e.message||'')))?'offline':'error';
    sync.msg=e&&e.code==='permission-denied'?'Cloud rules block this account. Check firestore.rules.':'';
    if(manual)toast(sync.state==='offline'?'You are offline. Will sync later.':'Sync failed');
  }
  renderAccount();
}
function schedulePush(){
  if(!fb.on||!user)return;
  clearTimeout(pushT);pushT=setTimeout(function(){syncNow(false)},1500);
}
if(fb.on){
  fb.auth.onAuthStateChanged(function(u){
    user=u;
    if(u){
      var owner=lsGet('lectio-owner');
      if(owner&&owner!==u.uid){setProgress({});rounds=0;roundsT=0;saveProgress()}
      lsSet('lectio-owner',u.uid);
      refreshViews();
      syncNow(false);
    }else{sync.state='idle'}
    renderAccount();renderHome();
  });
  window.addEventListener('online',function(){syncNow(false)});
  document.addEventListener('visibilitychange',function(){
    if(document.visibilityState==='visible'&&user&&Date.now()-lastResume>30000){lastResume=Date.now();syncNow(false)}
  });
}

/* ---- account card ---- */
function syncLine(){
  if(sync.state==='syncing')return'<p class="sync">Syncing…</p>';
  if(sync.state==='ok')return'<p class="sync ok">Synced '+sync.at.toLocaleTimeString([], {hour:'numeric',minute:'2-digit'})+'</p>';
  if(sync.state==='offline')return'<p class="sync bad">Offline. Changes sync when you are back online.</p>';
  if(sync.state==='error')return'<p class="sync bad">Could not sync. '+esc(sync.msg||'Tap Sync now to retry.')+'</p>';
  return'';
}
function renderAccount(){
  var el=$('acct'),h;
  if(!fb.on){
    var why={
      sdk:'The Firebase files did not load. Run <code>npx cap sync android</code>, then rebuild and reinstall.',
      nocfg:'The app cannot read <code>www/firebase-config.js</code>. It must contain only the <code>window.LECTIO_FIREBASE = {...}</code> block, with no import lines. If the file is missing, copy <code>firebase-config.example.js</code> to that name. Then sync and rebuild.',
      placeholder:'<code>www/firebase-config.js</code> still has the PASTE placeholders. Replace them with the keys from your Firebase <b>Web</b> app, then run <code>npx cap sync android</code> and rebuild.'
    }[fb.reason]||'Add your Firebase keys to <code>www/firebase-config.js</code>.';
    h='<h3>Account</h3><p class="muted">Cloud sign-in is off. '+why+' Until then your progress is saved on this phone.</p>'+(fb.err?'<p class="err">'+esc(fb.err)+'</p>':'');
  }else if(!user){
    h='<h3>Account</h3><p class="muted">Sign in to back up your progress and read on any device. Your progress on this phone is kept and merged into your account.</p><div class="row"><button class="btn main" data-act="signin" type="button">Sign in</button><button class="btn" data-act="signup" type="button">Create account</button></div><p class="sync">Cloud project: '+esc(CFG.projectId||'')+'</p>';
  }else{
    h='<h3>'+esc(userName())+'</h3><p class="muted">'+esc(user.email||'')+'</p>'+syncLine()+'<div class="row"><button class="btn" data-act="sync" type="button">Sync now</button><button class="btn" data-act="signout" type="button">Sign out</button></div>';
  }
  el.innerHTML=h;
}
$('acct').addEventListener('click',function(e){
  var a=e.target.closest('[data-act]');if(!a)return;
  var act=a.dataset.act;
  if(act==='signin')openAuth('signin');
  else if(act==='signup')openAuth('signup');
  else if(act==='sync')syncNow(true);
  else if(act==='signout'){fb.auth.signOut().then(function(){toast('Signed out. Progress stays on this phone.')})}
});

/* ---- sign-in screen ---- */
var authMode='signin';
function setAuthMode(m){
  authMode=m;
  $('authTitle').textContent=m==='signin'?'Sign in':'Create account';
  $('authGo').textContent=m==='signin'?'Sign in':'Create account';
  $('authSwap').textContent=m==='signin'?'Create an account':'I already have an account';
  $('nameRow').hidden=m==='signin';
  $('authPass').autocomplete=m==='signin'?'current-password':'new-password';
  $('authErr').textContent='';
}
function openAuth(m){go('auth');setAuthMode(m)}
function authMsg(e){
  var c=e&&e.code||'';
  if(c==='auth/invalid-credential'||c==='auth/wrong-password'||c==='auth/user-not-found')return'Email or password is not right.';
  if(c==='auth/email-already-in-use')return'That email already has an account. Try signing in.';
  if(c==='auth/weak-password')return'Choose a password with at least 6 characters.';
  if(c==='auth/invalid-email')return'Enter a valid email address.';
  if(c==='auth/network-request-failed')return'No internet connection.';
  if(c==='auth/too-many-requests')return'Too many tries. Wait a bit and try again.';
  if(c==='auth/operation-not-allowed')return'Email sign-in is not switched on in Firebase yet.';
  return'Something went wrong. Try again.';
}
$('authSwap').onclick=function(){setAuthMode(authMode==='signin'?'signup':'signin')};
$('authForgot').onclick=async function(){
  var em=$('authEmail').value.trim();
  if(!em){$('authErr').textContent='Enter your email first.';return}
  try{await fb.auth.sendPasswordResetEmail(em);$('authErr').textContent='';toast('Password reset email sent')}
  catch(e){$('authErr').textContent=authMsg(e)}
};
$('authForm').addEventListener('submit',async function(e){
  e.preventDefault();
  var err=$('authErr'),btn=$('authGo');err.textContent='';
  if(!fb.on){err.textContent='Cloud sync is not set up yet. See FIREBASE_SETUP.md.';return}
  var em=$('authEmail').value.trim(),pw=$('authPass').value,nm=$('authName').value.trim();
  if(!em||!pw){err.textContent='Enter your email and password.';return}
  if(authMode==='signup'&&!nm){err.textContent='Enter your name.';return}
  btn.disabled=true;
  try{
    if(authMode==='signup'){
      var cred=await fb.auth.createUserWithEmailAndPassword(em,pw);
      await cred.user.updateProfile({displayName:nm});
      user=fb.auth.currentUser;
    }else{await fb.auth.signInWithEmailAndPassword(em,pw)}
    $('authPass').value='';
    toast(authMode==='signup'?'Welcome, '+(nm||'friend'):'Signed in');
    stack.length=0;show('home');
    syncNow(false);
  }catch(ex){err.textContent=authMsg(ex)}
  btn.disabled=false;
});

/* ================= verse ================= */
var SLOT_MS=15*60*1000, shownSlot=-1;
function rnd(seed){var t=(seed+0x6D2B79F5)|0;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296}
function idxFor(slot){return Math.floor(rnd(slot*7919+13)*VERSES.length)}
function verseIdx(slot){var i=idxFor(slot);if(i===idxFor(slot-1))i=(i+1)%VERSES.length;return i}
function renderVerse(slot){
  var v=VERSES[verseIdx(slot)];
  $('vtext').innerHTML=v[0].split(' ').map(function(w,i){return'<span style="--i:'+i+'">'+w+'</span>'}).join(' ');
  $('vref').textContent=v[1];shownSlot=slot;
}
function tick(){
  var now=Date.now(),slot=Math.floor(now/SLOT_MS);
  if(slot!==shownSlot)renderVerse(slot);
  var into=now-slot*SLOT_MS,left=Math.ceil((SLOT_MS-into)/1000);
  $('tleft').textContent=String(Math.floor(left/60)).padStart(2,'0')+':'+String(left%60).padStart(2,'0');
  $('tbar').style.width=(into/SLOT_MS*100)+'%';
}

/* ================= shared API for reader.js and bg.js ================= */
var L=window.Lectio={$:$,esc:esc,toast:toast,lsGet:lsGet,lsSet:lsSet,onShow:[],back:[],
  openReader:function(){},
  chapterRead:function(b,c){return done[b].has(c)},
  setChapterRead:function(b,c,on){
    if(on)done[b].add(c);else done[b].delete(c);
    stamp[b]=Date.now();saveProgress();schedulePush();
    if(on&&totals().ch===TOTAL_CH)openFinish();
  },
  go:function(n,b){go(n,b)},show:function(n){show(n)},
  get curBook(){return curBook},set curBook(v){curBook=v},
  get view(){return view},
  goBack:function(){onBack()}
};

/* ================= navigation + back button ================= */
var view='home',curBook=0,stack=[],exitArmed=false;
var V={home:$('vHome'),lib:$('vLib'),book:$('vBook'),read:$('vRead'),settings:$('vSettings'),auth:$('vAuth')};
function show(name){
  clearSel();view=name;
  Object.keys(V).forEach(function(k){
    var el=V[k];el.hidden=k!==name;
    if(k===name){el.style.animation='none';void el.offsetWidth;el.style.animation=''}
  });
  $('tabHome').setAttribute('aria-current',name==='home'?'page':'false');
  $('tabLib').setAttribute('aria-current',(name==='lib'||name==='book'||name==='read')?'page':'false');
  document.body.classList.toggle('reading',name==='read');
  $('tabSet').setAttribute('aria-current',(name==='settings'||name==='auth')?'page':'false');
  window.scrollTo(0,0);
  if(name==='home')renderHome();
  else if(name==='lib')renderLib();
  else if(name==='book')renderBook();
  else if(name==='settings')openSettings();
  L.onShow.forEach(function(fn){try{fn(name)}catch(e){}});
}
function go(name,bookIdx){
  var e={view:view,book:curBook},top=stack[stack.length-1];
  if(!top||top.view!==e.view||top.book!==e.book)stack.push(e);
  if(stack.length>30)stack.shift();
  if(name==='book')curBook=bookIdx;
  show(name);
}
function onBack(){
  for(var i=0;i<L.back.length;i++){try{if(L.back[i]())return}catch(e){}}
  if(!$('doneModal').hidden){closeFinish();return}
  if(sel.size){clearSel();return}
  if(stack.length){var p=stack.pop();if(p.view==='book')curBook=p.book;show(p.view);return}
  if(view!=='home'){show('home');return}
  if(exitArmed){var A=capApp();if(A&&A.exitApp)A.exitApp();return}
  exitArmed=true;toast('Press back again to exit');setTimeout(function(){exitArmed=false},2000);
}
function capApp(){return window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.App}
(function(){var A=capApp();if(A&&A.addListener)A.addListener('backButton',onBack)})();
function refreshViews(){
  if(view==='home')renderHome();else if(view==='lib')renderLib();else if(view==='book')renderBook();
}

/* ================= home ================= */
function renderHome(){
  var t=totals(),pct=t.ch/TOTAL_CH,C=263.9,n=firstName();
  $('ringfg').style.strokeDashoffset=C;
  requestAnimationFrame(function(){requestAnimationFrame(function(){$('ringfg').style.strokeDashoffset=C*(1-pct)})});
  $('ringpct').textContent=Math.round(pct*100)+'%';
  $('pname').textContent=n?(n+(/s$/i.test(n)?'’':'’s')+' progress'):'Your progress';
  $('pline1').textContent=t.ch+' of '+TOTAL_CH+' chapters read';
  $('pline2').textContent=t.bk+' of '+BOOKS.length+' books complete';
  $('pline3').textContent='Bible completed '+rounds+(rounds===1?' time':' times')+(rounds>0?' · now on round '+(rounds+1):'');
  $('finishBtn').hidden=t.ch!==TOTAL_CH;
  $('signinHome').hidden=!!user;
}

/* ================= library + chapters ================= */
function bookTile(i,delay){
  var b=BOOKS[i],n=done[i].size,full=n===b.c;
  var cls='book'+(full?' done':'')+(sel.has(i)&&selMode==='lib'?' sel':'')+(popSet.has(i)?' pop':'');
  return'<button type="button" class="'+cls+'" data-id="'+i+'" style="--d:'+delay+'" aria-label="'+b.n+', '+n+' of '+b.c+' chapters read">'
    +'<span class="nm">'+b.n+'</span><span class="ct">'+n+'/'+b.c+'</span>'
    +'<span class="bar"><i style="width:'+(n/b.c*100)+'%"></i></span>'
    +'<span class="tick">'+CHECK+'</span><span class="pick">'+CHECK+'</span></button>';
}
function renderLib(){
  var ot='',nt='',otCh=0,ntCh=0,otB=0,ntB=0,otTot=0,ntTot=0;
  BOOKS.forEach(function(b,i){
    if(i<OT_N){ot+=bookTile(i,i);otCh+=done[i].size;otTot+=b.c;if(isDone(i))otB++}
    else{nt+=bookTile(i,i-OT_N);ntCh+=done[i].size;ntTot+=b.c;if(isDone(i))ntB++}
  });
  $('otGrid').innerHTML=ot;$('ntGrid').innerHTML=nt;
  $('otSub').textContent=otB+'/'+OT_N+' books · '+otCh+'/'+otTot+' ch.';
  $('ntSub').textContent=ntB+'/'+(BOOKS.length-OT_N)+' books · '+ntCh+'/'+ntTot+' ch.';
  var t=totals();
  $('libStats').textContent=t.bk+' of '+BOOKS.length+' books · '+t.ch+' of '+TOTAL_CH+' chapters read';
  popSet.clear();
}
function renderBook(){
  var b=BOOKS[curBook],n=done[curBook].size,h='';
  $('bkTest').textContent=b.t;$('bkName').textContent=b.n;
  $('bkStats').textContent=n+' of '+b.c+' chapters read';
  $('bkMeter').style.width=(n/b.c*100)+'%';
  for(var c=1;c<=b.c;c++){
    var cls='chap'+(done[curBook].has(c)?' done':'')+(sel.has(c)&&selMode==='book'?' sel':'')+(popSet.has(c)?' pop':'');
    h+='<button type="button" class="'+cls+'" data-id="'+c+'" style="--d:'+Math.min(c,40)+'" aria-label="Chapter '+c+(done[curBook].has(c)?', read':'')+'">'+c+'<span class="pick">'+CHECK+'</span></button>';
  }
  $('cGrid').innerHTML=h;popSet.clear();
}

/* ================= selection ================= */
var selMode=null,sel=new Set(),popSet=new Set();
function clearSel(){sel.clear();selMode=null;updateBar()}
function updateBar(){
  var bar=$('bar');
  if(!sel.size){bar.hidden=true;document.querySelectorAll('.sel').forEach(function(e){e.classList.remove('sel')});return}
  bar.hidden=false;$('cnt').textContent=sel.size;
  $('cntLbl').textContent=selMode==='lib'?(sel.size===1?'book':'books'):(sel.size===1?'chapter':'chapters');
  var all=Array.from(sel).every(function(id){return selMode==='lib'?isDone(id):done[curBook].has(id)});
  var btn=$('doneBtn');btn.textContent=all?'Mark unread':'Done';
  btn.classList.toggle('undo',all);btn.dataset.undo=all?'1':'';
}
function paintSel(){
  document.querySelectorAll('#vLib [data-id], #vBook [data-id]').forEach(function(e){
    e.classList.toggle('sel',sel.has(+e.dataset.id)&&(e.classList.contains('book')?selMode==='lib':selMode==='book'));
  });
  updateBar();
}
function startSel(mode,id){selMode=mode;sel.clear();sel.add(id);paintSel()}
function toggle(id){if(sel.has(id))sel.delete(id);else sel.add(id);if(!sel.size)selMode=null;paintSel()}
$('cancelBtn').onclick=clearSel;
$('allBtn').onclick=function(){
  if(selMode==='lib')BOOKS.forEach(function(b,i){sel.add(i)});
  else for(var c=1;c<=BOOKS[curBook].c;c++)sel.add(c);
  paintSel();
};
$('doneBtn').onclick=function(){
  var undo=!!$('doneBtn').dataset.undo,n=sel.size,mode=selMode;
  if(mode==='lib'){
    sel.forEach(function(i){
      if(undo)done[i].clear();else{for(var c=1;c<=BOOKS[i].c;c++)done[i].add(c);popSet.add(i)}
      stamp[i]=Date.now();
    });
  }else{
    sel.forEach(function(c){if(undo)done[curBook].delete(c);else{done[curBook].add(c);popSet.add(c)}});
    stamp[curBook]=Date.now();
  }
  saveProgress();schedulePush();
  sel.clear();selMode=null;updateBar();
  if(mode==='lib')renderLib();else renderBook();
  toast(undo?'Marked unread':(n+(mode==='lib'?(n===1?' book':' books'):(n===1?' chapter':' chapters'))+' marked as read'));
  if(!undo&&totals().ch===TOTAL_CH)openFinish();
};
/* ---- whole Bible completed ---- */
function openFinish(){
  $('finNum').textContent=rounds+1;$('finNum2').textContent=rounds+1;
  $('finTimes').textContent=(rounds+1===1?'time':'times');
  $('doneModal').hidden=false;
}
function closeFinish(){$('doneModal').hidden=true}
function startNewRound(){
  var now=Date.now();
  rounds++;roundsT=now;
  done.forEach(function(s,i){s.clear();stamp[i]=now});
  saveProgress();schedulePush();closeFinish();clearSel();
  refreshViews();toast('Round '+(rounds+1)+' started');
}
$('newRoundBtn').onclick=startNewRound;
$('finLater').onclick=closeFinish;
$('finishBtn').onclick=openFinish;
function bindPress(grid,mode,onTap){
  var timer=null,fired=false,sx=0,sy=0,tgt=null;
  function clear(){clearTimeout(timer);timer=null;if(tgt){tgt.classList.remove('pressing');tgt=null}}
  grid.addEventListener('pointerdown',function(e){
    var t=e.target.closest('[data-id]');if(!t||e.button>0)return;
    fired=false;sx=e.clientX;sy=e.clientY;tgt=t;t.classList.add('pressing');
    var id=+t.dataset.id;
    timer=setTimeout(function(){
      fired=true;clear();
      if(navigator.vibrate)try{navigator.vibrate(14)}catch(_){}
      if(selMode===mode)toggle(id);else startSel(mode,id);
    },440);
  });
  grid.addEventListener('pointermove',function(e){if(timer&&(Math.abs(e.clientX-sx)>10||Math.abs(e.clientY-sy)>10))clear()});
  ['pointerup','pointercancel','pointerleave'].forEach(function(ev){grid.addEventListener(ev,clear)});
  grid.addEventListener('contextmenu',function(e){e.preventDefault()});
  grid.addEventListener('click',function(e){
    var t=e.target.closest('[data-id]');if(!t)return;
    if(fired){fired=false;e.preventDefault();return}
    var id=+t.dataset.id;
    if(selMode===mode)toggle(id);else onTap(id);
  });
}
bindPress($('otGrid'),'lib',function(i){go('book',i)});
bindPress($('ntGrid'),'lib',function(i){go('book',i)});
bindPress($('cGrid'),'book',function(c){L.openReader(curBook,c)});

/* ================= settings page ================= */
var draft=null,sTab='fonts',sSec='verse';
function openSettings(){
  draft=clone(settings);sTab='fonts';sSec='verse';
  renderAccount();renderAppearance();
  $('bkText').value='';
}
function dirty(){return JSON.stringify(draft.fonts)!==JSON.stringify(settings.fonts)||JSON.stringify(draft.colors)!==JSON.stringify(settings.colors)}
function renderAppearance(){
  document.querySelectorAll('#modeSeg button').forEach(function(b){b.setAttribute('aria-pressed',String(b.dataset.mode===settings.mode))});
  document.querySelectorAll('#tabSeg button').forEach(function(b){b.setAttribute('aria-pressed',String(b.dataset.tab===sTab))});
  var secs=sTab==='fonts'?FONT_SECS:COLOR_SECS;
  $('secChips').innerHTML=secs.map(function(s){return'<button type="button" class="chip" data-sec="'+s[0]+'" aria-pressed="'+(s[0]===sSec)+'">'+s[1]+'</button>'}).join('');
  var h='';
  if(sTab==='fonts'){
    var cur=sSec==='all'?null:draft.fonts[sSec];
    var allSame=sSec==='all'&&['verse','title','ui','num','read'].every(function(k){return draft.fonts[k]===draft.fonts.verse})?draft.fonts.verse:null;
    h='<div class="opts">'+FONTS.map(function(f){
      var on=sSec==='all'?allSame===f.id:cur===f.id;
      return'<button type="button" class="opt" data-font="'+f.id+'" aria-pressed="'+on+'" style="font-family:'+f.css.replace(/"/g,"'")+'"><b>Aa Verse 12</b><span style="font-family:var(--f-ui)">'+f.name+'</span></button>';
    }).join('')+'</div>';
  }else{
    var cv=draft.colors[sSec];
    h='<div class="swatches"><button type="button" class="sw def" data-color="" aria-pressed="'+(cv===null)+'" aria-label="Default colour">Auto</button>'
      +SWATCHES.map(function(c){return'<button type="button" class="sw" data-color="'+c+'" style="background:'+c+'" aria-pressed="'+(cv&&cv.toLowerCase()===c.toLowerCase())+'" aria-label="'+c+'"></button>'}).join('')
      +'</div><label class="custom" style="margin-top:12px">Custom<input type="color" id="customColor" value="'+(cv||'#1f8a5b')+'"></label>';
  }
  $('optBox').innerHTML=h;
  updatePreview();
}
function updatePreview(){
  var pv=$('pv');applyVars(pv,draft);
  pv.querySelectorAll('[data-hl]').forEach(function(e){e.classList.toggle('hl',e.dataset.hl.split(' ').indexOf(sSec)>-1)});
  pv.classList.toggle('hl',sSec==='bg');
  $('applyBtn').disabled=!dirty();
}
$('modeSeg').addEventListener('click',function(e){
  var b=e.target.closest('[data-mode]');if(!b)return;
  settings.mode=b.dataset.mode;draft.mode=settings.mode;applyTheme(settings);saveSettings();schedulePush();renderAppearance();
});
$('tabSeg').addEventListener('click',function(e){
  var b=e.target.closest('[data-tab]');if(!b)return;
  sTab=b.dataset.tab;sSec=sTab==='fonts'?'verse':'bg';renderAppearance();
});
$('secChips').addEventListener('click',function(e){
  var b=e.target.closest('[data-sec]');if(!b)return;
  sSec=b.dataset.sec;renderAppearance();
});
$('optBox').addEventListener('click',function(e){
  var f=e.target.closest('[data-font]');
  if(f){
    if(sSec==='all')['verse','title','ui','num','read'].forEach(function(k){draft.fonts[k]=f.dataset.font});
    else draft.fonts[sSec]=f.dataset.font;
    renderAppearance();return;
  }
  var c=e.target.closest('[data-color]');
  if(c){draft.colors[sSec]=c.dataset.color||null;renderAppearance()}
});
$('optBox').addEventListener('input',function(e){
  if(e.target.id==='customColor'){
    draft.colors[sSec]=e.target.value;updatePreview();
    document.querySelectorAll('#optBox .sw').forEach(function(s){s.setAttribute('aria-pressed','false')});
  }
});
$('applyBtn').onclick=function(){
  settings.fonts=clone(draft.fonts);settings.colors=clone(draft.colors);
  applyTheme(settings);saveSettings();schedulePush();updatePreview();toast('Saved');
};
$('resetBtn').onclick=function(){
  draft.fonts=clone(DEF_FONTS);draft.colors=clone(DEF_COLORS);renderAppearance();
  toast('Defaults loaded. Tap Apply to keep them.');
};

/* ---- backup ---- */
function backupText(){return JSON.stringify({app:'lectio',v:2,p:progressObj(),settings:{d:settings,t:settingsT},r:{n:rounds,t:roundsT}})}
$('bkCopy').onclick=function(){
  var txt=backupText(),ta=$('bkText');ta.value=txt;ta.focus();ta.select();
  var done_=function(){toast('Backup copied')};
  if(navigator.clipboard&&navigator.clipboard.writeText){
    navigator.clipboard.writeText(txt).then(done_,function(){toast('Select the text and copy it')});
  }else{try{document.execCommand('copy');done_()}catch(e){toast('Select the text and copy it')}}
};
var restoreArmed=false;
$('bkRestore').onclick=function(){
  var raw=$('bkText').value.trim();
  if(!raw){toast('Paste a backup first');return}
  var o;try{o=JSON.parse(raw)}catch(e){toast('That is not a Lectio backup');return}
  if(!o||o.app!=='lectio'||!o.p){toast('That is not a Lectio backup');return}
  if(!restoreArmed){
    restoreArmed=true;$('bkRestore').textContent='Tap again to replace';
    setTimeout(function(){restoreArmed=false;$('bkRestore').textContent='Restore'},4000);return;
  }
  restoreArmed=false;$('bkRestore').textContent='Restore';
  var now=Date.now(),p={};
  Object.keys(o.p).forEach(function(k){p[k]={c:o.p[k].c,t:now}});
  setProgress(p);if(o.r){rounds=+o.r.n||0;roundsT=now}saveProgress();
  if(o.settings&&o.settings.d){setSettings(o.settings.d);saveSettings();applyTheme(settings);draft=clone(settings);renderAppearance()}
  schedulePush();toast('Backup restored');
};

/* ================= wiring ================= */
$('tabHome').onclick=function(){stack.length=0;show('home')};
$('tabLib').onclick=function(){if(view!=='lib')go('lib')};
$('tabSet').onclick=function(){if(view!=='settings')go('settings')};
$('goLib').onclick=function(){go('lib')};
$('readNow').onclick=function(){L.openReader()};
$('backBtn').onclick=onBack;
$('signinHome').onclick=function(){if(fb.on)openAuth('signin');else go('settings')};

loadProgress();loadSettings();applyTheme(settings);
L.start=function(){renderAccount();show('home');tick();setInterval(tick,1000)};
})();
