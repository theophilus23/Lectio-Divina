/* Melody extraction: turns a recording into a small note contour (no audio, no voice) using the YIN pitch method.
   LSongs.melody(blob) -> Promise<{rle:[midi,len,midi,len,...], fps, dur, key, notes}>  (midi 0 = silence; 10 values per second) */
(function(){
'use strict';
var S=window.LSongs,SR=16000,FR=1024,HOP=320;
function decode(blob){
  return blob.arrayBuffer().then(function(buf){
    var AC=window.AudioContext||window.webkitAudioContext,ac=new AC();
    return ac.decodeAudioData(buf).then(function(ab){try{ac.close()}catch(e){}return ab});
  });
}
function resample(ab){
  var len=Math.ceil(ab.duration*SR),oc=new OfflineAudioContext(1,len,SR),src=oc.createBufferSource();
  src.buffer=ab;src.connect(oc.destination);src.start();
  return oc.startRendering().then(function(r){return r.getChannelData(0)});
}
/* YIN: returns frequency in Hz or 0 */
function yin(x,off){
  var half=FR>>1,tmin=Math.floor(SR/1000),tmax=Math.min(half-1,Math.floor(SR/80)),d=new Float32Array(tmax+1),t,i,s=0,e=0;
  for(i=0;i<FR;i++)e+=x[off+i]*x[off+i];
  if(e/FR<1e-6)return 0;                         /* silence */
  for(t=1;t<=tmax;t++){var sum=0;for(i=0;i<half;i++){var df=x[off+i]-x[off+i+t];sum+=df*df}d[t]=sum}
  var run=0;d[0]=1;
  for(t=1;t<=tmax;t++){run+=d[t];d[t]=run?d[t]*t/run:1}
  for(t=tmin;t<=tmax;t++){
    if(d[t]<0.15){
      while(t+1<=tmax&&d[t+1]<d[t])t++;
      var a=d[t-1],b=d[t],c=d[t+1]===undefined?d[t]:d[t+1],den=a+c-2*b,sh=den?(a-c)/(2*den):0;
      return SR/(t+sh);
    }
  }
  return 0;
}
function median(a){var b=a.slice().sort(function(x,y){return x-y});return b[b.length>>1]}
S.melody=function(blob){
  return decode(blob).then(resample).then(function(x){
    var fr=[],n=Math.floor((x.length-FR)/HOP),i;
    for(i=0;i<n;i++){var f=yin(x,i*HOP);fr.push(f>0?Math.round(69+12*Math.log2(f/440)):0)}
    /* 50 fps -> 10 fps: median of the voiced values in each group of 5 */
    var out=[],g;
    for(i=0;i<fr.length;i+=5){
      var v=[];for(g=0;g<5&&i+g<fr.length;g++)if(fr[i+g]>0)v.push(fr[i+g]);
      out.push(v.length>=3?median(v):0);
    }
    /* fix one-frame octave jumps */
    for(i=1;i<out.length-1;i++)if(out[i]&&Math.abs(out[i]-out[i-1])>=11&&Math.abs(out[i]-out[i+1])>=11)out[i]=out[i-1];
    var rle=[],cur=out[0],len=0,hist=new Array(12).fill(0),notes=0;
    out.forEach(function(m,k){
      if(m)hist[m%12]++;
      if(m===cur)len++;else{rle.push(cur,len);if(cur)notes++;cur=m;len=1}
    });
    if(out.length){rle.push(cur,len);if(cur)notes++}
    var best=0;for(i=1;i<12;i++)if(hist[i]>hist[best])best=i;
    var names=['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];
    return{rle:rle,fps:10,dur:Math.round(x.length/SR*10)/10,key:names[best],notes:notes,voiced:out.filter(Boolean).length};
  });
};
})();
